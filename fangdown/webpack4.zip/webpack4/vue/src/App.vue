<template>
  <router-view></router-view>
</template>

<style lang="less">
@import url("./assets/style/base.less");
</style>
