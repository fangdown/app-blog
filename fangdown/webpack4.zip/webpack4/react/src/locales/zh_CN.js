/* eslint-disable camelcase */
const zh_CN = {
  'recruit.ok': '确定',
  'recruit.cancel': '取消',
  'recruit.close': '关闭',
  'recruit.alert': 'alert,参数1:{param1}, 参数2:{param2}',
  'recruit.param': '这是界面传入的参数:{param1},{param2}',
};
export default zh_CN;
/* eslint-enable camelcase */
