/* eslint-disable camelcase */
const en_US = {
  'recruit.ok': 'ok',
  'recruit.cancel': 'cancel',
  'recruit.close': 'close',
  'recruit.alert': 'alert,param1:{param1}, param2:{param2}',
  'recruit.param': 'the input param:{param1},{param2}',
};
export default en_US;
/* eslint-enable camelcase */
