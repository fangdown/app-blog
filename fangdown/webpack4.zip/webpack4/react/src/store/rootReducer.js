import TestRedux from '@modules/demo/testRedux/reducer';
// import Recruit from '@modules/recruit/Recruit.reducer';
import { global } from './global';

const rootReducer = {
  global,
  TestRedux,
  // Recruit,
};
export default rootReducer;
