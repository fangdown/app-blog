const express = require('express')
const proxy = require('http-proxy-middleware')
const pexyConfig = require('./config')
const app = express()
const chalk = require('chalk')

// 导入代理设置
for (var key in pexyConfig.dev.proxyTable) {
  app.use(key, proxy(pexyConfig.dev.proxyTable[key]))
}

app.use('/', express.static('dist'))

app.get('*', function (req, res) {
  res.redirect('/')
})

app.listen(4005, function () {
  console.log(chalk.cyan('ERP server start at ==>  http://localhost:4005/'))
})
