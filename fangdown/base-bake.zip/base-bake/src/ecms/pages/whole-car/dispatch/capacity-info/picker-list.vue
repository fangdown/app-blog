<template>
  <div>
    <kye-form ref="form"
              :inline="true"
              label-position="left"
              :model.sync="form">
      <kye-form-item label="所属点部"
                     prop="department">
        <kye-input v-model="form.department"
                   clearable
                   placeholder="请输入"></kye-input>
      </kye-form-item>
      <kye-form-item label-width="0px">
        <kye-button type="primary"
                    icon="el-icon-search"
                    @click="getQhyList">查询</kye-button>
      </kye-form-item>
    </kye-form>
    <div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="data"
                  :options="tableOption"
                  :operation="operation"
                  ref="canvas"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      :current-page="page.currentPage"
                      :page-size.sync="page.pageSize"
                      @current-change="currentChange"
                      @size-change="sizeChange">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  import { vehicleScheduingMixin } from '../vehicle-scheduling' // 状态信息
  export default {
    mixins: [vehicleScheduingMixin],
    props: {
      formData: Object
    },
    computed: {
      // 计算属性的 getter
      form: function () {
        // `this` 指向 vm 实例
        return {
          department: Object.assign({}, this.formData).startDepartmentName
        }
      },
    },
    watch: {
      // formData: {
      //   handler: function (val, oldval) {
      //     if (val && (val.taskCode !== oldval.taskCode)) {
      //       if (val.getGoodsPatcherName || val.getGoodsPatcher) {
      //         this.operation.options[0].label = '确认调度'
      //         this.operation.options[0].auth = 'zc.dispatch.assignTakePerson.do'
      //         this.operation.options[0].func = this.executeSchedule
      //       } else {
      //         this.operation.options[0].label = '重新调度'
      //         this.operation.options[0].auth = 'zc.dispatch.reschedule.do'
      //         this.operation.options[0].func = this.reExecuteSchedule
      //       }
      //     }
      //   },
      //   deep: true
      // }
    },
    data () {
      return {
        loading: false,
        data: [],
        column: [
          // {
          //   key: 'id',
          //   label: '序号',
          //   show: true,
          //   width: '120px',
          //   colorchange: true
          // },
          {
            key: 'networkName',
            label: '所属点部',
            show: true,
            width: '100px'
          },
          {
            key: 'name',
            label: '姓名',
            show: true,
            width: '80px'
          },
          {
            key: 'companyMobile',
            label: '公司电话',
            show: true,
            width: '120px'
          },
          {
            key: 'privateMobile',
            label: '私人电话',
            show: true,
            width: '120px'
          },
          // {
          //   key: 'positiveDate',
          //   label: '上班时间',
          //   show: true,
          //   width: '120px',
          //   formatter: (row, column, val) => {
          //     return formatTime(val, 'T')
          //   }
          // },
          // {
          //   key: 'inductionDate',
          //   label: '下班时间',
          //   show: true,
          //   width: '120px',
          //   formatter: (row, column, val) => {
          //     return formatTime(val, 'T')
          //   }
          // }
        ],
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        pageSizes: [10, 20, 50, 100],
        operation: {
          label: '操作',
          width: '70px',
          options: [
            {
              type: 'link',
              label: '确认调度',
              auth: 'zc.dispatch.assignTakePerson.do',
              func: this.executeSchedule
            }
          ]
        },
        tableOption: {
          stripe: true,
          moduleCode: 'hr_employee'
        },
      }
    },
    created () {
      // if (this.$route.params.id) {
      //   this.getQhyList()
      // }
      // this.isReschedule()
    },
    mounted () {
      this.$nextTick(() => {
        // if (this.$route.params.id) {
        // this.getQhyList()
        // }
      })
    },
    methods: {
      async getQhyList (params = {}) {
        this.loading = true
        let vo = {
          departmentFuzzy: this.form.department
        }
        try {
          let res = await this.$http('hr.remoteEmployee.search', { vo: vo, page: this.page.currentPage, pageSize: this.page.pageSize })
          this.loading = false
          this.data = res.rows
          this.page = {
            pageSize: res.pageSize,
            currentPage: res.page,
            total: res.rowTotal
          }
        } catch (err) {
          this.loading = false
        }
      },
      // 指定取货跟车人
      async setQuy (params = {}) {
        let res = await this.$http('zc.dispatch.assignTakePerson.do', params)
        return res
      },
      // 调度员创建整车调度
      async createCargoMsg (params = {}) {
        let res = await this.$http('zc.erp.createCargoPdaMsg.do', params)
        return res
      },
      currentChange (currentPage) {
        this.page.currentPage = currentPage
        this.getQhyList()
      },
      sizeChange (pageSize) {
        this.page.pageSize = pageSize
        this.page.currentPage = 1
        this.getQhyList()
      },
      executeSchedule (row) {
        this.$confirm('确认调度？', '提示').then(async () => {
          // this.createCargoMsg({
          //   taskCode: this.formData.taskCode,
          //   getGoodPatcher: row.employeeNumber,
          // })
          const res = await this.setQuy({
            taskId: this.$route.params.id,
            patcher: row.name,
            phone: row.companyMobile || row.privateMobile,
            getGoodPatcher: row.employeeNumber
          })
          this.$message.success('调度成功')
          if (res === 'OK') {
            this.$emit('upDateData')
            this.$refreshMainQueryTable()
          } else {
            this.$message.error(res)
          }
        }).catch(e => {

        })
      },
      reExecuteSchedule (row) {
        this.$confirm('是否重新调度？', '提示').then(async () => {
          this.createCargoMsg({
            taskCode: this.formData.taskCode,
            getGoodPatcher: row.employeeNumber,
          })
          let params = {
            taskId: this.$route.params.id,
            patcher: row.employeeNumber,
            phone: row.companyMobile || row.privateMobile
          }
          let res = await this.$http('zc.dispatch.assignTakePerson.do', params)
          this.$message.success('调度成功')
          if (res === 'OK') {
            this.$emit('upDateData')
            this.$refreshMainQueryTable()
          } else {
            this.$message.error(res)
          }
        }).catch(e => {
        })
      },
      isReschedule () {
        if (this.formData.getGoodsPatcherName || this.formData.getGoodsPatcher) {
          this.operation.options[0].label = '确认调度'
          this.operation.options[0].auth = 'zc.dispatch.assignTakePerson.do'
          this.operation.options[0].func = this.executeSchedule
        } else {
          this.operation.options[0].label = '重新调度'
          this.operation.options[0].auth = 'zc.dispatch.reschedule.do'
          this.operation.options[0].func = this.reExecuteSchedule
        }
      }
    }
  }
</script>
<style lang='scss' scoped>
  .paging-wrap {
    padding-top: 20px;
    padding-bottom: 20px;
  }
  .ky-erp .el-form--inline .el-form-item {
    margin-top: 4px;
    margin-bottom: 4px;
  }
</style>


