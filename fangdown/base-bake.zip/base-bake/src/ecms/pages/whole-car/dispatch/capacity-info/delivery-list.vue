<template>
  <div>
    <kye-form ref="form"
              :inline="true"
              label-position="left"
              :model="form">
      <kye-form-item label="所属点部"
                     prop="department">
        <kye-input v-model="form.department"
                   clearable
                   placeholder="请输入"></kye-input>
      </kye-form-item>
      <kye-form-item label-width="0px">
        <!-- <kye-button type="primary"
                    @click="handleSearch">
          <i class="iconfont icon-search"></i>查询
        </kye-button> -->
        <kye-button type="primary"
                    icon="el-icon-search"
                    @click="handleSearch">查询</kye-button>
      </kye-form-item>

    </kye-form>
    <div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="data"
                  :options="tableOption"
                  :operation="operation"
                  ref="canvas"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      :current-page="page.currentPage"
                      :page-size.sync="page.pageSize"
                      @current-change="currentChange"
                      @size-change="sizeChange">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  export default {
    props: {
      formData: Object
    },
    computed: {
      // 计算属性的 getter
      form: function () {
        // `this` 指向 vm 实例
        return {
          department: Object.assign({}, this.formData).endDepartmentName
        }
      },
    },
    data () {
      return {
        loading: false,
        data: [],
        column: [
          // {
          //   key: 'id',
          //   label: '序号',
          //   show: true,
          //   width: '120px',
          //   colorchange: true
          // },
          {
            key: 'networkName',
            label: '所属点部',
            show: true,
            width: '100px'
          },
          {
            key: 'name',
            label: '姓名',
            show: true,
            width: '80px'
          },
          {
            key: 'companyMobile',
            label: '公司电话',
            show: true,
            width: '120px'
          },
          {
            key: 'privateMobile',
            label: '私人电话',
            show: true,
            width: '120px'
          },

          // {
          //   key: 'packageNum',
          //   label: '上班时间',
          //   show: true,
          //   width: '120px'
          // },
          // {
          //   key: 'packageNum',
          //   label: '下班时间',
          //   show: true,
          //   width: '120px'
          // }
        ],
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        pageSizes: [10, 20, 50, 100],
        tableOption: {
          stripe: true,
          moduleCode: 'hr_employee'
        },
        operation: {
          label: '操作',
          width: '70px',
          options: [
            {
              type: 'link',
              label: '确认调度',
              auth: 'zc.dispatch.assignDeliveryPerson.do',
              func: (row) => {
                this.$confirm('确认调度？', '提示').then(async () => {
                  if (row.privateMobile === '*****' || row.companyMobile === '*****') {
                    this.$message.info('请先解密电话监控字段')
                    return
                  }
                  let res = await this.setDelivery({
                    taskId: this.$route.params.id,
                    patcher: row.employeeNumber,
                    phone: row.companyMobile || row.privateMobile
                  })
                  this.$message.success('调度成功')
                  if (res === 'OK') {
                    this.$emit('upDateData')
                    this.$refreshMainQueryTable()
                  }
                }).catch(e => {
                })
              }
            }
          ]
        },
      }
    },
    created () {
      if (this.$route.params.id) {
        // this.getPhyList()
      }
    },
    mounted () {

    },
    methods: {
      // 获取派货员
      async getPhyList (params) {
        try {
          this.loading = true
          let vo = {
            departmentFuzzy: this.form.department
          }
          let res = await this.$http('hr.remoteEmployee.search', { vo: vo, page: this.page.currentPage, pageSize: this.page.pageSize })
          this.loading = false
          this.data = res.rows
          this.page = {
            pageSize: res.pageSize,
            currentPage: res.page,
            total: res.rowTotal
          }
        } catch (error) {
          this.loading = false
        }
      },
      // 指定派货员
      async setDelivery (params = {}) {
        let res = await this.$http('zc.dispatch.assignDeliveryPerson.do', params)
        return res
      },
      // 调度员创建整车调度
      async createCargoMsg (params = {}) {
        let res = await this.$http('zc.erp.createCargoPdaMsg.do', params)
        return res
      },
      currentChange (currentPage) {
        this.page.currentPage = currentPage
        this.getPhyList()
      },
      sizeChange (pageSize) {
        this.form.size = pageSize
        this.page.currentPage = 1
        this.getPhyList()
      },
      handleSearch () {
        this.getPhyList(this.form)
      }
    }
  }
</script>
<style lang='scss' scoped>
  .paging-wrap {
    padding-top: 20px;
    padding-bottom: 20px;
  }
  .ky-erp .el-form--inline .el-form-item {
    margin-top: 4px;
    margin-bottom: 4px;
  }
</style>


