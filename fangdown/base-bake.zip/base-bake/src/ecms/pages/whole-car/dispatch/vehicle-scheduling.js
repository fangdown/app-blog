/**
 * 整车调度混合
 **/

export const vehicleScheduingMixin = {
  data() {
    return {
      isCheck: ['是', '否'],
      vehicleDetails: {}, // 整车调度详情（单条记录）
      // dispatchInfo: {}, // 选择调度的信息
      dispatchTypes: {}, // 保存调度的信息状态
      dispatchStatus: {
        'status_1': '待取货',
        'status_3': '调度异常',
        'status_6': '待取货',
        'status_7': '出车扫描',
        'status_8': '取件签到',
        'status_9': '已取货(运单报单)',
        'status_10': '派件签到',
        'status_11': '签收报单(己完成)',
        'status_901': '已签收(未签回单)',
        'status_910': '封箱拍照',
        'status_920': '出车派送',
        'status_930': '解封拍照',
        'status_1000': '待取货',
        'status_1001': '已调度已取消'
      },
      taskStates: {
        'status_1': '待调度',
        'status_2': '已经调度',
        'status_3': '已取消-待调度',
        'status_4': '已取消-已调度',
      }
    }
  },
  beforeDestroy() {
    this.$bus.$off('vehicle-dispatch-info')
  },
  mounted() {},
  methods: {
    getDispatchInfo(data, type) {
      this.$bus.$emit('vehicle-dispatch-info', {
        data,
        type
      })
    }
  }
}
