<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="formTools"></search-pager>
    <kye-expand-page>
      <kye-form ref="formArea"
                :model.sync="formData"
                label-position="left"
                :biz-id="$route.params.id"
                module-code="ecs_zc">
        <h3 class="kye-block-title">基本信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="任务编码"
                           prop="taskCode">
              <kye-field v-model="formData.taskCode"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="运单号"
                           prop="waybillCode">
              <kye-field disabled
                         v-model="formData.waybillCode"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4"
                   class="tow-input-wrap">
            <kye-form-item label="公司简称"
                           prop="companyName">
              <kye-field disabled
                         v-model="formData.companyName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="新客户"
                           prop="newCustomer">
              <kye-field>{{formData.newCustomer|lookup('ecs_zc_newcustomer')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="下单时间"
                           prop="confirmTime">
              <kye-field>{{formData.confirmTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="托寄物"
                           prop="goodsName">
              <kye-field disabled
                         v-model="formData.goodsName"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="始发地"
                           prop="startAddress">
              <kye-field disabled
                         v-model="formData.startAddressStr"></kye-field>
              <!-- <kye-field>{{ showPickupCustomerName ? ruleForm.esWaybill.waybillPickup.customerName : '*****' }}</kye-field> -->
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4"
                 class="tow-input-wrap">
          <kye-form-item label="始发地区号">
            <kye-col :span="12">
              <kye-field>{{ruleForm.damagedLoseOtherInfo.waybillPickupArea | lookup('common_region')}}</kye-field>
            </kye-col>
            <kye-col :span="12">
              <kye-field>{{ruleForm.damagedLoseOtherInfo.waybillDeliveryArea | lookup('common_region')}}</kye-field>
            </kye-col>
          </kye-form-item>
        </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="始发地区号"
                           prop="startAreaCode">
              <kye-field disabled
                         v-model="formData.startAreaCode"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="目的地"
                           prop="endAddress">
              <kye-field disabled
                         v-model="formData.endAddressStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="目的地区号"
                           prop="endAreaCode">
              <kye-field disabled
                         v-model="formData.endAreaCode"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="销售经理"
                           prop="saleser">
              <kye-field disabled
                         v-model="formData.saleser"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4"
                   class="tow-input-wrap">
            <kye-form-item label="经理电话"
                           prop="saleserPhone">
              <kye-field disabled
                         v-model="formData.saleserPhone"></kye-field>
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4">
          <kye-form-item label="销售助理">
            <kye-field disabled
                       v-model="formData.saleser"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="助理电话">
            <kye-field disabled
                       v-model="formData.saleserPhone"></kye-field>
          </kye-form-item>
        </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="调度状态"
                           prop="schedulingState">
              <kye-field disabled
                         v-model="taskStates[`status_${formData.taskState}`]"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="调度时间"
                           prop="schedulingTime">
              <kye-field>{{formData.schedulingTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="调度编码"
                           prop="dispatchCode">
              <kye-field disabled
                         v-model="formData.dispatchCode"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="任务状态"
                           prop="taskState">
              <kye-field disabled
                         v-model="dispatchStatus[`status_${formData.schedulingState}`]"></kye-field>
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4">
          <kye-form-item label="报单时间">
            <kye-field disabled
                       v-model="formData.schedulingTimeStr"></kye-field>
          </kye-form-item>
        </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="签收时间"
                           prop="signingTime">
              <kye-field>{{formData.signingTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="备注"
                           prop="remark">
              <kye-field disabled
                         v-model="formData.remark"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="操作说明"
                           prop="operationDescription">
              <kye-field disabled
                         v-model="formData.operationDescription"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">参考信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="成交价格"
                           prop="transactionPrice">
              <kye-field>{{formData.transactionPrice|money}}
              </kye-field>

            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="跨越价格"
                           prop="kyePrice">
              <kye-field>{{formData.kyePrice|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="所需车型"
                           prop="carNeed">
              <kye-field disabled
                         v-model="formData.carNeed"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="货好时间"
                           prop="loadingTime">
              <kye-field>{{formData.loadingTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="需要尾板"
                           prop="isTailboard">
              <kye-field>{{formData.isTailboard|lookup('ecs_zc_istailboard')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="装货服务"
                           prop="loadService">
              <kye-field>{{formData.loadService|lookup('ecs_zc_loadservice')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="卸货服务"
                           prop="unloadService">
              <kye-field>{{formData.unloadService|lookup('ecs_zc_unloadservice')}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="回单服务"
                           prop="isReceipt">
              <kye-field>{{formData.isReceipt|lookup('ecs_zc_isreceipt')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">调度信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="运力类型"
                           prop="capacityType">
              <kye-field v-model="formData.capacityType"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="司机姓名"
                           prop="driverName">
              <kye-field v-model="formData.driverName"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="联系方式"
                           prop="driverPhone">
              <kye-field v-model="formData.driverPhoneStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="车牌号"
                           prop="carPlateNum">
              <kye-field v-model="formData.carPlateNumStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="车型"
                           prop="carTypeName">
              <kye-field v-model="formData.carTypeNameStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="价格"
                           prop="actualTransportFee">
              <kye-field>{{formData.actualTransportFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="取货点部"
                           prop="startDepartmentName">
              <kye-field v-model="formData.startDepartmentName"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="取货员"
                           prop="getGoodsPatcher">
              <kye-field v-model="formData.getGoodsPatcherStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="联系方式"
                           prop="getGoodsPhone">
              <kye-field v-model="formData.getGoodsPhoneStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="派货点部"
                           prop="endDepartmentName">
              <kye-field v-model="formData.endDepartmentName"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="派货员"
                           prop="sendGoodsPatcher">
              <kye-field v-model="formData.sendGoodsPatcherStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="联系方式"
                           prop="sendGoodsPhone">
              <kye-field v-model="formData.sendGoodsPhoneStr"
                         disabled></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">运力信息</h3>
        <!-- <div class="timer">
          <count-down :endTime="1542129064"
                      endText="报价时间已失效" />
        </div> -->
        <div>
          <kye-tabs v-model="activeName"
                    @tab-click="handleClick">
            <kye-tab-pane label="外部运力"
                          name="wbyl"
                          :disabled="wbylDisabled"
                          v-if="wbylFlag">
              <external-vehicle ref='wbyl'
                                @upDateData="initData()"
                                v-if="wbylTabFlag"
                                :formData="formData"> </external-vehicle>
            </kye-tab-pane>
            <!-- <kye-tab-pane label="未报价临时线路"
                       name="wbjlsxl">
            <wbjlsxl-Info v-if="activeName==='wbjlsxl'"> </wbjlsxl-Info>
          </kye-tab-pane> -->
            <kye-tab-pane label="跨越运力"
                          name="kyyl"
                          v-if="kyylFlag"
                          :disabled="kyylDisabled">
              <kye-vehicle ref='kyyl'
                           :carLength="formData.carLength"
                           :formData="formData"
                           @upDateData="initData()"
                           v-if="kyylTabFlag"> </kye-vehicle>
            </kye-tab-pane>
            <!-- <kye-tab-pane label="手动录入"
                       name="sdlr">
            <sdlr-Info ref='sdlrInfo'
                       v-if="activeName==='sdlr'"> </sdlr-Info>
          </kye-tab-pane> -->
            <kye-tab-pane label="取货员"
                          name="qhy"
                          v-if="qhyFlag"
                          :disabled="qhyDisabled">
              <picker-list ref='qhy'
                           @upDateData="initData()"
                           :formData="formData"
                           v-if="qhyTabFlag"> </picker-list>
            </kye-tab-pane>
            <kye-tab-pane label="派货员"
                          name="phy"
                          v-if="phyFlag"
                          :disabled="phyDisabled">
              <delivery-list ref='phy'
                             @upDateData="initData()"
                             :formData="formData"
                             v-if="phyTabFlag"> </delivery-list>
            </kye-tab-pane>
          </kye-tabs>
        </div>
      </kye-form>
    </kye-expand-page>
    <kye-dialog v-bind="dialogOption"
                :before-close="closeDialog"
                :visible.sync="dialogOption.show"
                append-to-body>
      <component :is="dialogOption.view"
                 :dialog-data="dialogData">
      </component>
    </kye-dialog>
  </div>
</template>
<script>
  import mixins from 'public/mixins'
  // 倒计时
  import countDown from '../components/count-down'
  // 外部运力
  import externalVehicle from './capacity-info/external-vehicle'
  // 跨越运力
  import kyeVehicle from './capacity-info/kye-vehicle'
  // 取货员
  import pickerList from './capacity-info/picker-list'
  // 派货员
  import deliveryList from './capacity-info/delivery-list'

  import { vehicleScheduingMixin } from './vehicle-scheduling'
  export default {
    mixins: [mixins, vehicleScheduingMixin],
    components: {
      countDown,
      externalVehicle,
      kyeVehicle,
      pickerList,
      deliveryList
    },
    computed: {
      formTools: function () {
        let tool = []
        if (Number(this.formData.schedulingState) === 11 || Number(this.formData.schedulingState) === 901) {
        } else {
          if (this.formData.taskState === '1') {
            tool.push(this.searchTools[0])
          } else if (this.formData.taskState === '2') {
            tool.push(this.searchTools[1])
            if (this.formData.platformType !== '1') {
              tool.push(this.searchTools[2])
            }
          }
        }
        return tool
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.wbylFlag = false
          vm.kyylFlag = false
          vm.qhyFlag = false
          vm.phyFlag = false
          // vm.wbylDisabled = true
          // vm.kyylDisabled = true
          // vm.qhyDisabled = true
          // vm.phyDisabled = true
          vm.initData()
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.wbylFlag = false
      this.kyylFlag = false
      this.qhyFlag = false
      this.phyFlag = false
      // this.wbylDisabled = true
      // this.kyylDisabled = true
      // this.qhyDisabled = true
      // this.phyDisabled = true
      this.getDetails({ taskId: to.params.id })
      next()
    },
    created () {
      // this.$bus.$on('refreshCarDetail', res => {
      //   this.$nextTick(() => {
      //     this.initData()
      //   })
      // })
      // this.initData()
    },
    beforeDestroy () {
      // this.$bus.$off('refreshCarDetail')
    },
    mounted () {

    },
    data () {
      return {
        taskId: null,
        formData: {},
        wbylFlag: true,
        kyylFlag: true,
        qhyFlag: true,
        phyFlag: true,
        wbylTabFlag: false,
        kyylTabFlag: false,
        qhyTabFlag: false,
        phyTabFlag: false,
        qhyDisabled: false,
        phyDisabled: false,
        kyylDisabled: false,
        wbylDisabled: false,
        platformTypes: {
          'type_1': '跨越',
          'type_2': '云鸟',
          'type_3': '福佑',
          'type_4': '外请司机',
          'type_7': '好多车'
        },
        option: {
          back: '/ecms/whole-car/dispatch/index',
          method: 'zc.dispatch.getDispatchedPageList.do',
          searchCode: 'ecs_zc_disptach_list_search_define',
          idKey: 'taskId',
        },
        searchTools: [
          {
            label: '取消订单',
            icon: 'close',
            auth: 'zc.inquiry.cancelNonDispatchFullcarTask.do',
            // auth: 'zc.cancelFullcarTask.do',
            func: () => this.cancelOrder()
          },
          {
            label: '取消订单',
            icon: 'close',
            // auth: 'zc.cancelFullcarTask.do',
            auth: 'zc.dispatch.cancelFullcarTask.do',
            func: () => this.cancelOrder()
          },
          {
            label: '重新调度',
            icon: 'ecs-caiwufanshen',
            auth: 'zc.dispatch.reschedule.do',
            func: () => this.reschedule()
          },
        ],
        dialogOption: {
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        dialogData: null,
        activeName: '',
      }
    },
    methods: {
      // 进入页面初始化数据
      initData () {
        this.taskId = this.$route.params.id
        this.getDetails({ taskId: this.taskId })
      },
      // 获取调度详情信息
      async getDetails (params = {}) {
        this.formData = {}
        let res = await this.$http('zc.dispatch.getFullCarTaskDetail.do', params)
        this.formData = res
        this.formData.startAddressStr = this.changeAddress(res.startProvince, res.startCity, res.startArea, res.startAddress)
        this.formData.endAddressStr = this.changeAddress(res.endProvince, res.endCity, res.endArea, res.endAddress)
        this.formData['carNeed'] = this.formData.dispatchEntity.carLength + '米' + this.formData.dispatchEntity.carTypeName
        this.formData['driverNameStr'] = this.formData.driverName
        this.formData['driverPhoneStr'] = this.formData.driverPhone
        this.formData['carPlateNumStr'] = this.formData.carPlateNum
        this.formData['carTypeNameStr'] = this.formData.carLength + '米' + this.formData.carTypeName
        this.formData['getGoodsPatcherStr'] = this.formData.getGoodsPatcherName || this.formData.getGoodsPatcher
        this.formData['getGoodsPhoneStr'] = this.formData.getGoodsPhone
        this.formData['sendGoodsPatcherStr'] = this.formData.sendGoodsPatcherName || this.formData.sendGoodsPatcher
        this.formData['sendGoodsPhoneStr'] = this.formData.sendGoodsPhone
        this.wbylFlag = true
        this.changeTabShow()
      },

      // 取消订单
      cancelOrder () {
        if (this.formData) {
          this.$confirm('是否要取消该订单？', '提示', '是否继续?').then(async () => {
            if (this.formData.taskState === '1') {
              // this.searchTools[0].auth = 'zc.inquiry.cancelNonDispatchFullcarTask.do'
              const res = await this.$http('zc.inquiry.cancelNonDispatchFullcarTask.do', { taskId: this.taskId })
              if (res === 'OK') {
                this.$message.success('取消成功')
                this.$refreshMainQueryTable()
                this.$router.push({
                  path: '/ecms/whole-car/dispatch/index'
                })
              }
            } else {
              const res = await this.$http('zc.dispatch.cancelFullcarTask.do', { taskId: this.taskId })
              if (res === 'OK') {
                this.$message.success('取消成功')
                this.$refreshMainQueryTable()
                this.$router.push({
                  path: '/ecms/whole-car/dispatch/index'
                })
              }
            }
          }).catch(() => {
          })
        }
      },
      closeDialog () {
        this.dialogOption = {
          show: false,
          view: null,
          title: '',
          width: '0px'
        }
      },
      handleClick (tab) {
        if (this.activeName === 'wbyl') {
          this.wbylTabFlag = true
        } else if (this.activeName === 'kyyl') {
          this.kyylTabFlag = true
        } else if (this.activeName === 'qhy') {
          this.qhyTabFlag = true
        } else {
          this.phyTabFlag = true
        }
        if (this.activeName === 'kyyl') {
          this.$refs && this.$refs[this.activeName] && this.$refs[this.activeName].$refs.canvastable.setCanvasWidth()
          this.$refs && this.$refs[this.activeName] && this.$refs[this.activeName].$refs.canvastable2.setCanvasWidth()
        } else {
          this.$refs && this.$refs[this.activeName] && this.$refs[this.activeName].$refs.canvas.setCanvasWidth()
        }
      },
      changeTabShow () {
        // this.formData.platformType = '2'
        this.kyylFlag = false
        // this.wbylFlag = false
        this.qhyFlag = false
        this.phyFlag = false
        if (Number(this.formData.taskState) === 1) {
          this.kyylFlag = true
          // this.wbylFlag = true
        }
        if (this.formData.platformType !== '1' && this.formData.platformType !== '10') {
          if (this.formData.getGoodsPatcherName || this.formData.getGoodsPatcher) {
            // this.qhyDisabled = true
            this.qhyFlag = false
          } else {
            // this.qhyDisabled = false
            this.qhyFlag = true
          }

          // this.qhyDisabled = false
          if (this.formData.unloadService === 1) {
            if (this.formData.sendGoodsPatcherName || this.formData.sendGoodsPatcher) {
              // this.phyDisabled = true
              this.phyFlag = false
            } else {
              // this.phyDisabled = false
              this.phyFlag = true
            }

            // this.phyDisabled = false
          } else {
            // this.phyDisabled = true
            this.phyFlag = false
          }
        }

        if (this.formData.platformType === '1') {
          // this.wbylDisabled = true
          // this.kyylDisabled = true
          // this.qhyDisabled = true
          // this.phyDisabled = true
          this.qhyFlag = false
          this.phyFlag = false
        }

        // if (this.formData.platformType === '10') {
        //   // this.wbylDisabled = false
        //   // this.kyylDisabled = false
        //   this.wbylFlag = true
        //   this.kyylFlag = true
        // } else {
        // }
        // if (!this.wbylDisabled) {
        //   this.activeName = 'wbyl'
        // } else if (!this.kyylDisabled) {
        //   this.activeName = 'kyyl'
        // } else if (!this.qhyDisabled) {
        //   this.activeName = 'qhy'
        // } else if (!this.phyDisabled) {
        //   this.activeName = 'phy'
        // } else {
        //   this.activeName = ''
        // }
        if (Number(this.formData.taskState) === 3 || Number(this.formData.taskState) === 4) {
          this.kyylFlag = false
          // this.wbylFlag = false
          this.qhyFlag = false
          this.phyFlag = false
        }
        if (this.wbylFlag) {
          this.activeName = 'wbyl'
        } else if (this.kyylFlag) {
          this.activeName = 'kyyl'
        } else if (this.qhyFlag) {
          this.activeName = 'qhy'
        } else if (this.phyFlag) {
          this.activeName = 'phy'
        } else {
          this.activeName = ''
        }
        this.handleClick()
      },
      changeAddress (province, city, district, address) {
        if (address.indexOf(province) >= 0) {
          address = address.split(province).join('')
        }
        if (address.indexOf(city) >= 0) {
          address = address.split(city).join('')
        }
        if (address.indexOf(district) >= 0) {
          address = address.split(district).join('')
        }
        if (province === city) {
          return province + district + address
        } else {
          return province + city + district + address
        }
      },
      reschedule () {
        this.$confirm('是否重新调度？', '提示').then(async () => {
          let res = await this.$http('zc.dispatch.reschedule.do', { taskId: this.$route.params.id })
          try {
            const taskId = JSON.parse(res).taskId
            if (taskId) {
              // this.$message.success('重新调度成功')
              this.$router.push(`/ecms/whole-car/dispatch/detail/${taskId}`)
              this.$refreshMainQueryTable()
            } else {
              this.$message.error(res)
            }
          } catch (error) {
            this.$message.error(error)
          }
        }).catch(e => {
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .operoperation-btn {
    button {
      margin-bottom: 10px;
    }
    .btn-right {
      text-align: right;
    }
  }
  .timer {
    float: right;
  }
  .mg-t10 {
    margin-top: 10px;
  }
</style>
