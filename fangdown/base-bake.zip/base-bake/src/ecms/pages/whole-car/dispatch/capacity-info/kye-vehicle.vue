<template>
  <div>
    <kye-form ref="form"
              :inline="true"
              label-position="left"
              :model="form">
      <kye-form-item label="所属点部">
        <kye-input v-model="form.newPoint"
                   clearable
                   placeholder="请输入"></kye-input>
      </kye-form-item>
      <kye-form-item label-width="0px">
        <kye-button type="primary"
                    icon="el-icon-search"
                    @click="submitForm('form')"
                    auth='zc.dispatch.getDriverListByPoint.do'>查询</kye-button>
        <!-- <kye-button type="primary"
                    @click="setData"
                    auth="zc.dispatch.executeScheduleForKye.do">
          <i class="iconfont icon-flag"></i>确定调度
        </kye-button> -->
      </kye-form-item>
    </kye-form>
    <div>
      <!-- <div class="el-input el-input--mini el-input-group el-input-group--append"
           style="width: 250px;"><input type="text"
               autocomplete="off"
               placeholder="请输入运单号/代理单号/派送单号"
               class="el-input__inner">
        <div class="el-input-group__append"><button disabled="disabled"
                  type="button"
                  class="el-button el-button--default el-button--mini is-disabled re-button"><i class="iconfont icon-search"></i></button></div>
      </div> -->
      <div class="audit">
        <button type="button"
                class="el-button el-button--text el-button--mini"
                @click="setData"
                auth="zc.dispatch.executeScheduleForKye.do"
                v-if="querenBtn">
          <span><i class="iconfont icon-COOxitong-zhongzhuantiaodu"></i>确认调度
          </span>
        </button>
        <button type="button"
                class="el-button el-button--text el-button--mini"
                @click="setReData"
                auth="zc.dispatch.executeScheduleForKye.do"
                v-if="chongxinBtn">
          <span><i class="iconfont icon-COOxitong-zhongzhuantiaodu"></i>重新调度
          </span>
        </button>
      </div>
    </div>
    <!-- <kye-canvas-table :column="carColumn"
                      :data="car"
                      :page="page"
                      :isScroll="true"
                      :stripe="true"
                      :height="15 * 44"
                      :checkedOptions="checkedOption"
                      @cell-checkbox="cellCheckbox"
                      ref="canvastable"
                      :pageable=false /> -->
    <div v-loading="loading1"
         class="query-table-container">
      <table-list :column="carColumn"
                  :data="car"
                  :options="tableOption"
                  :checkedOptions="checkedOption"
                  @cell-checkbox="cellCheckbox"
                  ref="canvastable"
                  :height="15 * 44"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      :current-page="page.currentPage"
                      :page-size.sync="page.pageSize"
                      @current-change="currentChange"
                      @size-change="sizeChange">
      </kye-pagination>
    </div>
    <div class="h20"></div>
    <div v-loading="loading2"
         class="query-table-container">
      <table-list :column="peoplesColumn"
                  :data="peoples"
                  :options="tableOption"
                  :checkedOptions="checkedOption2"
                  @cell-checkbox="cellCheckbox2"
                  ref="canvastable2"
                  :height="15 * 44"
                  id="wholecar-canvastable2"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="prev,pager,next"
                      background
                      :total="page2.total"
                      :page-sizes="pageSizes"
                      :current-page="page2.currentPage"
                      :page-size.sync="page2.pageSize"
                      @current-change="currentChange2"
                      @size-change="sizeChange2">
      </kye-pagination>
    </div>

  </div>
</template>
<script>
  export default {
    props: {
      carLength: Number,
      formData: Object
    },
    watch: {
      // formData: {
      //   handler: function (val, oldval) {
      //     console.log(val.taskState)
      //     if (Number(val.taskState) === 1) {
      //       this.querenBtn = true
      //       this.chongxinBtn = false
      //     } else if (Number(val.taskState) === 2) {
      //       this.chongxinBtn = true
      //       this.querenBtn = false
      //     }
      //   },
      //   deep: true
      // }
    },
    computed: {
      // 计算属性的 getter
      form: function () {
        // `this` 指向 vm 实例
        return {
          newPoint: Object.assign({}, this.formData).startDepartmentName
        }
      }
    },
    data () {
      return {
        querenBtn: true,
        chongxinBtn: false,
        exScheduleTxt: '确认调度',
        loading1: false,
        loading2: false,
        peoples: [],
        dispatchInfo: {
          plateNum: null,
          driverName: null,
          driverPhone: null,
          driverNo: null
        },
        car: [],
        currentChecked: '',
        currentChecked2: '',
        peoplesColumn: [
          {
            key: 'companyCheck',
            label: '',
            show: true,
            width: '50px'
          },
          {
            key: 'department',
            label: '所属点部',
            show: true,
            width: '100px'
          },
          {
            key: 'name',
            label: '司机姓名',
            show: true,
            width: '80px',
            colorchange: true
          },
          {
            key: 'companyMobile',
            label: '公司电话',
            show: true,
            width: '100px'
          },
          {
            key: 'privateMobile',
            label: '私人电话',
            show: true,
            width: '100px'
          },
          // {
          //   key: 'atWork',
          //   label: '上班时间',
          //   show: true,
          //   width: '140px'
          // },
          // {
          //   key: 'offWork',
          //   label: '下班时间',
          //   show: true,
          //   width: '140px'
          // }
        ],
        carColumn: [
          {
            key: 'companyCheck',
            label: '',
            show: true,
            width: '50px'
          },
          {
            key: 'useNetwork',
            label: '所属点部',
            show: true,
            width: '100px'
          },
          {
            key: 'plateNumber',
            label: '车牌号',
            show: true,
            width: '100px',
            colorchange: true
          },
          {
            key: 'vehicleSpecification.containerLength',
            label: '车长',
            show: true,
            width: '60px'
          },
          {
            key: 'isTailplate',
            label: '是否有尾板',
            show: true,
            width: '100px',
            formatter: (row, column, val) => {
              if (val === '10') {
                return '有'
              } else {
                return '无'
              }
            }
          },
          {
            key: 'useStatus',
            label: '使用状态',
            show: true,
            width: '100px',
            formatter: (row, column, val) => {
              if (val === '10') {
                return '使用'
              } else if (val === '20') {
                return '闲置'
              } else if (val === '30') {
                return '报废'
              } else if (val === '40') {
                return '不合作'
              } else if (val === '50') {
                return '新车'
              } else if (val === '60') {
                return '请假'
              } else if (val === '70') {
                return '维修'
              } else if (val === '80') {
                return '事故'
              }
            }
          },
          {
            key: 'serviceStatus',
            label: '运营状态',
            show: true,
            width: '100px',
            formatter: (row, column, val) => {
              if (val === '10') {
                return '运营'
              } else if (val === '20') {
                return '非运营'
              }
            }
          },

        ],
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        page2: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        pageSizes: [10, 20, 50, 100],
        tableOption: {
          stripe: true,
          moduleCode: 'hr'
        },
        checkedOption: {
          companyCheck: {
            disabled: row => {
              return false
            },
            default (row) {
              return row.companyCheck === 10
            },
            func: (row, key, status) => {
              this.cellCheckbox(row, key, status)
            }
          },
        },
        checkedOption2: {
          companyCheck: {
            disabled: row => {
              return false
            },
            default (row) {
              return row.companyCheck === 10
            },
            func: (row, key, status) => {
              this.cellCheckbox2(row, key, status)
            }
          }
        },
      }
    },
    created () {
      if (this.$route.params.id) {
        this.getErpDriver()
        this.getErpCarInfo()
        // this.isReschedule()
      }
    },
    mounted () {
      this.$nextTick(() => {

      })
    },
    methods: {
      // 通过点部获取跨越司机信息
      async getErpDriver (params = {}) {
        try {
          this.loading2 = true
          // params['ERPSearchCacheFlag'] = true
          params.vo = {
            departmentFuzzy: this.form.newPoint
          }
          params['page'] = this.page2.currentPage
          params['pageSize'] = this.page2.pageSize
          let res = await this.$http('hr.remoteEmployee.search', params)
          window.innerHeight = window.innerHeight - 200
          this.$bus.$emit('GLOBAL_RESIZE')
          this.peoples = res.rows
          this.page2 = {
            pageSize: res.pageSize,
            currentPage: res.page,
            total: res.rowTotal
          }
          this.loading2 = false
        } catch (error) {
          this.loading2 = false
        }
      },
      // 通过点部获取跨越可用车辆信息
      async getErpCarInfo (params = {}) {
        try {
          this.loading1 = true
          // params['containerLength'] = this.carLength
          // params['useNetwork'] = this.form.newPoint || this.point
          // params['ERPSearchCacheFlag'] = true
          let obj = {
            useNetwork: this.form.newPoint,
            page: this.page.currentPage,
            pageSize: this.page.pageSize,
            ERPSearchCacheFlag: true,
            forceCache: params.forceCache ? params.forceCache : undefined
          }
          let res = await this.$http('vms.vehicle.search', obj)
          this.car = res.rows
          this.loading1 = false
          this.page = {
            pageSize: res.pageSize,
            currentPage: res.page,
            total: res.pageTotal
          }
        } catch (error) {
          this.loading1 = false
        }
      },
      currentChange (currentPage) {
        this.page.currentPage = currentPage
        this.getErpCarInfo()
      },
      currentChange2 (currentPage) {
        this.page2.currentPage = currentPage
        this.getErpDriver()
      },
      sizeChange (pageSize) {
        this.page.pageSize = pageSize
        this.getErpCarInfo()
      },
      sizeChange2 (pageSize) {
        this.page2.pageSize = pageSize
        this.getErpDriver()
      },
      submitForm (formName) {
        if (this.$route.params.id) {
          this.getErpDriver({ forceCache: true })
          this.getErpCarInfo({ forceCache: true })
        }
      },
      cellCheckbox (row, key, status) {
        let ref = this.$refs.canvastable.$refs.table
        if (status.checked) {
          for (let i in ref.checkboxRows) {
            ref.checkboxRows[i].disabled = true
          }
          status.disabled = false
          this.currentChecked = row
          this.dispatchInfo.plateNum = row.plateNumber
        } else {
          for (let i in ref.checkboxRows) {
            ref.checkboxRows[i].disabled = false
          }
          this.dispatchInfo.plateNum = ''
          this.currentChecked = ''
        }
      },
      cellCheckbox2 (row, key, status) {
        let ref = this.$refs.canvastable2.$refs.table
        if (status.checked) {
          for (let i in ref.checkboxRows) {
            ref.checkboxRows[i].disabled = true
          }
          status.disabled = false
          this.currentChecked2 = row
          this.dispatchInfo.driverName = row.name
          this.dispatchInfo.driverPhone = row.companyMobile || row.privateMobile
          this.dispatchInfo.driverNo = row.employeeNumber
        } else {
          for (let i in ref.checkboxRows) {
            ref.checkboxRows[i].disabled = false
          }
          this.currentChecked2 = ''
          this.dispatchInfo.driverName = null
          this.dispatchInfo.driverPhone = null
          this.dispatchInfo.driverNo = null
        }
      },
      // 确认调用调度接口
      setData () {
        // const self = this
        if (!(this.dispatchInfo.plateNum && this.dispatchInfo.driverName)) {
          return this.$message.info('请完整选择车辆及司机信息')
        }
        this.$confirm('确认调度？', '提示').then(async () => {
          let res = await this.$http('zc.dispatch.executeScheduleForKye.do', { ...this.dispatchInfo, taskId: this.$route.params.id })
          if (res) {
            this.$emit('upDateData')
            this.$refreshMainQueryTable()
            if (res === 'OK') {
              this.$message.success('调度成功')
              // this.getDriver({ taskCode: this.form.taskCode })
            } else {
              this.$message.error(res)
            }
          }
        }).catch(e => {
        })
      },
      // 重新调用调度接口
      setReData () {
        // const self = this
        if (!(this.dispatchInfo.plateNum && this.dispatchInfo.driverName)) {
          return this.$message.info('请完整选择车辆及司机信息')
        }
        this.$confirm('是否重新调度？', '提示').then(async () => {
          let res = await this.$http('zc.dispatch.reschedule.do', { ...this.dispatchInfo, taskId: this.$route.params.id })
          if (res === 'OK') {
            this.$message.success('重新调度成功')
            this.$emit('upDateData')
            this.$refreshMainQueryTable()
          } else {
            this.$message.error(res)
          }
        }).catch(e => {
          console.log(e)
        })
      },
      isReschedule () {
        if (this.formData.taskState === '1') {
          this.querenBtn = true
          this.chongxinBtn = false
        } else if (this.formData.taskState === '2') {
          this.chongxinBtn = true
          this.querenBtn = false
        }
      }
    }
  }
</script>
<style lang='scss' scoped>
  .h20 {
    height: 20px;
  }
  .paging-wrap {
    padding-top: 20px;
  }
  .ky-erp .el-form--inline .el-form-item {
    margin-top: 4px;
    margin-bottom: 0px;
  }
  .audit {
    margin-bottom: 4px;
  }
</style>


