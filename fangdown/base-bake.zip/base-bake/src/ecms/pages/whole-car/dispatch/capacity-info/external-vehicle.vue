<template>
  <div>
    <div>
      <div class="audit">
        <button type="button"
                class="el-button el-button--text el-button--mini"
                @click="getDriver({ taskCode: formData.taskCode })"
                auth="zc.dispatch.getDriverQuotationPageList.do">
          <span><i class="iconfont icon-reset"></i>刷新
          </span>
        </button>
        <button type="button"
                class="el-button el-button--text el-button--mini"
                @click="addPriceDialogVisible = true"
                auth="zc.dispatch.createQueryPrice.do"
                v-if="formData.taskState !== '2'">
          <span><i class="iconfont icon-plus"></i>添加报价
          </span>
        </button>
      </div>
    </div>
    <div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="data"
                  :options="tableOption"
                  :operation="operation"
                  :buttonOptions="buttonOptions"
                  ref="canvas"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.pageTotal>1">
      <kye-pagination layout="prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      :current-page="page.currentPage"
                      :page-size.sync="page.pageSize"
                      @current-change="currentChange"
                      @size-change="sizeChange">
      </kye-pagination>
    </div>

    <kye-dialog title="添加报价"
                :visible.sync="addPriceDialogVisible"
                width="40%">
      <div class="kye-dialog-body">
        <kye-form ref="addPriceForm"
                  :model="addPriceForm"
                  label-position="left"
                  :rules="addPriceRules">
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="合同企业"
                             prop="contractName">
                <kye-search-tips v-model="addPriceForm.contractName"
                                 url="zc.dispatch.queryCompanyDriverInfo.do"
                                 value-key="fullName"
                                 :keys="['fullName']"
                                 placeholder="请输入合同企业"
                                 :format-data="formatShortCompanyData"
                                 :warning=false
                                 @select="handleShortCompany">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="价格"
                             prop="contractPrice">
                <kye-number v-model="addPriceForm.contractPrice"
                            placeholder="请输入"
                            :precision="2"
                            symbol="￥">
                </kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="联系方式"
                             prop="contactPhone">
                <kye-input disabled
                           v-model="addPriceForm.contactPhone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="合作次数"
                             prop="cooperationCount">
                <kye-input disabled
                           v-model="addPriceForm.cooperationCount"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="违约次数"
                             prop="violateCount">
                <kye-input disabled
                           v-model="addPriceForm.violateCount"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </kye-form>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button type="primary"
                   @click="saveAddPrice('addPriceForm')"
                   hotkey="ctrl+s">保存(S)</el-button>
        <el-button @click="addPriceDialogVisible = false">取 消</el-button>
      </span>
    </kye-dialog>

    <kye-dialog :title="addCarTitle"
                :visible.sync="addCarDialogVisible"
                width="40%">
      <div class="kye-dialog-body">
        <kye-form ref="addCarForm"
                  :model="addCarForm"
                  label-position="left"
                  :rules="addPriceRules">
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="司机姓名"
                             prop="driverName">
                <kye-input v-model="addCarForm.driverName"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="司机电话"
                             prop="driverPhone">
                <kye-input v-model="addCarForm.driverPhone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="司机车牌"
                             prop="plateNum">
                <kye-input v-model="addCarForm.plateNum"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </kye-form>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="addCarDialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="saveAddCar('addCarForm')"
                   hotkey="ctrl+s">保存(S)</el-button>
      </span>
    </kye-dialog>

    <kye-dialog title="合同报价"
                :visible.sync="contractPriceVisible"
                width="50%">
      <div class="kye-dialog-body">
        <table-list :column="contractColumn"
                    :data="contractData"
                    :options="tableOption"
                    ref="contractPriceCanvas"></table-list>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import { vehicleScheduingMixin } from '../vehicle-scheduling' // 状态信息

  export default {
    mixins: [vehicleScheduingMixin],
    props: {
      formData: {
        type: Object,
        default () {
          return {}
        }
      }
    },
    watch: {
      formData: {
        handler: function (val, oldval) {
          console.log(val)
          if (val.taskCode && ((val.taskCode !== oldval.taskCode))) {
            this.getDriver({ taskCode: val.taskCode })
          }
          if (val.taskState && (val.taskState !== oldval.taskState)) {
            this.getDriver({ taskCode: val.taskCode })
          }
        },
        deep: true
      }
    },
    computed: {

    },
    data () {
      const validatorPhone = (rule, value, callback) => {
        if (!(/^1[3|4|5|6|7|8|9][0-9]\d{8}$/).test(value)) {
          callback(new Error('手机号码格式错误'))
        } else {
          callback()
        }
      }
      const validatorPateNum = (rule, value, callback) => {
        if (value.length === 7) {
          var express = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/
          if (express.test(value)) {
            callback()
          } else {
            callback(new Error('车牌号码格式错误'))
          }
        } else {
          callback(new Error('车牌号码格式错误'))
        }
      }
      return {
        addCarTitle: '添加车辆',
        addCarForm: {
          driverName: '',
          driverPhone: '',
          plateNum: '',
          priceId: ''
        },
        addPriceForm: {
          contractName: '',
          contractPrice: '',
          contactPhone: '',
          driverId: ''
        },
        addPriceDialogVisible: false,
        addCarDialogVisible: false,
        contractPriceVisible: false,
        loading: false,
        data: [],
        contractData: [],
        column: [
          // {
          //   key: 'platformType',
          //   label: '运力类型',
          //   show: true,
          //   width: '120px',
          //   formatter: (val) => {
          //     return platformTypes['type_' + val.platformType]
          //   }
          // },
          {
            key: 'capacityType',
            label: '运力类型',
            show: true,
            width: '120px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_car_driver_type'
              ]
            }
          },
          {
            key: 'capacityName',
            label: '运力名称',
            show: true,
            width: '120px',
            formatter: (row, column, val) => {
              return row.capacityName || row.driverName
            }
          },
          {
            key: 'driverPhone',
            label: '联系方式',
            show: true,
            width: '140px'
          },
          {
            key: 'plateNum',
            label: '车牌号',
            show: true,
            width: '80px',
          },
          {
            key: 'carLength',
            label: '车长(米)',
            show: true,
            width: '80px',
          },
          // {
          //   key: 'driverName',
          //   label: '司机姓名',
          //   show: true,
          //   width: '100px'
          // },
          {
            key: 'cooperationCount',
            label: '合作次数',
            show: true,
            width: '80px',
          },
          {
            key: 'violateCount',
            label: '违约次数',
            show: true,
            width: '80px',
          },
          {
            key: 'driverQuotation',
            label: '价格(元)',
            show: true,
            width: '80px'
          },
          {
            key: 'quotationType',
            label: '报价方式',
            show: true,
            width: '80px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_zc_quotationType'
              ]
            }
          },
          {
            key: 'queryPriceStatus',
            label: '中标状态',
            show: true,
            width: '80px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_zc_queryPriceStatus'
              ]
            }
          }
        ],
        contractColumn: [
        ],
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0,
          pageTotal: 0
        },
        pageSizes: [10],
        tableOption: {
          stripe: true
        },
        operation: {
          label: '操作',
          width: '80px',
          options: row => {
            if (row.queryPriceStatus === 300 && row.capacityType === '合同企业') {
              if (!row.plateNum) {
                return [
                  {
                    type: 'link',
                    label: '添加车辆',
                    auth: 'zc.dispatch.executeSchedule.do',
                    func: (row) => {
                      this.addCarForm.priceId = row.priceId
                      this.addCarDialogVisible = true
                      this.addCarTitle = '添加车辆'
                    }
                  }]
              } else {
                return [
                  {
                    type: 'link',
                    label: '修改车辆',
                    auth: 'zc.dispatch.executeSchedule.do',
                    func: (row) => {
                      this.addCarForm.priceId = row.priceId
                      this.addCarForm.driverName = row.driverName
                      this.addCarForm.driverPhone = row.driverPhone
                      this.addCarForm.plateNum = row.plateNum
                      this.addCarDialogVisible = true
                      this.addCarTitle = '修改车辆'
                    }
                  }]
              }
            } else {
              return [
                // {
                //   type: 'link',
                //   label: '添加车辆',
                //   auth: 'zc.dispatch.executeSchedule.do',
                //   func: (row) => {
                //     this.addCarForm.priceId = row.priceId
                //     this.addCarDialogVisible = true
                //   }
                // },
                {
                  type: 'link',
                  label: '确认调度',
                  auth: 'zc.dispatch.executeSchedule.do',
                  disabled: row => {
                    if (Number(this.formData.taskState) !== 1) {
                      return true
                    }
                  },
                  func: this.executeSchedule
                }
              ]
            }
          }
        },
        buttonOptions: {
          'capacityName': {
            type: 'link',
            color: row => {
              if (row.capacityType === '合同企业' && row.quotationType === 2) {
                return '#9571e9'
              }
            },
            disabled: row => {
              if (row.capacityType !== '合同企业' || row.quotationType !== 2) {
                return true
              }
            },
            func: (row) => {
              this.contractPriceVisible = true
              this.$nextTick(() => {
                this.$refs.contractPriceCanvas.$refs.table.repaint()
                this.getContractPriceList(row)
              })
            }
          }
        },
        addPriceRules: {
          contractName: [
            { required: true, message: '必填', trigger: 'blur' }
          ],
          contractPrice: [
            { required: true, message: '必填', trigger: 'blur' }
          ],
          driverName: [
            { required: true, message: '必填', trigger: 'blur' }
          ],
          driverPhone: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorPhone, message: '手机格式错误', trigger: 'blur' }
          ],
          plateNum: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorPateNum, message: '车牌号格式错误', trigger: 'blur' }
          ]
        },
      }
    },
    created () {
      this.getDriver({ taskCode: this.formData.taskCode })
      // this.isReschedule()
    },
    mounted () {

    },
    methods: {
      // 获取外部可用车辆信息
      async getDriver (params = {}) {
        try {
          this.loading = true
          params.size = this.page.pageSize
          params.page = this.page.currentPage
          let res = await this.$http('zc.dispatch.getDriverQuotationPageList.do', params)
          window.innerHeight = window.innerHeight + 200
          this.$bus.$emit('GLOBAL_RESIZE')
          this.loading = false
          this.data = res.rows
          this.page.total = res ? res.total : 0
          this.page.pageTotal = res ? res.pageTotal : 0
        } catch (error) {
          this.loading = false
        }
      },
      currentChange (currentPage) {
        this.page.currentPage = currentPage
        this.getDriver({ taskCode: this.formData.taskCode })
      },
      sizeChange (pageSize) {
        this.page.pageSize = pageSize
        this.page.currentPage = 1
        this.getDriver({ taskCode: this.formData.taskCode })
      },
      executeSchedule (row) { // 确认调度
        this.$confirm('是否确认调度此对象', '提示').then(async () => {
          let res = await this.$http('zc.dispatch.executeSchedule.do', {
            taskId: this.$route.params.id,
            quoteId: row.priceId + ''
          })
          if (res) {
            this.$emit('upDateData')
            this.$refreshMainQueryTable()
            if (res === 'OK') {
              this.$message.success('调度成功')
              // this.getDriver({ taskCode: this.formData.taskCode })
            } else {
              this.$message.error(res)
            }
          }
        }).catch(() => {
        })
      },
      async getContractPriceList (row) {
        this.contractColumn = []
        if (row.calcWay === '05') {
          let res = await this.$http('zc.dispatch.querySignedDriverOfferTrunkRoute.do', {
            contractId: row.contractNo
          })
          this.contractData = res
          this.contractColumn = [{
            key: 'carTypeName',
            label: '车型',
            show: true,
            width: '80px'
          },
          {
            key: 'carLength',
            label: '车长',
            show: true,
            width: '60px'
          },
          {
            key: 'startPoint',
            label: '始发地',
            show: true,
            width: '180px'
          },
          {
            key: 'endPoint',
            label: '目的地',
            show: true,
            width: '180px'
          },
          {
            key: 'transportAskPrice',
            label: '一口价',
            show: true,
            width: '80px'
          },
          {
            key: 'stopLand1Code',
            label: '经停点1',
            show: true,
            width: '120px'
          },
          {
            key: 'stopLand2Code',
            label: '经停点2',
            show: true,
            width: '120px'
          },
          {
            key: 'stopLand3Code',
            label: '经停点3',
            show: true,
            width: '120px'
          },
          {
            key: 'stopLand4Code',
            label: '经停点4',
            show: true,
            width: '120px'
          }]
        } else {
          let res = await this.$http('zc.dispatch.findTrunkChargeByKMByContractId.do', {
            contractId: row.contractNo
          })
          this.contractData = res
          this.contractColumn = [{
            key: 'carTypeName',
            label: '车型',
            show: true,
            width: '80px'
          },
          {
            key: 'carLength',
            label: '车长',
            show: true,
            width: '60px'
          },
          {
            key: 'startKilometer',
            label: '起步公里(km)',
            show: true,
            width: '80px'
          },
          {
            key: 'startPrice',
            label: '起步价(元)',
            show: true,
            width: '80px'
          },
          {
            key: 'minKilometer',
            label: '最小公里',
            show: true,
            width: '80px'
          },
          {
            key: 'maxKilometer',
            label: '最大公里',
            show: true,
            width: '80px'
          }
          ]
        }
        this.$refs.contractPriceCanvas.$refs.table.repaint()
      },
      saveAddCar (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            let res = await this.$http('zc.dispatch.saveDriverInfo.do', {
              driverName: this.addCarForm.driverName,
              driverPhone: this.addCarForm.driverPhone,
              plateNum: this.addCarForm.plateNum,
              priceId: this.addCarForm.priceId
            })
            if (res === 'OK') {
              this.addCarDialogVisible = false
              this.addCarForm = {
                driverName: '',
                driverPhone: '',
                plateNum: '',
                priceId: ''
              }
              // this.getDriver({ taskCode: this.formData.taskCode })
              this.$emit('upDateData')
              this.$refreshMainQueryTable()
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      saveAddPrice (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            let res = await this.$http('zc.dispatch.createQueryPrice.do', {
              taskCode: this.formData.taskCode,
              price: this.addPriceForm.contractPrice,
              driverId: this.addPriceForm.driverId
            })
            if (res === 'OK') {
              this.addPriceDialogVisible = false
              this.addPriceForm = {
                contractName: '',
                contractPrice: '',
                contactPhone: '',
                driverId: ''
              }
              // this.getDriver({ taskCode: this.formData.taskCode })
              this.$emit('upDateData')
              this.$refreshMainQueryTable()
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      handleShortCompany (item) {
        if (!item) {
          this.addPriceForm.driverId = ''
          this.addPriceForm.contactPhone = ''
          this.addPriceForm.violateCount = ''
          this.addPriceForm.cooperationCount = ''
          this.addPriceForm.contractName = ''
          return false
        } else {
          this.addPriceForm.contactPhone = item.contactPhone
          this.addPriceForm.driverId = item.driverId
          this.addPriceForm.violateCount = item.violateCount
          this.addPriceForm.cooperationCount = item.cooperationCount
        }
      },
      formatShortCompanyData (val) {
        let obj = {
          companyName: val
        }
        return obj
      }
    }
  }
</script>
<style lang='scss' scoped>
  .paging-wrap {
    padding-top: 20px;
  }
</style>


