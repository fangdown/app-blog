<template>
  <div class="p2"
       :endTime="endTime"
       :callback="callback"
       :endText="endText">
    <div v-if="isEnd">{{endText}}</div>
    <div v-else>
      <span>{{hours.substring(0,1)}}</span>
      <span>{{hours.substring(1)}}</span> 小时
      <span>{{minutes.substring(0,1)}}</span>
      <span>{{minutes.substring(1)}}</span> 分
      <span>{{seconds.substring(0,1)}}</span>
      <span>{{seconds.substring(1)}}</span> 秒
      <!-- <i>{{milliseconds}}</i> -->
    </div>

  </div>
</template>
<script>
  export default {
    data () {
      return {
        hours: '00',
        minutes: '00',
        seconds: '00',
        milliseconds: '00',
        pageTimer: {
          timer1: '',
          timer2: ''
        },
        isEnd: false
      }
    },
    props: {
      endTime: {
        type: Number,
        default: 0
      },
      endText: {
        type: String,
        default: '已结束'
      },
      callback: {
        type: Function,
        default: () => {

        }
      }
    },
    mounted () {
      this.countdowm(this.endTime)
    },
    watch: {
      endTime (curVal, oldVal) {
        if (this.pageTimer) {
          for (let each in this.pageTimer) {
            clearInterval(this.pageTimer[each])
          }
        }
        this.countdowm(curVal, oldVal)
      }
    },
    methods: {
      countdowm (timestamp, oldtime) {
        this.pageTimer['timer1'] = setInterval(() => {
          let nowTime = new Date()
          let endTime = new Date(timestamp * 1000)
          let t = endTime.getTime() - nowTime.getTime()
          if (t > 0) {
            let hour = Math.floor(t / 3600000)
            let min = Math.floor((t / 60000) % 60)
            let sec = Math.floor((t / 1000) % 60)
            hour = hour < 10 ? '0' + hour : '' + hour + ''
            min = min < 10 ? '0' + min : '' + min + ''
            sec = sec < 10 ? '0' + sec : '' + sec + ''
            this.hours = hour
            this.minutes = min
            this.seconds = sec
            let millSeconds = 9
            this.pageTimer['timer2'] = setInterval(() => {
              this.milliseconds = millSeconds
              millSeconds--
              if (millSeconds < 0) {
                millSeconds = 9
              }
            }, 100)
          } else {
            clearInterval(this.pageTimer['timer1'])
            this.hours = '00'
            this.minutes = '00'
            this.seconds = '00'
            this.milliseconds = '00'
            this.isEnd = true
            this._callback()
          }
        }, 1000)
      },
      _callback () {
        if (this.callback && this.callback instanceof Function) {
          this.callback()
        }
      }
    }
  }
</script>
<style lang='scss' scoped>
  .p2 {
    span {
      display: inline-block;
      width: 18px;
      height: 20px;
      background: #ff9300;
      border-radius: 2px;
      font-family: PingFangSC-Regular;
      font-size: 12px;
      color: #ffffff;
      line-height: 20px;
      text-align: center;
    }
  }
</style>
