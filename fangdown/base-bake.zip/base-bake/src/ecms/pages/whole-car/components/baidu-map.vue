<template>
  <div :id="id">

  </div>
</template>
<script>
  import { requireSDK } from '@/shared/components/kye-map/utils.js'
  export default {
    props: {
      id: String,
      address: {
        default: '',
        type: String
      }
    },
    watch: {
      // myValue: {
      //   handler: function (val, oldval) {
      //     console.log(val, oldval)
      //   },
      //   deep: true
      // }
    },
    data () {
      return {
        MAP: '', // 实例map
        geoc: '',
        addressBd: {},
        myValue: '',
        ac: ''
      }
    },
    beforeCreate () {
      requireSDK()
    },
    mounted () {
      this.$nextTick(() => {
        this.myValue = this.address
        let timer = setInterval(() => {
          if (!this.MAP) {
            this.MAP = new window.BMap.Map(this.id)
          } else {
            this.initAutocomplete()
            clearInterval(timer)
          }
        }, 300)
        // setTimeout(() => {

        // }, 200)
      })
    },
    methods: {
      initAutocomplete () {
        // this.MAP = new window.BMap.Map(id)
        // 初始化地图,设置中心点坐标，
        var point = new window.BMap.Point(113.786939, 22.687931) // 创建点坐标
        this.MAP.centerAndZoom(point, 15)
        this.MAP.enableScrollWheelZoom()
        this.initAC()
        this.geoc = new window.BMap.Geocoder()
        this.MAP.addEventListener('click', (e) => {
          this.addressBd = {}
          let pt = e.point
          this.geoc.getLocation(pt, (rs) => {
            let addComp = rs.addressComponents
            this.myValue = addComp.province + addComp.city + addComp.district + addComp.street + addComp.streetNumber
            this.setPlace()
          })
        })
      },
      initAC () { // 初始化自动模糊搜索实例
        this.ac = new window.BMap.Autocomplete( // 建立一个自动完成的对象
          {
            'input': this.id + 'Input',
            'location': this.MAP,
            'types': '',
            onSearchComplete: (val) => {
            }
          })
        this.ac.setInputValue(this.myValue)
        this.ac.addEventListener('onconfirm', (e) => { // 鼠标点击下拉列表后的事件
          this.confirmFn(e)
          setTimeout(() => {
            this.initAC(this.id)
          }, 300)
        })
      },

      setInputVal (address) {
        let timer = setInterval(() => {
          if (this.ac) {
            clearInterval(timer)
            this.ac.setInputValue(address)
          }
        }, 200)
      },
      setPlace () {
        this.MAP.clearOverlays() // 清除地图上所有覆盖物
        this.local = new window.BMap.LocalSearch(this.MAP, { // 智能搜索
          onSearchComplete: this.setPlaceFun
        })
        this.local.search(this.myValue) // 测试输出坐标（指的是输入框最后确定地点的经纬度）
      },
      async setPlaceFun () {
        let userlocation = this.local.getResults().getPoi(0) // 获取第一个智能搜索的结果
        this.MAP.centerAndZoom(userlocation.point, 18)
        this.MAP.addOverlay(new window.BMap.Marker(userlocation.point)) // 添加标注
        this.geoc.getLocation(userlocation.point, (rs) => {
          var addComp = rs.addressComponents
          if (this.addressBd.business) {
            this.myValue = addComp.province + addComp.city + addComp.district + addComp.street + this.addressBd.business
          } else {
            this.myValue = addComp.province + addComp.city + addComp.district + addComp.street
          }
          this.$emit('update', {
            address: this.myValue,
            longitude: userlocation.point.lng,
            latitude: userlocation.point.lat
          })
        })
      },
      confirmFn (e) {
        var _value = e.item.value
        let business = _value.business
        if (business.indexOf(_value.province) >= 0) {
          business = business.split(_value.province).join('')
        }
        if (business.indexOf(_value.city) >= 0) {
          business = business.split(_value.city).join('')
        }
        if (business.indexOf(_value.district) >= 0) {
          business = business.split(_value.district).join('')
        }
        this.myValue = _value.province + _value.city + _value.district + _value.street + business
        this.addressBd = _value
        this.$emit('update', {
          address: this.myValue,
          detailAddress: _value.street + business
        })
        this.ac.dispose()
      }
    }
  }
</script>
<style scope>
  #startMap,
  #endMap {
    width: 100%;
    height: 300px;
  }
</style>


