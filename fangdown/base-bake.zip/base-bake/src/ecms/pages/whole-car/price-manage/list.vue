<template>
  <div>
    <query-table ref="queryTable"
                 :form-tools="searchTools"
                 :option="option"
                 :tables="tables"
                 :generic="generic"
                 :form-model="formModel">
      <div slot="desc"></div>
    </query-table>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        timeTypes: 'loadingTime',
        loading: false,
        generic: {
          method: 'zc.erp.getErpCarDispatchEntityList',
          searchCode: 'zc_erp_getErpCarDispatchEntityList'
        },
        formModel: {
          loadingTime: [this.$options.filters.time(+new Date(+new Date() - 2 * 24 * 60 * 60 * 1000)), this.$options.filters.time(+new Date(+new Date() + 2 * 24 * 60 * 60 * 1000))],
        },
        tables: [
          {
            searchCode: 'ecs_zc_price_list_field',
            url: { method: 'zc.erp.getErpCarDispatchEntityList' },
            option: {
              load: false,
              stripe: true,
              detailAuth: 'zc.erp.getCarDispatchBytaskCodeList',
              rowDblClick: this.rowDblClick,
              idKey: 'taskCode',
              moduleCode: 'ecs_zc',
              defaultSort: {
                keys: ['cargo_dispatch.create_time', 'cargo_dispatch.create_time'],
                prop: 'cargo_dispatch.create_time',
                order: 'descending'
              },
              beforeFormSubmit: (data, model) => {
                delete data['createStartTime']
                delete data['createEndTime']
                delete data['loadingStartTime']
                delete data['loadingEndTime']
                delete data['signingStartTime']
                delete data['signingEndTime']
                delete data['signingTime']
                delete data['createTime']
                delete data['loadingTime']
                const obj = {}
                for (let key in model) {
                  if (model[key] && ['createTime', 'loadingTime', 'singingTime'].indexOf(key) === -1) {
                    obj[key] = model[key]
                  } else {
                    delete data[key]
                  }
                }
                if (model.createTime && model.createTime.length > 1 && this.timeTypes === 'createTime') {
                  obj['createStartTime'] = model.createTime[0]
                  obj['createEndTime'] = model.createTime[1]
                }
                if (model.loadingTime && model.loadingTime.length > 1 && this.timeTypes === 'loadingTime') {
                  obj['loadingStartTime'] = model.loadingTime[0]
                  obj['loadingEndTime'] = model.loadingTime[1]
                }
                if (model.signingTime && model.signingTime.length > 1 && this.timeTypes === 'signingTime') {
                  obj['signingStartTime'] = model.signingTime[0]
                  obj['signingEndTime'] = model.signingTime[1]
                }
                const nObj = Object.assign({}, obj)
                if (Object.keys(nObj).length === 0) {
                  this.$message.warning('请输入查询条件')
                  return true
                } else {
                  for (let key in nObj) {
                    if (!nObj[key] || nObj[key].length === 0) {
                      this.$message.warning('请输入查询条件')
                      return true
                    }
                  }
                }
                Object.assign(data, obj)
              },
            },
            formatter: {
              status: (row, column, val) => {
                if (val === 200) {
                  return '待确认'
                } else if (val === 100 || val === 300) {
                  return '待报价'
                } else if (val === 410) {
                  return '待支付'
                } else if (val === 400) {
                  return '已报价'
                } else if (val === 500) {
                  return '待取货'
                } else if (val === 600) {
                  return '取货中'
                } else if (val === 700) {
                  return '已取货'
                } else if (val === 800) {
                  return '已签收'
                } else if (val === 102 || val === 301 || val === 302 || val === 401 || val === 402) {
                  return '已超时'
                } else if (val === 101 || val === 403 || val === 501) {
                  return '已取消'
                }
              },
              carTypeStr: (row, column, val) => {
                return row.carLength + '米' + row.carTypeName
              },
              startAddress: (row, column, val) => {
                return this.changeAddress(row.startProvince, row.startCity, row.startArea, row.startAddress)
              },
              endAddress: (row, column, val) => {
                return this.changeAddress(row.endProvince, row.endCity, row.endArea, row.endAddress)
              },
            },
            buttonOptions: {
              'status': {
                type: 'link',
                color: row => {
                  if (row.status === 100 || row.status === 300) {
                    return 'red'
                  }
                },
                func: (row) => {
                  // this.toDetail(row)
                }
              }
            }
          }
        ],
        searchTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: 'zc.erp.getErpCarDispatchEntityList',
            func: () => {
              this.$refreshMainQueryTable()
            }
          },
          {
            label: '新增',
            icon: 'plus',
            auth: 'zc.inquiry.insert.do',
            func: () => {
              this.$router.push({
                path: '/ecms/whole-car/price-manage/add'
              })
            }
          },
          // {
          //   label: '通用查询',
          //   icon: 'search',
          //   func: () => this.$refs.queryTable.showGenericDialog()
          // },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'ecs_zc_price_list_search_define',
          module: true,
          timeType: {
            change: ({ key, value, model }) => {
              this.timeTypes = key
            }
          }
        },
      }
    },
    methods: {
      rowDblClick (row, col) {
        this.$router.push(`/ecms/whole-car/price-manage/detail/${row.taskCode}`)
      },
      changeAddress (province, city, district, address) {
        if (address.indexOf(province) >= 0) {
          address = address.split(province).join('')
        }
        if (address.indexOf(city) >= 0) {
          address = address.split(city).join('')
        }
        if (address.indexOf(district) >= 0) {
          address = address.split(district).join('')
        }
        if (province === city) {
          return province + district + address
        } else {
          return province + city + district + address
        }
      }
    }
  }
</script>
<style lang='scss' scoped>
</style>


