<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="formTools"></search-pager>
    <kye-expand-page>
      <div class="timer"
           v-if="form.status === 400||form.status === 100||form.status === 300||form.status === 410">
        <span v-if="form.status === 400">下单倒计时</span>
        <span v-if="form.status === 100 || form.status === 300">报价倒计时</span>
        <span v-if="form.status === 410">支付倒计时</span>
        <count-down :endTime="endTime"
                    :callback="callback"
                    endText="时间已失效" />
      </div>
      <kye-form ref="formArea"
                :model.sync="form"
                label-position="left"
                :biz-id="$route.params.id"
                module-code="ecs_zc">
        <h3 class="kye-block-title">基本信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="任务编码"
                           prop="taskCode">
              <kye-field v-model="form.taskCode"
                         :disabled="true"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="订单状态"
                           prop="status">
              <kye-field v-model="form.statusStr"
                         :disabled="true"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4"
                   class="tow-input-wrap">
            <kye-form-item label="货好时间"
                           prop="loadingTime">
              <kye-field>{{form.loadingTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="创建时间"
                           prop="createTime">
              <kye-field>{{form.createTime|minute}}</kye-field>
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4">
          <kye-form-item label="下单时间">
            <kye-field :disabled="true"
                       v-model="form.confirmQuoteTimeStr"></kye-field>
          </kye-form-item>
        </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="询价渠道"
                           prop="channel">
              <kye-field v-model="form.channelStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="公司简称"
                           prop="companyName">
              <kye-field v-model="form.companyName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="客户姓名"
                           prop="clientName">
              <kye-field v-model="form.clientName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="联系电话"
                           prop="phone">
              <kye-field v-model="form.phone"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="车型"
                           prop="carType">
              <kye-field v-model="form.carTypeStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="托寄物"
                           prop="goodsName">
              <kye-field v-model="form.goodsName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总重量"
                           prop="countWeight">
              <!-- <kye-number v-model="form.countWeight"
                          unit="kg"
                          :precision="2"
                          :disabled="true">
              </kye-number> -->
              <kye-field>{{form.countWeight+'kg'}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总体积"
                           prop="countVolume">
              <!-- <kye-number v-model="form.countVolume"
                          unit="m³"
                          :precision="2"
                          :disabled="true">
              </kye-number> -->
              <kye-field>{{form.countVolume+'m³'}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="始发地"
                           prop="startAddress">
              <kye-field v-model="form.startAddressStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="目的地"
                           prop="endAddress">
              <kye-field v-model="form.endAddressStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4">
            <kye-form-item label="任务状态"
                           prop="status">
              <kye-field v-model="option.title"></kye-field>
            </kye-form-item>
          </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="销售经理"
                           prop="saleser">
              <kye-field v-model="form.saleser"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="经理电话"
                           prop="saleserPhone">
              <kye-field v-model="form.saleserPhone"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="销售助理"
                           prop="assistant">
              <kye-field v-model="form.assistant"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="助理电话"
                           prop="assistantPhone">
              <kye-field v-model="form.assistantPhone"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="备注"
                           prop="remark">
              <kye-field v-model="form.remark"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="运单号"
                           prop="waybillCode">
              <kye-field v-model="form.waybillCode"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="签收时间"
                           prop="signingTime">
              <kye-field v-model="form.signingTimeStr"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="调度员"
                           prop="dispatcher">
              <kye-field v-model="form.dispatcher"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="调度电话"
                           prop="dispatcherPhone">
              <kye-field v-model="form.dispatcherPhone"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">增值服务</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="装货服务"
                           prop="loadService">
              <kye-field>{{form.loadService|lookup('ecs_zc_loadservice')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="卸货服务"
                           prop="unloadService">
              <kye-field>{{form.unloadService|lookup('ecs_zc_unloadservice')}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="需要尾板"
                           prop="isTailboard">
              <kye-field>{{form.isTailboard|lookup('ecs_zc_istailboard')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="回单服务"
                           prop="isReceipt">
              <kye-field>{{form.isReceipt|lookup('ecs_zc_isreceipt')}}
              </kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">参考价格</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="行情价"
                           prop="averageTransportFee">
              <kye-field>{{form.averageTransportFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="跨越价"
                           prop="kyePrice">
              <kye-field>{{form.kyePrice|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>

        </kye-row>
        <h3 class="kye-block-title">费用信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="发票类型"
                           prop="invoiceType">
              <kye-field>{{form.invoiceType|invoice}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="运费"
                           prop="transportFee">
              <kye-field>{{form.transportFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="装卸费"
                           prop="loadFee">
              <kye-field>{{form.loadFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="回单费"
                           prop="receiptFee">
              <kye-field>{{form.receiptFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="保价金额"
                           prop="insuredMoney">
              <kye-field>{{form.insuredMoney|money}}
              </kye-field>

            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="保价费"
                           prop="insuredFee">
              <kye-field>{{form.insuredFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总报价"
                           prop="countFee">
              <kye-field>{{form.countFee|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <template v-if="$route.params.status==100">
          <h3 class="kye-block-title">费用确认</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="押车费"
                             prop="escortFee">
                <kye-field>{{form.escortFee|money}}
                </kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超里程费"
                             prop="exceedMileageFee">
                <kye-field>{{form.exceedMileageFee|money}}
                </kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="空驶费"
                             prop="emptyPlyFee">
                <kye-field>{{form.emptyPlyFee|money}}
                </kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="其他费用"
                             prop="otherFee">
                <kye-field>{{form.otherFee|money}}
                </kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </template>
      </kye-form>
    </kye-expand-page>
    <kye-dialog v-bind="dialogOption"
                :view.sync="dialogOption.view"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :data="form"
                 @close="dialogOption.show = false"
                 @confirmOrder="confirmOrder">
      </component>
    </kye-dialog>

  </div>
</template>
<script>
  import mixins from 'public/mixins'
  // 倒计时
  import countDown from '../components/count-down'
  // 格式化
  import { formatTime } from '../../utils/format'
  // 弹窗
  import dialogs from './dialog'
  export default {
    mixins: [mixins],
    components: {
      countDown,
      dialogs
    },
    filters: {
      invoice: function (value) {
        if (!value) {
          return ''
        } else if (value === 'noInvoice') {
          return '收据'
        } else if (value === 'ordinaryInvoice') {
          return '增值普通发票6%'
        } else if (value === 'specialInvoice') {
          return '增值专用发票6%'
        } else if (value === 'transportInvoice') {
          return '增值运输发票10%'
        }
      }
    },
    computed: {
      formTools: function () {
        let tool = []
        let status = this.form.status
        if (status === 200) {
          tool.push(this.searchTools[2])
        } else if (status === 100 || status === 300) {
          tool.push(this.searchTools[0])
          tool.push(this.searchTools[3])
        } else if (status === 410) {
          tool.push(this.searchTools[0])
        } else if (status === 400) {
          tool.push(this.searchTools[0])
          tool.push(this.searchTools[4])
          tool.push(this.searchTools[5])
        } else if (status === 102 || status === 301 || status === 302 || status === 401 || status === 402 || status === 101 || status === 403 || status === 501) {
          tool.push(this.searchTools[1])
        }
        return tool
      }
    },
    data () {
      return {
        dialogOption: {
          width: '360px',
          title: '确认下单',
          show: false,
          view: '',
        }, // 确认下单弹框
        saveBtn: false,
        endTime: 0, // 报价倒计时时间戳
        option: {
          back: '/ecms/whole-car/price-manage/index',
          method: 'zc.erp.getErpCarDispatchEntityList',
          searchCode: 'ecs_zc_price_list_search_define',
          idKey: 'taskCode',
        },
        data: [],
        form: {
          status: ''
        },
        searchTools: [
          {
            label: '取消订单',
            icon: 'close',
            auth: 'zc.erp.cancelCarDispatchEntity.do',
            func: () => {
              this.$confirm('是否要取消该订单？', '提示', '是否继续?').then(() => {
                this.$http('zc.erp.cancelCarDispatchEntity.do', { taskCode: this.form.taskCode }).then(res => {
                  this.$message.success('取消成功')
                  this.$refreshMainQueryTable()
                  // this.$bus.$emit('ECS_WHOLE_CAR_RefreshPriceIndex')
                  this.$router.push({
                    path: '/ecms/whole-car/price-manage/index',
                    // name: 'priceManageAdd',
                  })
                })
              })
            }
          },
          {
            label: '重新询价',
            icon: 'ecs-zhongxinxunjia',
            auth: 'zc.inquiry.submitPrice.do',
            func: () => {
              this.gotoInquiry()
            }
          },
          {
            label: '确认费用',
            icon: 'ecs-querenfeiyong',
            auth: 'zc.erp.ConfirmCustomerFeeStatus.do',
            func: () => {
              this.confirmFee()
            }
          },
          {
            label: '去报价',
            icon: 'ecs-querenbaojia',
            auth: 'zc.inquiry.submitPrice.do',
            func: () => {
              this.$router.push({
                path: '/ecms/whole-car/price-manage/edit/' + this.$route.params.id,
                query: {
                  sp: '1'
                }
              })
            }
          },
          {
            label: '确认下单',
            icon: 'ecs-koukuanshenhe',
            auth: 'zc.erp.confirmCargoOrder.do',
            func: () => {
              this.openConfirmQDialog()
            }
          },
          {
            label: '修改报价',
            icon: 'ecs-xiugaibaojia',
            auth: 'zc.inquiry.submitPrice.do',
            func: () => {
              this.$router.push({
                path: '/ecms/whole-car/price-manage/edit/' + this.$route.params.id,
              })
            }
          },
        ],
        modeData: {},
        column: [
          {
            key: 'goodsSN',
            label: '计提对象',
            show: true,
            width: '350px',
            colorchange: true
          },
          {
            key: 'fromCity',
            label: '姓名',
            show: true,
            width: '350px'
          },
          {
            key: 'packageNum',
            label: '计提比例(%)',
            show: true,
            width: '350px'
          },
          {
            key: 'updatedBy',
            label: '计提金额(元)',
            show: true,
            width: '350px'
          }
        ],
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.getDetail()
          vm.getQueryPrice()
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.getDetail(to.params.id)
      this.getQueryPrice()
      next()
    },
    methods: {
      async getDetail (id = this.$route.params.id) {
        const data = {
          taskCode: id
        }
        this.form = {}
        const res = await this.$http('zc.erp.getCarDispatchBytaskCodeList', data)
        this.form = { ...res.carDispatchEntity, ...res.cargoDispatchDetailEntity, kyePrice: res.kyePrice, kyePriceMask: res.kyePriceMask, dispatcher: res.dispatcher, dispatcherPhone: res.dispatcherPhone }
        this.changeStatus(this.form.status)
        this.form['loadingTimeStr'] = formatTime(this.form.loadingTime, 'M')
        this.form['createTimeStr'] = formatTime(this.form.createTime, 'M')
        this.form['channelStr'] = this.form.channel === 1 ? '400' : 'app下单'
        this.form['carTypeStr'] = this.form.carLength + '米' + this.form.carTypeName
        this.form['confirmQuoteTimeStr'] = formatTime(this.form.confirmQuoteTime, 'M')
        this.form['signingTimeStr'] = formatTime(this.form.signingTime, 'M')
        this.form.startAddressStr = this.changeAddress(res.carDispatchEntity.startProvince, res.carDispatchEntity.startCity, res.carDispatchEntity.startArea, res.carDispatchEntity.startAddress)
        this.form.endAddressStr = this.changeAddress(res.carDispatchEntity.endProvince, res.carDispatchEntity.endCity, res.carDispatchEntity.endArea, res.carDispatchEntity.endAddress)
        this.form['loadServiceStr'] = this.form.loadService === 1 ? '是' : '否'
        this.form['unloadServiceStr'] = this.form.unloadService === 1 ? '是' : '否'
        this.form['isTailboardStr'] = this.form.isTailboard === 1 ? '是' : '否'
        this.form['isReceiptStr'] = this.form.isReceipt === 1 ? '是' : '否'
        this.form['statusStr'] = this.changeStatus(this.form.status)
        if (this.form.status === 400) {
          this.endTime = Math.round(this.form.createTime / 1000) + 60 * 60 * 2
        } else if (this.form.status === 100 || this.form.status === 300) {
          this.endTime = Math.round(this.form.createTime / 1000) + 60 * 60
        } else if (this.form.status === 410) {
          this.endTime = Math.round(this.form.confirmQuoteTime / 1000) + 60 * 60 * 0.5
        }
      },
      showDynamicDialog (view, title, width = '360px') {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
      },

      changeStatus (status) {
        if (status === 200) {
          return '待确认'
        } else if (status === 100 || status === 300) {
          return '待报价'
        } else if (status === 410) {
          return '待支付'
        } else if (status === 400) {
          return '已报价'
        } else if (status === 500) {
          return '待取货'
        } else if (status === 600) {
          return '取货中'
        } else if (status === 700) {
          return '已取货'
        } else if (status === 800) {
          return '已签收'
        } else if (status === 102 || status === 301 || status === 302 || status === 401 || status === 402) {
          return '已超时'
        } else if (status === 101 || status === 403 || status === 501) {
          return '已取消'
        }
      },
      callback () {
        this.getDetail(this.$route.params.id)
      },
      confirmQuo () {
        let data = {
          id: this.form.id,
          isReceipt: this.form.isReceipt,
          receiptFee: Number(this.form.receiptFee),
          isInsured: this.form.isInsured,
          loadFee: Number(this.form.loadFee),
          isTailboard: this.form.isTailboard,
          loadService: this.form.loadService,
          unloadService: this.form.unloadService,
          transportFee: Number(this.form.transportFee),
          insuredMoney: Number(this.form.insuredMoney),
          countFee: Number(this.form.countFee),
          insuredFee: Number(this.form.insuredFee),
          invoiceType: this.form.invoiceType
        }
        this.$http('zc.inquiry.submitPrice.do', this.$diff(data, '**')).then(res => {
          if (res === 'OK') {
            this.$message.success('保存成功')
            this.cancelSave()
            // this.$bus.$emit('ECS_WHOLE_CAR_RefreshPriceIndex')
            this.$refreshMainQueryTable()
            this.$router.push({
              path: '/ecms/whole-car/price-manage/index',
            })
          }
        })
      },
      confirmFee () {
        const data = {
          taskCode: this.form.taskCode
        }
        this.$http('zc.erp.ConfirmCustomerFeeStatus.do', data).then(res => {
          // this.$bus.$emit('ECS_WHOLE_CAR_RefreshPriceIndex')
          this.$refreshMainQueryTable()
          this.$message.success('操作成功')
          this.$router.push({
            path: '/ecms/whole-car/price-manage/index',
          })
        })
      },
      cancelSave () {
        this.saveBtn = false
      },
      openConfirmQDialog () {
        this.showDynamicDialog('dialogs', '确认下单', '600px')
      },
      async confirmOrder (data) {
        const customerData = await this.$http('crm.customer.sync.search', { customerCode: this.form.companyNo })
        let payMode
        if (customerData.rows[0].payMode === '40') {
          payMode = '月结'
        } else if (customerData.rows[0].payMode === '30') {
          payMode = '半月结'
        } else if (customerData.rows[0].payMode === '20') {
          payMode = '周结'
        } else {
          payMode = '现结'
        }
        let datas = {
          contactPhone: data.contactPhone,
          contactName: data.contactName,
          addresserName: data.addresserName,
          addresserPhone: data.addresserPhone,
          taskCode: this.form.taskCode,
          payMode: payMode
        }
        this.$router.push({
          path: '/ecms/whole-car/price-manage/index'
        })
        this.$http('zc.erp.confirmCargoOrder.do', this.$diff(datas, '**')).then(res => {
          if (res === '确定下单成功') {
            // this.$bus.$emit('ECS_WHOLE_CAR_RefreshPriceIndex')
            this.$refreshMainQueryTable()
            this.$router.push({
              path: '/ecms/whole-car/price-manage/index'
            })
            this.$message.success('下单成功')
          }
        })
      },
      gotoInquiry () {
        let params = {
          form: this.form
        }
        for (let i in params.form) {
          if (i === 'companyName' && params.form[i] === '*****') {
            this.$message.info('请先解除公司简称监控字段')
            return
          } else if (i === 'phone' && params.form[i] === '*****') {
            this.$message.info('请先解除联系电话监控字段')
            return
          }
        }
        // sessionStorage.setItem('ECS_WHOLECAR_reInquiryParams', JSON.stringify(params))
        this.$store.commit('ecms/SET_ECS_WHOLECAR_REPARAMS', params)
        this.$bus.$emit('refreshData')
        this.$router.push({
          path: '/ecms/whole-car/price-manage/reInquiry/' + this.$route.params.id
        })
      },
      changeAddress (province, city, district, address) {
        if (address.indexOf(province) >= 0) {
          address = address.split(province).join('')
        }
        if (address.indexOf(city) >= 0) {
          address = address.split(city).join('')
        }
        if (address.indexOf(district) >= 0) {
          address = address.split(district).join('')
        }
        if (province === city) {
          return province + district + address
        } else {
          return province + city + district + address
        }
      },
      async getQueryPrice () {
        let data = {
          taskCode: this.form.taskCode
        }
        await this.$http('zc.inquiry.getQueryPrice.do', data).then(res => {
          this.form.averageTransportFee = res.averageMarketPrice
        })
      }

    }
  }
</script>
<style lang="scss" scoped>
  .operoperation-btn {
    button {
      margin-bottom: 10px;
    }
    .btn-right {
      text-align: right;
    }
  }
  .timer {
    display: flex;
    width: 300px;
    margin: 10px auto;
    span {
      padding-right: 20px;
    }
  }
  .kye-btn {
    width: 200px;
    margin: 20px auto;
  }

  .kye-block-gray {
    margin-bottom: 16px;
    padding-left: 12px;
    font-size: 12px;
    color: #666666;
    font-weight: 500;
    height: 32px;
    line-height: 32px;
    background: #f8f8fa;
    span {
      font-size: 12px;
      color: #000000;
    }
  }
  .mg-t10 {
    margin-top: 10px;
  }
</style>
