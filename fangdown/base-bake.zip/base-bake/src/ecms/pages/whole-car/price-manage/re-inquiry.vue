<template>
  <div class="whole-car-detail">
    <search-pager :option="option"
                  :tools="searchTools"></search-pager>
    <kye-expand-page>
      <kye-form ref="form"
                :model="form"
                label-position="left"
                :rules="rules">
        <h3 class="kye-block-title">基本信息</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="公司简称"
                           prop="shortCompanyName">
              <kye-search-tips v-model="form.shortCompanyName"
                               url="crm.customer.sync.search"
                               value-key="customerShortName"
                               :keys="['customerShortName']"
                               placeholder="请输入公司简称"
                               :format-data="formatShortCompanyData"
                               :warning=false
                               @select="handleShortCompany">
              </kye-search-tips>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4"
                   class="tow-input-wrap">
            <kye-form-item label="货好时间"
                           prop="lodingTime">
              <kye-date-picker v-model="form.lodingTime"
                               type="datetime"
                               placeholder="选择日期"
                               :picker-options="pickerOptions"
                               value-format="yyyy-MM-dd HH:mm"
                               :default-value="new Date().getTime()+1000*60*60*3+1000*60*3">
              </kye-date-picker>
            </kye-form-item>
          </kye-col>
          <!-- <kye-col :span="4">
          <kye-form-item label="创建时间">
            <kye-input :disabled="dqrFlag"
                       v-model="ruleForm.follow.followDetail.agent"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="下单时间">
            <kye-input :disabled="dqrFlag"
                       v-model="ruleForm.follow.followDetail.agentNumber"></kye-input>
          </kye-form-item>
        </kye-col> -->
          <kye-col :span="4">
            <kye-form-item label="客户姓名"
                           prop="clientName">
              <kye-input :disabled="dqrFlag"
                         v-model="form.clientName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="联系电话"
                           prop="phone">
              <kye-input :disabled="dqrFlag"
                         v-model="form.phone"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="车型"
                           prop="carId">
              <kye-select v-model="form.carId"
                          placeholder="请选择"
                          :disabled="dqrFlag"
                          @change="getCarInfo">
                <kye-option :key="i"
                            :value="op.id"
                            :label="op.carExtent+'米 '+op.carTypeName"
                            v-for="(op, i) in carData"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="托寄物"
                           prop="goodsName">
              <kye-input :disabled="dqrFlag"
                         v-model="form.goodsName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总重量"
                           prop="carWeight">
              <kye-number v-model="form.carWeight"
                          unit="kg"
                          :precision="0"
                          :disabled="dqrFlag||carInfoFlag">
              </kye-number>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总体积"
                           prop="carCubage">
              <kye-number v-model="form.carCubage"
                          unit="m³"
                          :precision="0"
                          :disabled="dqrFlag||carInfoFlag">
              </kye-number>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="始发地"
                           prop="startAddress">
              <kye-input :disabled="dqrFlag"
                         v-model="form.startAddressStr"
                         id="startMapInput"
                         @focus="showMap('start')"></kye-input>

            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="目的地"
                           prop="endAddress">
              <kye-input :disabled="dqrFlag"
                         v-model="form.endAddressStr"
                         id="endMapInput"
                         @focus="showMap('end')"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="市场员">
              <kye-input :disabled="true"
                         v-model="form.marketName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="市场电话">
              <kye-input :disabled="true"
                         v-model="form.marketPhone"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="市场助理">
              <kye-input :disabled="true"
                         v-model="form.assistantName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="助理电话">
              <kye-input :disabled="true"
                         v-model="form.assistantPhone"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="备注">
              <kye-input :disabled="dqrFlag"
                         v-model="form.remark"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">增值服务</h3>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="装货服务"
                           prop="loadingService">
              <kye-select v-model="form.loadingService"
                          placeholder="请选择"
                          :disabled="dqrFlag">
                <kye-option v-for="item in lookUpOptions['ecs_zc_loadservice']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="卸货服务"
                           prop="unloadingService">
              <kye-select v-model="form.unloadingService"
                          placeholder="请选择"
                          :disabled="dqrFlag">
                <kye-option v-for="item in lookUpOptions['ecs_zc_unloadservice']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="需要尾板"
                           prop="isTailboard">
              <kye-select v-model="form.isTailboard"
                          placeholder="请选择"
                          :disabled="dqrFlag">
                <kye-option v-for="item in lookUpOptions['ecs_zc_istailboard']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="回单服务"
                           prop="returnService">
              <kye-select v-model="form.returnService"
                          placeholder="请选择"
                          :disabled="dqrFlag">
                <kye-option v-for="item in lookUpOptions['ecs_zc_isreceipt']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <h3 class="kye-block-title">保价服务</h3>
        <kye-row>
          <kye-col :span="5">
            <kye-form-item label="保价金额"
                           prop="computePremium">
              <kye-number v-model="form.computePremium"
                          placeholder="请输入"
                          unit="万元"
                          :precision="2"
                          :disabled="dqrFlag"
                          @change="computePremium">
              </kye-number>

            </kye-form-item>
          </kye-col>
          <kye-col :span="5">
            <kye-form-item label="保价费">
              <kye-field>{{form.premium|money}}
              </kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <b-Map :id="'startMap'"
             @update="changeData"
             v-show="startAddFlag"
             :address="form.startAddress"
             ref="sbmap"></b-Map>
      <b-Map :id="'endMap'"
             @update="changeData2"
             v-show="endAddFlag"
             :address="form.endAddress"
             ref="ebmap"></b-Map>
    </kye-expand-page>
  </div>
</template>
<script>
  // 公共模块
  import mixins from 'public/mixins'
  // 倒计时
  import countDown from '../components/count-down'
  // 百度地图组件
  import bMap from '../components/baidu-map'
  // 百度地图SDK
  import { requireSDK } from '@/shared/components/kye-map/utils.js'
  import routeHook from 'public/mixins/route-hook'
  export default {
    mixins: [mixins, routeHook],
    components: {
      countDown,
      bMap
    },
    beforeCreate () {
      requireSDK()
    },
    data () {
      const validatorDate = (rule, value, callback) => {
        if (value > Number(rule.max)) {
          callback(new Error(rule.message))
        } else {
          callback()
        }
      }
      const validatorDate2 = (rule, value, callback) => {
        if (new Date(value).getTime() < Date.now() + 1000 * 60 * 60 * 3) {
          callback(new Error('货好时间需大于当前三小时后'))
        } else {
          callback()
        }
      }
      const validatorPhone = (rule, value, callback) => {
        if (!(/^1[3|4|5|6|7|8|9][0-9]\d{8}$/).test(value)) {
          callback(new Error('手机号码格式错误'))
        } else {
          callback()
        }
      }
      const validatorPremium = (rule, value, callback) => {
        if (Number(value) < 5 || Number(value) > 500) {
          if (Number(value) !== 0) {
            callback(new Error(rule.message))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
      return {
        clearCache: false,
        dqrFlag: false,
        dbjFlag: false,
        carInfoFlag: true,
        startAddFlag: false,
        endAddFlag: false,
        reForm: {},
        option: {
          back: '/ecms/whole-car/price-manage/index',
          pageFooter: true,
          title: ''
        },
        data: [],
        startAddressData: '',
        searchTools: [
          {
            label: '保存',
            icon: 'save1',
            auth: 'zc.inquiry.insert.do',
            disabled: false,
            func: () => {
              this.submitForm('form')
            }
          },
          {
            label: '取消',
            icon: 'cancel1',
            auth: 'zc.inquiry.insert.do',
            func: () => {
              this.BACK_HOOK_MODULE()
            }
          }
        ],
        rules: {
          carId: [
            { required: true, message: '请选择车型', trigger: 'change' }
          ],
          carCubage: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorDate, message: '体积上限', trigger: 'blur' }
          ],
          carWeight: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorDate, message: '重量上限', trigger: 'blur' }
          ],
          loadingService: [
            { required: true, message: '必填', trigger: 'change' },
          ],
          unloadingService: [
            { required: true, message: '必填', trigger: 'change' },
          ],
          isTailboard: [
            { required: true, message: '必填', trigger: 'change' },
          ],
          returnService: [
            { required: true, message: '必填', trigger: 'change' },
          ],
          lodingTime: [
            { required: true, message: '必选', trigger: 'change' },
            { validator: validatorDate2, trigger: 'change' }
          ],
          shortCompanyName: [
            { required: true, message: '必选', trigger: 'change' },
          ],
          clientName: [
            { required: true, message: '必填', trigger: 'blur' },
          ],
          phone: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorPhone, trigger: 'blur' }

          ],
          goodsName: [
            { required: true, message: '必填', trigger: 'blur' },
          ],
          startAddress: [
            { message: '必填', trigger: 'blur', required: true },
          ],
          endAddress: [
            { message: '必填', trigger: 'blur', required: true },
          ],
          computePremium: [
            { message: '保价金额范围5万-500万', trigger: 'blur', validator: validatorPremium },
          ],
        },
        carData: [],
        form: {
          carId: '', // 车Id
          carType: '', // 车型
          carCubage: '', // 车体积
          carWeight: '', // 车重量
          carLength: '', // 车长
          shortCompanyName: '', // 公司简称
          // originPlace: '', // 始发地
          // destination: '', // 目的地
          loadingService: '', // 装车服务
          unloadingService: '', // 卸车服务
          isTailboard: '', // 需要尾板
          returnService: '', // 回单服务
          computePremium: '', // 保价金额
          premium: '', // 总保价
          marketName: '', // 市场员
          marketPhone: '', // 市场电话
          assistantName: '', // 助理姓名
          assistantPhone: '', // 助理电话
          loadingTime: '', // 货好时间
          clientName: '', // 客户名称
          phone: '', // 客户电话
          goodsName: '', // 托寄物
          remark: '', // 备注
          carChildName: '', // 车类型字名称类型（如 面包车（金杯）
          carTypeName: '', // 车辆类型名称
          companyNo: '', // 公司编码
          payMode: '', // 月结方式
          startAddress: '',
          endAddress: '',
          startLongitude: '',
          startLatitude: '',
          endLongitude: '',
          endLatitude: '',
          insuredFeeTax: 0, // 保价费率
        },
        startAddressBd: {},
        endAddressBD: {},
        pickerOptions: {
          disabledDate (time) {
            // let threeHour = Date.now() + 1000 * 60 * 60 * 3
            return time.getTime() < Date.now() - 8.64e7 // 大于当前时间
          }
        },

      }
    },
    created () {
      this.getCarStandardType()
      this.$bus.$on('refreshData', res => {
        this.getReInquiryData()
        this.getCarStandardType()
      })
    },
    mounted () {
      this.$nextTick(() => {
        this.getReInquiryData()
      })
    },
    beforeRouteLeave: function (to, from, next) {
      if (this.clearCache) { // 此处判断是否动态清除本业缓存。
        if (this.$vnode && this.$vnode.data.keepAlive) {
          if (this.$vnode.parent && this.$vnode.parent.componentInstance && this.$vnode.parent.componentInstance.cache) {
            if (this.$vnode.componentOptions) {
              var key = this.$vnode.key == null
                ? this.$vnode.componentOptions.Ctor.cid + (this.$vnode.componentOptions.tag ? `::${this.$vnode.componentOptions.tag}` : '')
                : this.$vnode.key
              var cache = this.$vnode.parent.componentInstance.cache
              var keys = this.$vnode.parent.componentInstance.keys
              if (cache[key]) {
                if (keys.length) {
                  var index = keys.indexOf(key)
                  if (index > -1) {
                    keys.splice(index, 1)
                  }
                }
                delete cache[key]
              }
            }
          }
        }
        this.$destroy()
      }
      next()
    },
    beforeDestroy () {
      this.$bus.$off('refreshData')
    },
    methods: {
      getReInquiryData () {
        let reInquiryParams = this.$store.getters['ecms/ecs_wholecar_reparams']
        this.reForm = reInquiryParams.form
        this.carInfoFlag = false
        this.form = {
          carId: this.reForm.carId,
          carType: this.reForm.carType + '', // 车型
          carCubage: this.reForm.countVolume, // 车体积
          carWeight: this.reForm.countWeight, // 车重量
          carLength: this.reForm.carLength, // 车长
          shortCompanyName: this.reForm.companyName, // 公司简称
          // originPlace: this.reForm.startAddress, // 始发地
          // destination: this.reForm.endAddress, // 目的地
          loadingService: this.reForm.loadService + '', // 装车服务
          unloadingService: this.reForm.unloadService + '', // 卸车服务
          isTailboard: this.reForm.isTailboard + '', // 需要尾板
          returnService: this.reForm.isReceipt + '', // 回单服务
          computePremium: this.reForm.insuredMoney / 10000, // 保价金额
          premium: this.reForm.countFee, // 总保价
          marketName: this.reForm.saleser, // 市场员
          marketPhone: this.reForm.saleserPhone, // 市场电话
          assistantName: this.reForm.assistant, // 助理姓名
          assistantPhone: this.reForm.assistantPhone, // 助理电话
          loadingTime: '', // 货好时间
          clientName: this.reForm.clientName, // 客户名称
          phone: this.reForm.phone, // 客户电话
          goodsName: this.reForm.goodsName, // 托寄物
          remark: this.reForm.remark, // 备注
          carChildName: this.reForm.carChildName, // 车类型字名称类型（如 面包车（金杯）
          carTypeName: this.reForm.carTypeName, // 车辆类型名称
          companyNo: this.reForm.companyNo, // 公司编码
          startAddress: this.reForm.startAddress,
          endAddress: this.reForm.endAddress,
          startLongitude: this.reForm.startLongitude,
          startLatitude: this.reForm.startLatitude,
          endLongitude: this.reForm.endLongitude,
          endLatitude: this.reForm.endLatitude,
          startAddressStr: this.reForm.startAddressStr,
          endAddressStr: this.reForm.endAddressStr
        }
        this.$refs.sbmap.setInputVal(this.reForm.startAddressStr)
        this.$refs.ebmap.setInputVal(this.reForm.endAddressStr)

        this.computePremium()
      },
      getCarStandardType () {
        const data = {
        }
        this.$http('zc.erp.getCarType', data).then(res => {
          this.carData = res
          for (let i = 0; i < this.carData.length; i++) {
            this.carData[i]['id'] = this.carData[i]['id'] + ''
          }
        })
      },
      getCarInfo () {
        if (this.form.carId) {
          this.carInfoFlag = false
        }
        for (let i in this.carData) {
          if (this.carData[i].id === this.form.carId) {
            this.rules.carCubage[1].max = this.carData[i].carCubage
            this.rules.carCubage[1].message = '该车体积上限' + this.carData[i].carCubage
            this.rules.carWeight[1].max = this.carData[i].carWeight
            this.rules.carWeight[1].message = '该车重量上限' + this.carData[i].carWeight
            this.form.carLength = this.carData[i].carLength
            // this.form.carWeight = this.carData[i].carWeight
            this.form.carTypeName = this.carData[i].carTypeName
            this.form.carChildName = this.carData[i].carChildName
            this.form.carType = this.carData[i].carType
            // this.form.carCubage = this.carData[i].carCubage
            break
          }
        }
      },
      handleShortCompany (item) {
        if (!item) {
          this.form.shortCompanyName = ''
          return
        }
        this.form.marketName = item.marketName
        this.form.marketPhone = item.marketPhone
        this.form.assistantName = item.assistantName
        this.form.assistantPhone = item.assistantPhone
        this.form.companyNo = item.customerCode
        this.form.payMode = item.payMode
      },
      async computePremium () {
        if (this.form.insuredFeeTax) {
          this.form.premium = (Number(this.form.computePremium) * 10000 * this.form.insuredFeeTax)
        } else {
          const res = await this.$http('zc.clientele.getClientInsuredFee', {})
          this.form.insuredFeeTax = res
          this.form.premium = (Number(this.form.computePremium) * 10000 * res)
        }
      },
      submitForm (formName) {
        let lodingTime = new Date(this.form.lodingTime).getTime()
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            this.searchTools[0].disabled = true
            let startData, endData
            try {
              const startLnData = await this.$http('third.gaode.geocode', { address: this.form.startAddressStr })
              this.form.startLongitude = startLnData.geocodes[0].location.split(',')[0]
              this.form.startLatitude = startLnData.geocodes[0].location.split(',')[1]
            } catch (error) {
              this.$message.error('无法解析始发地经纬度，请重新尝试')
              this.searchTools[0].disabled = false
              return
            }
            try {
              const endLnData = await this.$http('third.gaode.geocode', { address: this.form.endAddressStr })
              this.form.endLongitude = endLnData.geocodes[0].location.split(',')[0]
              this.form.endLatitude = endLnData.geocodes[0].location.split(',')[1]
            } catch (error) {
              this.$message.error('无法解析目的地经纬度，请重新尝试')
              this.searchTools[0].disabled = false
              return
            }

            try {
              startData = await this.$http('zc.system.gaoDeAreaInfo.getGaoDeAdress.do', { longitude: this.form.startLongitude, latitude: this.form.startLatitude })
            } catch (error) {
              this.$message.error('始发地地址有误，请重新选择地址')
              this.searchTools[0].disabled = false
              return
            }
            try {
              endData = await this.$http('zc.system.gaoDeAreaInfo.getGaoDeAdress.do', { longitude: this.form.endLongitude, latitude: this.form.endLatitude })
            } catch (error) {
              this.$message.error('目的地地址有误，请重新选择地址')
              this.searchTools[0].disabled = false
              return
            }
            let startAddress = this.changeAddress(startData.province, startData.city, startData.district, this.form.startAddressStr)
            let endAddress = this.changeAddress(endData.province, endData.city, endData.district, this.form.endAddressStr)
            const data = {
              companyName: this.form.shortCompanyName,
              clientName: this.form.clientName,
              phone: this.form.phone,
              loadingTime: lodingTime,
              carLength: this.form.carLength,
              startAddress: startAddress,
              endAddress: endAddress,
              countWeight: this.form.carWeight,
              countVolume: this.form.carCubage,
              goodsName: this.form.goodsName,
              channel: '1',
              loadService: this.form.loadingService,
              unloadService: this.form.unloadingService,
              isTailboard: this.form.isTailboard,
              isReceipt: this.form.returnService,
              carChildName: this.form.carChildName, // 车类型字名称类型（如 面包车（金杯）
              carTypeName: this.form.carTypeName,
              carType: this.form.carType,
              lineType: '20',
              roleType: '1',
              startAreaId: startData.districtId,
              startCityId: startData.cityId,
              startProvinceId: startData.provinceId,
              endAreaId: endData.districtId,
              endCityId: endData.cityId,
              endProvinceId: endData.provinceId,
              endArea: endData.district,
              endCity: endData.city,
              endProvince: endData.province,
              startArea: startData.district,
              startCity: startData.city,
              startProvince: startData.province,
              endLatitude: this.form.endLatitude,
              endLongitude: this.form.endLongitude,
              startLatitude: this.form.startLatitude,
              startLongitude: this.form.startLongitude,
              companyNo: this.form.companyNo,
              saleser: this.form.marketName,
              saleserPhone: this.form.marketPhone,
              assistant: this.form.assistantName,
              assistantPhone: this.form.assistantPhone,
              addresserName: this.form.clientName,
              addresserPhone: this.form.phone,
              insuredMoney: this.form.computePremium > 0 ? this.form.computePremium * 10000 : 0,
              insuredFee: this.form.premium,
              remark: this.form.remark,
              payMode: this.form.payMode,
              isInsured: this.form.premium > 0 ? '1' : '2'
            }
            if (this.$route.params.type === 'reset') {
              data['taskCode'] = this.reForm.taskCode
            }
            try {
              const res = await this.$http('zc.inquiry.insert.do', data)
              this.searchTools[0].disabled = false
              if (res) {
                this.$message.success('重新询价成功')
                this.clearCache = true
                this.$refreshMainQueryTable()
                this.SET_SAVE_HOOK_FLAG()
                this.$router.push({
                  path: '/ecms/whole-car/price-manage/detail/' + res
                })
              }
            } catch (error) {
              this.searchTools[0].disabled = false
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      formatShortCompanyData (val) {
        let obj = {
          page: 1,
          pageSize: 10,
          customerShortName: val

        }
        return obj
      },
      changeData (res) {
        this.form.startAddressStr = res.address
        this.form.startAddressDetail = res.detailAddress
      },
      changeData2 (res) {
        this.form.endAddressStr = res.address
        this.form.endAddressDetail = res.detailAddress
      },
      showMap (type) {
        if (type === 'start') {
          this.startAddFlag = true
          this.endAddFlag = false
        } else {
          this.startAddFlag = false
          this.endAddFlag = true
        }
        this.startAddFlag = false
        this.endAddFlag = false
      },
      goback () {
        this.$router.push({
          path: '/ecms/whole-car/price-manage/index'
        })
      },
      changeAddress (province, city, district, address) {
        if (address.indexOf(province) >= 0) {
          address = address.split(province).join('')
        }
        if (address.indexOf(city) >= 0) {
          address = address.split(city).join('')
        }
        if (address.indexOf(district) >= 0) {
          address = address.split(district).join('')
        }
        return address
      }
    }
  }
</script>
<style lang="scss" scoped>
  .operoperation-btn {
    button {
      margin-bottom: 10px;
    }
    .btn-right {
      text-align: right;
    }
  }
  .timer {
    display: flex;
    width: 300px;
    margin: 20px auto;
    span {
      padding-right: 20px;
    }
  }
  .kye-btn {
    width: 200px;
    margin: 20px auto;
  }
  .kye-field-content {
    background-color: #f1f1f5;
    border-color: #dcdae2;
    color: #333333;
    cursor: not-allowed;
  }
</style>
