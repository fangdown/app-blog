<template>
  <div>
    <div class="kye-dialog-body">
      <kye-form ref="form"
                :model="form"
                label-position="left"
                :rules="rules">
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="发件人姓名"
                           prop="addresserName">
              <kye-input v-model="form.addresserName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="发件人电话"
                           prop="addresserPhone">
              <kye-input v-model="form.addresserPhone"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="收件人姓名"
                           prop="contactName">
              <kye-input v-model="form.contactName"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="收件人电话"
                           prop="contactPhone">
              <kye-input v-model="form.contactPhone"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
    </div>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  @click="submit('form')"
                  hotkey="ctrl+s">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      id: String,
      data: Object
    },
    data () {
      const validatorPhone = (rule, value, callback) => {
        if (!(/^1[3|4|5|6|7|8|9][0-9]\d{8}$/).test(value)) {
          callback(new Error('手机号码格式错误'))
        } else {
          callback()
        }
      }
      return {
        form: {
          addresserName: this.data.clientName || '',
          addresserPhone: this.data.phone === '*****' ? '' : this.data.phone || '',
          contactName: '',
          contactPhone: ''
        },
        rules: {
          addresserName: [
            { required: true, message: '必填', trigger: 'blur' }
          ],
          addresserPhone: [
            { required: true, message: '必填', trigger: 'blur' },
            { validator: validatorPhone, message: '手机格式错误', trigger: 'blur' }
          ],
          contactName: [
            { required: true, message: '必填', trigger: 'blur' },
          ],
          contactPhone: [
            { required: true, message: '必填', trigger: 'change' },
            { validator: validatorPhone, message: '手机格式错误', trigger: 'blur' }

          ],
        },
      }
    },
    methods: {
      close () {
        // 通知父组件关闭弹框
        this.$emit('close')
      },
      submit (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            let data = {
              addresserName: this.form.addresserName,
              addresserPhone: this.form.addresserPhone,
              contactName: this.form.contactName,
              contactPhone: this.form.contactPhone
            }
            this.$emit('confirmOrder', data)
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      }
    }
  }
</script>
