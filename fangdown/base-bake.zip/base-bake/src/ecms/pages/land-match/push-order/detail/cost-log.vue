<template>
  <div class="delivery-log">
    <kye-table ref="deliveryLogTable"
               :data="costLog"
               tooltip-effect="dark"
               show-overflow-tooltip
               style="width: 100%">
      <kye-table-column type="index"
                        label="序号"
                        width="50">
      </kye-table-column>
      <kye-table-column prop="ydCode"
                        label="运单号"
                        show-overflow-tooltip
                        width="100px">
      </kye-table-column>
      <kye-table-column prop="taskCode"
                        label="任务编码"
                        show-overflow-tooltip
                        width="150px">
      </kye-table-column>
      <kye-table-column prop="createTime"
                        label="流向时间"
                        show-overflow-tooltip
                        width="120px">
      </kye-table-column>
      <kye-table-column prop="operateInfo"
                        label="流向说明"
                        show-overflow-tooltip
                        width="auto">
      </kye-table-column>
    </kye-table>
  </div>
</template>
<script>
  export default {
    props: {
      costLog: Array
    }
  }
</script>
<style lang='scss' scoped>
</style>




