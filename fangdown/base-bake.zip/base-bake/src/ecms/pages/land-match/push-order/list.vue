<template>
  <div>
    <query-table ref="queryTable"
                 class="ecms-push-order"
                 :form-model="formModel"
                 :form-tools="formTools"
                 :option="option"
                 :generic="generic"
                 :tables="tables">
      <div slot="desc">
        <div class="push-operation">
          <kye-button type="text"
                      @click="pushOrderAction"
                      auth="ldp.ThirdDelivery.V1.Delivery.PushDelivery"
                      class="el-button--text el-button--mini"
                      icon="iconfont icon-ecs-tuidan">推单</kye-button>
          <kye-button type="text"
                      @click="cancelAction"
                      auth="ldp.ThirdDelivery.V1.Delivery.CancelDelivery"
                      class="el-button--text el-button--mini"
                      icon="iconfont icon-ecs-quxiaodingdan">取消推单</kye-button>
          <kye-button type="text"
                      @click="abnormalSend"
                      auth="ldp.ThirdDelivery.V1.Delivery.WaybillSearch"
                      class="el-button--text el-button--mini"
                      icon="iconfont icon-ecs-peisongyichang">配送异常</kye-button>
        </div>
      </div>
    </query-table>
    <!-- 推单start -->
    <kye-dialog :visible.sync="pushDialogShow"
                title="推单"
                width="600px">
      <div class="kye-dialog-body">
        <kye-form ref="pushFormArea"
                  :model="data2"
                  label-position="left">
          <kye-row>
            <kye-col :span="6">
              <kye-form-item label="平台名称"
                             prop="platformId"
                             :rules="[{ required: true, message: '请选择平台名称',trigger:'change'}]">
                <kye-select v-model="data2.platformId"
                            placeholder=''>
                  <kye-option v-for="item in lookUpOptions['ecs_ldp_platform_id']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="10">
              <kye-form-item label="推送门店"
                             prop="shopName"
                             auth="ldp.ThirdDelivery.V1.Delivery.SearchShopByName"
                             :rules="$rule.str('请选择推送门店',true)">
                <kye-search-tips v-model="data2.shopName"
                                 url="ldp.ThirdDelivery.V1.Delivery.SearchShopByName"
                                 value-key="shopName"
                                 :keys="['shopName']"
                                 :warning=false
                                 :input-length='1'
                                 placeholder=' '
                                 class="shopNameInput"
                                 @clear="clearable('shopName')"
                                 :format-data="storeFormatData"
                                 @select="storeHandleSelect">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="门店编码">
                <kye-input v-model="data2.shopCode"
                           class="shopCodeInput"
                           :disabled="true"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <div v-if="data2.platformId==10">
              <kye-col :span="6">
                <kye-form-item label="配送服务">
                  <kye-input v-model="deleServer"
                             :disabled="true"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="10">
                <kye-form-item label="时效">
                  <kye-number v-model="timeliness"
                              unit="min"
                              :disabled="true"
                              placeholder=''>
                  </kye-number>
                </kye-form-item>
              </kye-col>
            </div>
          </kye-row>
        </kye-form>
      </div>
      <div slot="footer">
        <kye-button type="primary"
                    :disabled="pushClick"
                    @click="pushOrder('pushFormArea')">确定</kye-button>
        <kye-button @click="closeOrder">取消</kye-button>
      </div>
    </kye-dialog>
    <!-- 推单end -->
    <!-- 取消推单start -->
    <kye-dialog :visible.sync="cancelDialogShow"
                title="取消推单"
                append-to-body>
      <kye-form ref="cancelFormArea"
                class="cancelPush"
                :model="ruleForm"
                size="mini">
        <kye-row>
          <kye-col v-if="platformShow=='10'">
            <kye-form-item label="取消原因"
                           prop="cancelReasonId"
                           :rules="[{ required: true, message: '请选择取消原因',trigger:'change'}]">
              <kye-select v-model="ruleForm.cancelReasonId"
                          placeholder="请选择取消原因">
                <kye-option label="顾客主动取消"
                            value="101"></kye-option>
                <kye-option label="顾客更改配送时间/地址"
                            value="102"></kye-option>
                <kye-option label="备货、包装、货品质量问题取消"
                            value="103"></kye-option>
                <kye-option label="其他接入方面的原因"
                            value="199"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col v-if="platformShow=='20'">
            <kye-form-item label="取消原因"
                           prop="cancelReasonId"
                           :rules="[{ required: true, message: '请选择取消原因',trigger:'change'}]">
              <kye-select v-model="ruleForm.cancelReasonId"
                          placeholder="请选择取消原因">
                <kye-option label="没有配送员接单"
                            value="1"></kye-option>
                <kye-option label="配送员没来取货"
                            value="2"></kye-option>
                <kye-option label="配送员态度太差"
                            value="3"></kye-option>
                <kye-option label="顾客取消订单"
                            value="4"></kye-option>
                <kye-option label="订单填写错误"
                            value="5"></kye-option>
                <kye-option label="配送员让我取消此单"
                            value="34"></kye-option>
                <kye-option label="配送员不愿上门取货"
                            value="35"></kye-option>
                <kye-option label="我不需要配送了"
                            value="36"></kye-option>
                <kye-option label="配送员以各种理由表示无法完成订单"
                            value="37"></kye-option>
                <kye-option label="其他"
                            value="10000"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col>
            <kye-form-item label="其他原因"
                           prop="otherReason">
              <kye-input type="textarea"
                         v-model="ruleForm.otherReason"
                         maxlength='50'
                         placeholder="输入取消推单原因"
                         :rows="5"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer">
        <kye-button type="primary"
                    :disabled="cancelClick"
                    @click="checkSubmit('cancelFormArea')">确定</kye-button>
        <kye-button @click="closeOrder">取消</kye-button>
      </div>
    </kye-dialog>
    <!-- 取消推单end -->
  </div>
</template>
<script>
  import URL from '../api'
  // 时间 YYYY-MM-DD
  import { date } from '@/public/utils/filter'
  import mixins from 'public/mixins/index'
  export default {
    mixins: [mixins],
    data () {
      return {
        pushDialogShow: false, // 推单
        cancelDialogShow: false, // 取消推单
        platformShow: '20', // 平台切换
        LDPtimerOut: null, // 延时器
        timeType: 10, // 日期类型
        endTime: this.getCurrentTime()[1], // 结束时间
        startTime: this.getCurrentTime()[0], // 开始时间
        pushClick: false, // 推单确定按钮是否禁用
        cancelClick: false, // 取消推单确定按钮是否禁用
        data2: {
          platformId: '', // 推送平台类型
          shopName: '', // 推送门店
          shopCode: '' // 门店编码
        },
        deleServer: '及时达', // 配送服务
        timeliness: '120', // 时效
        ruleForm: {
          cancelReasonId: '', // 取消原因id
          cancelReason: '', // 取消原因
          otherReason: '', // 输入的取消推单原因
        },
        ydcodes: [], // 推送单号
        ydCode: '',
        selectedRow: [], // 选中数据
        formTools: [
          {
            label: '刷新',
            auth: URL.waybillSearch,
            icon: 'reset',
            func: () => {
              let tableData = this.$refs.queryTable.getTableData() || []
              if (tableData.length <= 0) {
                this.$message.warning('无数据！')
                return false
              }
              this.refreshTable()
            }
          }
        ],
        option: {
          searchCode: 'ecs_ldp_push_order_search_define',
          // 所属点部
          receiverDept: {
            change: ({ key, value, model }) => { },
            labelKey: 'nodeName',
            valueKey: 'nodeName',
            remoteMethod: (val) => this.$http(URL.findByNodeNameAndFlag, { nodeName: val })
          },
          // 日期类型
          timeType: {
            change: ({ key, value, model }) => {
              if (value) {
                this.startTime = value[0]
                this.endTime = value[1]
              }
              if (key === 'sentTime') {
                this.timeType = 10
                this.$nextTick(() => {
                  let dom = this.$el.querySelector('.ecms-push-order .is-disabled input')
                  dom.value = ''
                })
              }
              if (key === 'pushTime') {
                this.timeType = 20
              }
            }
          },
          sentTime: {
            change: ({ key, value, model }) => {
              if (this.timeType === 10) {
                this.startTime = value[0]
                this.endTime = value[1]
              }
            }
          },
          pushTime: {
            change: ({ key, value, model }) => {
              if (this.timeType === 20) {
                this.startTime = value[0]
                this.endTime = value[1]
              }
            }
          },
          // 如果是派送日期 则订单状态禁用
          orderStatus: {
            disabled: () => {
              if (this.timeType === 10) return true
              return false
            }
          }
        },
        generic: {
          method: URL.waybillSearch,
          searchCode: 'ecs_ldp_push_order_list_field'
        },
        tables: [
          {
            searchCode: 'ecs_ldp_push_order_list_field',
            url: { method: URL.waybillSearch },
            option: {
              load: false,
              type: 'selection',
              moduleCode: 'ecs_ldp',
              detailAuth: URL.waybillSearchDetail,
              rowDblClick: this.rowDblClick,
              idKey: 'ydCode',
              // 点击查询按钮的钩子函数，data: post请求参数，model：表单model，返回 true 时可阻止查询(用来配合表单校验)
              beforeFormSubmit: (data, model) => {
                this.clearTimeoutLdp() // 关闭延时器
                const obj = {}
                for (let key in model) {
                  if (model[key]) {
                    obj[key] = model[key]
                  } else {
                    delete data[key]
                  }
                }
                if (model.receiverDept) {
                  let reArr = []
                  reArr.push(model.receiverDept)
                  obj['receiverDept'] = reArr
                }
                obj.timeType = this.timeType
                obj.endTime = this.endTime
                obj.startTime = this.startTime
                if (this.timeType === 10 && (!this.endTime || !this.startTime)) {
                  this.$message.warning('请选择派送日期')
                  return true
                }
                if (this.timeType === 20 && (!this.endTime || !this.startTime)) {
                  this.$message.warning('请选择推单日期')
                  return true
                }
                Object.assign(data, obj)
              },
              // 勾选
              selectionChange: (rows) => {
                this.ydcodes = []
                this.selectedRow = rows
                rows.forEach(item => {
                  this.ydcodes.push(item.ydCode)
                  this.ydCode = item.ydCode
                })
              },
            },
            buttonOptions: {
              'waitingOrderTime': {
                type: 'link',
                auth: URL.waybillSearchDetail,
                color: row => {
                  if (row.waitingOrderTime >= 5) {
                    return '#ff5555'
                  }
                },
                func: (row) => {
                  this.tables[0].option.rowDblClick(row)
                }
              },
              'ydCode': {
                type: 'link',
                auth: URL.waybillSearchDetail,
                color: row => {
                  if (row.waitingOrderTime >= 5) {
                    return '#ff5555'
                  }
                },
                func: (row) => {
                  this.tables[0].option.rowDblClick(row)
                }
              }
            }
          }
        ],
        formModel: {
          sentTime: this.getCurrentTime(),
          pushTime: this.getCurrentTime(),
          timeType: 10
        }
      }
    },
    beforeDestroy () {
      this.clearTimeoutLdp()
    },
    methods: {
      // 刷新
      refreshTable () {
        this.clearTimeoutLdp() // 关闭延时器
        this.$refs.queryTable.loadData()
      },
      // 清除门店名称
      clearable (param) {
        if (param === 'shopName') {
          this.data2.shopName = ''
        }
      },
      // 平台门店触发
      storeHandleSelect (item) {
        if (item) {
          this.data2.shopCode = item.shopCode
        }
        if (!item) {
          this.data2.shopName = ''
        }
      },
      // 平台门店名称
      storeFormatData (val) {
        this.data2.shopName = val
        if (!this.data2.platformId) {
          delete this.data2.platformId
        }
        let storeObj = {
          pushDept: val,
          platformId: this.data2.platformId
        }
        return storeObj
      },
      // 获取当前时间
      getCurrentTime () {
        let timeStamp = new Date().getTime()
        let date = this.$options.filters.date(timeStamp)
        let preDate = this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000))
        return [preDate + ' 00:00:00', date + ' 23:59:59']
      },
      // 点击显示推单弹窗
      pushOrderAction () {
        if (this.ydcodes.length === 0) {
          this.$alert('请选择要推送的运单', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
            }
          })
          return
        }
        if (this.ydcodes.length > 10) {
          this.$alert('每次推送运单数不能超过10条', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
            }
          })
          return
        }
        this.data2.platformId = ''
        this.data2.shopName = ''
        this.data2.shopCode = ''
        this.pushDialogShow = true
        this.$nextTick(() => {
          this.$refs.pushFormArea.resetFields()
        })
      },
      // 点击推单
      async pushOrder (formName) {
        this.clearTimeoutLdp() // 关闭延时器
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            this.pushClick = true
            try {
              let param = {
                platformId: this.data2.platformId,
                ydcodes: this.ydcodes,
                shopcode: this.data2.shopCode
              }
              this.$message.info('推送中')
              let result = await this.$http(URL.pushDelivery, param)
              this.pushClick = false
              this.pushDialogShow = false
              this.pushOrderData = result.waybills || [] // 推单传回的成功的数据
              this.failedOrderData = result.failed || [] // 推单传回的失败的数据
              if (this.failedOrderData.length > 0) {
                let failedStr = ''
                this.failedOrderData.forEach((param, index) => {
                  failedStr += ('订单号' + param.Item1 + '' + param.Item2 + '; ')
                  this.$alert(failedStr, '推单失败', {
                    confirmButtonText: '我知道了',
                    type: 'warning',
                    callback: action => {
                      this.LDPtimerOut = setTimeout(() => {
                        this.refreshTable()
                      }, 3000)
                    }
                  })
                })
              } else {
                this.$alert('已推送到平台，等待平台处理，请稍后查看!', '推单成功', {
                  confirmButtonText: '我知道了',
                  type: 'success',
                  callback: action => {
                    this.LDPtimerOut = setTimeout(() => {
                      this.refreshTable()
                    }, 3000)
                  }
                })
              }
            } catch (e) {
              this.pushClick = false
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 关闭推单弹窗
      closeOrder (param) {
        this.pushDialogShow = false
        this.cancelDialogShow = false
      },
      // 点击取消推单
      cancelAction () {
        if (this.selectedRow.length === 1) {
          this.ruleForm.cancelReasonId = ''
          this.cancelDialogShow = true
          let platformId = this.selectedRow[0].platformId
          if (platformId === 10) {
            this.platformShow = '10'
          } else if (platformId === 20) {
            this.platformShow = '20'
          }
          this.$nextTick(() => {
            this.$refs.cancelFormArea.resetFields()
          })
        } else {
          this.$alert('请选择一条取消推单', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
            }
          })
        }
      },
      // 点击取消推单确定
      async checkSubmit (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            this.cancelClick = true
            // 取消原因
            switch (this.ruleForm.cancelReasonId) {
              case '101':
                this.ruleForm.cancelReason = '顾客主动取消'
                break
              case '102':
                this.ruleForm.cancelReason = '顾客更改配送时间/地址'
                break
              case '103':
                this.ruleForm.cancelReason = '备货、包装、货品质量问题取消'
                break
              case '199':
                this.ruleForm.cancelReason = '其他接入方原因'
                break
              case '1':
                this.ruleForm.cancelReason = '没有配送员接单'
                break
              case '2':
                this.ruleForm.cancelReason = '配送员没来取货'
                break
              case '3':
                this.ruleForm.cancelReason = '配送员态度太差'
                break
              case '4':
                this.ruleForm.cancelReason = '顾客取消订单'
                break
              case '5':
                this.ruleForm.cancelReason = '订单填写错误'
                break
              case '34':
                this.ruleForm.cancelReason = '配送员让我取消此单'
                break
              case '35':
                this.ruleForm.cancelReason = '配送员不愿上门取货'
                break
              case '36':
                this.ruleForm.cancelReason = '我不需要配送了'
                break
              case '37':
                this.ruleForm.cancelReason = '配送员以各种理由表示无法完成订单'
                break
              case '10000':
                this.ruleForm.cancelReason = '其他'
                break
              default:
                break
            };
            try {
              let param = {
                ydCode: this.ydCode,
                cancelReasonId: this.ruleForm.cancelReasonId,
                cancelReason: this.ruleForm.cancelReason,
                otherReason: this.ruleForm.otherReason
              }
              this.$message.info('取消中！')
              await this.$http(URL.cancelDelivery, param)
              this.cancelClick = false
              this.cancelDialogShow = false
              setTimeout(() => {
                this.refreshTable() // 刷新列表
              }, 1000)
            } catch (e) {
              this.cancelClick = false
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 去详情页
      rowDblClick (row) {
        this.$router.push(`/ecms/land-match/push-order-detail/${row.ydCode}`)
      },
      // 配送异常
      abnormalSend () {
        this.clearTimeoutLdp() // 关闭延时器
        const nowDate = new Date().getTime()
        const day = date(nowDate)
        let params = {
          timeType: 20,
          startTime: day + ' 00:00:00',
          endTime: day + ' 23:59:59',
          orderStatus: 502
        }
        this.$refs.queryTable.loadData(params)
      },
      // 关闭定时器
      clearTimeoutLdp () {
        if (this.LDPtimerOut) {
          clearTimeout(this.LDPtimerOut) // 关闭延时器
          this.LDPtimerOut = null
        }
      },
    }
  }
</script>
<style lang="scss">
  .ecms-push-order {
    .query-form-wrap {
      .is-disabled {
        input {
          background: transparent;
        }
      }
    }
  }
</style>
