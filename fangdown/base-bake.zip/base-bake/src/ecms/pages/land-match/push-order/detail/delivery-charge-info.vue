<template>
  <div class="ldp-delivery-info">
    <kye-table ref="multipleTable"
               :data="deliveryInfo"
               tooltip-effect="dark"
               style="width: 100%">
      <kye-table-column type="index"
                        label="序号"
                        width="50">
      </kye-table-column>
      <kye-table-column prop="peisongId"
                        label="任务编码"
                        show-overflow-tooltip
                        width="150px">
      </kye-table-column>
      <kye-table-column prop="serviceName"
                        show-overflow-tooltip
                        label="配送服务"
                        width="125px">
      </kye-table-column>
      <kye-table-column prop="serviceCode"
                        show-overflow-tooltip
                        label="服务代码"
                        width="65px">
      </kye-table-column>
      <kye-table-column prop="pushDepot"
                        show-overflow-tooltip
                        label="推送门店"
                        width="70px">
      </kye-table-column>
      <kye-table-column prop="status"
                        show-overflow-tooltip
                        label="费用状态"
                        width="65px">
      </kye-table-column>
      <kye-table-column prop="cityName"
                        show-overflow-tooltip
                        label="城市名称"
                        width="65px">
      </kye-table-column>
      <kye-table-column prop="pushTime"
                        show-overflow-tooltip
                        label="推送时间"
                        width="120px">
      </kye-table-column>
      <kye-table-column prop="weight"
                        show-overflow-tooltip
                        label="重量(kg)"
                        width="70px">
      </kye-table-column>
      <kye-table-column prop="gpsDistance"
                        show-overflow-tooltip
                        label="预导航距离(m)"
                        width="100px">
      </kye-table-column>
      <kye-table-column prop="finalDeliveryAmount"
                        show-overflow-tooltip
                        label="派送费用"
                        width="65px">
      </kye-table-column>
      <kye-table-column prop="deliveryAmount"
                        show-overflow-tooltip
                        label="平台费用"
                        width="auto">
        <template slot-scope="scope">
          <span style="color:#ff0000">{{ scope.row.deliveryAmount }}</span>
        </template>
      </kye-table-column>
    </kye-table>
  </div>
</template>
<script>
  export default {
    props: {
      deliveryInfo: {
        type: Array
      }
    }
  }
</script>
<style lang='scss'>
</style>




