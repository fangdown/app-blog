<template>
  <div class="add-input">
    <kye-form class="kye-dialog-body_form"
              ref="formArea"
              :model="ruleForm"
              style="padding-bottom:4px"
              module-code="ecs_ldp"
              :biz-id="ruleForm.id"
              :rules="rules">
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="收件点部"
                         prop="receiverDept">
            <kye-search-tips v-model="ruleForm.receiverDept"
                             url="baseconfig.node.findByNodeNameAndFlag"
                             value-key="nodeName"
                             :keys="['nodeName']"
                             :warning=false
                             :message="message"
                             :input-length='1'
                             placeholder=' '
                             @clear="clearable('receiverDept')"
                             :format-data="formatData"
                             @select="handleSelect">
            </kye-search-tips>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="平台名称"
                         prop="platformId"
                         :rules="$rule.str('请选择推送平台',true)">
            <kye-select v-model="ruleForm.platformId"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_platform_id']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店编码"
                         prop="shopCode"
                         :rules="$rule.str('请输入门店编码',true)">
            <kye-input v-model="ruleForm.shopCode"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店类型"
                         prop="shopType"
                         :rules="$rule.str('请输入门店类型',true)">
            <kye-select v-model="ruleForm.shopType"
                        placeholder=''>
              <kye-option label="真实门店"
                          value="真实门店"></kye-option>
              <kye-option label="虚拟门店"
                          value="虚拟门店"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店名称"
                         prop="shopName"
                         :rules="$rule.str('请输入门店名称',true)">
            <kye-input v-model="ruleForm.shopName"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店联系人"
                         prop="linkman"
                         :rules="$rule.str('请输入门店联系人',true)">
            <kye-input v-model="ruleForm.linkman"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="联系电话"
                         prop="contactPhone"
                         :rules="$rule.str('请输入门店联系电话',true)">
            <kye-input v-model="ruleForm.contactPhone"
                       maxlength='11'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="所属区域"
                         prop="regionName"
                         :rules="$rule.str('请选择所属区域',true)">
            <kye-select v-model="ruleForm.regionName"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_region_name']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店经度"
                         prop='lng'
                         :rules="$rule.reg(/^(\-|\+)?(((\d|[1-9]\d|1[0-7]\d|0{1,3})\.\d{0,6})|(\d|[1-9]\d|1[0-7]\d|0{1,3})|180\.0{0,6}|180)$/, '经度整数部分为0-180,小数部分为0到6位!',true)">
            <kye-input v-model.number="ruleForm.lng"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店纬度"
                         prop='lat'
                         :rules="$rule.reg(/^(\-|\+)?([0-8]?\d{1}\.\d{0,6}|90\.0{0,6}|[0-8]?\d{1}|90)$/, '纬度整数部分为0-90,小数部分为0到6位!',true)">
            <kye-input v-model.number="ruleForm.lat"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="24">
          <kye-form-item label="详细地址"
                         class="detailAddress"
                         prop="address"
                         :rules="$rule.str('请输入门店详细地址',true)">
            <kye-input v-model="ruleForm.address"
                       maxlength='100'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="城市名称"
                         prop="cityName"
                         :rules="$rule.str('请输入城市名称',true)">
            <kye-city v-model="ruleForm.cityName"
                      @select="selectCityName"
                      clearable
                      placeholder=''></kye-city>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="城市区号">
            <kye-input v-model="ruleForm.cityCode"
                       maxlength='10'
                       placeholder=''
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="城市等级"
                         prop="cityType"
                         :rules="$rule.str('请选择城市等级',true)">
            <kye-select v-model="ruleForm.cityType"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_city_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="路线类型"
                         prop="pathPlanning"
                         :rules="$rule.str('请选择路线规划类型',true)">
            <kye-select v-model="ruleForm.pathPlanning"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_path_planning']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  @click="submitForm('formArea')">保存(S)
      </kye-button>
      <kye-button @click="$emit('cancelClose')">取消</kye-button>
    </div>
  </div>
</template>
<script>
  import mixins from 'public/mixins/index'
  import URL from '../../api'
  // 城市组件
  import KyeCity from '@/shared/components/kye-city'
  export default {
    mixins: [mixins],
    components: { KyeCity },
    props: {
      sendModifyObj: {
        type: Object
      }
    },
    data () {
      return {
        data: {},
        message: '',
        ruleForm: {
          id: '', // id
          receiverDept: '', // 所属点部
          // platformName: '', // 平台名称
          platformId: null, // 平台ID
          shopCode: '', // 门店编码
          shopType: '', // 门店类型
          shopName: '', // 平台门店名称
          linkman: '', // 门店联系人
          contactPhone: '', // 联系方式
          regionName: '', // 所属区域
          lng: '', // 门店经度
          lat: '', // 门店纬度
          region: '', // 所在地区
          regionArr: [], // 所在地区数组
          address: '', // 详细地址
          cityCode: '', // 城市区号
          cityName: '', // 城市名称
          cityType: '', // 城市等级
          pathPlanning: '', // 路线规划类型
          auditStatus: '0' // 默认未审核状态
        },
        rules: {},
        sendModifyData: [], // 修改页面数据
      }
    },
    created () {
    },
    mounted () {
      this.ruleForm = this.sendModifyObj
    },
    methods: {
      // 清除点部名称
      clearable (param) {
        if (param === 'receiverDept') {
          this.ruleForm.receiverDept = ''
        }
      },
      // 点部模糊查询
      formatData (val) {
        this.ruleForm.receiverDept = val
        let obj = {
          nodeName: val
        }
        return obj
      },
      // 点部触发
      handleSelect (item) {
        if (!item) {
          this.$message.warning('没有找到该点部')
          this.ruleForm.receiverDept = ''
        }
      },
      // 点击保存
      submitForm (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            delete this.ruleForm.platformName
            await this.$http(URL.cityShopUpdate, this.ruleForm)
            this.$message.success('修改成功！')
            this.$emit('cancelClose')
            this.$emit('refreshTable')
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 选择城市名称
      selectCityName (item) {
        if (item) {
          this.ruleForm.cityName = item.addressName
          this.ruleForm.cityCode = item.cityCode
        } else {
          this.$message.warning('没有找到该城市')
        }
      },
    }
  }
</script>
<style lang='scss' scoped>
</style>


