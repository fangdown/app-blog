<template>
  <div class="kye-detail">
    <search-pager :option="options"
                  :tools="formTools"></search-pager>
    <kye-expand-page>
      <!-- <div class="platform-detail">
        <kye-button type="text"
                    style="height:28px">
          <i class="iconfont icon-pen"></i>
          驳回</kye-button>
      </div> -->
      <kye-table ref="multipleTable"
                 :data="detailData"
                 tooltip-effect="dark"
                 style="width: 100%">
        <kye-table-column type="index"
                          fixed
                          width="50">
        </kye-table-column>
        <kye-table-column prop="waybillCode"
                          label="运单号"
                          show-overflow-tooltip
                          width="95px">
        </kye-table-column>
        <kye-table-column prop="taskCode"
                          label="任务编码"
                          show-overflow-tooltip
                          width="130px">
        </kye-table-column>
        <kye-table-column prop="largeArea"
                          label="所属区域"
                          width="65px"
                          show-overflow-tooltip
                          :formatter="largeAreaStatus">
        </kye-table-column>
        <kye-table-column prop="departmentName"
                          label="所属点部"
                          show-overflow-tooltip
                          width="90px">
        </kye-table-column>
        <kye-table-column prop="payFee"
                          label="核算费用"
                          filter="money"
                          show-overflow-tooltip
                          width="65px">
        </kye-table-column>
        <kye-table-column prop="taskStatus"
                          label="任务状态"
                          width="65px"
                          show-overflow-tooltip
                          :formatter="checkManageStatus">
        </kye-table-column>
        <kye-table-column prop="confirmTime"
                          label="推单时间"
                          show-overflow-tooltip
                          width="120px">
        </kye-table-column>
        <kye-table-column prop="reportTime"
                          label="接单时间"
                          show-overflow-tooltip
                          width="120px">
        </kye-table-column>
        <kye-table-column prop="finishTime"
                          label="完结时间"
                          show-overflow-tooltip
                          width="120px">
        </kye-table-column>
        <kye-table-column prop="totalNum"
                          label="件数"
                          show-overflow-tooltip
                          width="45px">
        </kye-table-column>
        <kye-table-column prop="totalWeight"
                          label="实际重量（kg)"
                          show-overflow-tooltip
                          width="100px">
        </kye-table-column>
        <kye-table-column prop="navigationDistance"
                          label="预导航距离（m)"
                          show-overflow-tooltip
                          width="110px">
        </kye-table-column>
        <kye-table-column prop="driverName"
                          label="派送人"
                          show-overflow-tooltip
                          width="auto">
        </kye-table-column>
      </kye-table>
    </kye-expand-page>
  </div>
</template>
<script>
  // 时间YYYY-MM-DD HH:mm / 费用过滤
  import { minute, money } from '@/public/utils/filter'
  import URL from '../../api'
  export default {
    data () {
      return {
        options: {
          back: '/ecms/land-match/platform-account',
          method: URL.getPlatformTotalBillList,
          searchCode: 'ecs_ldp_platform_account_list_field',
        },
        formTools: [
          {
            label: '导出',
            icon: 'export',
            disabled: false,
            auth: URL.exportLDPWayBillList,
            func: () => this.downloadTable()
          }
        ],
        detailData: [],
      }
    },
    methods: {
      // 导出
      async downloadTable () {
        let param = {
          billId: String(this.$route.params.id)
        }
        try {
          let xlsUrl = await this.$http(URL.exportLDPWayBillList, param)
          window.erpOpen(xlsUrl)
          this.$message.success('导出成功！')
        } catch (e) {
          this.$message.warning('导出失败！')
        }
      },
      // 任务状态
      checkManageStatus (row, column, cellValue, index) {
        return this.$filter['lookup'](cellValue, 'ecs_ldp_check_manage_status')
      },
      // 所属区域
      largeAreaStatus (row, column, cellValue, index) {
        return this.$filter['lookup'](cellValue, 'ecs_ldp_region_name')
      },
      // 获取详情数据
      async getDetailInfo (param) {
        let params = { billId: param }
        let res = await this.$http(URL.getPlatformWayBillList, params)
        this.detailData = res.rows || []
        this.detailData.map(item => {
          // 推单时间
          item.confirmTime = minute(item.confirmTime)
          // 接单时间
          item.reportTime = minute(item.reportTime)
          // 签收时间
          item.finishTime = minute(item.finishTime)
          // 核算费用
          item.payFee = money(item.payFee)
          return item
        })
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (!vm.$route.meta.layout) {
          vm.getDetailInfo(to.params.id)
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.getDetailInfo(to.params.id)
      next()
    }
  }
</script>
<style lang="scss" scoped>
</style>

