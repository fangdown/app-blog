<template>
  <div class="check-manage">
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="searchTools"
                 :form-model="formModel"
                 :option="option"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
    <kye-dialog :visible.sync="dialogShow"
                title="核算费用修改"
                append-to-body>
      <kye-row>
        <kye-number v-model="modifyPayFee"
                    symbol="￥"
                    :precision="2"
                    :max="99999"
                    :min="0"
                    placeholder=''>
        </kye-number>
      </kye-row>
      <div slot="footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    @click="checkSubmit">保存(S)</kye-button>
        <kye-button @click="checkClose">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from '../api'
  // 时间 YYYY-MM-DD
  import { date } from '@/public/utils/filter'
  export default {
    data () {
      return {
        dialogShow: false,
        modifyPayFee: '', // 修改核算费用
        downloadData: {}, // 导出接口入参
        resData: {}, // 选择的行的数据
        currentMonthFirst: '', // 当月第一天
        currentDate: '', // 当天
        generic: {
          method: URL.ldpSummaryList,
          searchCode: 'ecs_ldp_check_manage_list_field'
        },
        tables: [
          {
            searchCode: 'ecs_ldp_check_manage_list_field',
            url: { method: URL.ldpSummaryList },
            option: {
              load: false,
              stripe: true,
              detailAuth: false,
              moduleCode: 'ecs_ldp',
              beforeFormSubmit: (data, model) => {
                const obj = {}
                let isEmpty = true // 是否有条件
                delete data.startSchedulingTime
                delete data.endSchedulingTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'schedulingTime') {
                      if (model.schedulingTime && model.schedulingTime.length === 2) {
                        isEmpty = false
                        const startSchedulingTime = +new Date(model.schedulingTime[0])
                        const endSchedulingTime = +new Date(model.schedulingTime[1])
                        Object.assign(obj, {
                          startSchedulingTime,
                          endSchedulingTime
                        })
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
                this.downloadData = {}
                Object.assign(this.downloadData, obj)
              },
            },
            operation: {
              label: '操作',
              fixed: 'left',
              width: '80px',
              options:
                [{
                  btnType: 'button',
                  label: '修改',
                  disabled: row => {
                    return row.auditStatus === 200
                  },
                  detailAuth: URL.ldpUpdateFee,
                  func: row => {
                    this.resData = row
                    this.modify(row)
                  }
                },
                {
                  btnType: 'button',
                  label: '审核',
                  disabled: row => {
                    return row.auditStatus === 200
                  },
                  detailAuth: URL.driverFeeAudit,
                  func: row => {
                    this.resData = row
                    this.check()
                  }
                }]
            }
          }
        ],
        searchTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: URL.ldpSummaryList,
            disabled: false,
            func: () => {
              let tableData = this.$refs.queryTable.getTableData() || []
              if (tableData.length <= 0) {
                this.$message.warning('无数据！')
                return false
              }
              this.refreshTable()
            }
          },
          {
            label: '导出',
            icon: 'export',
            disabled: false,
            auth: URL.exportLdpCheckBill,
            func: () => this.downloadTable()
          }
        ],
        option: {
          searchCode: 'ecs_ldp_check_manage_search_define',
          // 所属点部
          departmentName: {
            change: ({ key, value, model }) => { },
            labelKey: 'nodeName',
            valueKey: 'nodeName',
            remoteMethod: (val) => this.$http(URL.findByNodeNameAndFlag, { nodeName: val })
          }
        },
        formModel: {
          // 默认日期为当月第一天--当天
          schedulingTime: () => {
            return [this.currentMonthFirst, this.currentDate]
          }
        }
      }
    },
    created () {
      let currentMonthFirst = new Date(this.getCurrentMonthFirst()).getTime()
      this.currentMonthFirst = this.$options.filters.date(currentMonthFirst)
      this.currentDate = this.$options.filters.date(new Date())
    },
    methods: {
      // 刷新
      refreshTable () {
        this.$refs.queryTable.loadData()
      },
      // 导出
      async downloadTable () {
        let platformType = this.downloadData.platformType
        let startTime = date(this.downloadData.startSchedulingTime) || ''
        let endTime = date(this.downloadData.endSchedulingTime) || ''
        let startMonth = startTime.split('-')[1]
        let endMonth = endTime.split('-')[1]
        if (!platformType || startMonth !== endMonth) {
          this.$message.warning('代理名称不能为空且推单日期需为同一月份')
          return false
        }
        let tableData = this.$refs.queryTable.getTableData() || []
        if (tableData.length <= 0) {
          this.$message.warning('无数据可导出！')
          return false
        }
        delete this.downloadData['schedulingTime']
        try {
          let xlsUrl = await this.$http(URL.exportLdpCheckBill, this.downloadData)
          window.erpOpen(xlsUrl)
          this.$message.success('导出成功！')
        } catch (e) {
          // this.$message.warning('导出失败！')
        }
      },
      // 修改
      modify (param) {
        this.modifyPayFee = param.payFee
        this.dialogShow = true
      },
      // 取消修改
      checkClose () {
        this.dialogShow = false
      },
      // 确定修改
      checkSubmit () {
        this.modifyData()
        this.dialogShow = false
      },
      // 修改数据
      async modifyData () {
        let param = {
          'id': this.resData.id,
          'payFee': this.modifyPayFee
        }
        await this.$http(URL.ldpUpdateFee, param)
        this.$message.success('修改成功')
        // 刷新页面
        this.refreshTable()
      },
      // 点击审核
      check () {
        this.$confirm(`确定审核通过运单号为${this.resData.waybillCode}的账单？`, '审核', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.getCheckData()
        }).catch(() => {
        })
      },
      // 调用审核接口
      async getCheckData () {
        let param = {
          'id': this.resData.id,
          'auditDescription': '',
          'auditStatus': 200
        }
        await this.$http(URL.driverFeeAudit, param)
        this.$confirm('每月5号可以前往账单管理，查看每月账单和账单明细', '审核成功', {
          confirmButtonText: '我知道了',
          cancelButtonText: '',
          type: 'success'
        }).then(() => {
          // 刷新页面
          this.refreshTable()
        })
      },
      // 获取当月第一天
      getCurrentMonthFirst () {
        let date = new Date()
        date.setDate(1)
        return date
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>



