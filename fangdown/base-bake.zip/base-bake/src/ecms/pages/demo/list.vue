<template>
  <div>demo
    <kye-button @click="toDetail">点击</kye-button>
  </div>
</template>
<script>
  export default {
    created () {
      console.log('list-created')
    },
    mounted () {
      console.log('list-mounted')
    },
    activated () {
      console.log('list-activated')
    },
    methods: {
      toDetail () {
        this.$router.push({ path: '/ecms/demo/detail' })
      }
    }
  }
</script>
