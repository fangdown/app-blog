<template>
  <div>demo
    <c1></c1>
  </div>
</template>
<script>
  import c1 from './c1.vue'
  export default {
    components: {
      c1
    },
    created () {
      console.log('list-created')
    },
    mounted () {
      console.log('list-mounted')
    },
    activated () {
      console.log('list-activated')
    }
  }
</script>
