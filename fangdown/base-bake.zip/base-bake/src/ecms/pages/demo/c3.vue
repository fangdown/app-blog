<template>
  <div>
    333
  </div>
</template>
<script>
  export default {
    created () {
      console.log('c3-created')
    },
    mounted () {
      console.log('c3-mounted')
    },
    activated () {
      console.log('c3-activated')
    }
  }
</script>
