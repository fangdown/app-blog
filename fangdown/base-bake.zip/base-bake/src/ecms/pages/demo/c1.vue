<template>
  <div>111
    <c2></c2>
  </div>
</template>
<script>
  import c2 from './c2.vue'
  export default {
    components: {
      c2
    },
    created () {
      console.log('c1-created')
    },
    mounted () {
      console.log('c1-mounted')
    },
    activated () {
      console.log('c1-activated')
    }
  }
</script>
