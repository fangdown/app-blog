<template>
  <div>22
    <c3></c3>
  </div>
</template>
<script>
  import c3 from './c3.vue'
  export default {
    components: {
      c3
    },
    created () {
      console.log('c2-created')
    },
    mounted () {
      console.log('c2-mounted')
    },
    activated () {
      console.log('c2-activated')
    }
  }
</script>
