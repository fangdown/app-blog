<template>
  <kye-dialog title="新增运力合同"
              width="40%"
              top="30vh"
              :visible="showNewDialog"
              :show-close="false"
              :close-on-click-modal="false">
    <kye-form ref="ruleForm"
              :model="form"
              size="mini">
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="供应商名"
                         prop="keyword"
                         :rules="[
                              { required: true, message: '请输入关键字',trigger:'change'},
                            ]">
            <kye-autocomplete v-model="form.keyword"
                              @select="handleSelect"
                              :fetch-suggestions="querySearchAsync"
                              clearable
                              prefix-icon="el-icon-search"></kye-autocomplete>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="运力类型"
                         prop="contractType"
                         :rules="[
                              { required: true, message: '请选择运力合同类型',trigger:'change'},
                            ]">
            <kye-select placeholder=""
                        v-model="form.contractType"
                        clearable
                        @change="getContractType">
              <kye-option v-for="item in lookUpOptions['ecs_ht_contract_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div slot="footer"
         class="dialog-footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  :auth="Api.supplierSyncContract"
                  @click="formSubmit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </kye-dialog>
</template>
<script>
  // API模块
  import Api from '../../contract.api'
  // 表单校验
  import { submitForm } from '../../../../utils/validate'
  // 数据字典
  import mixins from 'public/mixins/index'

  export default {
    mixins: [mixins],
    props: {
      showNewDialog: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        Api,
        form: {
          keyword: '',
          contractType: ''
        },
        showDialog: false, // 控制弹窗的显示隐藏
        allowSave: false, // 是否允许关闭新增运力合同弹窗,校验不通过不能关闭弹窗
        driverData: '', // 合同信息
        remoteEmployeeList: []
      }
    },
    methods: {
      // 取消弹窗
      close () {
        this.allowSave = false
        this.driverData = null
        this.$emit('close')
        this.$refs.ruleForm.resetFields()
        this.$router.push('/ecms/contract/list')
      },
      // 检索供应商信息
      async querySearchAsync (queryString, cb) {
        if (!queryString) {
          return
        }
        let result = []
        const { rows } = await this.$http(Api.supplierSyncSearch, {
          page: 1,
          pageSize: 10,
          name: queryString
        })
        rows.forEach(item => {
          item.value = item.supplierFullName
          result.push(item)
        })
        cb(result)
      },
      // 选择运力类型
      getContractType (val) {
        const tempData = {}
        tempData.driverType = val // 运力类型
        if (val === '3') {
          // 【运力运力类型】选择为【运力运力】时【报价类型】默认=【运力报价】，其余类型不做限制，可自由组合；
          tempData.bidType = '102' // 报价类型
        }
        this.mergeDriverData(tempData)
      },
      // 选择供应商信息
      handleSelect (item) {
        if (!(item.businessAuditFlag === '20' && item.cashierAuditFlag === '20' && item.financeAuditFlag === '20')) {
          this.$message({
            type: 'error',
            showClose: true,
            message: '该供应商审核不通过'
          })
          return
        }
        this.allowSave = true // 允许关闭弹窗
        const areaMap = new Map([['10', '华东'], ['20', '华南'], ['30', '华北'], ['40', '京津冀']])
        const payPeriodMap = new Map([['16', '16'], ['12', '12'], ['10', '10'], ['6', '6'], ['5', '5'], ['3', '3'], ['1.5', '1.5'], ['0', '0']])
        const tempData = {}
        this.form.keyword = item.supplierFullName // 关键字，用于表单验证
        // 字段翻译
        tempData.bankAccount = item.bankAccount // 收款账号 => 银行账号
        tempData.bankAccountName = item.bankName // 开户名 => 账户名称
        tempData.bankBranchName = item.bankName // 开户支行 => 开户行
        tempData.bankName = item.bankType // 开户行 => 银行类型
        if (tempData.driverType === '3') { // 签约类型(2平台运力，3合同运力)
          tempData.bidType = '102' // 合同报价
        } else {
          tempData.bidType = '101' // 竞价
        }
        tempData.businessArea = areaMap.get(item.region) // 服务大区转译
        tempData.businessType = item.supplierModelNames // 业务类型 => 供应商类型
        tempData.carNo = 0 // 车辆数
        tempData.checkState = 102 // 审核状态 => 客户审核状态 ，业务审核状态(ims_supplier_audit_flag)10-待审核(已反审)，20-已审核
        tempData.cooperationTimes = 0 // 合作频次
        tempData.createPerson = '' // 录入人
        tempData.createTime = '' // 录入时间
        tempData.driverId = '' // 运力Id
        tempData.financeCheckState = item.financeAuditFlag // 财务审核状态(ims_supplier_audit_flag)10-待审核(已反审)，20-已审核
        tempData.fullName = item.supplierFullName // 供应商全称
        tempData.invoiceType = item.invoiceType // 发票类型(100公司普票，101增值税专票，102无,103其它发票) => 发票类型（ims_invoice_type）10-增值税普通发票，20-增值税专用发票，30-收据，40-定额发票
        tempData.isInvoicing = '1' // 是否开票(1是2否)
        // tempData.liableName = item.enterpriseLegalPerson // 企业负责人 => 企业法人
        tempData.liableName = item.contacts // 企业负责人 => 企业法人
        tempData.name = item.supplierName // 企业简称 => 供应商简称
        tempData.payPeriod = item.settlementInterval // 结账周期（101：45天，102：60天，103：90天，104：实时） => 结算类型(ims_settlement_type)10-收到账单N天，20-收到发票N天，30-月结N天（不含当月），40--预付款
        tempData.payType = item.payAmountType // 结算类型(1未填,101月结，102非月结) => 付款类型(ims_pay_amount_type)10-月结，20-非月结
        tempData.paymentMethod = item.payAmountMode // 付款方式(1未填,201网付，202电汇，203支票，204现金) => 付款方式(ims_pay_amount_mode)10-网转，20-电汇，30-现金，40支票
        // tempData.phone = item.phone // 负责人电话 => 电话
        tempData.phone = item.contactType // 负责人电话 => 电话
        tempData.remark = item.remark // 备注 => 备注
        tempData.servicePoint = [] // 服务点部
        tempData.state = '' // 合作状态(1正在合作，2暂停合作，3停止合作)
        tempData.supplierNum = item.supplierNumber // 供应商编号 => 供应商编号
        tempData.taxRate = payPeriodMap.get(item.taxRate) // 税率 => 税率(ims_tax_rate)16-16，12-12，10-10，6-6，5-5，3-3，1.5-1.5，0-0
        tempData.usualRunArea = '' // 常跑区域
        tempData.provinceId = item.provinceId // 省ID
        tempData.province = item.province // 省
        tempData.cityId = item.cityId // 市ID
        tempData.city = item.city // 市
        tempData.areaId = item.areaId // 市ID
        tempData.area = item.area // 市
        tempData.address = item.address // 详细地址
        tempData.supplierId = item.id // 供应商id
        tempData.supplierModelIdList = item.supplierModelIds // 供应商类型Id集合
        this.mergeDriverData(tempData)
      },
      // 合并对象
      mergeDriverData (tempData) {
        this.driverData = Object.assign({}, this.driverData, tempData)
      },
      // 新增运力合同弹窗--保存
      formSubmit () {
        if (!this.allowSave) {
          this.$message({
            type: 'error',
            showClose: true,
            message: '请检索并选择供应商'
          })
          return
        }
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.$emit('setDriverData', this.driverData)
        this.$refs.ruleForm.resetFields()
        this.$emit('close')
        this.allowSave = false
        this.driverData = null
      },
    }
  }
</script>
