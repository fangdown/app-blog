<template>
  <kye-dialog title="选择付款主体"
              width="800px"
              :visible.sync="showDialog"
              @closed="dialogClosed">
    <kye-form :model="payOwnerForm"
              ref="ruleForm">
      <kye-row>
        <kye-col :span="11">
          <kye-form-item label="付款主体">
            <kye-input suffix-icon="el-icon-search"
                       @input="searchList"
                       clearable></kye-input>
          </kye-form-item>
          <kye-table :data="signOwnerTableData"
                     border
                     stripe
                     @row-click="handlePaymentRowClick"
                     height="350">
            <kye-table-column prop="companyName"
                              label="付款主体"
                              align="center"
                              :show-overflow-tooltip="true">
            </kye-table-column>
          </kye-table>
        </kye-col>
        <kye-col :span="2">
          <div class="iconfont icon-exchange"></div>
        </kye-col>
        <kye-col :span="11">
          <div class="title">已选付款主体</div>
          <div class="selectedBox">
            <span @click="deleteItem(index)"
                  v-for="(item, index) in payOwnerSelected"
                  :key="index"
                  class="selectedItem">{{item.companyName}}<i class="iconfont icon-close"></i></span>
          </div>
        </kye-col>
      </kye-row>
    </kye-form>
    <div slot="footer"
         class="dialog-footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  @click="saveDialog">保存(S)</kye-button>
      <kye-button @click="showDialog = false">取消</kye-button>
    </div>
  </kye-dialog>
</template>

<script>
  // API接口模块
  import Api from '../../contract.api'

  export default {
    data () {
      return {
        payOwnerForm: {}, // 表单
        showDialog: false,
        payOwnerSelected: [], // 付款主体已选择
        signOwnerTableData: [] // 列表数据
      }
    },
    props: {
      isShow: {
        type: Boolean,
        default: false
      }
    },
    watch: {
      isShow (newVal) {
        if (newVal) {
          this.getCompanyListByName() // 获取付款主体列表
          this.showDialog = this.isShow
        }
      },
      showDialog (newVal) {
        this.$emit('visiable-change', newVal)
      }
    },
    methods: {
      // 弹窗关闭时回调
      dialogClosed () {
        this.$refs.ruleForm.resetFields()
      },
      async getCompanyListByName (companyName) {
        // 签订主体/付款主体
        const data = await this.$http(Api.companyListByName, { companyName })
        this.signOwnerTableData = data
      },
      // 付款主体表格点击列
      handlePaymentRowClick (row, event, column) {
        // 排重
        const redo = this.payOwnerSelected.find(n => n.companyName === row.companyName)
        if (!redo) {
          this.payOwnerSelected.push(row)
        }
      },
      // 删除已选择的付款主体
      deleteItem (index) {
        this.payOwnerSelected.splice(index, 1)
      },
      // 点击确定按钮
      saveDialog () {
        const selected = this.payOwnerSelected
        this.$emit('form-saved', selected)
        this.showDialog = false
      },
      // 搜索
      searchList (value) {
        this.getCompanyListByName(value)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .title {
    font-size: 12px;
    color: #666666;
    line-height: 12px;
    margin-bottom: 8px;
  }
  .selectedBox {
    border: 1px solid #dcdae2;
    border-radius: 4px;
    min-width: 328px;
    height: 398px;
  }
  .selectedItem {
    display: inline-block;
    padding: 4px 8px;
    margin: 8px 0px 8px 14px;
    background: #f1f1fd;
    border-radius: 4px;
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #9571e9;
    text-align: center;
    cursor: pointer;
  }
  .iconfont.delete {
    padding-left: 5px;
    font-size: 10px;
    cursor: pointer;
  }
  .icon-exchange {
    font-size: 20px;
    color: #9571e9;
    height: 398px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
