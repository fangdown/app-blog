<template>
  <div>
    <kye-dialog :visible.sync="showDialog"
                width="800px"
                @closed="closeDialog">
      <div slot="title">{{dialogTitle}}</div>
      <kye-form ref="ruleForm"
                :model.sync="addContractForm"
                size="mini">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="合同名称"
                           prop="contractName"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-input v-model="addContractForm.contractName"
                         maxlength="20"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="合同编号">
              <kye-input :disabled="true"
                         v-model="addContractForm.contractNo"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="签约大区"
                           prop="businessRegion"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.businessRegion"
                          clearable>
                <kye-option v-for="item in lookUpOptions['ecs_ht_business_area']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="签约点部"
                           prop="signedPoint"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <el-select placeholder=""
                         v-model="addContractForm.signedPoint"
                         multiple
                         filterable
                         remote
                         collapse-tags
                         :remote-method="getOperationPoint"
                         value-key="pointCode">
                <el-option v-for="item in pointOptions"
                           :key="item.label"
                           :label="item.label"
                           :value="item.value">
                </el-option>
              </el-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="16">
            <!-- 省市 -->
            <addressSelector :type="2"
                             :required="true"
                             v-on:addr="getBussinessLicenseAddr"
                             :span1="12"
                             :span2="12"
                             :data.sync="operationAddrObj" />
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="合同类型"
                           prop="contractType"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.contractType"
                          clearable
                          size="mini">
                <kye-option v-for="item in lookUpOptions['ecs_ht_business_type']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item prop="cooperationPart"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <span slot="label"
                    class="kye-label-click"
                    @click="showProviderDialog = true">合作方</span>
              <kye-input id="cooperationPart"
                         v-model="addContractForm.cooperationPart"
                         disabled></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <div @click="showSignOwnerDialog = true">
              <kye-form-item prop="signedPart"
                             :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
                <span slot="label"
                      class="kye-label-click"
                      @click="showSignOwnerDialog = true">签订主体</span>
                <kye-input id="signedPart"
                           v-model="addContractForm.signedPart"
                           disabled></kye-input>
              </kye-form-item>
            </div>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <div @click="showPayOwnerDialog = true">
              <kye-form-item prop="payPart"
                             :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
                <span slot="label"
                      class="kye-label-click"
                      @click="showPayOwnerDialog = true">付款主体</span>
                <kye-input id="payPart"
                           v-model="addContractForm.payPart"
                           disabled></kye-input>
              </kye-form-item>
            </div>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="状态"
                           prop="status"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select v-if="dialogTitle === '新增合同信息'"
                          placeholder=""
                          disabled
                          v-model="addContractForm.status"
                          clearable>
                <kye-option v-for="item in lookUpOptions['ecs_ht_check_state']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                </kye-option>
              </kye-select>
              <kye-select v-if="dialogTitle === '修改合同信息'"
                          placeholder=""
                          v-model="addContractForm.status"
                          clearable>
                <kye-option v-for="item in lookUpOptions['ecs_ht_check_state']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                            :disabled="item.value!=='105'" />
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="开始时间"
                           prop="startTime"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-date-picker v-model="addContractForm.startTime"
                               type="date">
              </kye-date-picker>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="终止日"
                           prop="contractEndDay"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-date-picker v-model="addContractForm.contractEndDay"
                               type="date">
              </kye-date-picker>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="签订人"
                           prop="contractSignPerson"
                           :rules="[
                              { required: true, message: '请检索并选择合同签订人',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.contractSignPerson"
                          filterable
                          remote
                          reserve-keyword
                          @change="handleSelectSignPerson"
                          :remote-method="querySearchAsync">
                <kye-option v-for="item in remoteEmployeeList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value+'#'+item.label">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="保管人"
                           prop="keeper"
                           :rules="[
                              { required: true, message: '请检索并选择保管人',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.keeper"
                          filterable
                          remote
                          reserve-keyword
                          @change="handleSelectKeeper"
                          :remote-method="querySearchAsync">
                <kye-option v-for="item in remoteEmployeeList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value+'#'+item.label">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="签订部门"
                           prop="contractSignDepartment"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-input v-model="addContractForm.contractSignDepartment"
                         maxlength="20"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="附件信息"
                           prop="documentInfo"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-input v-model="addContractForm.documentInfo"
                         :maxlength="50"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="承诺约定"
                           prop="promise"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-input v-model="addContractForm.promise"
                         :maxlength="50"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="16">
            <kye-form-item label="备注"
                           prop="remark">
              <kye-input v-model="addContractForm.remark"
                         :maxlength="50"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :auth="Api.saveSignedDriverContractInfo"
                    :loading="loading"
                    @click="addContractDialogSave">保存(S)</kye-button>
        <kye-button @click="closeDialog">取消</kye-button>
      </div>
    </kye-dialog>
    <!-- 图片预览弹窗 -->
    <kye-dialog :visible.sync="showImg"
                width="800px">
      <div slot="title">图片预览</div>
      <kye-image :config="config" />
    </kye-dialog>
    <!-- 选择合作方（供应商）弹窗 -->
    <providerDialog :isShow="showProviderDialog"
                    @visiable-change="showProviderDialogChange"
                    @form-saved="partnerFormSaved" />
    <!-- 选择付款主体 弹窗 -->
    <payOwnerDialog :isShow="showPayOwnerDialog"
                    @visiable-change="showPayOwnerDialogChange"
                    @form-saved="payOwnerFormSaved" />
    <!-- 选择签订主体弹窗 -->
    <signOwnerDialog :isShow="showSignOwnerDialog"
                     @visiable-change="showSignOwnerDialogChange"
                     @form-saved="signOwnerFormSaved" />
  </div>
</template>

<script>
  // 表单校验
  import { submitForm } from '../../../../utils/validate'
  // API接口
  import Api from '../../contract.api'
  // 付款主体弹窗
  import payOwnerDialog from './pay-owner-dialog'
  // 合作方弹窗
  import providerDialog from './provider-dialog'
  // 签订主体弹窗
  import signOwnerDialog from './sign-owner-dialog'
  // 地址选择器
  import addressSelector from '../../../../../components/addr-selector/address-selector.vue'
  // 为了使用数据字典
  import mixins from 'public/mixins/index'

  const addContractForm = { // 新增合同信息表单
    status: '100',
    contractName: '',
    businessRegion: '',
    contractType: '',
    startTime: '',
    contractEndDay: '',
    contractSignPerson: '',
    keeper: '',
    contractSignDepartment: '',
    documentInfo: '',
    promise: '',
    remark: '',
    signedPoint: [],
    contractAttachPath: '', //  合同附件(上传文件路径)
    insuranceAttachPath: '', // 保险图片(上传文件路径)
    cooperationPart: '',
    signedPart: '',
    payPart: ''
  }
  export default {
    mixins: [mixins],
    components: {
      payOwnerDialog,
      providerDialog,
      signOwnerDialog,
      addressSelector
    },
    props: {
      dialogTitle: {
        type: String,
        default: '新增合同信息'
      },
      popEditInfo: {
        type: Object,
        default: () => ({})
      }
    },
    data () {
      return {
        Api,
        loading: false,
        showDialog: false, // 显示新增弹窗
        pointOptions: [], // 点部
        showSignOwnerDialog: false, // 显示选择签订主体弹窗
        showProviderDialog: false, // 显示选择供应商主体弹窗
        showPayOwnerDialog: false, // 显示付款主体弹窗
        bussinessLicenseAddr: {}, // 获取选择的地址
        operationAddrObj: {}, // 回显地址
        remoteEmployeeList: [], // 员工列表
        addContractForm: { ...addContractForm },
        contractAttachPathView: '', // 上传合同照片预览
        insuranceAttachPathView: '', // 上传保险照片预览
        showImg: false, // 是否显示图片预览器
        config: { imgSrc: '', width: 765, height: 430 }
      }
    },
    created () {
      if (this.popEditInfo && this.popEditInfo.id) {
        this.setFormData()
      }
    },
    beforeDestroy () {
      this.addContractForm = null
      this.$refs.ruleForm.resetFields()
    },
    methods: {
      // 修改详情赋值
      setFormData () {
        const updateData = {
          signedPoint: []
        }
        let signedPoint = []
        let signedPointCodes = []
        if (typeof this.popEditInfo.signedPoint === 'string') {
          signedPoint = this.popEditInfo.signedPoint.split(',')
        }
        if (typeof this.popEditInfo.signedPointCodes === 'string') {
          signedPointCodes = this.popEditInfo.signedPointCodes.split(',')
        }
        // 赋值点部信息
        for (let i = 0; i < signedPoint.length; i++) {
          updateData.signedPoint.push({ nodeName: signedPoint[i], pointCode: signedPointCodes[i] })
          this.pointOptions.push({ label: signedPoint[i], value: { nodeName: signedPoint[i], pointCode: signedPointCodes[i] } })
        }
        // 创建时间
        updateData.createTime = new Date(this.popEditInfo.createTime).getTime()
        updateData.updateTime = new Date(this.popEditInfo.updateTime).getTime()

        Object.assign(this.addContractForm, this.popEditInfo, updateData)
        // 省市赋值
        this.bussinessLicenseAddr.provinceId = this.popEditInfo.provinceCode
        this.bussinessLicenseAddr.province = this.popEditInfo.province
        this.bussinessLicenseAddr.cityId = this.popEditInfo.cityCode
        this.bussinessLicenseAddr.city = this.popEditInfo.city
        this.operationAddrObj = {
          provinceId: this.popEditInfo.provinceCode,
          province: this.popEditInfo.province,
          cityId: this.popEditInfo.cityCode,
          city: this.popEditInfo.city
        }
      },
      openDialog () {
        this.showDialog = true
      },
      closeDialog () {
        this.showDialog = false
        this.addContractForm = null
        this.bussinessLicenseAddr = {}
        this.operationAddrObj = {}
        this.remoteEmployeeList = []
        this.$refs.ruleForm.resetFields()
        this.$emit('close')
        this.loading = false
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
      },
      // 获取操作点部下拉数据
      async getOperationPoint (query) {
        const data = await this.$http(Api.getOperationData, { nodeName: query })
        let tempData = []
        if (data && Array.isArray(data) && data.length > 0) {
          data.forEach(item => {
            tempData.push({ label: item.nodeName, value: { nodeName: item.nodeName, pointCode: item.pointCode } })
          })
          this.pointOptions = tempData
        }
      },
      // 上传保险图片
      beforeUploadInsurePic (file) {
        const isJPG = !!file.type.match('image/')
        if (!isJPG) {
          this.$message.error('请上传图片!')
          return isJPG
        } else {
          const that = this
          const reader = new FileReader()
          reader.readAsDataURL(file)
          reader.onload = async function (e) {
            const data = await that.$http(Api.uploadFilesBase64, { base64Code: this.result, fileType: 1 })
            that.addContractForm.insuranceAttachPath = data
            that.insuranceAttachPathView = this.result // 预览
          }
          return false
        }
      },
      // 上传保险图片
      beforeUploadPapersPic (file) {
        const isJPG = !!file.type.match('image/')
        if (!isJPG) {
          this.$message.error('请上传图片！')
          return isJPG
        } else {
          const that = this
          const reader = new FileReader()
          reader.readAsDataURL(file)
          reader.onload = async function (e) {
            const data = await that.$http(Api.uploadFilesBase64, { base64Code: this.result, fileType: 1 })
            that.addContractForm.contractAttachPath = data
            that.contractAttachPathView = this.result // 预览
          }
          return false
        }
      },
      // 模糊检索人名
      async querySearchAsync (query) {
        if (query !== '') {
          const data = await this.$http(Api.remoteEmployee, { name: query })
          if (!data) {
            return
          }
          this.remoteEmployeeList = data.map(item => {
            return { value: item.id, label: item.name }
          })
        } else {
          this.remoteEmployeeList = []
        }
      },
      // 选择合同保管人
      handleSelectKeeper (item) {
        this.addContractForm.keeperId = item.split('#')[0]
        this.addContractForm.keeper = item.split('#')[1]
      },
      // 选择合同签订人
      handleSelectSignPerson (item) {
        this.addContractForm.signerId = item.split('#')[0]
        this.addContractForm.contractSignPerson = item.split('#')[1]
      },
      // 监听付款主体弹窗显示隐藏状态
      showPayOwnerDialogChange (newVal) {
        this.showPayOwnerDialog = newVal
      },
      // 监听签订主体弹窗显示隐藏状态
      showSignOwnerDialogChange (newVal) {
        this.showSignOwnerDialog = newVal
      },
      // 监听合作方弹窗显示隐藏状态
      showProviderDialogChange (newVal) {
        this.showProviderDialog = newVal
      },
      // 合作方
      partnerFormSaved (data) {
        this.addContractForm.cooperationPart = data.supplierFullName
        this.addContractForm.supplierId = data.id
      },
      // 付款主体
      payOwnerFormSaved (data) {
        let companyNameStr = ''
        let ids = ''
        data.forEach(item => {
          companyNameStr += item.companyName + ','
          ids += item.id + ','
        })
        companyNameStr.slice(companyNameStr.length - 1, 1)
        this.addContractForm.payPart = companyNameStr.slice(0, companyNameStr.length - 1)
        this.addContractForm.payCompanyIds = ids.slice(0, ids.length - 1)
      },
      // 签订主体
      signOwnerFormSaved (data) {
        this.addContractForm.signedPart = data.companyName
        this.addContractForm.signCompanyId = data.id
      },
      // 新增合同信息弹窗--保存
      async addContractDialogSave () {
        try {
          // 表单校验
          if (typeof submitForm('ruleForm', this) === 'object') {
            return false
          }
          const startTime = new Date(this.addContractForm.startTime).getTime()
          const contractEndDay = new Date(this.addContractForm.contractEndDay).getTime()
          // 开始时间不能大于终止时间
          let params = {
            startTime,
            contractEndDay,
          }
          if (contractEndDay < startTime) {
            this.$message.error('开始时间不能大于终止时间')
            return
          }
          if (!Number(this.$route.query.driverId)) {
            this.$message.error('请先保存基础信息')
            return
          }
          // 签约点部及点部code
          if (Array.isArray(this.addContractForm.signedPoint)) {
            let signedPointsStr = ''
            let signedPointCodesStr = ''
            this.addContractForm.signedPoint.forEach(point => {
              signedPointsStr += point.nodeName + ','
              signedPointCodesStr += point.pointCode + ','
            })
            params.signedPoint = signedPointsStr.slice(0, signedPointsStr.length - 1)
            params.signedPointCodes = signedPointCodesStr.slice(0, signedPointCodesStr.length - 1)
          }
          if (params.signedPoint.length > 100 || params.signedPointCodes > 500) {
            this.$message.error('签约点部长度超过限制')
            return
          }
          // 省市
          this.addContractForm.provinceCode = this.bussinessLicenseAddr.provinceId
          this.addContractForm.province = this.bussinessLicenseAddr.province
          this.addContractForm.cityCode = this.bussinessLicenseAddr.cityId
          this.addContractForm.city = this.bussinessLicenseAddr.city
          // 运力id
          this.addContractForm.driverId = Number(this.$route.query.driverId)
          params = Object.assign({}, this.addContractForm, params)
          this.$emit('save', params)
          this.loading = true
        } catch (error) {
          this.closeDialog()
          this.loading = false
        }
      },
      // 获取营业执照地址
      getBussinessLicenseAddr (addr) {
        this.bussinessLicenseAddr = { ...addr }
        this.operationAddrObj = { ...addr }
      }
    }
  }
</script>
<style lang="scss">
  .ecs_center {
    text-align: center;
  }
  .avatar-uploader .el-upload {
    border: 1px solid #dcdae2;
    border-radius: 6px;
    width: 128px;
    height: 128px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    background-color: #f1f1f5;
  }
  .avatar-uploader .el-upload:hover {
    background-color: #f6f6fa;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 128px;
    height: 128px;
    line-height: 128px;
    text-align: center;
  }
  .avatar {
    width: 128px;
    height: 128px;
    display: block;
  }
  .ecs-yc-contract-upload {
    .el-upload {
      height: 128px;
      width: 128px;
      line-height: 128px;
      border: 1px solid #dcdae2;
      background-color: #f1f1f5;
      &:hover {
        background-color: #f6f6fa;
      }
      .el-upload__text {
        line-height: 1.5;
      }
    }
  }
</style>

