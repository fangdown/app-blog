<template>
  <div>
    <div class="kye-block-title">合同信息</div>
    <div class="tab-operation">
      <kye-button type="text"
                  icon="iconfont icon-plus"
                  :auth="Api.saveSignedDriverContractInfo"
                  :disabled="contractList.length>0"
                  @click="handleShowAddContractDialog">新增
      </kye-button>
      <kye-button type="text"
                  icon="iconfont icon-pen"
                  :disabled="editDisabled"
                  :auth="Api.saveSignedDriverContractInfo"
                  @click="handleEditDialog">修改
      </kye-button>
      <!-- <kye-button type="text"
                  icon="iconfont icon-delete"
                  :disabled="deleteDisabled"
                  :auth="Api.deleteSignedDriverContractInfoBatch"
                  @click="deleteSelectedInfo">删除
      </kye-button> -->
    </div>
    <kye-table :data="contractList"
               max-height="500"
               border
               stripe
               :header-cell-style="{background:'#F1F1F5'}"
               @row-dblclick="dbFun"
               @selection-change="handleSelectChange">
      <kye-table-column type="selection"
                        width="40"
                        fixed="left"
                        align="center"
                        :show-overflow-tooltip="true"
                        :selectable="selectableFanc">
      </kye-table-column>
      <kye-table-column type="index"
                        width="50"></kye-table-column>
      <kye-table-column prop="contractName"
                        label="合同名称"
                        align="center"
                        width="65"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractNo"
                        label="合同编号"
                        align="center"
                        width="112"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="businessRegionName"
                        label="签约大区"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="signedPoint"
                        label="签约点部"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="province"
                        label="所在省"
                        width="55"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="city"
                        label="所在市"
                        width="55"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractTypeName"
                        label="合同类型"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="cooperationPart"
                        label="合作方"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="signedPart"
                        label="签订主体"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="payPart"
                        label="付款主体"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="statusName"
                        label="状态"
                        align="center"
                        width="70"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="startTime"
                        label="开始时间"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractEndDay"
                        label="合同终止日"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractSignPerson"
                        label="合同签订人"
                        width="75"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractSignDepartment"
                        label="合同签订部门"
                        width="90"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="promise"
                        label="承诺约定"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
    </kye-table>
    <!-- 新增合同信息弹窗 -->
    <addContractDialog v-if="showAddContractDialog"
                       ref="newContractDialog"
                       :dialogTitle="dialogTitle"
                       :popEditInfo="popEditInfo"
                       @save="saveContractFormData"
                       @close="closeNewDialog" />
    <!-- 查看合同信息 -->
    <addContractDialogView :isShow="showExamine"
                           :dialogTitle="dialogTitle"
                           :form="popUpInfo"
                           @visiable-change="isExamine" />
  </div>
</template>

<script>
  // 深度克隆
  import { cloneDeep } from 'lodash'
  // 合同弹窗-添加合同
  import addContractDialog from './contract-dialog/add-contract-dialog'
  // 合同弹窗-编辑合同
  import addContractDialogView from '../components-view/contract-dialog/add-contract-dialog.vue'
  // API接口
  import Api from '../../../car-manage/contract/contract.api.js'

  export default {
    components: {
      addContractDialog,
      addContractDialogView
    },
    props: {
      driverId: {
        type: null,
        default: ''
      },
      contractList: {
        type: Array,
        default: () => ([])
      }
    },
    data () {
      return {
        Api,
        selectedList: [], //  选中的列数据
        showAddContractDialog: false, // 显示新增合同弹窗
        addDisabled: true,
        editDisabled: true,
        deleteDisabled: true,
        dialogTitle: '修改合同信息',
        popUpInfo: {}, // 查看合同信息
        popEditInfo: null, // 修改合同信息
        showExamine: false // 查看显示隐藏
      }
    },
    methods: {
      // 保存合同
      saveContractFormData (data) {
        this.$emit('save-contract', data)
      },
      // 显示新增合同弹窗
      handleShowAddContractDialog () {
        this.showAddContractDialog = true
        this.popEditInfo = null
        this.dialogTitle = '新增合同信息'
        setTimeout(() => {
          this.$refs.newContractDialog.openDialog()
        }, 0)
      },
      // 点击修改合同
      handleEditDialog () {
        this.dialogTitle = '修改合同信息'
        this.showAddContractDialog = true
        if (this.selectedList[0]) {
          this.popEditInfo = { ...this.selectedList[0] }
        } else {
          this.popEditInfo = null
        }
        setTimeout(() => {
          this.$refs.newContractDialog.openDialog()
        }, 0)
      },
      // 选中的列数据
      handleSelectChange (val) {
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        const tempVal = cloneDeep(val)
        if (val.length === 1) {
          this.editDisabled = false
          tempVal.forEach(item => {
            item.startTime = new Date(item.startTime).getTime()
            item.contractEndDay = new Date(item.contractEndDay).getTime()
          })
        } else {
          this.editDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      async deleteSelectedInfo () {
        if (Array.isArray(this.selectedList) && this.selectedList.length <= 0) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        const selectedIds = []
        this.selectedList.forEach(item => {
          selectedIds.push(item.id)
        })
        this.selectedList = []
        this.popEditInfo = null
        const params = { ids: selectedIds.join(',') }
        this.$emit('delete-contract', params)
      },
      // 监听查看弹框
      isExamine (newVal) {
        this.showExamine = newVal
      },
      // 合同是否允许编辑
      selectableFanc (row, index) {
        if (row.imsContract === '1') {
          return false
        } else {
          return true
        }
      },
      // 双击表格查看详情
      dbFun (row, event) {
        this.popUpInfo = row
        this.dialogTitle = '查看合同信息'
        this.showExamine = true
      },
      // 关闭新增弹窗
      closeNewDialog () {
        this.showAddContractDialog = false
      }
    }
  }
</script>
