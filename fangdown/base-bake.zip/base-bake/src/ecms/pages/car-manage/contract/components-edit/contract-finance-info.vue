<template>
  <div>
    <div class="kye-block-title">财务信息</div>
    <kye-form class="form-details"
              ref="ruleForm">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="开户名">
            <el-tooltip effect="dark"
                        :content="form.bankAccountName"
                        placement="top">
              <kye-input v-model="form.bankAccountName"
                         :maxlength="50"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="开户行">
            <el-tooltip effect="dark"
                        :content="form.bankName"
                        placement="top">
              <kye-input v-model="form.bankName"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="支行名称">
            <el-tooltip effect="dark"
                        :content="form.bankBranchName"
                        placement="top">
              <kye-input v-model="form.bankBranchName"
                         :maxlength="50"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="收款账号">
            <el-tooltip effect="dark"
                        :content="form.bankAccount"
                        placement="top">
              <kye-input v-model.number="form.bankAccount"
                         :maxlength="20"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="结算类型">
            <kye-select placeholder=""
                        v-model="form.payType"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_yc_clearing_form']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="付款方式">
            <kye-select placeholder=""
                        v-model="form.paymentMethod"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_yc_payment_method']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="账期">
            <!-- <kye-select placeholder=""
                        v-model="form.payPeriod"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_ht_pay_period']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select> -->
            <kye-input v-model="form.payPeriod"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否开票">
            <kye-select placeholder=""
                        v-model="form.isInvoicing"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_ht_is_billing']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票类型">
            <kye-select placeholder=""
                        v-model="form.invoiceType"
                        disabled
                        @change="invoiceTypeChange">
              <kye-option v-for="item in lookUpOptions['ecs_ht_invoice_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票税率"
                         disabled>
            <el-tooltip effect="dark"
                        :content="form.taxRate+''"
                        placement="top">
              <kye-input v-model.number="form.taxRate"
                         disabled>
                <span slot="append">%</span>
              </kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  // API接口
  import Api from '../../../car-manage/contract/contract.api.js'
  // 表单校验
  import { submitForm } from '../../../utils/validate'
  // 为了使用数据字典
  import mixins from 'public/mixins/index'

  export default {
    mixins: [mixins],
    props: {
      form: {
        type: Object,
        default: () => ({})
      }
    },
    methods: {
      // 新增或修改财务信息
      async addFinanceInfo () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        if (!this.$route.query.driverId) {
          this.$message({
            type: 'error',
            showClose: true,
            message: '请先保存基本信息'
          })
          return
        }
        this.form.driverId = this.$route.query.driverId // 运力Id
        await this.$http(Api.savesignedcompanyfinanceinfo, this.form)
      },
      invoiceTypeChange (val) {
        if (val === '102') {
          this.form.taxRate = 10 // 增值税
        } else if (val === '101') {
          this.form.taxRate = 6 // 普票
        }
      }
    }
  }
</script>

