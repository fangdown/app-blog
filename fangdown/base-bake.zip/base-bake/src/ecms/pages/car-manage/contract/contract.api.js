const prefix = 'ecs.yc.'
const URL = {
  uploadFilesBase64: `ecs.yc.file.uploadBase64CodeFile.do`, // 找不到
  getLargeArea: `${prefix}signedCompanyManage.getLargeArea.do`, // 找不到
  getOperationData: `baseconfig.node.findByNodeNameAndFlag`, // 找不到
  findAllSignedDriverList: `${prefix}signedCompanyManage.findAllSignedDriverList.do`, // 新ERP:合同企业管理-合同企业分页列表查询
  savesignedcompanybaseinfo: `${prefix}signedCompanyManage.saveSignedCompanyBaseInfo.do`, // 找不到
  editSignedCompanyBaseInfo: `${prefix}signedCompanyManage.editSignedCompanyBaseInfo.do`, // 新ERP:修改合同企业(基础信息)
  findErpSignedDriverDetailByDriverId: `${prefix}signedCompanyManage.findSignedDriverDetailByDriverId.do`, // 找不到
  savesignedcompanyfinanceinfo: `${prefix}signedCompanyManage.saveSignedCompanyFinanceInfo.do`, // 新ERP:修改合同企业(财务信息)
  editSignedDriverCardInfo: `${prefix}signedCompanyManage.editSignedDriverCardInfo.do`, // 新ERP:合同企业管理-证件（营业执照，运输经营许可证，身份证）信息保存接口
  saveSignedDriverContractInfo: `${prefix}signedCompanyManage.saveSignedDriverContractInfo.do`, // 找不到
  querySignedDriverContractInfoById: `${prefix}signedCompanyManage.querySignedDriverContractInfoById.do`, // 新ERP:合同企业管理-查询合同详情信息
  saveSignedDriverCreditInfo: `${prefix}signedCompanyManage.saveSignedDriverCreditInfo.do`, // 新ERP:合同企业管理-保存合同信用信息(新增或者修改)
  querySignedDriverCreditInfo: `${prefix}signedCompanyManage.querySignedDriverCreditInfo.do`, // 新ERP:合同企业管理-查询合同关联信用信息，根据运力ID查询
  deleteSignedDriverContractInfoBatch: `${prefix}signedCompanyManage.delSignedDriverContractInfoBatch.do`, // 合同企业管理-删除合同详情信息
  deleteSignedDriverCreditInfoBatch: `${prefix}signedCompanyManage.deleteSignedDriverCreditInfoBatch.do`, // 新ERP:合同企业管理-删除合同信用信息
  queryDataDictByType: `${prefix}dataDict.erp.queryDataDictByType.do`, // 新ERP:合同企业管理-查询指定数据字典配置Type
  GetCarStandardType: `${prefix}erpBaseCar.erp.getCarType.do`, // 系统基础:获取车辆类型数据
  getCarLengthByType: `${prefix}signedCompanyManage.getCarLengthByType.do`, // 找不到
  saveSignedDriverCardInfoPhotos: `${prefix}signedCompanyManage.saveSignedDriverCardInfoPhotos.do`, // 新ERP:合同企业管理-证件图片（营业执照，运输经营许可证，身份证）保存接口
  querySignedDriverCardInfoPhotos: `${prefix}signedCompanyManage.querySignedDriverCardInfoPhotos.do`, // 新ERP：合同企业管理-证件图片（营业执照，运输经营许可证，身份证）查询接口
  delDriverDocAttachmentPhotos: `ecs.yc.signedCompanyManage.delDriverDocAttachmentPhotos.do`, // 合同企业管理-证件图片（营业执照，运输经营许可证，身份证）查询接口 (V1.0)
  deleteSignedDriverDocAttachmentPhotos: `${prefix}signedCompanyManage.delSignedDriverDocAttachmentPhotos.do`, // 找不到
  querySignedDriverCardInfoByDriverId: `${prefix}signedCompanyManage.querySignedDriverCardInfoById.do`, // 找不到
  saveDriverDiscount: `${prefix}signedCompanyManage.saveDriverDiscount.do`, // 新ERP:合同企业管理-折扣优惠-保存接口
  querySignedDriverDiscount: `${prefix}signedCompanyManage.querySignedDriverDiscount.do`, // 新ERP:合同企业管理-折扣优惠-列表查询接口
  delBatchSignedDriverDiscount: `${prefix}signedCompanyManage.delBatchSignedDriverDiscount.do`, // 新ERP:同企业管理-折扣优惠-删除接口
  saveDriverOfferTrunkRoute: `${prefix}signedCompanyManage.saveDriverOfferTrunkRoute.do`, // 新ERP:合同企业管理-干线报价-（按车型和公里）保存接口
  querySignedDriverOfferTrunkRoute: `${prefix}signedCompanyManage.queryDriverOfferTrunkRoute.do`, // 合同企业管理-干线报价-(按车型和公里)列表查询接口
  delBatchSignedDriverOfferTrunkRoute: `${prefix}signedCompanyManage.delBatchDriverOfferTrunkRoute.do`, // 合同企业管理-干线报价-（按车型和公里）批量删除接口
  saveSignedDriverChargingByWeight: `${prefix}signedCompanyManage.saveSignedDriverChargingByWeight.do`, // 合同企业管理-干线报价-（按车型和公里）保存接口
  querySignedDriverChargingByWeight: `${prefix}signedCompanyManage.querySignedDriverChargingByWeight.do`, // 新ERP:合同企业管理-取派报价-按重量计费录入标准列表查询接口，根据运力ID查询
  deleteSignedDriverChargingByWeightBatch: `${prefix}signedCompanyManage.deleteDriverChargingByWeightBatch.do`, // 新ERP:合同企业管理-取派报价-按重量计费录入标准删除接口
  saveDriverChargingByTicket: `${prefix}signedCompanyManage.saveDriverChargingByTicket.do`, // 新ERP:合同企业管理-取派报价-按票计费录入标准保存接口
  querySignedDriverChargeByTicket: `${prefix}signedCompanyManage.queryDriverChargeByTicket.do`, // 新ERP:合同企业管理-查询按票录入标准，根据运力ID查询
  delBatchSignedDriverChargingByTicket: `${prefix}signedCompanyManage.delBatchDriverChargingByTicket.do`, // 新ERP:合同企业管理-取派报价-按票计费录入标准删除接口
  saveDriverChargingByKilometer: `${prefix}signedCompanyManage.erp.saveDriverChargingByKilometer.do`, // 新ERP:合同企业管理-取派报价-按公里计费录入标准保存接口
  querySignedDriverChargingByKilometer: `${prefix}signedCompanyManage.erp.queryDriverChargingByKilometer.do`, // 新ERP:合同企业管理-取派报价-按公里计费录入标准保存接口
  delBatchSignedDriverChargingByKilometer: `${prefix}signedCompanyManage.delBatchDriverChargingByKilometer.do`, // 新ERP:合同企业管理-取派报价-按公里计费录入标准删除接口
  saveSupplierData: `${prefix}signedCompanyManage.saveSupplierData.do`, // 合同企业管理-确定并保存操作,将状态变成待审核
  supplierSyncSearch: `ims.supplier.sync.search`, // 供应商管理(对外)-查询 (V1.0)
  companyListByName: `fms.approve.company.listByName`, // 公司信息-通过公司名称查询公司列表 (V1.0)
  remoteEmployee: `hr.remoteEmployee.list`, // 员工查询-列表 (V1.0)
  supplierSyncContract: `ims.supplier.sync.contract.list`, //  供应商合同-获取合同列表(对外) (V1.0)
  findTrunkChargeByWeightByDriverId: `${prefix}signedCompanyManage.findTrunkChargeByWeightByDriverId.do`, // 合同企业管理-干线报价按重量计费查询接口
  getAllContractItemList: `${prefix}signedCompanyManage.getAllContractItemList.do`, // 合同企业管理-选择合同信息下拉列表数据查询接口
  supplierModelList: `ims.supplierModel.list`, //  供应商类型-下拉列表 (货物类型)
  addTrunkChaegeByWeightEntity: `${prefix}signedCompanyManage.addTrunkChaegeByWeightEntity.do`, // 合同企业管理-干线报价-按重量计费新增接口
  delBatchSignedDriverTrunkChargeByWeight: `${prefix}signedCompanyManage.delBatchDriverTrunkChargeByWeight.do`, // 合同企业管理-干线报价-按重量计费批量删除接口
  supplierReviewStatus: `${prefix}signedCompanyManage.supplierReviewStatus.do`, // 合同运力审核 (V1.0)
  findSupplierReviewStatus: `${prefix}signedCompanyManage.findSupplierReviewStatus.do`, // 合同运力审核状态查询接口 (V1.0)
  saveBidCalWay: `${prefix}erpSignedCompanyManage.saveBidCalWay.do`, // 合同企业管理-保存合同报价取派和干线计费方式 (V1.0)
  getBidCalWay: `${prefix}signedCompanyManage.erp.getBidCalWay.do`, // 企业管理-查询报价取派和干线计费方式 (V1.0)
  getSignedBaseAndFinanceInfo: `${prefix}signedCompanyManage.getSignedBaseAndFinanceInfo.do`, // 合同企业管理-根据合同信息主键ID查询运力基础信息，财务信息 (V1.0)
  addTakepieChargeByKilometer: `${prefix}signedCompanyManage.addTakepieChargeByKilometer.do`, // 合同企业管理-取派报价-按公里计费录入标准保存接口
  findTakepieChargeByKilometer: `${prefix}signedCompanyManage.findTakepieChargeByKilometer.do`, // 合同企业管理-取派报价-按公里计费录入标准列表查询接口
  deleteDriverChargeByKilometer: `${prefix}signedCompanyManage.deleteDriverChargeByKilometer.do`, // ERP:合同企业管理-取派报价-按公里计费录入标准删除接口
  addTrunkChargeByKilometerEntity: `${prefix}signedCompanyManage.addTrunkChargeByKilometerEntity.do`, // 合同企业管理-干线报价-按公里计费新增接口 (V1.0)
  findTrunkChargeByKMByContractId: `${prefix}signedCompanyManage.findTrunkChargeByKMByContractId.do`, // 合同企业管理-干线报价按公里计费查询接口 (V1.0)
  deleteDriverTrunkChargeByKm: `${prefix}signedCompanyManage.deleteDriverTrunkChargeByKm.do`, // 合同企业管理-干线报价-按公里计费批量删除接口 (V1.0)
  erpDownload: `${prefix}file.erp.download.do` // ERP文件下载 (V1.0)
}
export default URL


