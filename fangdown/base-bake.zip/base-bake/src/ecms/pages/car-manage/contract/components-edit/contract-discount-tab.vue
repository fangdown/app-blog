<template>
  <div class="ecms-mt4">
    <div class="tab-operation">
      <kye-button type="text"
                  icon="iconfont icon-plus"
                  :auth="Api.saveDriverDiscount"
                  @click="showDiscountDialog = true">新增
      </kye-button>
      <kye-button type="text"
                  icon="iconfont icon-delete"
                  :disabled="deleteDisabled"
                  :auth="Api.delBatchSignedDriverDiscount"
                  @click="deleteSelectedInfo">删除
      </kye-button>
    </div>
    <discount :tableData="discountInfoList"
              :showSelection="true"
              @selected-list="handleDataInfoSelectionChange" />
    <kye-dialog title="新增折扣优惠"
                :visible.sync="showDiscountDialog"
                width="600px"
                top="30vh"
                @close="closeDialog">
      <kye-form ref="ruleForm"
                :model="addDiscountForm"
                :rules="rules">
        <kye-row>
          <kye-col :span="16">
            <kye-form-item label="月总运费"
                           required>
              <kye-col :span="10">
                <div class="ecms-interval-block">
                  <kye-form-item prop="minFreight">
                    <kye-number v-model="addDiscountForm.minFreight"
                                placeholder=''
                                unit="元"
                                :precision="1"
                                :max="999999"
                                :min="0">
                    </kye-number>
                  </kye-form-item>
                </div>
              </kye-col>
              <kye-col :span="2">
                <div style="text-align:center">
                  <span>-</span>
                </div>
              </kye-col>
              <kye-col :span="10">
                <div class="ecms-interval-block">
                  <kye-form-item prop="maxFreight">
                    <kye-number v-model="addDiscountForm.maxFreight"
                                placeholder=''
                                unit="元"
                                :precision="1"
                                :max="999999"
                                :min="0">
                    </kye-number>
                  </kye-form-item>
                </div>
              </kye-col>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="折扣"
                           prop="discount">
              <kye-number v-model="addDiscountForm.discount"
                          placeholder=''
                          unit="%"
                          :precision="1"
                          :max="99.9"
                          :min="0">
              </kye-number>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :loading="loading"
                    @click="dialogSave"
                    :auth="Api.saveDriverDiscount">保存(S)</kye-button>
        <kye-button @click="showDiscountDialog = false">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  // 表单校验
  import { submitForm } from '../../../utils/validate'
  // API接口
  import Api from '../../../car-manage/contract/contract.api.js'
  // 新增折扣弹窗
  import discount from '../../../../components/contract-tables/discount'
  // 表单校验
  import rules from 'public/utils/rules'

  export default {
    components: {
      discount
    },
    props: {
      discountInfoList: {
        type: Array,
        default: () => ([])
      }
    },
    data () {
      return {
        Api,
        loading: false,
        editDisabled: true,
        deleteDisabled: true,
        showDiscountDialog: false, // 显示折扣优惠-新增弹窗
        addDiscountForm: {}, // 新增折扣优惠表单
        selectedList: [], // 选中列表
        rules: {
          minFreight: rules.str('不能为空', true, 'blur'),
          maxFreight: rules.str('不能为空', true, 'blur'),
          discount: rules.str('不能为空', true, 'blur')
        },
      }
    },
    methods: {
      // 弹窗--保存
      async dialogSave () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        const params = {
          id: '', // 主键ID
          driverId: Number(this.$route.query.driverId), // 关联运力ID
          minFreight: Number(this.addDiscountForm.minFreight), // 最低运费(元)
          maxFreight: Number(this.addDiscountForm.maxFreight), // 最高运费(元)
          discount: Number(this.addDiscountForm.discount) / 100 // 折扣(百分比)
        }
        if (params.minFreight > params.maxFreight) {
          this.$message({
            message: '范围值不合法',
            type: 'error'
          })
          return
        }
        //   折扣优惠-保存接口
        this.loading = true
        try {
          await this.$http(Api.saveDriverDiscount, params)
          this.showDiscountDialog = false // 隐藏弹窗
          this.loading = false
          this.$message({
            message: '操作成功',
            type: 'success'
          })
          this.$emit('discountInfoSaved')
        } catch (error) {
          this.loading = false
        }
      },
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        const tempVal = Object.assign([], val)
        if (val.length === 1) {
          this.editDisabled = false
        } else {
          this.editDisabled = true
        }
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      deleteSelectedInfo () {
        if (this.selectedList.length <= 0) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        this.$confirm('确定删除数据？', '提示').then(async () => {
          let ids = ''
          this.selectedList.map(element => {
            if (element.id) {
              ids += element.id + ','
            }
          })
          if (ids.length > 1) {
            ids = ids.slice(0, ids.length - 1) // 切掉最后一个逗号
          }
          await this.$http(Api.delBatchSignedDriverDiscount, { ids })
          this.$emit('discountInfoDeleted')
          this.$message({
            showClose: true,
            message: '删除成功',
            type: 'success'
          })
        })
      },
      closeDialog () {
        this.addDiscountForm = {}
        this.$refs.ruleForm.resetFields()
        this.loading = false
      }
    }
  }
</script>

<style lang="scss" scoped>
  .ecms-mt {
    margin-top: 4px;
  }
</style>
