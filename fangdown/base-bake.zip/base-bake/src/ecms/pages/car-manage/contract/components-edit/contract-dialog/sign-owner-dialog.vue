<template>
  <kye-dialog title="选择签订主体"
              width="800px"
              :visible.sync="showDialog"
              @closed="dialogClosed">
    <kye-form :model="signOwnerForm"
              ref="ruleForm">
      <kye-row>
        <kye-form-item label="签订主体">
          <kye-input suffix-icon="el-icon-search"
                     @input="searchList"
                     clearable></kye-input>
        </kye-form-item>
      </kye-row>
      <kye-row>
        <kye-table :data="signOwnerTableData"
                   border
                   stripe
                   height="350">
          <kye-table-column prop="companyName"
                            label="签订主体"
                            align="center"
                            :show-overflow-tooltip="true">
          </kye-table-column>
          <kye-table-column label="操作"
                            align="center"
                            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <kye-button @click="handleClick(scope.row)"
                          type="text"
                          size="small">选择</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
      </kye-row>
    </kye-form>
    <div slot="footer"
         class="dialog-footer">
      <kye-button type="primary"
                  @click="showDialog = false">关闭</kye-button>
    </div>
  </kye-dialog>
</template>

<script>
  // API接口模块
  import Api from '../../contract.api'

  export default {
    data () {
      return {
        signOwnerForm: {}, // 表单
        showDialog: false,
        signOwnerTableData: []
      }
    },
    props: {
      isShow: {
        type: Boolean,
        default: false
      }
    },
    watch: {
      isShow (newVal) {
        if (newVal) {
          this.getCompanyListByName() // 获取付款主体列表
          this.showDialog = this.isShow
        }
      },
      showDialog (newVal) {
        this.$emit('visiable-change', newVal)
      }
    },
    methods: {
      // 弹窗关闭时回调
      dialogClosed () {
        this.$refs.ruleForm.resetFields()
      },
      async getCompanyListByName (companyName) {
        const data = await this.$http(Api.companyListByName, { companyName })
        this.signOwnerTableData = data
      },
      handleClick (row) {
        this.$emit('form-saved', row)
        this.showDialog = false
      },
      // 搜索
      searchList (value) {
        this.getCompanyListByName(value)
      }
    }
  }
</script>
