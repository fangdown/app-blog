<template>
  <div>
    <div class="kye-block-title">财务信息</div>
    <kye-form ref="ruleForm">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="开户名">
            <kye-field v-model="form.bankAccountName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="开户行">
            <kye-field v-model="form.bankName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="支行名称">
            <kye-field v-model="form.bankBranchName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="收款账号">
            <kye-field v-model="form.bankAccount"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="结算类型">
            <kye-field v-model="form.payType"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="付款方式">
            <kye-field v-model="form.paymentMethod"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="账期">
            <kye-field v-model="form.payPeriod"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否开票">
            <kye-field v-model="form.isInvoicing"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票类型">
            <kye-field v-model="form.invoiceType"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票税率"
                         disabled>
            <kye-field v-model="form.taxRate"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  export default {
    props: {
      form: {
        type: Object,
        default: () => ({})
      }
    }
  }
</script>

