<template>
  <kye-dialog title="选择供应商"
              width="800px"
              :visible.sync="showDialog"
              @closed="dialogClosed">
    <kye-form ref="ruleForm"
              :model="form">
      <kye-row>
        <kye-form-item label="供应商编号/简称">
          <kye-input suffix-icon="el-icon-search"
                     @input="searchList"
                     clearable></kye-input>
        </kye-form-item>
      </kye-row>
      <kye-row>
        <kye-table :data="signOwnerTableData"
                   border
                   stripe
                   class="ky-table"
                   height="350">
          <kye-table-column label="序号"
                            type="index"
                            width="80"
                            align="center">
          </kye-table-column>
          <kye-table-column prop="supplierNumber"
                            label="供应商编号"
                            align="center"
                            :show-overflow-tooltip="true">
          </kye-table-column>
          <kye-table-column prop="supplierFullName"
                            label="供应商全称"
                            align="center"
                            :show-overflow-tooltip="true">
          </kye-table-column>
          <kye-table-column prop="supplierModelNames"
                            label="供应商类型"
                            align="center"
                            :show-overflow-tooltip="true">
          </kye-table-column>
          <kye-table-column prop="region"
                            label="所在区域"
                            align="center"
                            :show-overflow-tooltip="true">
          </kye-table-column>
          <kye-table-column label="操作"
                            align="center"
                            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <kye-button @click="handleClick(scope.row)"
                          type="text"
                          size="small">选择</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
      </kye-row>
    </kye-form>
    <div slot="footer"
         class="dialog-footer">
      <kye-button type="primary"
                  @click="showDialog = false">关闭</kye-button>
    </div>
  </kye-dialog>
</template>

<script>
  // API接口模块
  import Api from '../../contract.api'

  export default {
    data () {
      return {
        form: {}, // 表单
        showDialog: false,
        signOwnerTableData: []
      }
    },
    props: {
      isShow: {
        type: Boolean,
        default: false
      }
    },
    watch: {
      isShow (newVal, oldVal) {
        this.getCompanyListByName()
        this.showDialog = this.isShow
      },
      showDialog (newVal, oldVal) {
        this.$emit('visiable-change', newVal)
      }
    },
    methods: {
      // 弹窗关闭时回调
      dialogClosed () {
        this.$refs.ruleForm.resetFields()
      },
      // 合作方列表
      async getCompanyListByName (companyName) {
        const { rows } = await this.$http(Api.supplierSyncSearch, { name: companyName })
        const regionMap = new Map([
          ['10', '华东'],
          ['20', '华南'],
          ['30', '华北'],
          ['40', '京津冀']
        ])
        // 所在区域(region) 10-华东,20-华南,30-华北,40-京津冀
        rows.map(item => {
          item.region = regionMap.get(item.region)
        })
        this.signOwnerTableData = rows
      },
      handleClick (row) {
        this.$emit('form-saved', row)
        this.showDialog = false
      },
      // 搜索
      searchList (value) {
        this.getCompanyListByName(value)
      }
    }
  }
</script>
