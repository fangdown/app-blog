<template>
  <div>
    <div class="tab-operation">
      <kye-button type="text"
                  icon="iconfont icon-plus"
                  @click="handleShowAddContractDialog">新增
      </kye-button>
      <kye-button type="text"
                  icon="iconfont icon-delete"
                  :disabled="deleteDisabled"
                  :auth="Api.deleteDriverChargeByKilometer"
                  @click="deleteSelectedInfo">删除
      </kye-button>
    </div>
    <getSendKm :tableData="getSendKmList"
               :showSelection="true"
               @selected-list="handleDataInfoSelectionChange" />
    <kye-dialog title="新增取派报价(按公里)"
                width="800px"
                :visible.sync="showAddContractDialog"
                @close="closeDialog">
      <kye-form ref="ruleForm"
                :model="addContractForm">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="货物类型"
                           prop="productTypeName"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.productTypeName"
                          :clearable="false"
                          @change="getContractType">
                <kye-option v-for="item in lookUpOptions['crm_customer_type']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value+'#'+item.label">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="车型"
                           prop="carTypeId"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.carTypeId"
                          @change="getCarLengthByType">
                <kye-option v-for="item in carTypeOptions"
                            :key="item.dictKey"
                            :label="item.dictValue"
                            :value="item.dictKey">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="车长"
                           prop="carLength"
                           :rules="[
                            { required: true, message: '不能为空',trigger:'change'},
                          ]">
              <kye-select placeholder=""
                          v-model="addContractForm.carLength">
                <kye-option v-for="item in carLongOptions"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="起步公里"
                           prop="startKilometer"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-number v-model="addContractForm.startKilometer"
                          placeholder=''
                          unit="km"
                          :precision="0"
                          :max="999999"
                          :min="0">
              </kye-number>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="计费状态"
                           prop="status"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.status"
                          clearable>
                <kye-option :key="1"
                            label="生效"
                            value="1">
                </kye-option>
                <kye-option :key="2"
                            label="失效"
                            value="2"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="起步价"
                           prop="startPrice"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-number v-model="addContractForm.startPrice"
                          placeholder=''
                          unit="元"
                          :precision="1"
                          :max="999999"
                          :min="0">
              </kye-number>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="备注">
              <kye-input v-model="addContractForm.remark"
                         maxlength="50"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <div class="title-bar">单边公里范围列表</div>
        <kye-table :data="tableData"
                   border
                   :header-cell-style="{background:'#F1F1F5'}">
          <kye-table-column label="*单边公里"
                            width="300px">
            <template slot-scope="scope">
              <div class="marginbtn12">
                <kye-row>
                  <kye-col :span="10">
                    <kye-number v-model="scope.row.minKilometer"
                                unit="km"
                                :disabled="scope.$index!==0 || tableData.length-scope.$index>=1"
                                :precision="0"
                                placeholder=''
                                :max="99999"
                                :min="0">
                    </kye-number>
                  </kye-col>
                  <kye-col :span="4"
                           align="center">
                    <span>至</span>
                  </kye-col>
                  <kye-col :span="10">
                    <kye-number v-model="scope.row.maxKilometer"
                                unit="km"
                                :disabled="tableData.length-scope.$index>1"
                                :precision="0"
                                placeholder=''
                                :max="99999"
                                :min="0">
                    </kye-number>
                  </kye-col>
                </kye-row>
              </div>
            </template>
          </kye-table-column>
          <kye-table-column label="*公里单价"
                            width="160px">
            <template slot-scope="scope">
              <kye-number v-model="scope.row.unitPriceByKilometer"
                          unit="元/km"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="0">
              </kye-number>
            </template>
          </kye-table-column>
          <kye-table-column label="操作">
            <template slot-scope="scope">
              <kye-button @click="rowDelete(scope.$index)"
                          type="text"
                          v-if="scope.$index!==0"
                          size="small">删除</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
        <div class="btn-wrap">
          <kye-button type="text"
                      class="iconfont icon-plus"
                      :disabled="tableData.length>7"
                      @click="addTableData"> 新增
          </kye-button>
        </div>
      </kye-form>
      <div class="tips">
        <p>公里区间录入须知：</p>
        <p>1.公里范围录入时,设：X为起始公里数,Y为结束公里数,录入时记为X＜公里数≤Y;</p>
        <p>2.最后一个公里数区间录入时,区间最大值录入为0,0代表∞(无穷大),例：500＜公里数≤0,代表公里数在500km以上</p>
      </div>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :loading="loading"
                    :auth="Api.addTakepieChargeByKilometer"
                    @click="dialogSave">保存(S)</kye-button>
        <kye-button @click="showAddContractDialog = false">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  import mixins from 'public/mixins/index'
  import { submitForm } from '../../../utils/validate'
  import Api from '../../../car-manage/contract/contract.api.js'
  import getSendKm from '../../../../components/contract-tables/get-send-km'

  export default {
    mixins: [mixins],
    props: {
      getSendKmList: {
        type: Array,
        default: () => ([])
      },
      contractId: {
        type: null
      },
      contractName: {
        type: String
      }
    },
    components: {
      getSendKm
    },
    data () {
      return {
        Api,
        loading: false,
        editDisabled: true,
        deleteDisabled: true,
        selectedList: [], //  选中的列数据
        showAddContractDialog: false, // 显示新增合同弹窗
        addContractForm: {}, // 表单
        carTypeMap: new Map(), // 车型映射表
        carLongMap: new Map(), // 车长映射表
        goodsList: [], // 货物类型数组
        carTypeOptions: [], // 车型数组
        carLongOptions: [], // 车长数组
        tableData: [{
          minKilometer: '',
          maxKilometer: '',
          unitPriceByKilometer: '',
        }] // 弹窗表格数据
      }
    },
    watch: {
      'addContractForm.startKilometer' (newVal) {
        this.$set(this.tableData[0], 'minKilometer', newVal) // 更新数组中的第一个值
      }
    },
    methods: {
      // 显示新增取派报价弹窗
      async handleShowAddContractDialog () {
        this.showAddContractDialog = true
        const data = await this.$http(Api.supplierModelList, {}) // 获取货物类型
        if (data && Array.isArray(data)) {
          data.forEach(element => {
            this.goodsList.push({ label: element.supplierModelName, value: element.id })
          })
        }
        this.GetCarStandardType() // 获取车辆类型数据
      },
      // 弹窗--保存
      async dialogSave () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        let flag = false // 校验结果
        const len = this.tableData.length
        for (let [index, val] of this.tableData.entries()) {
          for (let item of Object.values(val)) {
            if (!item) {
              flag = true
              this.$message.error('单边公里范围列表：列数据不完整')
              break
            }
          }
          if (index === 0 && index !== len - 1) {
            if (val.minKilometer < this.addContractForm.startKilometer) {
              flag = true
              this.$message.error('单边公里第一个值不能小于起步公里')
              break
            }
            if (Number(val.minKilometer) > Number(val.maxKilometer)) {
              flag = true
              this.$message.error(`范围值非法：【${val.minKilometer}-${val.maxKilometer}】`)
              break
            }
          } else if (index === len - 1) {
            if (Number(val.minKilometer) > Number(val.maxKilometer) && Number(val.maxKilometer) !== 0) {
              flag = true
              this.$message.error(`范围值非法：【${val.minKilometer}-${val.maxKilometer}】`)
            }
          } else {
            if (Number(val.minKilometer) > Number(val.maxKilometer)) {
              flag = true
              this.$message.error(`范围值非法：【${val.minKilometer}-${val.maxKilometer}】`)
              break
            }
          }
        }
        if (flag) return
        this.addContractForm.takepieChargeByKilometerRangeList = JSON.stringify(this.tableData) // 重量区间列表字段赋值
        this.addContractForm.relateContractId = this.contractId
        this.addContractForm.relateContractName = this.contractName
        this.loading = true
        try {
          await this.$http(Api.addTakepieChargeByKilometer, this.addContractForm)
          this.$emit('getSendKmSaved')
          this.showAddContractDialog = false
          this.$message.success('操作成功')
        } catch (error) {
          this.loading = false
        }
      },
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        const tempVal = Object.assign([], val)
        if (val.length === 1) {
          this.editDisabled = false
        } else {
          this.editDisabled = true
        }
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      async deleteSelectedInfo () {
        if (this.selectedList.length <= 0) {
          this.$message.error('请选择要删除的数据！')
          return
        }
        this.$confirm('确定删除数据？', '提示').then(async () => {
          let ids = ''
          this.selectedList.map(element => {
            if (element.id) {
              ids += element.id + ','
            }
          })
          if (ids.length > 1) {
            ids = ids.slice(0, ids.length - 1) // 切掉最后一个逗号
          }
          await this.$http(Api.deleteDriverChargeByKilometer, { ids })
          this.$emit('getSendKmDeleted')
          this.$message.success('删除成功！')
        })
      },
      // 选择货物类型
      getContractType (val) {
        this.addContractForm.productType = Number(val.split('#')[0])
        this.addContractForm.productTypeName = String(val.split('#')[1])
      },
      // 获取车型数据
      async GetCarStandardType () {
        const data = await this.$http(Api.GetCarStandardType, {})
        data.forEach(element => {
          this.carTypeMap.set(element.dictKey, element.dictValue)
        })
        this.carTypeOptions = data
      },
      // 根据车型获取对应的车辆长度列表
      async getCarLengthByType (val) {
        if (!val) return
        const data = await this.$http(Api.getCarLengthByType, { carTypeId: val })
        if (data) {
          const temp = []
          data.forEach(element => {
            temp.push({
              label: element + '米',
              value: element
            })
            this.carLongMap.set(element, element + '米')
          })
          this.carLongOptions = temp
          this.addContractForm.carTypeName = this.carTypeMap.get(this.addContractForm.carTypeId + '') // 车型名称
        }
      },
      // 往表格添加列
      addTableData () {
        let len = this.tableData.length
        let isAdd = true
        let tempMaxWeight = ''
        let errInfo = ''
        if (len <= 7) { // 最多8条数据
          for (let item of this.tableData) {
            if (item.minKilometer === '' || item.maxKilometer === '' || item.unitPriceByKilometer === '') {
              this.$message.error('请输入有效值')
              isAdd = false
              break
            }
            if (Number(item.maxKilometer) === 0) {
              this.$message.error('最大值为0表示无穷大，后面不能再添加范围')
              isAdd = false
              break
            }
            if (Number(item.minKilometer) > Number(item.maxKilometer)) {
              errInfo = `【${item.minKilometer} - ${item.maxKilometer}】`
              this.$message.error(`范围值非法：${errInfo}`)
              isAdd = false
              break
            }
            tempMaxWeight = item.maxKilometer
          }
          if (isAdd) {
            this.tableData.push({
              minKilometer: tempMaxWeight,
              maxKilometer: '',
              unitPriceByKilometer: ''
            })
          }
        }
      },
      // 删除某列表格
      rowDelete (index) {
        if (index === 0) return
        this.tableData.splice(index, 1)
      },
      closeDialog () {
        this.addContractForm = {}
        this.$refs.ruleForm.resetFields()
        this.loading = false
        this.tableData = [{ // 手动清空，因为不是表单
          minKilometer: '',
          maxKilometer: '',
          unitPriceByKilometer: ''
        }]
      }
    }
  }
</script>

<style lang="scss" scoped>
  .title-bar {
    background: #f1f1f5;
    height: 28px;
    line-height: 28px;
    margin: 5px 0;
    padding-left: 10px;
    font-weight: bold;
    color: #333333;
  }
  .btn-wrap {
    text-align: right;
    margin-top: 8px;
  }
  .tips {
    color: #ff5555;
    font-size: 12px;
    line-height: 17px;
  }
</style>
