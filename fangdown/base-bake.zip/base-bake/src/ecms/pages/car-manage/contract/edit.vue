<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="searchTools"></search-pager>
    <kye-expand-page>
      <!-- 新增合同弹窗 -->
      <filterSupplier :showNewDialog.sync="showNewDialog"
                      @close="closeNewDialog"
                      @setDriverData="setDriverData" />
      <!-- 基础信息 -->
      <baseInfo v-if="driverData"
                :driverId="driverId"
                :form="driverData"
                ref="baseInfo"
                @setDriverType="getDriverType"
                @save-base="saveBase" />
      <!-- 财务信息 -->
      <financeInfo v-if="driverData"
                   :form="driverData"
                   ref="financeInfo" />
      <!-- 合同信息 -->
      <contractInfo v-if="driverId"
                    :driverId="driverId"
                    :contractList="contractList"
                    @delete-contract="deleteContract"
                    @save-contract="saveContract"
                    ref="contractInfo" />
      <!-- 报价信息 -->
      <div v-if="driverType===3">
        <div class="kye-block-title wbyl-mt12"
             v-if="contractType===100||contractType===200">报价信息</div>
        <kye-tabs v-if="contractType===100||contractType===200"
                  v-model="quoteTabsActiveName"
                  @tab-click="getQuoteInfo">
          <kye-tab-pane v-if="contractType===100"
                        label="取派报价"
                        name="first">
            <div class="wbyl-mt4">
              <kye-radio-group v-model="curGetSendQuote"
                               @change="getSendQuoteChange">
                <kye-radio label="01">按重量</kye-radio>
                <kye-radio label="03">按公里</kye-radio>
              </kye-radio-group>
            </div>
            <getSendQuoteWeight v-show="curGetSendQuote==='01'"
                                :loading="loading"
                                :contractId="contractId"
                                :contractName="contractName"
                                :getSendQuoteList="getSendQuoteList"
                                @getSendQuoteSaved="getSendQuoteSaved"
                                @getSendQuoteDeleted="getSendQuoteDeleted" />
            <getSendQuoteKm v-show="curGetSendQuote==='03'"
                            :contractId="contractId"
                            :contractName="contractName"
                            :getSendKmList="getSendKmList"
                            @getSendKmSaved="getSendKmSaved"
                            @getSendKmDeleted="getSendKmDeleted" />
          </kye-tab-pane>
          <kye-tab-pane v-if="contractType===200"
                        label="干线报价"
                        name="first">
            <div class="wbyl-mt4">
              <kye-radio-group v-model="curMainLineQuote"
                               @change="mainLineQuoteChange">
                <kye-radio label="05">按线路</kye-radio>
                <kye-radio label="04">按公里</kye-radio>
              </kye-radio-group>
            </div>
            <mainlineQuoteLine v-show="curMainLineQuote==='05'"
                               :contractId="contractId"
                               :contractName="contractName"
                               :mianLineQuoteList="mianLineQuoteList"
                               @mianLineQuoteSaved="mianLineQuoteSaved"
                               @mianLineQuoteDeleted="mianLineQuoteDeleted" />
            <mainlineQuoteKm v-show="curMainLineQuote==='04'"
                             :contractId="contractId"
                             :contractName="contractName"
                             :mianLineKmList="mianLineKmList"
                             @mianLineKmSaved="mianLineKmSaved"
                             @mainLinKmDeleted="mainLinKmDeleted" />
          </kye-tab-pane>
          <kye-tab-pane v-if="contractType===100||contractType===200"
                        label="折扣优惠"
                        name="second">
            <discountInfo v-if="discountInfoList"
                          :contractId="contractId"
                          :discountInfoList="discountInfoList"
                          @discountInfoSaved="discountInfoSaved"
                          @discountInfoDeleted="discountInfoDeleted" />
          </kye-tab-pane>
        </kye-tabs>
      </div>
      <!-- 附件信息 -->
      <div v-if="driverType===3">
        <div class="kye-block-title wbyl-mt12">附件信息</div>
        <el-upload :show-file-list="false"
                   action="/router/upload"
                   accept="image/png,image/jpeg,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-powerpoint,application/pdf,application/zip,application/rar,text/plain,image/jpeg,image/jpg,image/png"
                   :before-upload="beforeUpload"
                   v-loading="uploadLoading">
          <kye-button type="text"
                      :auth="Api.saveSignedDriverCardInfoPhotos"
                      icon="iconfont icon-import">导入</kye-button>
        </el-upload>
        <kye-table :data="uploadData"
                   stripe
                   max-height="200"
                   :header-cell-style="{background:'#F1F1F5',textAlign:'left'}">
          <kye-table-column prop="fileName"
                            width="250px"
                            label="文件名称">
          </kye-table-column>
          <kye-table-column prop="creatorName"
                            label="上传人"
                            width="150px">
          </kye-table-column>
          <kye-table-column prop="createdAt"
                            label="上传时间">
          </kye-table-column>
          <kye-table-column label="操作">
            <template slot-scope="scope">
              <kye-button type="text"
                          @click="handleDownload(scope.$index, scope.row)">下载</kye-button>
              <kye-button type="text"
                          :auth="Api.delDriverDocAttachmentPhotos"
                          @click="handleDelete(scope.$index, scope.row)">删除</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
      </div>
    </kye-expand-page>
  </div>
</template>
<script>
  // 从编辑页返回，提示是否保存数据
  import routeHook from 'public/mixins/route-hook'
  // 工具集
  import * as utils from '../../utils/common'
  // 时间格式化
  import { formatTime } from '../../utils/format'
  // 金钱格式化
  import { money } from 'public/utils/filter.js'
  // 基础信息模块
  import baseInfo from './components-edit/contract-base-info'
  // 财务信息模块
  import financeInfo from './components-edit/contract-finance-info'
  // 合同信息模块
  import contractInfo from './components-edit/contract-contractInfo'
  // 新增合同模块
  import filterSupplier from './components-edit/contract-dialog/filter-supplier'
  // 取派-按重量计费模块
  import getSendQuoteWeight from './components-edit/contract-weight-charge'
  // 取派-按公里计费模块
  import getSendQuoteKm from './components-edit/contract-km-charge'
  // 干线-按线路模块
  import mainlineQuoteLine from './components-edit/contract-line-quote'
  // 干线-按公里模块
  import mainlineQuoteKm from './components-edit/contract-km-quote'
  // 折扣优惠模块
  import discountInfo from './components-edit/contract-discount-tab'
  // API接口
  import Api from './contract.api.js'

  export default {
    mixins: [routeHook],
    components: {
      baseInfo,
      financeInfo,
      contractInfo,
      filterSupplier,
      getSendQuoteWeight,
      getSendQuoteKm,
      mainlineQuoteLine,
      mainlineQuoteKm,
      discountInfo
    },
    data () {
      return {
        Api,
        showNewDialog: false, // 是否新增弹窗
        driverId: '', // 运力ID
        driverType: '', // 运力合同类型
        driverData: null,
        contractId: '', // 合同id
        contractName: '', // 合同名称
        contractList: [], // 合同列表
        contractType: '', // 合同类型
        quoteTabsActiveName: 'first', // 报价信息激活的tab页
        loading: false, // 弹窗loading
        getSendQuoteList: [], // 取派报价列表
        getSendKmList: [], // 取派报价列表-按公里
        mianLineQuoteList: [], // 干线报价列表
        discountInfoList: [], // 折扣优惠列表
        mianLineKmList: [], // 干线报价列表-按公里
        taskType: '', // 合同类型 100：取派，200：干线，300：包车
        calWay: '', // 计费方式： 01:取派-按重量，02：取派-按公里，04：干线-按公里，05：干线-按线路
        curGetSendQuote: '', // 当前的取派报价方式
        curGetSendQuoteBackup: '', // 当前的取派报价方式
        curMainLineQuote: '', // 当前干线报价方式
        curMainLineQuoteBackup: '', // 当前干线报价方式
        option: {
          back: `/ecms/contract/list`
        },
        searchTools: [
          {
            label: '保存',
            icon: 'save1',
            auth: Api.editSignedCompanyBaseInfo,
            disabled: () => !!this.driverId,
            func: () => this.$refs.baseInfo.addBaseInfo()
          },
          {
            label: '取消',
            icon: 'cancel1',
            disabled: () => !!this.driverId,
            func: () => this.$router.push('/ecms/contract/list')
          },
          {
            label: '提交审核',
            icon: 'ecs-shenhe',
            disabled: () => !this.contractId,
            func: () => this.confirmAudit()
          },
        ],
        uploadData: [], // 附件列表
        uploadLoading: false, // 上传loading
      }
    },
    beforeRouteEnter (to, from, next) {
      next((vm) => {
        if (!vm.$route.meta.layout) {
          vm.driverData = null
          vm.driverId = ''
          vm.contractId = ''
          vm.driverType = ''
          vm.contractList = []
          vm.contractType = ''
          vm.quoteTabsActiveName = 'first'
          vm.getDetail()
        }
      })
    },
    methods: {
      // 获取报价信息
      getQuoteInfo (curTab = this.quoteTabsActiveName, contractType = this.contractType) {
        if (curTab === 'first') {
          if (this.contractType === 100) {
            this.querySignedDriverChargingByWeight() // 取派-按重量
            this.findTakepieChargeByKilometer() // 取派-按公里
          } else if (this.contractType === 200) {
            this.querySignedDriverOfferTrunkRoute() // 干线-按线路
            this.findTrunkChargeByKMByContractId() // 干线-按公里
          }
        }
        this.querySignedDriverDiscount()
      },
      // 获取详情
      getDetail () {
        if (this.$route.query.driverId) { // 非新增
          this.driverId = this.$route.query.driverId
          this.contractId = this.$route.query.contractId
          this.option.back = `/ecms/contract/view/${this.contractId}`
          this.findErpSignedDriverDetailByDriverId() // 获取基础信息、财务信息
          this.querySignedDriverContractInfoById() // 获取合同列表
          this.getBidCalWay() // 获取报价方式
        } else { // 新增
          this.driverData = null
          this.driverData = this.$store.getters['ecms/CONTRACT_DriverData']
        }
      },
      // 合同企业详情查看(基础信息，财务信息) 查询接口
      async findErpSignedDriverDetailByDriverId (driverId = this.driverId) {
        const data = await this.$http(Api.findErpSignedDriverDetailByDriverId, { driverId })
        if (data.servicePoint) {
          data.servicePoint = data.servicePoint.split(',')
        }
        this.driverData = data
        this.driverType = Number(data.driverType)
      },
      // 合同列表-查询
      async querySignedDriverContractInfoById (contractId = this.$route.query.contractId) {
        const data = await this.$http(Api.querySignedDriverContractInfoById, { contractId, driverId: this.driverId })
        if (!data) {
          return
        }
        if (Array.isArray(data)) {
          data.forEach(item => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            item.startTime = formatTime(item.startTime)
            item.contractEndDay = formatTime(item.contractEndDay)
          })
          this.contractList = data
          this.contractName = data[0] && data[0].contractName
          this.contractType = Number(data[0].contractType)
          this.taskType = data[0].contractType + ''
          this.getQuoteInfo() // 获取报价信息
          this.querySignedDriverCardInfoPhotos() // 获取附件信息
        }
      },
      // 取派-按公里报价列表-查询接口
      async findTakepieChargeByKilometer (contractId = this.$route.query.contractId) {
        const data = await this.$http(Api.findTakepieChargeByKilometer, { contractId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.range = `${item.minKilometer} - ${item.maxKilometer}`
            item.createdAt = formatTime(item.createdAt)
            item.updatedAt = formatTime(item.updatedAt)
            // 价格格式化
            item.startPrice = money(item.startPrice)
          })
          this.getSendKmList = data
        }
      },
      // 干线报价-查询接口
      async querySignedDriverOfferTrunkRoute () {
        const data = await this.$http(Api.querySignedDriverOfferTrunkRoute, { driverId: this.$route.query.driverId, contractId: this.$route.query.contractId })
        data.forEach(item => {
          item.createTime = formatTime(item.createTime)
          item.updateTime = formatTime(item.updateTime)
          // 价格格式化
          item.overLoadPoints = money(item.overLoadPoints)
          item.transportAskPrice = money(item.transportAskPrice)
          item.returnPrice = money(item.returnPrice)
        })
        this.mianLineQuoteList = data
      },
      // 干线-按公里-查询接口
      async findTrunkChargeByKMByContractId (contractId = this.$route.query.contractId) {
        const data = await this.$http(Api.findTrunkChargeByKMByContractId, { contractId })
        data.forEach(item => {
          item.range = `${item.minKilometer} - ${item.maxKilometer}`
          item.createdAt = formatTime(item.createdAt)
          item.updatedAt = formatTime(item.updatedAt)
          // 价格格式化
          item.startPrice = money(item.startPrice)
        })
        this.mianLineKmList = data
      },
      // 按重量报价列表-查询接口
      async querySignedDriverChargingByWeight () {
        const data = await this.$http(Api.querySignedDriverChargingByWeight, { contractId: this.$route.query.contractId, driverId: this.$route.query.driverId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.range = `${item.minWeight} - ${item.maxWeight}`
            item.updateTime = formatTime(item.updateTime)
            item.createTime = formatTime(item.createTime)
            // 价格格式化
            item.bottomPrice = money(item.bottomPrice)
            item.startPrice = money(item.startPrice)
            item.renewalPrice = money(item.renewalPrice)
          })
          this.getSendQuoteList = data
        }
      },
      // 折扣优惠-查询接口
      async querySignedDriverDiscount () {
        const data = await this.$http(Api.querySignedDriverDiscount, { driverId: this.$route.query.driverId })
        data.map(item => {
          item.createTime = formatTime(item.createTime)
          item.updateTime = formatTime(item.updateTime)
          if (item.discount < 1) {
            // 折扣转百分比
            item.discount = item.discount * 100
          }
          item.range = `${item.minFreight}-${item.maxFreight}` // 范围拼接
        })
        this.discountInfoList = data
      },
      // 取派报价-按重量-保存成功回调
      getSendQuoteSaved () {
        this.querySignedDriverChargingByWeight()
      },
      // 取派报价-按重量-删除成功回调
      getSendQuoteDeleted () {
        this.querySignedDriverChargingByWeight()
      },
      // 取派报价-按公里-保存成功回调
      getSendKmSaved () {
        this.findTakepieChargeByKilometer()
      },
      // 取派报价-按公里-删除成功回调
      getSendKmDeleted () {
        this.findTakepieChargeByKilometer()
      },
      // 干线报价-按公里-保存成功回调
      mianLineKmSaved () {
        this.findTrunkChargeByKMByContractId()
      },
      // 干线报价-按线路-保存成功回调
      mianLineQuoteSaved () {
        this.querySignedDriverOfferTrunkRoute()
      },
      // 干线报价-按线路-删除成功回调
      mianLineQuoteDeleted () {
        this.querySignedDriverOfferTrunkRoute()
      },
      // 干线报价-按公里-删除成功回调
      mainLinKmDeleted () {
        this.findTrunkChargeByKMByContractId()
      },
      // 折扣优惠-保存成功回调
      discountInfoSaved () {
        this.querySignedDriverDiscount()
      },
      // 折扣优惠-删除成功回调
      discountInfoDeleted () {
        this.querySignedDriverDiscount()
      },
      getDriverType (val) {
        this.driverType = Number(val)
      },
      // 检索供应商信息
      setDriverData (data) {
        this.driverData = data
        this.driverType = Number(this.driverData.driverType)
      },
      // 保存基础信息
      async saveBase (params) {
        let driverId
        if (params.driverId) {
          driverId = await this.$http(Api.editSignedCompanyBaseInfo, this.$diff(params, '**'))
        } else {
          driverId = await this.$http(Api.savesignedcompanybaseinfo, this.$diff(params, '**'))
        }
        this.saveFinace(driverId)
        this.driverId = driverId
        this.$message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        setTimeout(() => {
          const url = utils.changeURLArg(window.location.href, 'driverId', this.driverId)
          window.location.replace(url)
        }, 0)
      },
      // 保存财务信息
      async saveFinace (driverId) {
        const {
          bankAccountName,
          bankName,
          bankBranchName,
          bankAccount,
          payType,
          paymentMethod,
          payPeriod,
          isInvoicing,
          invoiceType,
          taxRate
        } = this.driverData
        const params = {
          driverId,
          bankAccountName,
          bankName,
          bankBranchName,
          bankAccount,
          payType,
          paymentMethod,
          payPeriod,
          isInvoicing,
          invoiceType,
          taxRate
        }
        this.$http(Api.savesignedcompanyfinanceinfo, params)
      },
      // 保存合同
      async saveContract (params) {
        const contractId = await this.$http(Api.saveSignedDriverContractInfo, params)
        this.contractId = contractId
        this.$message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.querySignedDriverContractInfoById(contractId)
        const url = utils.changeURLArg(window.location.href, 'contractId', contractId)
        setTimeout(() => {
          window.location.replace(url)
        }, 0)
        this.$refs.contractInfo.closeNewDialog()
        this.driverType = Number(this.driverData.driverType) // 运力类型
        this.contractType = Number(params.contractType) // 合同类型
        this.$refreshMainQueryTable()
      },
      // 删除合同
      async deleteContract (params) {
        this.$confirm('确定删除选中记录？', '提示').then(async () => {
          await this.$http(Api.deleteSignedDriverContractInfoBatch, params)
          this.contractList = []
          this.$message({
            showClose: true,
            message: '删除成功！',
            type: 'success'
          })
          const url = utils.changeURLArg(window.location.href, 'contractId', params.contractId)
          window.location.href = url // 改变url地址
        })
      },
      // 提交审核
      async confirmAudit () {
        this.$confirm('确定提交审核？', '提示').then(async () => {
          const contractId = this.contractId
          await this.$http(Api.saveSupplierData, { contractId }) // 提交审核
          this.$message({
            type: 'success',
            showClose: true,
            message: '操作成功'
          })
          // 保存成功后离开路由时不用提示是否保存当前数据
          this.SET_SAVE_HOOK_FLAG()
          this.$refreshMainQueryTable()
          this.$router.push(`/ecms/contract/view/${contractId}`)
        })
      },
      // 关闭新增弹窗
      closeNewDialog () {
        this.showNewDialog = false
      },
      // 上传
      beforeUpload (file) {
        if (file.size > 20 * 1024 * 1024) {
          this.$message.error('文件不能大于20M')
          return false
        } else {
          const that = this
          const isJPG = !!file.type.match('image/')
          const suffix = file.name.substring(file.name.lastIndexOf('.') + 1)
          const typeArr = [
            'image/png',
            'image/jpeg',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'application/vnd.ms-powerpoint',
            'application/pdf',
            'application/zip',
            'application/x-zip-compressed',
            'application/rar',
            'text/plain',
            'image/jpeg',
            'image/jpg',
            'image/png'
          ]
          if (typeArr.indexOf(file.type) === -1 && suffix.toLowerCase().indexOf('rar') === -1) {
            this.$message.error('不支持该上传格式')
            return false
          }
          const reader = new FileReader()
          reader.readAsDataURL(file)
          this.uploadLoading = true
          reader.onload = async function (e) {
            try {
              const data = await that.$http(Api.uploadFilesBase64, { base64Code: this.result, fileType: isJPG ? 1 : 2, suffix: '.' + suffix })
              const params = {
                contractId: that.$route.query.contractId,
                fileType: suffix,
                fileName: file.name,
                fileUrl: data
              }
              await that.$http(Api.saveSignedDriverCardInfoPhotos, params) // 保存附件信息
              that.$message.success('操作成功')
              that.uploadLoading = false
              that.querySignedDriverCardInfoPhotos() // 查询列表
            } catch (error) {
              that.uploadLoading = false
            }
          }
          return false
        }
      },
      // 下载附件
      async handleDownload (index, row) {
        window.erpOpen(row.fileUrl)
      },
      // 删除附件
      async handleDelete (index, row) {
        this.$confirm('确定删除该文件吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          let ids = row.id + ''
          await this.$http(Api.delDriverDocAttachmentPhotos, { ids }) // 删除
          this.querySignedDriverCardInfoPhotos() // 查询
        })
      },
      // 查询附件列表
      async querySignedDriverCardInfoPhotos () {
        const data = await this.$http(Api.querySignedDriverCardInfoPhotos, { contractId: this.$route.query.contractId })
        data.forEach(item => {
          item.createdAt = formatTime(item.createdAt, 'M')
        })
        this.uploadData = data
      },
      // 保存当前计价方式
      async saveBidCalWay (calWay = this.calWay, contractId = this.contractId, taskType = this.taskType) {
        this.$http(Api.saveBidCalWay, { contractId, taskType, calWay })
      },
      // 获取当前报价方式（干线和取派）
      async getBidCalWay (contractId = this.contractId) {
        const { taskType, calWay } = await this.$http(Api.getBidCalWay, { contractId })
        this.taskType = taskType
        this.calWay = calWay
        if (calWay === '01' || calWay === '03') { // 取派
          this.curGetSendQuote = calWay
          this.curGetSendQuoteBackup = calWay
        }
        if (calWay === '04' || calWay === '05') { // 干线
          this.curMainLineQuote = calWay
          this.curMainLineQuoteBackup = calWay
        }
      },
      // 取派报价方式切换
      getSendQuoteChange (value) {
        let tips = ''
        if (value === '01') { // 按重量
          tips = '选择按重量报价,点击确定立即生效'
        } else if (value === '03') { // 按公里
          tips = '选择按公里报价,点击确定立即生效'
        }
        this.$confirm(tips, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.saveBidCalWay(value) // 保存计费方式
          this.curGetSendQuote = value
          this.curGetSendQuoteBackup = value
        }).catch(() => {
          this.curGetSendQuote = this.curGetSendQuoteBackup
        })
      },
      // 干线报价方式切换
      mainLineQuoteChange (value) {
        let tips = ''
        if (value === '05') { // 按重量
          tips = '选择按线路报价,点击确定立即生效'
        } else if (value === '04') { // 按公里
          tips = '选择按公里报价,点击确定立即生效'
        }
        this.$confirm(tips, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.saveBidCalWay(value) // 保存计费方式
          this.curMainLineQuote = value
          this.curMainLineQuoteBackup = value
        }).catch(() => {
          this.curMainLineQuote = this.curMainLineQuoteBackup
        })
      }
    }
  }
</script>
<style lang="scss">
  .wbyl-mt12 {
    margin-top: 12px;
  }
  .ecms-interval-block {
    .el-form-item.is-required.el-form-item--mini {
      .el-form-item__label {
        display: none !important;
      }
    }
  }
</style>
