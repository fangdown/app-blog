<template>
  <div>
    <kye-dialog :visible.sync="showDialog"
                width="800px">
      <div slot="title">{{dialogTitle}}</div>
      <kye-form :model="addContractForm">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="合同名称">
              <kye-field v-model="addContractForm.contractName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="合同编号">
              <kye-field v-model="addContractForm.contractNo"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="签约大区">
              <kye-field v-model="addContractForm.businessRegionName"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="签约点部">
              <kye-field v-model="addContractForm.signedPoint"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="16">
            <!-- 省市 -->
            <kye-col :span="12">
              <kye-form-item label="所在省">
                <kye-field v-model="operationAddrObj.province"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="12">
              <kye-form-item label="所在市">
                <kye-field v-model="operationAddrObj.city"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="合同类型">
              <kye-field v-model="addContractForm.contractTypeName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="合作方">
              <kye-field v-model="addContractForm.cooperationPart"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="签订主体">
              <kye-field v-model="addContractForm.signedPart"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="付款主体">
              <kye-field v-model="addContractForm.payPart"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="状态"
                           prop="statusName">
              <kye-field>{{addContractForm.statusName}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="开始时间">
              <kye-field v-model="addContractForm.startTime"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="终止日">
              <kye-field v-model="addContractForm.contractEndDay"></kye-field>

            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="签订人">
              <kye-field v-model="addContractForm.contractSignPerson"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="保管人">
              <kye-field v-model="addContractForm.keeper"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="签订部门">
              <kye-field v-model="addContractForm.contractSignDepartment"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="附件信息">
              <kye-field v-model="addContractForm.documentInfo"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="承诺约定">
              <kye-field v-model="addContractForm.promise"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="16">
            <kye-form-item label="备注"
                           prop="remark">
              <kye-field v-model="addContractForm.remark"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer">
        <kye-button type="primary"
                    @click="showDialog = false">关 闭</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  export default {
    props: {
      isShow: {
        type: Boolean,
        default: false
      },
      dialogTitle: {
        type: String,
        default: ''
      },
      form: {
        type: null,
        default: () => ({})
      }
    },
    watch: {
      isShow (newVal) {
        if (newVal) {
          this.showDialog = this.isShow
        }
      },
      showDialog (newVal) {
        this.$emit('visiable-change', newVal)
      },
      form (newVal) {
        if (newVal && this.dialogTitle === '修改合同信息') {
          this.addContractForm = this.form
          this.operationAddrObj = {
            province: this.form.province,
            city: this.form.city
          }
        } else if (newVal && this.dialogTitle === '查看合同信息') {
          this.addContractForm = this.form
          this.hideBox = false
          this.operationAddrObj = {
            province: this.form.province,
            city: this.form.city
          }
        }
      }
    },
    data () {
      return {
        showDialog: false, // 显示弹窗
        operationAddrObj: {
          province: '',
          city: ''
        },
        addContractForm: {},
        hideBox: true
      }
    }
  }
</script>


