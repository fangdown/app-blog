<template>
  <div class="kye-detail">
    <search-pager :option="isAudit?optionAudit:option"
                  :tools="isAudit?searchToolsAudit:searchTools"></search-pager>
    <kye-expand-page>
      <!-- 基础信息 -->
      <baseInfo v-if="driverData"
                :formData="driverData" />
      <!-- 财务信息 -->
      <financeInfo v-if="driverData"
                   :form="driverData" />
      <!-- 合同信息 -->
      <contractInfo v-if="contractList"
                    :contractList="contractList" />
      <!-- 报价信息 -->
      <div v-if="driverType===3">
        <div class="kye-block-title wbyl-mt12"
             v-if="contractType===100||contractType===200">报价信息</div>
        <kye-tabs v-if="contractType===100||contractType===200"
                  v-model="quoteTabsActiveName"
                  @tab-click="getQuoteInfo">
          <kye-tab-pane v-if="contractType===100"
                        label="取派报价"
                        name="first">
            <div class="wbyl-mt4">
              <kye-radio-group v-model="curGetSendQuote">
                <kye-radio label="01">按重量</kye-radio>
                <kye-radio label="03">按公里</kye-radio>
              </kye-radio-group>
            </div>
            <getSendWeight v-if="curGetSendQuote==='01'"
                           :tableData="getSendQuoteListWeight"
                           class="wbyl-mt4" />
            <getSendKm v-if="curGetSendQuote==='03'"
                       :tableData="getSendKmList"
                       class="wbyl-mt4" />
          </kye-tab-pane>
          <kye-tab-pane v-if="contractType===200"
                        label="干线报价"
                        name="first">
            <div class="wbyl-mt4">
              <kye-radio-group v-model="curMainLineQuote">
                <kye-radio label="05">按线路</kye-radio>
                <kye-radio label="04">按公里</kye-radio>
              </kye-radio-group>
            </div>
            <mainlineQuoteLine v-if="curMainLineQuote==='05'"
                               :tableData="mianLineQuoteListLine"
                               class="wbyl-mt4" />
            <mainlineQuoteKm v-if="curMainLineQuote==='04'"
                             :tableData="mianLineKmList"
                             class="wbyl-mt4" />
          </kye-tab-pane>
          <kye-tab-pane v-if="contractType===100||contractType===200"
                        label="折扣优惠"
                        name="second">
            <discountInfo :tableData="discountInfoList"
                          class="wbyl-mt4" />
          </kye-tab-pane>
        </kye-tabs>
      </div>
      <!-- 附件信息 -->
      <div v-if="driverType===3">
        <div class="kye-block-title wbyl-mt12">附件信息</div>
        <kye-table :data="uploadData"
                   stripe
                   max-height="200"
                   :header-cell-style="{background:'#F1F1F5',textAlign:'left'}">
          <kye-table-column prop="fileName"
                            width="300px"
                            label="文件名称">
          </kye-table-column>
          <kye-table-column prop="creatorName"
                            label="上传人"
                            width="150px">
          </kye-table-column>
          <kye-table-column prop="createdAt"
                            width="150px"
                            label="上传时间">
          </kye-table-column>
          <kye-table-column label="操作">
            <template slot-scope="scope">
              <kye-button type="text"
                          @click="handleDownload(scope.$index, scope.row)">下载</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
      </div>
    </kye-expand-page>
  </div>
</template>
<script>
  // 基础模块
  import baseInfo from './components-view/contract-base-info'
  // 财务模块
  import financeInfo from './components-view/contract-finance-info'
  // 合同模块
  import contractInfo from './components-view/contract-contractInfo'
  // 取派-按重量计费模块
  import getSendWeight from '../../../components/contract-tables/get-send-weight'
  // 取派-按公里计费模块
  import getSendKm from '../../../components/contract-tables/get-send-km'
  // 干线-按线路计费模块
  import mainlineQuoteLine from '../../../components/contract-tables/mainline-quote-line'
  // 干线-按公里计费模块
  import mainlineQuoteKm from '../../../components/contract-tables/mainline-quote-km'
  // 折扣优惠模块
  import discountInfo from '../../../components/contract-tables/discount'
  // API接口
  import Api from './contract.api.js'
  // 时间格式化
  import { formatTime } from '../../utils/format'
  // 金钱格式化
  import { money } from 'public/utils/filter.js'

  export default {
    components: {
      baseInfo,
      financeInfo,
      contractInfo,
      getSendWeight,
      getSendKm,
      mainlineQuoteLine,
      mainlineQuoteKm,
      discountInfo
    },
    data () {
      return {
        isAudit: '', // 是否审核/反审
        driverId: '', // 运力ID
        contractId: '', // 合同id
        contractList: [], // 合同列表
        getSendQuoteListWeight: [], // 取派报价-按重量
        getSendKmList: [], // 取派报价列表-按公里
        mianLineQuoteListLine: [], // 干线报价-按线路
        mianLineKmList: [], // 干线报价列表-按公里
        discountInfoList: [], // 折扣优惠列表
        uploadData: [], // 附件列表
        driverType: '', // 运力类型
        contractType: '', // 合同类型
        driverData: null,
        allowEdit: false, // 是否允许编辑（待完善100||未完善101 才可以编辑）
        quoteTabsActiveName: 'first', // 报价tab当前激活页
        curGetSendQuote: '', // 当前的取派报价方式
        curMainLineQuote: '', // 当前干线报价方式
        auditStatus: {
          status: '00', // 状态 00-未审核（已提交），10-审核。20-反审
          role: '10' // 10-一级审核员，20-二级审核员，30-三级审核员
        },
        option: {
          back: '/ecms/contract/list',
          method: Api.findAllSignedDriverList,
          idKey: `contractId`
        },
        optionAudit: {
          back: '/ecms/contract/list',
          unpager: true // 不显示上下翻页组件
        },
        searchToolsAudit: [
          {
            label: '一级审核',
            icon: 'ecs-shenhe',
            auth: 'ecs.yc.signedCompanyManage.firstContractReview.do',
            disabled: () => !(this.auditStatus.status === '00' && this.auditStatus.role === '10'),
            func: () => this.audit('是否进行一级审核操作?', { status: '10', role: '10' })
          },
          {
            label: '一级反审',
            icon: 'ecs-fanshen',
            auth: 'ecs.yc.signedCompanyManage.firstContractRejectReview.do',
            disabled: () => !(this.auditStatus.status === '10' && this.auditStatus.role === '10'),
            func: () => this.audit('是否进行一反级审操作?（点击”确定“按钮将进入可编辑状态）', { status: '20', role: '10' })
          },
          {
            label: '二级审核',
            icon: 'ecs-shenhe',
            auth: 'ecs.yc.signedCompanyManage.secondContractReview.do',
            disabled: () => !(this.auditStatus.status === '10' && this.auditStatus.role === '10'),
            func: () => this.audit('是否进行二级审核操作?', { status: '10', role: '20' })
          },
          {
            label: '二级反审',
            icon: 'ecs-fanshen',
            auth: 'ecs.yc.signedCompanyManage.secondContractRejectReview.do',
            disabled: () => !(this.auditStatus.status === '10' && this.auditStatus.role === '20'),
            func: () => this.audit('是否进行二级反审操作?', { status: '20', role: '20' })
          },
          {
            label: '三级审核',
            icon: 'ecs-shenhe',
            auth: 'ecs.yc.signedCompanyManage.threeContractReview.do',
            disabled: () => !(this.auditStatus.status === '10' && this.auditStatus.role === '20'),
            func: () => this.audit('是否进行三级审核操作（点击“确定”按钮将推送数据给下一级部门）?', { status: '10', role: '30' })
          },
          {
            label: '三级反审',
            icon: 'ecs-fanshen',
            auth: 'ecs.yc.signedCompanyManage.threeContractRejectReview.do',
            disabled: () => !(this.auditStatus.status === '10' && this.auditStatus.role === '30'),
            func: () => this.audit('是否进行三级反审操作?', { status: '20', role: '30' })
          }
        ],
        searchTools: [
          {
            label: '修改',
            icon: 'pen',
            auth: 'ecs.yc.signedCompanyManage.saveSignedDriverContractInfo.do',
            disabled: () => this.allowEdit,
            func: () => {
              this.$router.push({
                path: `/ecms/contract/edit`,
                query: {
                  driverId: Number(this.driverId),
                  contractId: Number(this.$route.params.id),
                }
              })
            }
          }
        ]
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        vm.quoteTabsActiveName = 'first'
        vm.isAudit = !!vm.$route.query.audit // 是否审核/反审
        vm.contractId = vm.$route.params.id
        if (!vm.$route.meta.layout) {
          if (vm.$route.query.audit) { // 审核
            vm.findSupplierReviewStatus() // 查询审核状态
          }
          // 数据初始化
          vm.quoteTabsActiveName = 'first'
          vm.curGetSendQuote = '' // 当前的取派报价方式
          vm.curMainLineQuote = '' // 当前干线报价方式
          vm.driverData = {} // 基础、财务信息
          vm.contractList = []// 合同列表
          vm.getSendQuoteListWeight = []// 取派报价-按重量
          vm.getSendKmList = []// 取派报价列表-按公里
          vm.mianLineQuoteListLine = []// 干线报价-按线路
          vm.mianLineKmList = []// 干线报价列表-按公里
          vm.discountInfoList = []// 折扣优惠列表
          vm.uploadData = []// 附件列表
          vm.init(vm.contractId)
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.contractId = to.params.id // 注意，这里获取的是下一个路由的id
      // 数据初始化
      this.quoteTabsActiveName = 'first'
      this.curGetSendQuote = '' // 当前的取派报价方式
      this.curMainLineQuote = '' // 当前干线报价方式
      this.driverData = {} // 基础、财务信息
      this.contractList = []// 合同列表
      this.getSendQuoteListWeight = []// 取派报价-按重量
      this.getSendKmList = []// 取派报价列表-按公里
      this.mianLineQuoteListLine = []// 干线报价-按线路
      this.mianLineKmList = []// 干线报价列表-按公里
      this.discountInfoList = []// 折扣优惠列表
      this.uploadData = []// 附件列表
      this.init(this.contractId)
      next()
    },
    methods: {
      async init (contractId) {
        this.getBidCalWay(contractId) // 获取报价方式
        this.querySignedDriverCardInfoPhotos(contractId) // 获取附件信息
        await this.getSignedBaseAndFinanceInfo(contractId) // 获取基础信息、财务信息
        this.querySignedDriverContractInfoById(contractId) // 获取合同列表
      },
      // 获取报价信息
      getQuoteInfo (curTab = this.quoteTabsActiveName, contractType = this.contractType) {
        this.querySignedDriverDiscount()
        if (curTab === 'first') {
          if (this.contractType === 100) {
            this.querySignedDriverChargingByWeight() // 取派-按重量
            this.findTakepieChargeByKilometer() // 取派-按公里
          } else if (this.contractType === 200) {
            this.querySignedDriverOfferTrunkRoute() // 干线-按线路
            this.findTrunkChargeByKMByContractId() // 干线-按公里
          }
        }
      },
      // 获取基础信息、财务信息
      async getSignedBaseAndFinanceInfo (contractId) {
        const data = await this.$http(Api.getSignedBaseAndFinanceInfo, { contractId })
        if (!data) return
        this.driverData = data
        this.driverType = Number(this.driverData.driverType)
        this.driverId = data.driverId
        this.driverData.driverId = this.driverId
        // 数据翻译-运力类型
        if (this.driverData.driverType === '2') {
          this.driverData.driverType = '平台运力'
        } else if (this.driverData.driverType === '3') {
          this.driverData.driverType = '合同运力'
        }
        // 数据翻译-报价类型
        if (this.driverData.bidType === '101') {
          this.driverData.bidType = '竞价'
        } else if (this.driverData.bidType === '102') {
          this.driverData.bidType = '合同报价'
        }
        // 数据翻译-是否开票
        if (this.driverData.isInvoicing === '1') {
          this.driverData.isInvoicing = '是'
        } else if (this.driverData.isInvoicing === '2') {
          this.driverData.isInvoicing = '否'
        }
        // 数据翻译-发票类型
        const invoiceTypeType = {
          '10': '增值税普通发票',
          '20': '增值税专用发票',
          '30': '收据',
          '40': '定额发票'
        }
        this.driverData.invoiceType = invoiceTypeType[this.driverData.invoiceType]
        // 数据翻译-付款方式
        const paymentMethodType = {
          '10': '网转',
          '20': '电汇',
          '30': '现金',
          '40': '支票'
        }
        this.driverData.paymentMethod = paymentMethodType[this.driverData.paymentMethod]
        // 数据翻译-结算类型
        const payTypeType = {
          '10': '月结',
          '20': '非月结',
        }
        this.driverData.payType = payTypeType[this.driverData.payType]
        // 数据翻译-合作状态
        const stateType = {
          1: '正在合作',
          2: '暂停合作',
          3: '终止合作'
        }
        this.driverData.state = stateType[this.driverData.state]
      },
      // 合同信息列表查询
      async querySignedDriverContractInfoById (contractId = this.$route.params.id, quoteInfo = true) {
        const data = await this.$http(Api.querySignedDriverContractInfoById, { contractId })
        this.contractType = Number(data[0].contractType) // 合同类型
        if (quoteInfo) {
          this.getQuoteInfo() // 获取报价信息
        }
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            item.startTime = formatTime(item.startTime)
            item.contractEndDay = formatTime(item.contractEndDay)
          })
        }
        this.contractList = data
        if (data[0].status === 100 || data[0].status === 101) {
          this.allowEdit = false
        } else {
          this.allowEdit = true
        }
      },
      // 取派-按重量-查询接口
      async querySignedDriverChargingByWeight (contractId = this.contractId) {
        const data = await this.$http(Api.querySignedDriverChargingByWeight, { contractId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.range = `${item.minWeight} - ${item.maxWeight}`
            item.updateTime = formatTime(item.updateTime)
            item.createTime = formatTime(item.createTime)
            item.bottomPrice = money(item.bottomPrice)
            item.startPrice = money(item.startPrice)
            item.renewalPrice = money(item.renewalPrice)
          })
          this.getSendQuoteListWeight = data
        }
      },
      // 干线-按公里-查询接口
      async findTrunkChargeByKMByContractId (contractId = this.contractId) {
        const data = await this.$http(Api.findTrunkChargeByKMByContractId, { contractId })
        data.forEach(item => {
          item.range = `${item.minKilometer} - ${item.maxKilometer}`
          item.createdAt = formatTime(item.createdAt)
          item.updatedAt = formatTime(item.updatedAt)
          item.startPrice = money(item.startPrice)
        })
        this.mianLineKmList = data
      },
      // 取派-按公里-查询接口
      async findTakepieChargeByKilometer (contractId = this.contractId) {
        const data = await this.$http(Api.findTakepieChargeByKilometer, { contractId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.range = `${item.minKilometer} - ${item.maxKilometer}`
            item.createdAt = formatTime(item.createdAt)
            item.updatedAt = formatTime(item.updatedAt)
            item.startPrice = money(item.startPrice)
          })
          this.getSendKmList = data
        }
      },
      // 报价信息-干线报价-按线路
      async querySignedDriverOfferTrunkRoute (contractId = this.contractId) {
        const data = await this.$http(Api.querySignedDriverOfferTrunkRoute, { contractId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            item.overLoadPoints = money(item.overLoadPoints)
            item.transportAskPrice = money(item.transportAskPrice)
            item.returnPrice = money(item.returnPrice)
          })
        }
        this.mianLineQuoteListLine = data
      },
      // 报价信息-折扣优惠
      async querySignedDriverDiscount (contractId = this.contractId) {
        const data = await this.$http(Api.querySignedDriverDiscount, { contractId, driverId: this.driverId })
        if (data && Array.isArray(data)) {
          data.forEach(item => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            if (item.discount < 1) {
              item.discount = item.discount * 100
            }
            item.range = `${item.minFreight}-${item.maxFreight}` // 范围拼接
          })
        }
        this.discountInfoList = [] // 清空数据
        this.discountInfoList = data
      },
      // 合同运力审核状态-查询
      async findSupplierReviewStatus (contractId = this.$route.params.id) {
        const data = await this.$http(Api.findSupplierReviewStatus, { contractId })
        if (!data.role) { // 默认为一级审核人员
          data.role = '10'
        }
        this.auditStatus = data
      },
      // 合同运力审核
      async supplierReviewStatus ({ status, role } = {}) {
        const params = { driverId: this.$route.query.driverId, contractId: this.$route.params.id, status, role }
        const data = await this.$http(Api.supplierReviewStatus, params)
        this.auditStatus = data
        this.findSupplierReviewStatus() // 查询审核状态
      },
      // 审核
      audit (tips, auditStatus, contractId = this.$route.params.id) {
        this.$confirm(tips, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.supplierReviewStatus(auditStatus)
          await this.querySignedDriverContractInfoById(contractId, false)
          this.$refreshMainQueryTable()
        })
      },
      // 附件下载
      handleDownload (index, row) {
        window.erpOpen(row.fileUrl)
      },
      // 查询附件列表
      async querySignedDriverCardInfoPhotos (contractId) {
        const data = await this.$http(Api.querySignedDriverCardInfoPhotos, { contractId })
        data.forEach(item => {
          item.createdAt = formatTime(item.createdAt, 'M')
        })
        this.uploadData = data
      },
      // 获取当前报价方式（干线和取派）
      async getBidCalWay (contractId = this.contractId) {
        const { calWay } = await this.$http(Api.getBidCalWay, { contractId })
        if (calWay === '01' || calWay === '03') { // 取派
          this.curGetSendQuote = calWay
        }
        if (calWay === '04' || calWay === '05') { // 干线
          this.curMainLineQuote = calWay
        }
      }
    }
  }
</script>
<style lang="scss">
  .wbyl-mt12 {
    margin-top: 12px;
  }
  .wbyl-mt4 {
    margin-top: 4px;
  }
</style>


