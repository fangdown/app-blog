<template>
  <div>
    <div class="kye-block-title">基本信息</div>
    <kye-form ref="ruleForm"
              module-code="ecs_yc"
              :biz-id="$route.params.id"
              :model.sync="form">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="供应商编号">
            <kye-field v-model="form.supplierNum"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="运力简称">
            <kye-field v-model="form.name"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="运力全称">
            <kye-field v-model="form.fullName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="负责人">
            <kye-field v-model="form.liableName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="负责人电话"
                         prop="phone">
            <kye-field v-model="form.phone"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="运力类型">
            <kye-field v-model="form.driverType"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="报价类型">
            <kye-field v-model="form.bidType"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="服务大区">
            <kye-field v-model="form.businessArea"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4"
                 class="business-types">
          <kye-form-item label="业务类型">
            <kye-field>{{form.businessType}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="供应商状态">
            <kye-field>{{form.checkState|lookup('ecs_ht_supplier_status')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="合作频次">
            <kye-field>{{form.cooperationTimes}}</kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="地址">
            <kye-field v-model="form.address"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="16">
          <kye-form-item label="备注">
            <kye-field v-model="form.remark"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>

<script>
  export default {
    props: {
      formData: {
        type: Object,
        default: () => ({})
      }
    },
    data () {
      return {
        form: this.formData
      }
    },
    watch: {
      formData (newVal) { // 使用watch是为了解决解密监控字段报错问题
        if (newVal) {
          this.form = newVal
        }
      }
    }
  }
</script>


