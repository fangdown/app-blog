<template>
  <div class="ky-list">
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :form-model="formModel"
                 :option="option"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
    <!-- 新增合同弹窗 -->
    <filterSupplier :showNewDialog.sync="showNewDialog"
                    @close="closeNewDialog"
                    @setDriverData="setDriverData" />

  </div>
</template>
<script>
  // API接口
  import Api from './contract.api.js'
  // 新增合同模块
  import filterSupplier from './components-edit/contract-dialog/filter-supplier'
  // 时间格式化，时间加减
  import { formatTime, dateAdd } from '../../utils/format.js'

  export default {
    components: {
      filterSupplier
    },
    data () {
      return {
        Api,
        showNewDialog: false, // 是否新增弹窗
        selectData: [],
        generic: {
          method: Api.findAllSignedDriverList,
          searchCode: 'ecs_yc_contract_search'
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: Api.findAllSignedDriverList,
            func: () => {
              this.$refs.queryTable.loadData()
            }
          },
          {
            label: '新增',
            icon: 'plus',
            auth: Api.supplierSyncContract,
            func: () => this.showNewDialog = true
          },
          {
            label: '审核/反审',
            icon: 'ecs-shenhe',
            auth: Api.editSignedCompanyBaseInfo,
            disabled: () => !(this.selectData.length === 1 && [100, 105].indexOf(this.selectData[0].status) === -1),
            func: (row) => {
              this.$router.push({
                path: `/ecms/contract/view/${this.selectData[0].contractId}`,
                query: {
                  audit: 1,
                  driverId: this.selectData[0].driverId || ''
                }
              })
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'ecs_yc_contract_list_search_define'
        },
        formModel: {
          registTime: [this.$options.filters.date(+new Date(dateAdd(new Date(), -1))), this.$options.filters.date(+new Date())]
        },
        tables: [
          {
            searchCode: 'ecs_yc_contract_list_field',
            url: { method: Api.findAllSignedDriverList },
            option: {
              load: false, // 是否自动加载数据，默认 true
              type: 'selection',
              idKey: 'contractId', // 详情页上下翻页要用到
              moduleCode: 'ecs_yc',
              defaultSort: {
                keys: ['createTime', 'create_time'],
                prop: 'createTime',
                order: 'descending'
              },
              detailAuth: Api.editSignedCompanyBaseInfo,
              rowDblClick: (row) => this.$router.push(`/ecms/contract/view/${row.contractId}`),
              // 将搜索表单参数赋值给请求中去，时间转时间戳
              beforeFormSubmit: (data, model) => {
                const obj = {}
                let isEmpty = true // 是否有条件
                delete data.startTime
                delete data.endTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'registTime') {
                      if (model.registTime && model.registTime.length === 2) {
                        isEmpty = false
                        const startTime = +new Date(formatTime(model.registTime[0]) + ' 00:00:00')
                        const endTime = +new Date(formatTime(model.registTime[1]) + ' 23:59:59')
                        Object.assign(obj, {
                          startTime,
                          endTime
                        })
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
              selectionChange: (rows) => {
                this.selectData = rows
              },
            },
          }
        ],
      }
    },
    methods: {
      // 检索供应商信息
      setDriverData (data) {
        this.$store.commit('ecms/SET_CONTRACT_DRIVER_DATA', data)
        this.$router.push('/ecms/contract/edit')
      },
      // 关闭新增弹窗
      closeNewDialog () {
        this.showNewDialog = false
      }
    }

  }
</script>



