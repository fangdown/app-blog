<template>
  <div>
    <div class="tab-operation">
      <kye-button type="text"
                  icon="iconfont icon-plus"
                  :auth="Api.saveDriverOfferTrunkRoute"
                  @click="handleShowMainLineDialog">新增
      </kye-button>
      <kye-button type="text"
                  icon="iconfont icon-delete"
                  :disabled="deleteDisabled"
                  :auth="Api.delBatchSignedDriverOfferTrunkRoute"
                  @click="deleteSelectedInfo">删除
      </kye-button>
    </div>
    <mainlineQuoteLine :tableData="mianLineQuoteList"
                       :showSelection="true"
                       @selected-list="handleDataInfoSelectionChange" />
    <kye-dialog title="新增干线报价(按线路)"
                width="600px"
                :visible.sync="showMainLineDialog"
                @close="closeDialog">
      <kye-form ref="ruleForm"
                :model="quoteMainLineForm">
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="车型"
                           prop="carTypeId"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="quoteMainLineForm.carTypeId"
                          @change="getCarLengthByType">
                <kye-option v-for="item in carTypeOptions"
                            :key="item.dictKey"
                            :label="item.dictValue"
                            :value="item.dictKey">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="车长"
                           prop="carLength"
                           :rules="[
                            { required: true, message: '不能为空',trigger:'change'},
                          ]">
              <kye-select placeholder=""
                          v-model="quoteMainLineForm.carLength"
                          ref="carLengthSelect">
                <kye-option v-for="item in carLongOptions"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="始发地"
                           prop="startPoint"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete v-model="quoteMainLineForm.startPoint"
                                @select="handleSelect0"
                                :fetch-suggestions="querySearchAsync"
                                clearable
                                prefix-icon="el-icon-search"></kye-autocomplete>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="经停地1"
                           prefix-icon="el-icon-search"
                           prop="stopLand1"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete @select="handleSelect1"
                                :fetch-suggestions="querySearchAsync"
                                prefix-icon="el-icon-search"
                                v-model="quoteMainLineForm.stopLand1"
                                clearable></kye-autocomplete>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="经停地2"
                           prop="stopLand2"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete @select="handleSelect2"
                                :fetch-suggestions="querySearchAsync"
                                prefix-icon="el-icon-search"
                                v-model="quoteMainLineForm.stopLand2"
                                clearable></kye-autocomplete>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="经停地3"
                           prop="stopLand3"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete @select="handleSelect3"
                                :fetch-suggestions="querySearchAsync"
                                prefix-icon="el-icon-search"
                                v-model="quoteMainLineForm.stopLand3"
                                clearable></kye-autocomplete>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="经停地4"
                           prop="stopLand4"
                           :rules="[
                              { required: false, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete @select="handleSelect4"
                                :fetch-suggestions="querySearchAsync"
                                prefix-icon="el-icon-search"
                                v-model="quoteMainLineForm.stopLand4"
                                clearable></kye-autocomplete>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="目的地"
                           prop="endPoint"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-autocomplete @select="handleSelect5"
                                :fetch-suggestions="querySearchAsync"
                                prefix-icon="el-icon-search"
                                v-model="quoteMainLineForm.endPoint"
                                clearable></kye-autocomplete>
            </kye-form-item>
          </kye-col>

        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="单边公里"
                           prop="totalKm"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-number v-model="quoteMainLineForm.totalKm"
                          placeholder=''
                          unit="公里"
                          :precision="0"
                          :max="99999"
                          :min="1">
              </kye-number>

            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="含装卸点"
                           prop="includeLoadPoints">
              <kye-number v-model="quoteMainLineForm.includeLoadPoints"
                          unit="个"
                          placeholder=''
                          :precision="0"
                          :max="99"
                          :min="1">
              </kye-number>
            </kye-form-item>
          </kye-col>

        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="超装卸点"
                           prop="overLoadPoints">
              <kye-number v-model="quoteMainLineForm.overLoadPoints"
                          placeholder=''
                          unit="元/个"
                          :precision="1"
                          :max="99999"
                          :min="1">
              </kye-number>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="一口价"
                           prop="transportAskPrice"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-number v-model="quoteMainLineForm.transportAskPrice"
                          unit="元"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="1">
              </kye-number>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="回程价"
                           prop="returnPrice">
              <kye-number v-model="quoteMainLineForm.returnPrice"
                          unit="元"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="1">
              </kye-number>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="计费状态"
                           prop="status"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="quoteMainLineForm.status"
                          @change="getCalStatus">
                <kye-option key="1"
                            label="生效"
                            value="1" />
                <kye-option key="2"
                            label="失效"
                            value="2" />
              </kye-select>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="备注">
              <kye-input v-model="quoteMainLineForm.remark"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :loading="loading"
                    :auth="Api.saveDriverOfferTrunkRoute"
                    @click="dialogSave">保存(S)</kye-button>
        <kye-button @click="showMainLineDialog = false">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  // 表单校验
  import { submitForm } from '../../../utils/validate'
  // API接口
  import Api from '../../../car-manage/contract/contract.api.js'
  // 干线报价-按线路模块
  import mainlineQuoteLine from '../../../../components/contract-tables/mainline-quote-line'

  export default {
    props: {
      mianLineQuoteList: {
        type: Array,
        default: () => ([])
      },
      contractId: {
        type: null
      },
      contractName: {
        type: String
      },
    },
    components: {
      mainlineQuoteLine
    },
    data () {
      return {
        Api,
        loading: false,
        editDisabled: true,
        deleteDisabled: true,
        showMainLineDialog: false, // 显示干线报价- 新增干线报价弹窗
        carTypeMap: new Map(), // 车型映射表
        carLongMap: new Map(), // 车长映射表
        carTypeOptions: [], // 车型数组
        carLongOptions: [], // 车长数组
        quoteMainLineForm: {}, // 新增干线报价表单
        selectedList: [], //  选中的列数据
        pointOptions: [] // 点部数据
      }
    },
    methods: {
      // 显示弹窗
      handleShowMainLineDialog () {
        this.showMainLineDialog = true
        this.GetCarStandardType() // 获取车辆类型数据
      },
      // 获取车辆类型数据
      async GetCarStandardType () {
        const data = await this.$http(Api.GetCarStandardType, {})
        data.forEach(element => {
          this.carTypeMap.set(element.dictKey, element.dictValue)
        })
        this.carTypeOptions = data
      },
      // 获取计费状态
      getCalStatus (status) {
        if (status === '1') {
          this.quoteMainLineForm.statusName = '生效'
        } else if (status === '2') {
          this.quoteMainLineForm.statusName = '失效'
        }
      },
      // 根据车型获取对应的车辆长度列表
      async getCarLengthByType (val) {
        const data = await this.$http(Api.getCarLengthByType, { carTypeId: val })
        if (data) {
          const temp = []
          data.map(element => {
            temp.push({
              label: element + '米',
              value: element
            })
            this.carLongMap.set(element, element + '米')
          })
          this.carLongOptions = temp
        }
      },
      // 弹窗--保存
      async dialogSave () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.quoteMainLineForm.driverId = this.$route.query.driverId
        this.quoteMainLineForm.relateContractNo = this.contractId
        this.quoteMainLineForm.relateContractName = this.contractName
        this.quoteMainLineForm.carTypeName = String(this.carTypeMap.get(this.quoteMainLineForm.carTypeId)) // 车型
        this.loading = true
        try {
          await this.$http(Api.saveDriverOfferTrunkRoute, this.quoteMainLineForm)
          this.showMainLineDialog = false // 隐藏弹窗
          this.loading = false
          this.$message({
            message: '操作成功',
            type: 'success'
          })
          this.quoteMainLineForm = {}
          this.$emit('mianLineQuoteSaved')
        } catch (error) {
          this.loading = false
        }
      },
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        const tempVal = Object.assign([], val)
        if (val.length === 1) {
          this.editDisabled = false
        } else {
          this.editDisabled = true
        }
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      async deleteSelectedInfo () {
        if (this.selectedList.length <= 0) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        this.$confirm('确定删除数据？', '提示').then(async () => {
          let ids = ''
          this.selectedList.forEach(element => {
            if (element.id) {
              ids += element.id + ','
            }
          })
          if (ids.length > 1) {
            ids = ids.slice(0, ids.length - 1) // 切掉最后一个逗号
          }
          await this.$http(Api.delBatchSignedDriverOfferTrunkRoute, { ids })
          this.$emit('mianLineQuoteDeleted')
          this.$message({
            showClose: true,
            message: '删除成功！',
            type: 'success'
          })
        })
      },
      // 根据点部名称查询点部信息
      async  querySearchAsync (queryString, cb) {
        let result = []
        if (!queryString) {
          return
        }
        const data = await this.$http(Api.getOperationData, { nodeName: queryString })
        if (!data) {
          return
        }
        data.forEach(item => {
          item.value = item.nodeName
          result.push(item)
        })
        cb(result)
      },
      // 获取操作点部下拉数据
      async getOperationPoint (query) {
        if (query !== '') {
          const data = await this.$http(Api.getOperationData, { nodeName: query })
          this.pointOptions = data.map(item => {
            return { label: item.nodeName, value: item.pointCode }
          })
        } else {
          this.pointOptions = []
        }
      },
      // 始发地
      handleSelect0 (item) {
        this.quoteMainLineForm.startPoint = item.nodeName
        this.quoteMainLineForm.startPointCode = item.pointCode
        this.quoteMainLineForm.startAreaCode = item.cityCode
        this.quoteMainLineForm.startAddress = item.addressDetail
      },
      // 经停地1
      handleSelect1 (item) {
        this.quoteMainLineForm.stopLand1 = item.nodeName
        this.quoteMainLineForm.stopLand1Code = item.pointCode
        this.quoteMainLineForm.stopLand1AreaCode = item.cityCode
        this.quoteMainLineForm.stopLand1Address = item.addressDetail
      },
      // 经停地2
      handleSelect2 (item) {
        this.quoteMainLineForm.stopLand2 = item.nodeName
        this.quoteMainLineForm.stopLand2Code = item.pointCode
        this.quoteMainLineForm.stopLand2AreaCode = item.cityCode
        this.quoteMainLineForm.stopLand2Address = item.addressDetail
      },
      // 经停地3
      handleSelect3 (item) {
        this.quoteMainLineForm.stopLand3 = item.nodeName
        this.quoteMainLineForm.stopLand3Code = item.pointCode
        this.quoteMainLineForm.stopLand3AreaCode = item.cityCode
        this.quoteMainLineForm.stopLand3Address = item.addressDetail
      },
      // 经停地4
      handleSelect4 (item) {
        this.quoteMainLineForm.stopLand4 = item.nodeName
        this.quoteMainLineForm.stopLand4Code = item.pointCode
        this.quoteMainLineForm.stopLand4AreaCode = item.cityCode
        this.quoteMainLineForm.stopLand4Address = item.addressDetail
      },
      // 目的地
      handleSelect5 (item) {
        this.quoteMainLineForm.endPoint = item.nodeName
        this.quoteMainLineForm.endPointCode = item.pointCode
        this.quoteMainLineForm.endAreaCode = item.cityCode
        this.quoteMainLineForm.endAddress = item.addressDetail
      },
      closeDialog () {
        this.quoteMainLineForm = {}
        this.$refs.ruleForm.resetFields()
        this.loading = false
      }
    }
  }
</script>
