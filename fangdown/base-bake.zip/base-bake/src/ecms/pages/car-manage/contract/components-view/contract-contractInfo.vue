<template>
  <div>
    <div class="kye-block-title">合同信息</div>
    <kye-table :data="contractList"
               max-height="500"
               border
               stripe
               :header-cell-style="{background:'#F1F1F5'}"
               @row-dblclick="dbFun">
      <kye-table-column type="index"
                        width="50"></kye-table-column>
      <kye-table-column prop="contractName"
                        label="合同名称"
                        align="center"
                        width="65"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractNo"
                        label="合同编号"
                        align="center"
                        width="112"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="businessRegionName"
                        label="签约大区"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="signedPoint"
                        label="签约点部"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="province"
                        label="所在省"
                        width="55"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="city"
                        label="所在市"
                        width="55"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractTypeName"
                        label="合同类型"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="cooperationPart"
                        label="合作方"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="signedPart"
                        label="签订主体"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="payPart"
                        label="付款主体"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="statusName"
                        label="状态"
                        align="center"
                        width="70"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="startTime"
                        label="开始时间"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractEndDay"
                        label="合同终止日"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractSignPerson"
                        label="合同签订人"
                        width="75"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="contractSignDepartment"
                        label="合同签订部门"
                        width="90"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="promise"
                        label="承诺约定"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
    </kye-table>
    <!-- 查看合同信息 -->
    <addContractDialogView :isShow="showExamine"
                           :dialogTitle="dialogTitle"
                           :form="popUpInfo"
                           @visiable-change="isExamine" />
  </div>
</template>

<script>
  // 合同显示弹窗
  import addContractDialogView from './contract-dialog/add-contract-dialog'

  export default {
    components: {
      addContractDialogView
    },
    props: {
      contractList: {
        type: Array,
        default: () => ([]) // 合同信息列表
      }
    },
    data () {
      return {
        dialogTitle: '',
        popUpInfo: {}, // 查看的信息
        showExamine: false // 查看显示隐藏
      }
    },
    methods: {
      // 监听查看弹框
      isExamine (newVal) {
        this.showExamine = newVal
      },
      // 双击表格查看详情
      dbFun (row, event) {
        this.popUpInfo = row
        this.dialogTitle = '查看合同信息'
        this.showExamine = true
      }
    }
  }
</script>
