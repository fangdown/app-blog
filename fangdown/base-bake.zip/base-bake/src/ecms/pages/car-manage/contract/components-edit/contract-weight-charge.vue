<template>
  <div>
    <div class="tab-operation">
      <kye-button type="text"
                  icon="iconfont icon-plus"
                  :auth="Api.saveSignedDriverChargingByWeight"
                  @click="handleShowAddContractDialog">新增
      </kye-button>
      <kye-button type="text"
                  icon="iconfont icon-delete"
                  :disabled="deleteDisabled"
                  :auth="Api.deleteSignedDriverChargingByWeightBatch"
                  @click="deleteSelectedInfo">删除
      </kye-button>
    </div>
    <getSendWeight :tableData="getSendQuoteList"
                   :showSelection="true"
                   @selected-list="handleDataInfoSelectionChange" />
    <kye-dialog title="新增取派报价(按重量)"
                width="800px"
                :visible.sync="showAddContractDialog"
                @close="closeDialog">
      <kye-form ref="ruleForm"
                :model="addContractForm">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="货物类型"
                           prop="productTypeName"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.productTypeName"
                          @change="getContractType">
                <kye-option v-for="item in lookUpOptions['crm_customer_type']"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value+'#'+item.label">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="计费状态"
                           prop="status"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-select placeholder=""
                          v-model="addContractForm.status"
                          clearable>
                <kye-option :key="1"
                            label="生效"
                            value="1">
                </kye-option>
                <kye-option :key="2"
                            label="失效"
                            value="2"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="保底价格"
                           prop="bottomPrice"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-number v-model="addContractForm.bottomPrice"
                          unit="元"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="0">
              </kye-number>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="备注">
              <kye-input v-model="addContractForm.remark"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <div class="title-bar">重量区间列表</div>
        <kye-table :data="tableData"
                   border
                   :header-cell-style="{background:'#F1F1F5'}">
          <kye-table-column label="*重量区间"
                            width="300px">
            <template slot-scope="scope">
              <div class="marginbtn12">
                <kye-row>
                  <kye-col :span="10">
                    <kye-number v-model="scope.row.minWeight"
                                unit="kg"
                                :disabled="scope.$index!==0"
                                :precision="0"
                                placeholder=''
                                :max="99999"
                                :min="0">
                    </kye-number>
                  </kye-col>
                  <kye-col :span="4"
                           align="center">
                    <span>-</span>
                  </kye-col>
                  <kye-col :span="10">
                    <kye-number v-model="scope.row.maxWeight"
                                unit="kg"
                                :precision="0"
                                placeholder=''
                                :max="99999"
                                :min="0">
                    </kye-number>
                  </kye-col>
                </kye-row>
              </div>
            </template>
          </kye-table-column>
          <kye-table-column label="*价格"
                            width="200px">
            <template slot-scope="scope">
              <kye-number v-model="scope.row.startPrice"
                          unit="元/客户"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="0">
              </kye-number>
            </template>
          </kye-table-column>
          <kye-table-column label="*续重价格"
                            width="160px">
            <template slot-scope="scope">
              <kye-number v-model="scope.row.renewalPrice"
                          unit="元/kg"
                          :precision="1"
                          placeholder=''
                          :max="99999"
                          :min="0">
              </kye-number>
            </template>
          </kye-table-column>
          <kye-table-column label="操作">
            <template slot-scope="scope">
              <kye-button @click="rowDelete(scope.$index)"
                          type="text"
                          v-if="scope.$index!==0"
                          size="small">删除</kye-button>
            </template>
          </kye-table-column>
        </kye-table>
        <div class="btn-wrap">
          <kye-button type="text"
                      class="iconfont icon-plus"
                      :disabled="tableData.length>7"
                      @click="addTableData"> 新增
          </kye-button>
        </div>
      </kye-form>
      <div class="tips">
        <p>价格区间录入须知：</p>
        <p>1.重量区间录入时,设：X为起始重量,Y为结束重量,录入时记为X＜货物重量≤Y；</p>
        <p>2.最后一个重量区间录入时,区间最大值录入为0,0代表∞(无穷大),例：500＜货物重量≤0,代表货物重量在500kg以上</p>
      </div>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :loading="loading"
                    :auth="Api.saveSignedDriverChargingByWeight"
                    @click="dialogSave">保存(S)</kye-button>
        <kye-button @click="showAddContractDialog = false">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  // 为了使用数据字典
  import mixins from 'public/mixins/index'
  // 表单校验
  import { submitForm } from '../../../utils/validate'
  // API接口
  import Api from '../../../car-manage/contract/contract.api.js'
  // 取派-按重量-table表格
  import getSendWeight from '../../../../components/contract-tables/get-send-weight'

  export default {
    mixins: [mixins],
    props: {
      getSendQuoteList: {
        type: Array,
        default: () => ([])
      },
      contractId: {
        type: null
      },
      contractName: {
        type: String
      }
    },
    components: {
      getSendWeight
    },
    data () {
      return {
        Api,
        loading: false,
        editDisabled: true,
        deleteDisabled: true,
        selectedList: [], //  选中的列数据
        showAddContractDialog: false, // 显示新增合同弹窗
        addContractForm: {}, // 表单
        goodsList: [], // 货物类型数组
        tableData: [{
          minWeight: '',
          maxWeight: '',
          startPrice: '',
          renewalPrice: '',
        }] // 弹窗表格数据
      }
    },
    methods: {
      // 显示新增取派报价弹窗
      async handleShowAddContractDialog () {
        this.showAddContractDialog = true
        // 获取货物类型
        const data = await this.$http(Api.supplierModelList, {})
        if (data && Array.isArray(data)) {
          data.forEach(element => {
            this.goodsList.push({ label: element.supplierModelName, value: element.id })
          })
        }
      },
      // 弹窗--保存
      async dialogSave () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.addContractForm.takepieChargeByWeightRangeList = JSON.stringify(this.tableData) // 重量区间列表字段赋值
        this.addContractForm.relateContractId = this.contractId
        this.addContractForm.relateContractName = this.contractName
        this.loading = true
        try {
          await this.$http(Api.saveSignedDriverChargingByWeight, this.addContractForm)
          this.loading = false
          this.$emit('getSendQuoteSaved')
          this.showAddContractDialog = false
          this.$message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
          this.addContractForm = {}
        } catch (error) {
          this.loading = false
        }
      },
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        const tempVal = Object.assign([], val)
        if (val.length === 1) {
          this.editDisabled = false
        } else {
          this.editDisabled = true
        }
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      async deleteSelectedInfo () {
        if (this.selectedList.length <= 0) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        this.$confirm('确定删除数据？', '提示').then(async () => {
          let ids = ''
          this.selectedList.map(element => {
            if (element.id) {
              ids += element.id + ','
            }
          })
          if (ids.length > 1) {
            ids = ids.slice(0, ids.length - 1) // 切掉最后一个逗号
          }
          await this.$http(Api.deleteSignedDriverChargingByWeightBatch, { ids })
          this.$emit('getSendQuoteDeleted')
          this.$message({
            showClose: true,
            message: '删除成功！',
            type: 'success'
          })
        })
      },
      // 选择货物类型
      getContractType (val) {
        this.addContractForm.productType = Number(val.split('#')[0])
        this.addContractForm.productTypeName = String(val.split('#')[1])
      },
      // 往表格添加列
      addTableData () {
        let len = this.tableData.length
        let isAdd = true
        let tempMaxWeight = ''
        let errInfo = ''
        if (len <= 7) {
          for (let item of this.tableData) {
            if (item.minWeight === '' || item.maxWeight === '' || item.startPrice === '' || item.renewalPrice === '') {
              this.$message({
                message: `请输入有效值`
              })
              isAdd = false
              break
            }
            if (Number(item.maxWeight) === 0) {
              this.$message({
                message: `最大值为0表示无穷大，后面不能再添加范围`
              })
              isAdd = false
              break
            }
            if (Number(item.minWeight) > Number(item.maxWeight)) {
              errInfo = `【${item.minWeight} - ${item.maxWeight}】`
              this.$message({
                message: `范围值非法：${errInfo}`
              })
              isAdd = false
              break
            }
            tempMaxWeight = item.maxWeight
          }
          if (isAdd) {
            this.tableData.push({
              minWeight: tempMaxWeight,
              maxWeight: '',
              startPrice: '',
              renewalPrice: ''
            })
          }
        }
      },
      // 删除某列表格
      rowDelete (index) {
        if (index === 0) return
        this.tableData.splice(index, 1)
      },
      closeDialog () {
        this.addContractForm = {}
        this.$refs.ruleForm.resetFields()
        this.tableData = [{ // 清空弹窗表格数据
          minWeight: '',
          maxWeight: '',
          startPrice: '',
          renewalPrice: ''
        }]
        this.loading = false
      }
    }
  }
</script>
<style lang="scss" scoped>
  .title-bar {
    background: #f1f1f5;
    height: 28px;
    line-height: 28px;
    margin: 5px 0;
    padding-left: 10px;
    font-weight: bold;
    color: #333333;
  }
  .btn-wrap {
    text-align: right;
    margin-top: 8px;
  }
  .tips {
    color: #ff5555;
    font-size: 12px;
    line-height: 17px;
  }
</style>
