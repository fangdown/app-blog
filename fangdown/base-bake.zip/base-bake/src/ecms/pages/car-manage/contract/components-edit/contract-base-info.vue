<template>
  <div>
    <div class="kye-block-title">基本信息</div>
    <kye-form class="form-details"
              ref="ruleForm"
              module-code="ecs_yc"
              :biz-id="driverId||'driverid'"
              :model.sync="formData">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="供应商编号">
            <el-tooltip effect="dark"
                        :content="formData.supplierNum"
                        placement="top">
              <kye-input v-model="formData.supplierNum"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="运力简称">
            <el-tooltip effect="dark"
                        :content="formData.name"
                        placement="top">
              <kye-input v-model="formData.name"
                         :maxlength="50"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="运力全称">
            <el-tooltip effect="dark"
                        :content="formData.fullName"
                        placement="top">
              <kye-input v-model="formData.fullName"
                         :maxlength="50"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="负责人">
            <el-tooltip effect="dark"
                        :content="formData.liableName"
                        placement="top">
              <kye-input v-model="formData.liableName"
                         :maxlength="10"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="负责人电话"
                         prop="phone">
            <el-tooltip effect="dark"
                        :content="formData.phone+''"
                        placement="top">
              <kye-input disabled
                         v-model="formData.phone"></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="运力类型">
            <kye-select placeholder=""
                        v-model="formData.driverType"
                        :disabled="!!driverId"
                        @change="selectSignType">
              <kye-option v-for="item in lookUpOptions['ecs_ht_contract_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="报价类型">
            <kye-select placeholder=""
                        v-model="formData.bidType"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_ht_bid_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="服务大区">
            <kye-select placeholder=""
                        v-model="formData.businessArea"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_ht_business_area']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4"
                 class="business-types">
          <kye-form-item label="业务类型">
            <el-tooltip effect="dark"
                        :content="formData.businessType"
                        placement="top">
              <kye-input v-model="formData.businessType"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="供应商状态">
            <kye-select placeholder=""
                        v-model="formData.checkState"
                        disabled>
              <kye-option v-for="item in lookUpOptions['ecs_ht_supplier_status']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="合作频次">
            <el-tooltip effect="dark"
                        :content="formData.cooperationTimes+''"
                        placement="top">
              <kye-input v-model="formData.cooperationTimes"
                         disabled></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="地址">
            <el-tooltip effect="dark"
                        :content="formData.address"
                        placement="top">
              <kye-input v-model="formData.address"
                         disabled>
              </kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
        <kye-col :span="16">
          <kye-form-item label="备注">
            <el-tooltip effect="dark"
                        :content="formData.remark"
                        placement="top">
              <kye-input v-model="formData.remark"
                         :disabled="!!driverId"
                         :maxlength="500"></kye-input>
            </el-tooltip>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  // 为了使用数据字典
  import mixins from 'public/mixins/index'
  // 表单校验
  import { submitForm } from '../../../utils/validate'

  export default {
    mixins: [mixins],
    props: {
      driverId: {
        type: null
      },
      form: {
        type: Object,
        default: () => ({})
      },
    },
    computed: {
      formData: function () {
        return this.form
      }
    },
    methods: {
      // 新增、修改基础信息（在edit页面调用）
      async addBaseInfo () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        const params = Object.assign({}, this.formData)
        // 服务点部数据转换
        if (Array.isArray(params.servicePoint)) {
          params.servicePoint = params.servicePoint.join(',')
        }
        // 业务类型数据转换
        if (params.businessType && Array.isArray(params.businessType)) {
          params.businessType = params.businessType.join(',')
        }
        this.$emit('save-base', params)
      },
      // 当运力合作类型为合同运力时，报价类型为合同报价，当运力合作类型为平台运力时，报价类型为竞价
      selectSignType (val) {
        if (val === '3') {
          this.formData.bidType = '102'
        } else {
          this.formData.bidType = '101'
        }
        this.$emit('setDriverType', val)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
