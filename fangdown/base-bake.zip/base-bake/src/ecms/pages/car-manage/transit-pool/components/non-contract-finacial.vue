<template>
  <kye-form labkye-position="left"
            class="form-details"
            ref="ruleForm"
            :model="form"
            size="mini">
    <kye-row :gutter="20">
      <kye-col :span="4">
        <kye-form-item label="是否开票">
          <kye-field>
            {{form.isInvoicing |lookup('ecs_common_yes_no')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="开票类型">
          <kye-field>
            {{form.invoiceType |lookup('ecs_ylc_invoice_type')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="开票点数">
          <kye-field v-model="form.taxRate"></kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="结算方式">
          <kye-field>
            {{form.payType |lookup('ecs_ylc_clearing_form')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="账期">
          <kye-field>
            {{form.payPeriod |lookup('ecs_ylc_pay_period')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="报价类型">
          <kye-field>
            {{form.bidType |lookup('ecs_ylc_offer_type')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
    </kye-row>
  </kye-form>
</template>

<script>
  export default {
    props: ['form'],
    data () {
      return {
      }
    }
  }
</script>
