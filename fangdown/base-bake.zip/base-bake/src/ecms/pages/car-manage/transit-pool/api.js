const perfix = 'ecs.yc.'
// const perfix = 'zc.'
const URL = {
  // 运力池-运力池列表分页条件查询
  getDriverPoolManagerByPage: `${perfix}driverPoolManager.getDriverPoolManagerByPage.do`,
  // 运力池-查询企业用户或平台认证身份证图片信息
  getEnterpriseDriverIdCardPhoto: `${perfix}driverPoolManager.getEnterpriseDriverIdCardPhoto.do`,
  // 运力池--查询个体用户认证身份证图片信息
  getOutSideDriverIdCardPhoto: `${perfix}driverPoolManager.getOutSideDriverIdCardPhoto.do`,
  // 运力池-查询个体司机基础信息，财务信息
  getOutSideDriverInfo: `${perfix}driverPoolManager.getOutSideDriverInfo.do`,
  // 运力池 -查询合同企业基础信息，财务信息
  getSignedCompanyInfo: `${perfix}driverPoolManager.getSignedCompanyInfo.do`,
  // 运力池 -查询非合同企业基础信息，财务信息
  getUnSignedCompanyInfo: `${perfix}driverPoolManager.getUnSignedCompanyInfo.do`,
  // 合同企业管理-取派报价-按重量计费录入标准列表查询接口
  getTakepieRuleDetail: `${perfix}driverPoolManager.getTakepieRuleDetail.do`,
  // 合同企业管理-折扣优惠-列表查询接口
  querySignedDriverDiscount: `${perfix}signedCompanyManage.querySignedDriverDiscount.do`,
  // 合同企业管理-干线报价-(按路线)列表查询接口
  getTrunkRuleDetail: `${perfix}driverPoolManager.getTrunkRuleDetail.do`,
  // 获取详情
  getDriverInfoByDriverId: `${perfix}driverPoolManager.getDriverInfoByDriverId.do`,
}
export default URL
