<template>
  <div>
    <div class="kye-block-title">信用信息</div>
    <div class="tab-operation"
         v-if="edit">
      <kye-button type="button"
                  @click="handleShowCreditDialog"
                  :auth="Api.saveSignedDriverCreditInfo"
                  class="el-button--text el-button--mini">
        <i class="iconfont icon-plus"></i>新增
      </kye-button>
      <kye-button type="button"
                  @click="deleteSelectedInfo"
                  :disabled="deleteDisabled"
                  :auth="Api.deleteSignedDriverCreditInfoBatch"
                  class="el-button--text el-button--mini">
        <i class="iconfont icon-delete"></i>删除
      </kye-button>
    </div>
    <kye-table :data="creditInfo"
               :key="propDriverId+deleteSelectedInfo"
               max-height="500"
               border
               stripe
               class="ky-table"
               :header-cell-style="{background:'#F1F1F5'}"
               style="width: 100%"
               @selection-change="handleSelectChange">
      <kye-table-column v-if="edit"
                        type="selection"
                        width="40"
                        fixed="left"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakContractType"
                        label="违约类型"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakTime"
                        label="违约时间"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakContent"
                        label="违约内容"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="transportNo"
                        label="运单号/任务编码"
                        width="105"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="createPerson"
                        label="录入人"
                        width="100"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="createTime"
                        label="录入时间"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
    </kye-table>
    <kye-dialog :visible.sync="showCreditDialog"
                width="800px"
                @close="closeCreditDialog ('ruleForm')">
      <div slot="title">{{dialogTitle}}</div>
      <kye-form ref="ruleForm"
                :model="addCreditDataForm"
                size="mini">
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="违约类型"
                           prop="breakContractType"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
              <kye-select placeholder=""
                          v-model="addCreditDataForm.breakContractType">
                <kye-option label="时效"
                            value="1"></kye-option>
                <kye-option label="运输过程"
                            value="2"></kye-option>
                <kye-option label="少货"
                            value="3"></kye-option>
                <kye-option label="破损"
                            value="4"></kye-option>
                <kye-option label="爽约"
                            value="5"></kye-option>
                <kye-option label="其他"
                            value="6"></kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="违约时间"
                           prop="breakTime"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-date-picker v-model="addCreditDataForm.breakTime"
                               type="date">
              </kye-date-picker>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="违约内容"
                           prop="breakContent"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
              <kye-input v-model="addCreditDataForm.breakContent"
                         :maxlength="100"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="单据编码"
                           prop="transportNo"
                           :rules="[
                              { required: true, message: '不能为空',trigger:'blur'}
                            ]">
              <kye-input v-model.number="addCreditDataForm.transportNo"
                         :maxlength="100"
                         clearable></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :auth="Api.saveSignedDriverCreditInfo"
                    @click="addCreditDialogSave('ruleForm')">保存(S)</kye-button>
        <kye-button @click="closeCreditDialog('ruleForm')">取消</kye-button>

      </div>
    </kye-dialog>
  </div>
</template>

<script>
  import Api from '../../../car-manage/contract/contract.api.js'
  export default {
    props: {
      creditInfo: {
        type: Array,
        default: () => []
      },
      propDriverId: {
        type: String,
        default: ''
      },
      edit: {
        type: Boolean,
        default: false
      },
    },
    data () {
      return {
        Api,
        dialogTitle: '新增信用信息',
        showCreditDialog: false, // 显示信用信息-新增信用信息弹窗
        deleteDisabled: true,
        addCreditDataForm: {
          breakContractType: '',
          breakTime: '',
          breakContent: '',
          transportNo: ''
        }, // 新增信用信息表单
        selectedList: [] //  选中的列数据
      }
    },
    methods: {
      handleShowCreditDialog () {
        this.showCreditDialog = true
        this.addCreditDataForm = {} // 清空数据
      },
      // 新增信用信息弹窗--保存
      async addCreditDialogSave (ruleForm) {
        this.$refs[ruleForm].validate(async (valid) => {
          if (valid) {
            const save = Object.assign({}, this.addCreditDataForm)
            const params = {
              id: '', // 主键ID
              driverId: this.propDriverId, // 关联运力ID
              breakContractType: save.breakContractType, // 违约类型(1时效，2运输过程，3少货，4破损5爽约6其他)
              breakTime: new Date(save.breakTime).getTime(), // 违约时间
              breakContent: save.breakContent, // 违约内容
              transportNo: save.transportNo, // 运单号/任务编码
              createPerson: '', // 创建人
              createTime: '', // 创建时间
              updatePerson: '', // 修改人
              updateTime: '', // 修改时间
              remark: '' // 备注
            }
            //  合同信用信息-保存接口
            await this.$http(Api.saveSignedDriverCreditInfo, params)
            this.queryCreditInfo() // 查询数据
            this.closeCreditDialog('ruleForm')
            this.$message({
              showClose: true,
              message: '操作成功',
              type: 'success'
            })
            this.addCreditDataForm = {}
          } else {
            this.$rule.error(this, this.$refs[ruleForm])
          }
        })
      },
      // 关闭弹窗
      closeCreditDialog (ruleForm) {
        this.showCreditDialog = false
        this.$refs[ruleForm].resetFields()
        // 关闭弹框清空数据
        this.addCreditDataForm = {
          breakContractType: '',
          breakTime: '',
          breakContent: '',
          transportNo: ''
        }
      },
      // 选中的列数据
      handleSelectChange (val) {
        const tempVal = Object.assign([], val)
        if (val.length > 0) {
          this.deleteDisabled = false
        } else {
          this.deleteDisabled = true
        }
        this.selectedList = tempVal
      },
      // 删除选中的数据
      deleteSelectedInfo () {
        if (this.selectedList.length <= 0) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        let ids = ''
        this.selectedList.map(element => {
          if (element.id) {
            ids += element.id + ','
          }
        })
        if (ids.length > 1) {
          ids = ids.slice(0, ids.length - 1) // 切掉最后一个逗号
        }
        this.$confirm('确认删除该数据吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.$http(Api.deleteSignedDriverCreditInfoBatch, { ids })
          this.queryCreditInfo()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      },
      // 查询信用信息
      queryCreditInfo () {
        this.$emit('queryCreditInfo', this.propDriverId)
        this.$refreshMainQueryTable()
      }
    }
  }
</script>
