<template>
  <kye-form labkye-width="70px"
            labkye-position="left"
            ref="ruleForm"
            :model="form"
            size="mini">
    <kye-row :gutter="20">
      <kye-col :span="4">
        <kye-form-item label="报价类型">
          <kye-field>
            {{form.bidType |lookup('ecs_ylc_offer_type')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
      <kye-col :span="4">
        <kye-form-item label="结算方式">
          <kye-field>
            {{form.payType |lookup('ecs_ylc_clearing_form')}}
          </kye-field>
        </kye-form-item>
      </kye-col>
    </kye-row>
  </kye-form>
</template>

<script>
  export default {
    props: ['form'],
  }
</script>
