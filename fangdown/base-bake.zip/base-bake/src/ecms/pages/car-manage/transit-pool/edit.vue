<template>
  <div class="kye-detail">
    <search-pager :option="option"></search-pager>
    <kye-expand-page v-loading="loading">
      <!-- 个人 -->
      <div v-if="driverType == 1">
        <personalBaseInfo v-if="isSmallCar == 1"
                          :baseFinacialInfo="baseFinacialInfo" />
        <otherBaseInfo v-else
                       :baseFinacialInfo="baseFinacialInfo" />
      </div>
      <!-- 平台 -->
      <platformBaseInfo v-else-if="driverType == 2"
                        :baseFinacialInfo="baseFinacialInfo" />
      <!-- 非合同企业 -->
      <nonContractBaseInfo v-else-if="driverType == 3"
                           :baseFinacialInfo="baseFinacialInfo" />
      <!-- 合同企业 -->
      <contractBaseInfo v-else-if="driverType == 4"
                        :baseFinacialInfo="baseFinacialInfo" />
      <div class="kye-block-title">财务信息</div>
      <!-- 个人 -->
      <div v-if="driverType == 1">
        <personalFincial v-if="isSmallCar == 1"
                         :form="baseFinacialInfo" />
        <otherFincial v-else
                      :form="baseFinacialInfo" />
      </div>
      <!-- 平台 -->
      <platformFincial v-else-if="driverType == 2"
                       :form="baseFinacialInfo" />
      <!-- 非合同企业 -->
      <nonContractFincial v-else-if="driverType == 3"
                          :form="baseFinacialInfo" />
      <!-- 合同企业 -->
      <contractFincial v-else-if="driverType == 4"
                       :form="baseFinacialInfo" />
      <div v-if="driverType == 1 || driverType == 3">
        <div class="kye-block-title">证件信息</div>
        <kye-tabs v-if="driverType == 1"
                  v-model="activeName">
          <kye-tab-pane label="实名信息"
                        name="first">
            <div class="m10">
              <pictureDisplay :pics="displayPics2[0]" />
            </div>
          </kye-tab-pane>
          <kye-tab-pane label="从业信息"
                        v-if="isSmallCar == 2"
                        name="fourth">
            <div class="m10">
              <pictureDisplay :pics="displayPics2[1]" />
            </div>
          </kye-tab-pane>
          <kye-tab-pane label="车辆信息"
                        name="fifth">
            <div class="m10">
              <pictureDisplay :pics="displayPics2[2]" />
            </div>
          </kye-tab-pane>
        </kye-tabs>
        <kye-tabs v-else
                  v-model="activeName">
          <kye-tab-pane label="实名信息"
                        name="first">
            <div class="m10">
              <pictureDisplay :pics="displayPics1[0]" />
            </div>
          </kye-tab-pane>
          <kye-tab-pane label="企业信息"
                        name="second">
            <div class="m10">
              <pictureDisplay :pics="displayPics1[1]" />
            </div>
          </kye-tab-pane>
        </kye-tabs>
      </div>
      <poolCreditInfo v-if="creditInfo"
                      :propDriverId="driverId"
                      :edit="true"
                      :key="driverId"
                      :creditInfo="creditInfo"
                      @queryCreditInfo="querySignedDriverCreditInfo"></poolCreditInfo>
    </kye-expand-page>
  </div>
</template>

<script>
  import routeHook from 'public/mixins/route-hook'
  import Api from './api.js'
  import contractApi from '../../car-manage/contract/contract.api.js'
  import { formatTime } from '../../utils/format'
  // 个人财务信息
  import personalFincial from './components/personal-finacial.vue'
  // 平台财务信息
  import platformFincial from './components/platform-finacial.vue'
  // 合同财务信息
  import contractFincial from './components/contract-finacial.vue'
  // 非合同财务信息
  import nonContractFincial from './components/non-contract-finacial.vue'
  // 个人财务信息
  import otherFincial from './components/other-finacial.vue'
  // 信用信息
  import creditInfo from '../../../components/contract-tables/credit-info.vue'
  // 图片展示
  import pictureDisplay from './components/picture-display.vue'
  // 个人基础信息
  import personalBaseInfo from './components/personal-baseInfo.vue'
  // 平台基础信息
  import platformBaseInfo from './components/platform-baseInfo.vue'
  // 平台基础信息
  import contractBaseInfo from './components/contract-baseInfo.vue'
  // 非合同基础信息
  import nonContractBaseInfo from './components/non-contract-baseInfo.vue'
  // 个人基础信息
  import otherBaseInfo from './components/other-baseInfo.vue'
  // 信用信息新增
  import poolCreditInfo from './components/pool-creditInfo.vue'


  export default {
    mixins: [routeHook],
    components: {
      personalFincial,
      otherFincial,
      creditInfo,
      pictureDisplay,
      personalBaseInfo,
      otherBaseInfo,
      platformFincial,
      platformBaseInfo,
      contractFincial,
      contractBaseInfo,
      nonContractBaseInfo,
      nonContractFincial,
      poolCreditInfo
    },
    data () {
      return {
        option: {
          back: '',
        },
        displayPics1: [], // 长度为2
        displayPics2: [], // 长度为3
        creditInfo: null,
        editRecordTableData: [{
          editTime: '修改时间',
          operatePerson: '操作人',
          content: '修改内容'
        }],
        loading: false,
        activeName: 'first',
        driverType: '', // 合同运力type
        driverId: '', // 合同运力id
        isSmallCar: '', // 是否三轮车，1是2不是
        baseFinacialInfo: {}, // 基础财务数据
      }
    },
    methods: {
      // 获取详情
      async getDetail (driverId = this.$route.params.id) {
        this.option.back = `/ecms/transit-pool/detail/${driverId}`
        this.baseFinacialInfo = {}
        this.driverId = driverId
        this.loading = true
        const data = await this.$http(Api.getDriverInfoByDriverId, { driverId })
        this.driverType = data.driverType
        if (data.outSideDriverEntity) {
          this.isSmallCar = data.outSideDriverEntity.isSmallCar
        }
        this.loading = false
        const baseFinacialInfo = data.outSideDriverEntity || data.erpSignedCompanyEntity || data.erpUnSignedCompanyEntity
        this.baseFinacialInfo = baseFinacialInfo
        switch (data.driverType) {
          case 1: // 个人
            this.getIndividualPhoto()
            break
          case 3: // 非合同企业
            this.getEnterprisePlatformPhoto()
            break
          default:
            break
        }
      },
      // 请求运力池-查询企业用户或平台认证身份证图片信息
      async getEnterprisePlatformPhoto () {
        try {
          let data = await this.$http(Api.getEnterpriseDriverIdCardPhoto, { driverId: this.driverId })
          this.displayPics1 = this.setEnterprisePhoto(data)
        } catch (error) {
          this.displayPics1 = []
        }
      },
      // 请求运力池--查询个体用户认证身份证图片信息
      async getIndividualPhoto () {
        try {
          let data = await this.$http(Api.getOutSideDriverIdCardPhoto, { driverId: this.driverId })
          this.displayPics2 = this.setIndividualPhoto(data)
        } catch (error) {
          this.displayPics2 = []
        }
      },
      // 处理图片 实名信息，企业信息
      setEnterprisePhoto (obj) {
        let arr = []
        arr[0] = {}
        arr[1] = {}
        const arrKey0 = ['idCardBackPhoto', 'idCardFrontPhoto', 'personAndIdCardPhoto']
        const arrKey1 = ['operationPhoto', 'roadCardPhoto']
        this.setPhonoData(arrKey0, arr[0], obj)
        this.setPhonoData(arrKey1, arr[1], obj)
        return arr
      },
      // 处理图片 个人信息
      setIndividualPhoto (obj) {
        let arr = []
        arr[0] = {}
        arr[1] = {}
        arr[2] = {}
        const arrKey0 = ['idCardBackPhoto', 'idCardFrontPhoto', 'personAndIdCardPhoto']
        this.setPhonoData(arrKey0, arr[0], obj)
        const arrKey1 = ['driveCardFrontPhoto', 'driveCardVicePage', 'freightAgeCardPhoto']
        this.setPhonoData(arrKey1, arr[1], obj)
        let arrKey2 = []
        if (this.isSmallCar === '1') {
          arrKey2 = ['carPhoto', 'manCarPhoto']
          this.setPhonoData(arrKey2, arr[2], obj)
        } else if (this.isSmallCar === '2') {
          arrKey2 = ['carCardFrontPhoto', 'carCardBackPhoto', 'roadCardPhoto']
          this.setPhonoData(arrKey2, arr[2], obj)
        }
        return arr
      },
      setPhonoData (arrKey, arr, obj) {
        arrKey.forEach((item) => {
          if (obj[item]) {
            arr[item] = obj[item]
          }
        })
      },
      // 信用列表-查询接口
      async querySignedDriverCreditInfo (propDriverId) {
        const typeMap = new Map([
          ['1', '时效'],
          ['2', '运输过程'],
          ['3', '少货'],
          ['4', '破损'],
          ['5', '爽约'],
          ['6', '其他']
        ])
        const data = await this.$http(contractApi.querySignedDriverCreditInfo, { driverId: propDriverId })
        const show = Object.assign([], data)
        show.forEach(element => {
          element.breakTime = formatTime(element.breakTime)
          element.createTime = formatTime(element.createTime)
          element.updateTime = formatTime(element.updateTime)
          element.breakContractType = typeMap.get(element.breakContractType + '')
        })
        this.creditInfo = show
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (vm.$route.meta.layout) return
        vm.driverType = ''
        vm.isSmallCar = ''
        vm.activeName = 'first'
        vm.getDetail(vm.$route.params.id)
        vm.querySignedDriverCreditInfo(vm.$route.params.id)
      })
    },
  }
</script>
<style lang="scss">
  .m10 {
    margin: 10px;
  }
</style>

