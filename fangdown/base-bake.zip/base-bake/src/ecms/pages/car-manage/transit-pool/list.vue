<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :form-model="formModel"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
    <kye-dialog title="干线计费标准"
                :visible.sync="mainlineDialogVisible"
                width="1130px">
      <kye-tabs v-model="mainLineActive">
        <kye-tab-pane label="按线路计费标准"
                      name="first">
          <mainline-quote-line :tableData="quoteLine">
          </mainline-quote-line>
        </kye-tab-pane>
        <kye-tab-pane label="折扣优惠标准"
                      name="second">
          <discount :tableData="discountList"></discount>
        </kye-tab-pane>
      </kye-tabs>
      <span slot="footer"
            class="dialog-footer">
        <kye-button type="primary"
                    @click="mainlineDialogVisible = false">关闭</kye-button>
      </span>
    </kye-dialog>
    <kye-dialog title="取派计费标准"
                :visible.sync="getAndSendDialogVisible"
                width="1130px">
      <kye-tabs v-model="mainTakeActive">
        <kye-tab-pane label="按重量计费标准"
                      name="first">
          <get-send-weight :tableData="chargeWeightList"></get-send-weight>
        </kye-tab-pane>
        <kye-tab-pane label="折扣优惠标准"
                      name="second">
          <discount :tableData="discountList"></discount>
        </kye-tab-pane>
        <send-weight-prompt></send-weight-prompt>
      </kye-tabs>
      <span slot="footer"
            class="dialog-footer">
        <kye-button type="primary"
                    @click="getAndSendDialogVisible = false">关闭</kye-button>
      </span>
    </kye-dialog>
  </div>
</template>

<script>
  import Api from './api.js'
  // 合同折扣信息
  import discount from '../../../components/contract-tables/discount'
  // 合同取派按重量计费
  import getSendWeight from '../../../components/contract-tables/get-send-weight'
  // 合同按线路计费
  import mainlineQuoteLine from '../../../components/contract-tables/mainline-quote-line'
  // 取派合同须知
  import sendWeightPrompt from '../../../components/contract-tables/send-weight-prompt'
  import { formatTime } from '../../utils/format'
  import { money } from 'public/utils/filter.js'
  export default {
    components: {
      discount,
      getSendWeight,
      mainlineQuoteLine,
      sendWeightPrompt
    },
    data () {
      return {
        Api,
        loading: false,
        getAndSendDialogVisible: false, // 取派弹窗
        mainlineDialogVisible: false, // 干线弹窗
        mainLineActive: 'first', // 弹窗-当前tab页
        mainTakeActive: 'first',
        quoteLine: [], // 干线-按车型和公里计费标准
        chargeWeightList: [], // 取派-按重量
        discountList: [], // 取派-按折扣
        generic: {
          method: Api.getDriverPoolManagerByPage,
          searchCode: 'ecs_yc_transit_pool_basic_search'
        },
        formTools: [
          {
            label: '刷新',
            auth: Api.getDriverPoolManagerByPage,
            icon: 'reset',
            func: () => {
              // this.init({ forceCache: true })
              this.$refs.queryTable.loadData()
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'ecs_yc_transit_pool_search_define'
        },
        formModel: {
          registTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
        },
        tools: [
        ],
        tables: [
          {
            searchCode: 'ecs_yc_transit_pool_list_field',
            url: { method: Api.getDriverPoolManagerByPage },
            defaultSort: {
              // 通用查询对应字段的 propertyName, columnName 的值
              keys: ['driverType', 'driver_type'],
              prop: 'driverType', // 自定义列的 key
              order: 'ascending' // 默认排序 ascending:升序，descending:降序
            },
            option: {
              load: false,
              moduleCode: 'ecs_yc',
              idKey: 'driverId',
              detailAuth: Api.getDriverInfoByDriverId,
              rowDblClick: this.toDetails,
              // 将搜索表单参数赋值给请求中去，时间转时间戳
              beforeFormSubmit: (data, model) => {
                let isEmpty = true
                let obj = {}
                delete data.startTime
                delete data.endTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'registTime') {
                      if (model.registTime && model.registTime.length === 2) {
                        isEmpty = false
                        const startTime = +new Date(formatTime(model.registTime[0]) + ' 00:00:00')
                        const endTime = +new Date(formatTime(model.registTime[1]) + ' 23:59:59')
                        Object.assign(obj, {
                          startTime,
                          endTime
                        })
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
            },
            operation: {
              label: '操作',
              fixed: 'right',
              width: '50px',
              options: [
                // {
                //   type: 'button',
                //   label: '干线报价',
                //   auth: Api.getTrunkRuleDetail,
                //   disabled: row => {
                //     return row.driverType !== 4
                //   },
                //   func: row => {
                //     let param = { driverId: row.driverId }
                //     this.getTrunkRuleDetail(param)
                //     this.querySignedDriverDiscount(param)
                //     this.mainlineDialogVisible = true
                //   }
                // },
                // {
                //   type: 'button',
                //   label: '取派报价',
                //   auth: Api.getTakepieRuleDetail,
                //   disabled: row => {
                //     return row.driverType !== 4
                //   },
                //   func: row => {
                //     let param = { driverId: row.driverId }
                //     this.getTakepieRuleDetail(param)
                //     this.querySignedDriverDiscount(param)
                //     this.getAndSendDialogVisible = true
                //   }
                // }
                {
                  type: 'button',
                  label: '修改',
                  auth: Api.getDriverInfoByDriverId,
                  func: row => {
                    this.$router.push({ path: `/ecms/transit-pool/edit/${row.driverId}` })
                  }
                }
              ]
            }
          }
        ],
      }
    },
    methods: {
      // 跳转到详情页
      toDetails (row, event, column) {
        this.$router.push({ path: `/ecms/transit-pool/detail/${row.driverId}` })
      },
      // 取派按重量计费
      async getTakepieRuleDetail (row) {
        const statusMap = new Map([['1', '有效'], ['2', '无效']])
        const specificateTypeMap = new Map([['1', '小件'], ['2', '大件']])
        const data = await this.$http(Api.getTakepieRuleDetail, { driverId: row.driverId })
        if (data) {
          data.forEach((item, index) => {
            item.range = `${item.minWeight} - ${item.maxWeight}`
            item.updateTime = formatTime(item.updateTime)
            item.createTime = formatTime(item.createTime)
            item.specificateType = specificateTypeMap.get(
              item.specificateType + ''
            )
            item.statusName = statusMap.get(item.status + '')
            item.bottomPrice = money(item.bottomPrice)
            item.startPrice = money(item.startPrice)
            item.renewalPrice = money(item.renewalPrice)
          })
          this.chargeWeightList = data
        }
      },
      // 取派按折扣计费
      async querySignedDriverDiscount (row) {
        const data = await this.$http(Api.querySignedDriverDiscount, { driverId: row.driverId })
        if (data) {
          data.forEach((item, index) => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            if (item.discount < 1) {
              // 折扣转百分比
              item.discount = item.discount * 100
            }
            if (item.status === 1) {
              item.status = '有效'
            } else if (item.status === 2) {
              item.status = '失效'
            }
            item.range = `${money(item.minFreight)}-${money(item.maxFreight)}` // 范围拼接
          })
          this.discountList = data
        }
      },
      // 干线报价-按线路查询-查询接口
      async getTrunkRuleDetail (row) {
        const data = await this.$http(Api.getTrunkRuleDetail, { driverId: row.driverId })
        if (data) {
          data.forEach((item, index) => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            item.overLoadPoints = money(item.overLoadPoints)
            item.transportAskPrice = money(item.transportAskPrice)
            item.returnPrice = money(item.returnPrice)
            if (item.status === '1') {
              item.status = '有效'
            } else if (item.status === '2') {
              item.status = '失效'
            }
          })
          this.quoteLine = data
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
</style>



