<template>
  <div>
    <div class="pics-box">
      <div v-if="pics&&Object.keys(pics).length>0">
        <img v-for="(item, index) in pics"
             @click="look(item)"
             :key="index"
             :src="item" />
      </div>
      <span v-else>暂无数据</span>
    </div>
    <kye-dialog title="图片查看"
                width="800px"
                :visible.sync="isShow">
      <img :src="src"
           style="width:100%;">
      <span slot="footer"
            class="dialog-footer">
        <kye-button type="primary"
                    @click="isShow = false">关闭</kye-button>
      </span>
    </kye-dialog>
  </div>
</template>

<script>
  export default {
    props: {
      pics: {
        type: Object,
        default: () => {
          return null
        }
      }
    },
    data () {
      return {
        src: '',
        isShow: false
      }
    },
    methods: {
      look (v) {
        if (!v) return
        this.src = v
        this.isShow = true
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pics-box {
    display: flex;
    flex-direction: row;
    flex-shrink: 0;
    flex-grow: 0;
    white-space: normal;
    img {
      width: 200px;
      height: 150px;
      margin-right: 70px;
      background-color: #eee;
    }
  }
</style>

