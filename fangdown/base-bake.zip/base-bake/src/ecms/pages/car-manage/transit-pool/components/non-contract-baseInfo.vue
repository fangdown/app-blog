<template>
  <div>
    <div class="kye-block-title">
      <div>基本信息</div>
    </div>
    <kye-form class="form-details"
              ref="form"
              :model.sync="form"
              module-code="ecs_yc"
              :biz-id="$route.params.id"
              size="mini">
      <kye-row :gutter="20">
        <kye-col :span="4">
          <kye-form-item label="运力名称">
            <kye-field v-model="form.fullName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="运力类型">
            <kye-field>{{form.driverType|lookup('ecs_ylc_driver_type')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否有效">
            <kye-field>{{form.state|lookup('ecs_ylc_cooperation_type')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="联系人">
            <kye-field v-model="form.name"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="联系电话"
                         prop="phone">
            <kye-field v-model="form.phone"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="合作频次">
            <kye-field v-model="form.cooperationTimes"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="20">
        <kye-col :span="4">
          <kye-form-item label="车辆数">
            <kye-field v-model="form.carNo"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="地址">
            <kye-field v-model="form.address"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注">
            <kye-field v-model="form.note"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>

</template>

<script>
  export default {
    props: {
      baseFinacialInfo: {
        type: null,
        default: () => ({})
      }
    },
    data () {
      return {
        form: this.baseFinacialInfo
      }
    }
  }
</script>
