<template>
  <div>
    <div class="carrier-info">
      <div class="kye-block-title ecs-common-mt0">货物信息</div>
      <div class="kye-tool-list">
        <div v-if="!isDisabled"
             style="display: inline;">
          <kye-button type="text"
                      :auth="URL.queryCarrierInfo"
                      @click="handleAdd">
            <i class="iconfont icon-plus"></i>新增
          </kye-button>
        </div>
        <span class="estimate-box"
              :key="taskCode">
          <span>运单：<span class="estimate-num">{{estimate.waybillNum}}</span>票</span>
          <span>货物：<span class="estimate-num">{{estimate.goodsNum}}</span>件</span>
          <span>预估里程：<span class="estimate-num">{{estimate.estimateDistance}}</span>km</span>
          <span>预估体积：<span class="estimate-num">{{estimate.goodsVolume}}</span>m³</span>
          <span>预估重量：<span class="estimate-num">{{estimate.goodsWeight}}</span>kg</span>
        </span>
      </div>
      <div>
        <kye-table :data="listData"
                   border
                   stripe
                   class="ky-table"
                   :header-cell-style="{background:'#F1F1F5'}"
                   :key="taskCode"
                   style="width: 100%">
          <el-table-column type="index"
                           width="50">
          </el-table-column>
          <kye-table-column v-if="!isDisabled"
                            width="90"
                            label="操作">
            <template slot-scope="scope">
              <kye-button @click="getwaybill(scope.row.addWaybillCode)"
                          type="text"
                          size="small"
                          v-if="scope.row.add"
                          :auth="URL.queryCarrierInfo">保存</kye-button>
              <kye-button @click="rowDelete(scope.$index)"
                          type="text"
                          size="small"
                          :auth="URL.queryCarrierInfo">删除</kye-button>
            </template>
          </kye-table-column>
          <kye-table-column label="单据编号"
                            width="150px">
            <template slot-scope="scope">
              <input size="mini"
                     type="text"
                     v-if="scope.row.add"
                     class="addWaybillCode"
                     v-model="scope.row.addWaybillCode" />
              <div v-else>{{scope.row.waybillCode}}</div>
            </template>
          </kye-table-column>
          <kye-table-column prop="takeAndSendAdress"
                            label="取派地址"
                            width="140px">
          </kye-table-column>
          <kye-table-column prop="goodsName"
                            label="托寄物"
                            width="80px">
          </kye-table-column>
          <kye-table-column prop="goodsNumber"
                            label="件数"
                            width="55px">
          </kye-table-column>
          <kye-table-column prop="goodsWeight"
                            label="预估重量（kg）"
                            width="90px">
          </kye-table-column>
          <kye-table-column prop="actualWeight"
                            v-if="status===300 || status===400"
                            label="实际重量（kg）"
                            width="90px">
          </kye-table-column>
          <kye-table-column prop="goodsVolume"
                            label="体积（m³）"
                            :width="isDisabled?'80px':''">
          </kye-table-column>
          <kye-table-column v-if="isDisabled"
                            prop="type"
                            :formatter="formatterType"
                            label="类型"
                            width="50px">
          </kye-table-column>
          <kye-table-column v-if="isDisabled"
                            prop="avgCost"
                            label="平均成本"
                            width="100px">
          </kye-table-column>
          <kye-table-column v-if="isDisabled"
                            prop="status"
                            :formatter="formatterStatus"
                            label="状态"
                            width="55px">
          </kye-table-column>
          <kye-table-column prop="isDispatch"
                            label="调度标识"
                            :formatter="formatterDispatchType">
          </kye-table-column>
        </kye-table>
      </div>
    </div>
  </div>
</template>
<script>
  import URL from '../takeCar.api'
  // code翻译
  import { takeAndSendObj, orderStatusObj, isDispatch } from '../selectOption.js'
  export default {
    props: {
      taskCode: {
        type: String,
        default: ''
      },
      isDisabled: {
        type: Boolean,
        default: false
      },
      status: {
        type: Number,
        default: 100
      },
      listData: {
        type: Array,
        default () {
          return []
        }
      },
      estimate: {
        type: Object,
        default () {
          return {
            goodsWeight: 0,
            goodsVolume: 0,
            estimateDistance: 0,
            estimateCarType: '厢式车',
            estimateCarLength: 3.2,
            waybillNum: 0,
            goodsNum: 0
          }
        }
      }
    },
    data () {
      return {
        URL: URL,
        orderNo: '',
        id: '',
        confirmOrderVisble: false,
        prospectData: {},
        rowSelection: []
      }
    },
    methods: {
      // 状态格式化
      formatterStatus (row, column) {
        return orderStatusObj[row.status]
      },
      // 状态格式化
      formatterType (row, column) {
        return takeAndSendObj[row.type]
      },
      // 调度标识格式化
      formatterDispatchType (row, column) {
        return isDispatch[row.isDispatch + '']
      },
      // 删除行数据
      rowDelete (index) {
        this.$emit('rowDelete', index)
      },
      // 新增运单信息
      handleAdd () {
        this.$emit('handleAdd')
      },
      // 通过编号查找运单信息
      async getwaybill (code) {
        if (!code) {
          this.$alert('运单号不能为空！')
          return false
        }
        this.loading = true
        let addWaybillCode = code.trim()
        if (addWaybillCode) {
          let flag = true
          this.listData.length > 1 && this.listData.forEach((element, index) => {
            if (element.waybillCode === addWaybillCode && !element.add) {
              addWaybillCode = ''
              flag = false
              this.$alert('运单号不能重复！')
              return false
            }
          })
          if (flag) {
            const data = await this.$http(URL.queryCarrierInfo, { waybillCode: addWaybillCode })
            if (data) {
              this.$emit('getwaybill', data)
            }
          }
        }
      }
    }
  }
</script>

<style scoped>
  .addWaybillCode {
    width: 140px;
  }
  .kye-tool-list {
    height: 28px;
    max-height: 28px;
    line-height: 28px;
  }
  .ecs-common-mt0 {
    margin-bottom: 0;
  }
  .estimate-box {
    margin-bottom: 5px;
  }
  .estimate-box > span {
    margin-right: 10px;
  }
  .estimate-num {
    padding-right: 5px;
    color: #ff9300;
    font-weight: 600;
  }
  .carrier-info {
    margin-bottom: 12px;
  }
</style>
