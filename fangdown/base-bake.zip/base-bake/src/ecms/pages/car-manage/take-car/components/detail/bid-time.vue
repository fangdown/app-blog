<template>
  <div class="bid-time">
    <span class="wbyl-mr20 time-text">报价已持续</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(0, 1)}}</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(1, 2)}}</span>
    <span class="time-text">小时</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(3, 4)}}</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(4, 5)}}</span>
    <span class="time-text">分</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(6, 7)}}</span>
    <span :class="{'time-number':true, active: isActive}">{{this.effectDurationTime.substring(7, 8)}}</span>
    <span class="time-text">秒</span>
  </div>
</template>
<script>
  export default {
    props: {
      effectDurationTime: {
        type: String,
        default: '00:00:00'
      },
      isActive: {
        type: Boolean,
        default: true
      }
    }
  }
</script>
<style scoped>
  .bid-time {
    display: flex;
  }
  .time-number {
    width: 18px;
    height: 20px;
    line-height: 20px;
    background: #9a9aa6;
    border-radius: 2px;
    margin: 0 2px;
    text-align: center;
    color: #fff;
    font-size: 14px;
  }
  .time-text {
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #666666;
    height: 20px;
    line-height: 20px;
  }

  .active {
    background: #ff9300;
  }
</style>

