<template>
  <div>
    <table-list :column="column"
                :data="bidingData"
                :options="tableOption"></table-list>
  </div>
</template>
<script>
  import URL from '../../takeCar.api'

  export default {
    props: {
      bidingData: {
        type: Array,
        default () {
          return []
        }
      },
      viewStatus: {
        type: Number,
        default: 2
      }
    },
    data () {
      return {
        URL: URL,
        cancelVisble: false, // 注明原因弹窗
        remark: '',
        column: [
          {
            key: 'driverName',
            label: '运力名称',
            show: true,
            width: '200px'
          },
          {
            key: 'driverPhone',
            label: '联系电话',
            show: true,
            width: '100px'
          },
          {
            key: 'driverType',
            label: '运力类型',
            show: true,
            width: '120px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_car_driver_type'
              ]
            }
          },
          {
            key: 'entrustPlatformName',
            label: '挂靠公司',
            show: true,
            width: '80px'
          },
          {
            key: 'carrierDriverName',
            label: '司机姓名',
            show: true,
            width: '70px'
          },
          {
            key: 'carrierDriverPhone',
            label: '司机电话',
            show: true,
            width: '100px'
          },
          {
            key: 'carPlate',
            label: '车牌号',
            show: true,
            width: '80px'
          },
          {
            key: 'carTypeName',
            label: '实际车型',
            show: true,
            width: '65px'
          },
          {
            key: 'carLength',
            label: '实际车长',
            show: true,
            width: '65px'
          },
          {
            key: 'price',
            label: '价格',
            show: true,
            width: '450px',
            filter: 'money'
          }
        ],
        tableOption: {
          moduleCode: 'ecs_yc',
          stripe: true
        },
      }
    }
  }
</script>
