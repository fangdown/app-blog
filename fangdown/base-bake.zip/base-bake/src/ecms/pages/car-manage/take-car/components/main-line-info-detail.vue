<template>
  <div>
    <div class="kye-block-title">要车信息
    </div>
    <kye-form :model="ruleForm"
              ref="ruleForm">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="要车编号">
            <kye-field>
              {{ruleForm.taskCode}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="要车类型">
            <kye-field>
              {{ruleForm.takeType|lookup('ecs_yc_line_take_type')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用车时间">
            <kye-field>
              {{ruleForm.loadingTimeAt}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估货量">
            <kye-field>
              {{ruleForm.goodsWeight}}kg
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估体积">
            <kye-field>
              {{ruleForm.goodsVolume}}m³
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估里程">
            <kye-field>
              {{ruleForm.estimateDistance}}km
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="尾板需求">
            <kye-field>
              {{ruleForm.isTailboard|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车型">
            <kye-field>
              {{ruleForm.carTypeName}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车长">
            <kye-field>
              {{ruleForm.carLength}}米
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="走高速否">
            <kye-field>
              {{ruleForm.isExpressway|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="去程时效">
            <kye-field>
              {{ruleForm.consumeTime}}小时
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="上岗说明">
            <kye-field>{{ruleForm.postRequirements}}</kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="始发地">
            <kye-field>
              {{ruleForm.startPoint}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="目的地">
            <kye-field>
              {{ruleForm.endPoint}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否往返">
            <kye-field>
              {{ruleForm.isGoBack|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否经停">
            <kye-field>
              {{ruleForm.isPause|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row v-if="ruleForm.isGoBack===1">
        <kye-col :span="4">
          <kye-form-item label="返程时间">
            <kye-field>
              {{ruleForm.backTimeAt}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="返程时效">
            <kye-field>
              {{ruleForm.backConsumerTime}}小时
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row v-if="ruleForm.isPause===1 && ruleForm.landArr.length>0">
        <kye-col :span="8"
                 v-for="(item,index) in ruleForm.landArr"
                 v-bind:key="item+'-'+index">
          <kye-form-item :label="'经停地'+(index+1)">
            <kye-field>
              {{ruleForm.landArr[index]}}
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  export default {
    props: {
      ruleForm: {
        type: Object,
        default () {
          return {}
        }
      }
    }
  }
</script>
