<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="formTools"
                  :key="taskCode"></search-pager>
    <kye-expand-page v-loading="loading">
      <!-- 取派 -->
      <main-take-info-edit ref="mainTakeInfo"
                           v-if="takeDetailData!==null && tableData!==null"
                           :detailData="takeDetailData"
                           :tableData='tableData'
                           :carLengthOption="carLengthOption"
                           :carTypeOption="carTypeOption"
                           @getDetail="getDetail"
                           @setSaveDisabled="setSaveDisabled"
                           :key="'main-take-info-edit'+taskCode"></main-take-info-edit>
      <!-- 干线 -->
      <main-line-info-edit ref="mainLineInfo"
                           v-if="lineDetailData!==null"
                           :detailData="lineDetailData"
                           :carLengthOption="carLengthOption"
                           :carTypeOption="carTypeOption"
                           @getDetail="getDetail"
                           @setSaveDisabled="setSaveDisabled"
                           :key="'main-line-info-edit'+taskCode"> </main-line-info-edit>
    </kye-expand-page>
  </div>
</template>
<script>
  import routeHook from 'public/mixins/route-hook'
  // 取派新增
  import mainTakeInfoEdit from './main-take-info-edit'
  // 干线新增
  import mainLineInfoEdit from './main-line-info-edit.vue'
  import URL from '../takeCar.api'
  import { money } from 'public/utils/filter.js'
  export default {
    mixins: [routeHook],
    components: {
      mainTakeInfoEdit,
      mainLineInfoEdit
    },
    data () {
      return {
        URL: URL,
        option: {
          back: `/ecms/take-car/main-detail/${this.$route.params.id}`,
        },
        lineDetailData: null, // 干线详情数据
        takeDetailData: null, // 取派详情数据
        tableData: null, // 取派承运信息
        carLengthOption: [],
        carTypeOption: [],
        estimate: { // 取派预估数据
          goodsWeight: 0,
          goodsVolume: 0,
          waybillNum: 0,
          goodsNum: 0,
          estimateDistance: 0
        },
        taskCode: this.$route.params.id, // 任务编码
        loading: false,
        takeType: '', // 200 干线 300取派
        formTools: [{
          label: '保存',
          disabled: false,
          icon: 'save1',
          auth: this.takeType === 200 ? URL.createTakePieTask : URL.saveTrunkTask,
          func: () => {
            this.SET_SAVE_HOOK_FLAG()
            if (this.takeType === 300) {
              this.$refs.mainTakeInfo.createTakePieTask('mainTakeInfo')
            } else {
              this.$refs.mainLineInfo.submitForm('mainLineInfo')
            }
          }
        },
        {
          auth: URL.searchTaskList,
          label: '取消',
          icon: 'cancel1',
          func: () => {
            this.BACK_HOOK_MODULE()
          }
        }],
      }
    },
    methods: {
      /**
       * 设置详情数据
       * @param data: 取派、干线数据
       * @param takeType: 取派干线类型
       */
      setDetailData (data, takeType) {
        this.takeDetailData = null
        this.tableData = null
        this.lineDetailData = null
        if (takeType === 300) {
          this.takeDetailData = data
          for (let key in this.estimate) {
            this.estimate[key] = data[key]
          }
        } else {
          setTimeout(() => { this.lineDetailData = data }, 100)
        }
        this.publishTimeAt = data.publishTimeAt
        this.getCarType()
        this.getCarLength()
      },
      // 避免距离没有返回保存
      setSaveDisabled (data) {
        this.formTools[0].disabled = data
      },
      // 取派实际承运信息
      async getWayBillList () {
        const param = { taskCode: this.taskCode }
        const data = await this.$http(URL.findTaskWaybillListByDispatch, param)
        if (data.length > 0) {
          data.forEach(element => {
            element.avgCost = money(element.avgCost)
          })
        }
        this.tableData = data
      },
      // 获取详情
      async getDetail (id = this.$route.params.id) {
        this.taskCode = id
        this.loading = true
        const detailData = await this.$http(URL.findTaskInfo, { taskCode: id })
        if (detailData.status === 300) {
          this.getWayBillList()
          this.setDetailData(detailData.takePieTaskRVo, 300)
        } else {
          this.setDetailData(detailData.trunkTaskInfoRVo, 200)
        }
        this.takeType = detailData.status === 300 ? 300 : 200
        this.loading = false
      },
      // 获取车型
      async getCarType () {
        const param = {}
        const carTypeOption = await this.$http(URL.getCarType, param) || []
        if (this.takeType === 200) {
          this.carTypeOption = carTypeOption.filter(item => {
            return ['面包车', '厢式车'].indexOf(item.dictValue) > -1
          })
        } else {
          this.carTypeOption = carTypeOption
        }
      },
      // 获取车长
      async getCarLength () {
        const param = {}
        this.carLengthOption = await this.$http(URL.getCarLength, param)
      },
    },
    beforeRouteEnter (to, from, next) {
      next((vm) => {
        if (!vm.$route.meta.layout) {
          vm.taskCode = vm.$route.params.id
          vm.getDetail(vm.$route.params.id)
        }
      })
    },
  }
</script>
<style lang="scss" scoped>
  .carrier-info {
    margin-bottom: 12px;
  }
</style>
