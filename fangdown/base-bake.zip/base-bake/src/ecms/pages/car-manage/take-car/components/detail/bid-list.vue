<template>
  <div class="ky-table-box">
    <kye-edit-table :column="column"
                    :data="bidListData"
                    :showIndex="true"
                    moduleCode="esc_yc"
                    v-loading="bidLoading"
                    :options="tableOption">
      <template slot="handle"
                v-if="isShowOperator">
        <kye-table-column label="操作"
                          align="center"
                          width="130px"
                          fixed="left">
          <template slot-scope="scope">
            <kye-button @click="handleOk(scope.row)"
                        type="text"
                        v-if="isOffering"
                        :auth="takeType===200?URL.affirmTrunkTask:URL.confirmCar"
                        size="small">确认要车</kye-button>
            <kye-button v-if="scope.row.driverType===3 || scope.row.driverType===4"
                        type="text"
                        class="eyes"
                        :auth="takeType===200?URL.findTrunkTaskCompactInfo:URL.findTakePieTaskCompactInfo"
                        @click="handleViewContract(scope.row)">查看合同
            </kye-button>
          </template>
        </kye-table-column>
      </template>
    </kye-edit-table>
    <kye-dialog title="取派计费标准"
                :visible.sync="takeSendVisible"
                width="800px"
                right>
      <div class="content">
        <kye-tabs v-model="activeName">
          <kye-tab-pane label="按重量计费标准"
                        v-if="chargeWeightList"
                        name="first">
            <get-send-weight :tableData="chargeWeightList"></get-send-weight>
          </kye-tab-pane>
          <kye-tab-pane label="按公里计费标准"
                        v-if="chargeKmList"
                        name="second">
            <get-send-km :tableData="chargeKmList"></get-send-km>
          </kye-tab-pane>
          <kye-tab-pane label="折扣优惠标准"
                        name="three"
                        v-if="chargeWeightList||chargeKmList">
            <discount :tableData="discountList"></discount>
          </kye-tab-pane>
          <send-weight-prompt></send-weight-prompt>
        </kye-tabs>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <kye-button type="primary"
                    @click="handleCancel">关闭</kye-button>
      </span>
    </kye-dialog>
    <kye-dialog title="干线计费标准"
                :visible.sync="mainLineVisible"
                width="800px"
                right>
      <div class="content">
        <kye-tabs v-model="activeName">
          <kye-tab-pane label="按线路费标准"
                        v-if="quoteLine"
                        name="first">
            <mainline-quote-line :tableData="quoteLine">
            </mainline-quote-line>
          </kye-tab-pane>
          <kye-tab-pane label="按公里计费标准"
                        v-if="lineKmList"
                        name="second">
            <mainline-quote-km :tableData="lineKmList"></mainline-quote-km>
          </kye-tab-pane>
          <kye-tab-pane label="折扣优惠标准"
                        name="three"
                        v-if="quoteLine||lineKmList">
            <discount :tableData="discountList"></discount>
          </kye-tab-pane>
        </kye-tabs>
      </div>
      <span slot="footer"
            class="dialog-footer">
        <kye-button type="primary"
                    @click="handleCancel">关闭</kye-button>
      </span>
    </kye-dialog>
  </div>
</template>
<script>
  import { money } from 'public/utils/filter.js'
  import URL from '../../takeCar.api'
  // 合同折扣信息
  import discount from '../../../../../components/contract-tables/discount'
  // 合同取派按重量计费
  import getSendWeight from '../../../../../components/contract-tables/get-send-weight'
  // 合同取派按公里计费
  import getSendKm from '../../../../../components/contract-tables/get-send-km'
  // 合同干线按线路计费
  import mainlineQuoteLine from '../../../../../components/contract-tables/mainline-quote-line'
  // 合同取派按公里计费
  import mainlineQuoteKm from '../../../../../components/contract-tables/mainline-quote-km'
  // 取派须知
  import sendWeightPrompt from '../../../../../components/contract-tables/send-weight-prompt'
  import { formatTime } from '../../../../utils/format'
  export default {
    components: {
      discount,
      getSendWeight,
      mainlineQuoteLine,
      sendWeightPrompt,
      getSendKm,
      mainlineQuoteKm
    },
    props: {
      loading: {
        type: Boolean,
        default: false
      },
      isTakeSend: {
        type: Boolean,
        default: false
      },
      bidListData: {
        type: Array,
        default () {
          return []
        }
      },
      isShowOperator: {
        type: Boolean,
        default: false
      },
      isOffering: {
        type: Boolean,
        default: false
      },
      takeType: {
        type: Number,
        default: 0
      },
      bidLoading: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        URL: URL,
        takeSendVisible: false,
        mainLineVisible: false,
        activeName: 'first',
        chargeWeightList: null,
        chargeKmList: null,
        discountList: [],
        quoteLine: null,
        lineKmList: null,
        column: [
          {
            key: 'price',
            label: '价格',
            show: true,
            width: '80px',
            filter: 'money'
          },
          {
            key: 'effectlTimesTotal',
            label: '合作总次数',
            show: true,
            width: '45px'
          },
          {
            key: 'driverName',
            label: '运力名称',
            show: true,
            width: '80px'
          },
          {
            key: 'driverPhone',
            label: '联系电话',
            show: true,
            moduleCode: 'ecs_yc',
            bizIdKey: 'id',
            width: '60px',
            fieldName: 'driverPhone'
          },
          {
            key: 'driverType',
            label: '运力类型',
            show: true,
            width: '45px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_car_driver_type'
              ]
            }
          },
          {
            key: 'entrustPlatformName',
            label: '挂靠公司',
            show: true,
            width: '80px'
          },
          {
            key: 'effectTimesMonthly',
            label: '当月合作次数',
            show: true,
            width: '60px'
          },
          {
            key: 'contractPromise',
            label: '承诺约定',
            show: true,
            width: '40x'
          },
          {
            key: 'carrierDriverName',
            label: '司机姓名',
            show: true,
            width: '45px'
          },
          {
            key: 'carrierDriverPhone',
            label: '司机电话',
            moduleCode: 'ecs_yc',
            bizIdKey: 'id',
            show: true,
            width: '60px',
            fieldName: 'carrierDriverPhone'
          },
          {
            key: 'breakContractTimes',
            label: '违约次数',
            show: true,
            width: '40px'
          },
          {
            key: 'driverType',
            label: '报价类型',
            show: true,
            width: '40px',
            filter: {
              type: 'lookup',
              args: [
                'ecs_car_bid_type'
              ]
            }
          },
          {
            key: 'ycStatus',
            label: '状态',
            show: !this.isOffering,
            filter: {
              type: 'lookup',
              args: [
                'ecs_car_yc_status'
              ]
            }
          }
        ],
        tableOption: {
          moduleCode: 'ecs_yc',
          stripe: true
        },
      }
    },
    methods: {
      // 查看合同计费
      handleViewContract (record) {
        let param = { driverId: record.driverId }
        if (this.takeType === 300) {
          this.findTakePieTaskCompactInfo({ taskCode: record.taskCode, contractId: record.contractNo })
          this.querySignedDriverDiscount(param)
          this.takeSendVisible = true
        } else {
          this.findTrunkTaskCompactInfo({ taskCode: record.taskCode, contractId: record.contractNo })
          this.querySignedDriverDiscount(param)
          this.mainLineVisible = true
        }
      },
      // 关闭弹窗
      handleCancel () {
        this.takeSendVisible = false
        this.mainLineVisible = false
      },
      // 确认要车
      async handleOk (row) {
        if (this.takeType === 200) {
          await this.$http(URL.affirmTrunkTask, { taskDriverOfferPriceItemId: row.id })
        } else {
          await this.$http(URL.confirmCar, { driverTaskCode: row.driverTaskCode })
        }
        // 刷新详情信息
        this.$emit('refreshDetails')
        this.$message({
          showClose: true,
          message: '操作成功',
          type: 'success'
        })
        this.$refreshMainQueryTable()
      },
      // 取派按重量计费
      async findTakePieTaskCompactInfo (param) {
        const statusMap = new Map([['1', '有效'], ['2', '无效']])
        const specificateTypeMap = new Map([['1', '小件'], ['2', '大件']])
        const { driverChargingByWeightRVos, driverChargingByKilometerOVos } = await this.$http(URL.findTakePieTaskCompactInfo, param)
        if (driverChargingByWeightRVos && Array.isArray(driverChargingByWeightRVos)) {
          this.chargeKmList = null
          this.activeName = 'first'
          driverChargingByWeightRVos.forEach((item, index) => {
            item.range = `${item.minWeight} - ${item.maxWeight}`
            item.updateTime = formatTime(item.updateTime)
            item.createTime = formatTime(item.createTime)
            item.specificateType = specificateTypeMap.get(
              item.specificateType + ''
            )
            item.statusName = statusMap.get(item.status + '')
            item.bottomPrice = money(item.bottomPrice)
            item.startPrice = money(item.startPrice)
            item.renewalPrice = money(item.renewalPrice)
          })
          this.chargeWeightList = driverChargingByWeightRVos
        }
        if (driverChargingByKilometerOVos && Array.isArray(driverChargingByKilometerOVos)) {
          this.chargeWeightList = null
          this.activeName = 'second'
          const chargeKmList = this.driverByKilometerRVos(driverChargingByKilometerOVos)
          this.chargeKmList = chargeKmList
        }
      },
      // 按公里计费数据处理
      driverByKilometerRVos (data) {
        data.forEach(item => {
          item.range = `${item.minKilometer} - ${item.maxKilometer}`
          item.createdAt = formatTime(item.createdAt)
          item.updatedAt = formatTime(item.updatedAt)
          // 价格格式化
          item.startPrice = money(item.startPrice)
          item.unitPriceByKilometer = money(item.unitPriceByKilometer)
        })
        return data
      },
      // 取派按折扣计费
      async querySignedDriverDiscount (row) {
        this.discountList = []
        const data = await this.$http(URL.querySignedDriverDiscount, { driverId: row.driverId })
        data.forEach((item, index) => {
          item.createTime = formatTime(item.createTime)
          item.updateTime = formatTime(item.updateTime)
          if (item.discount < 1) {
            // 折扣转百分比
            item.discount = item.discount * 100
          }
          if (item.status === 1) {
            item.status = '有效'
          } else if (item.status === 2) {
            item.status = '失效'
          }
          item.range = `${money(item.minFreight)}-${money(item.maxFreight)}` // 范围拼接
        })
        this.discountList = data
      },
      // 干线报价-按线路查询-查询接口
      async findTrunkTaskCompactInfo (param) {
        const { driverTrunkRouteRVos, driverTrunkChargeByKilometerList } = await this.$http(URL.findTrunkTaskCompactInfo, param)
        if (driverTrunkRouteRVos && Array.isArray(driverTrunkRouteRVos)) {
          this.lineKmList = null
          this.activeName = 'first'
          driverTrunkRouteRVos.forEach((item, index) => {
            item.createTime = formatTime(item.createTime)
            item.updateTime = formatTime(item.updateTime)
            item.overLoadPoints = money(item.overLoadPoints)
            item.transportAskPrice = money(item.transportAskPrice)
            item.returnPrice = money(item.returnPrice)
            if (item.status === '1') {
              item.statusName = '有效'
            } else if (item.status === '2') {
              item.statusName = '失效'
            }
          })
          this.quoteLine = driverTrunkRouteRVos
        }
        if (driverTrunkChargeByKilometerList && Array.isArray(driverTrunkChargeByKilometerList)) {
          this.quoteLine = null
          this.activeName = 'second'
          const lineKmList = this.driverByKilometerRVos(driverTrunkChargeByKilometerList)
          this.lineKmList = lineKmList
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
  .eyes {
    margin-left: 5px;
    border: none;
    background-color: transparent;
  }
</style>


