<template>
  <div>
    <div class="kye-block-title">要车信息
    </div>
    <kye-form :model="ruleForm"
              :rules="rules"
              ref="mainLineInfo">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="要车编号">
            <kye-input v-model="ruleForm.taskCode"
                       disabled
                       placeholder="">
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="要车类型"
                         prop="takeType"
                         required>
            <kye-select v-model="ruleForm.takeType"
                        disabled
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_yc_line_take_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用车时间"
                         prop="loadingTimeAt"
                         required>
            <kye-date-picker v-model="ruleForm.loadingTimeAt"
                             type="datetime"
                             :picker-options="pickerOptions">
            </kye-date-picker>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估货量"
                         prop="goodsWeight"
                         required>
            <kye-number v-model="ruleForm.goodsWeight"
                        type="text"
                        :min="0"
                        :precision="2"
                        :max="999999.99"
                        unit="kg">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估体积"
                         prop="goodsVolume"
                         required>
            <kye-number v-model="ruleForm.goodsVolume"
                        type="text"
                        :min="0"
                        :precision="2"
                        :max="9999.99"
                        unit="m³">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预估里程">
            <kye-number v-model="ruleForm.totalMiles"
                        type="text"
                        :min="0"
                        disabled
                        unit="km">
            </kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="尾板需求"
                         prop="isTailboard"
                         required>
            <kye-select v-model="ruleForm.isTailboard"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车型"
                         prop="carType"
                         required>
            <kye-select v-model="ruleForm.carType"
                        placeholder=""
                        value-key="dictKey"
                        @change="carTypeChange">
              <kye-option v-for="item in carTypeOption"
                          :key="item.dictKey"
                          :label="item.dictValue"
                          :value="item"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车长"
                         prop="carLength"
                         required>
            <kye-select v-model="ruleForm.carLength"
                        placeholder="">
              <kye-option v-for="item in carLengthOption"
                          :key="item.dictKey"
                          :label="item.dictValue"
                          :value="item.dictKey"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="走高速否"
                         prop="isExpressway"
                         required>
            <kye-select v-model="ruleForm.isExpressway"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="去程时效"
                         prop="consumeTime"
                         required>
            <kye-number v-model="ruleForm.consumeTime"
                        type="text"
                        :precision="1"
                        :min="0.1"
                        :max="99.9"
                        unit="h">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="上岗说明">
            <kye-input v-model="ruleForm.postRequirements"
                       :maxlength="50"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="始发地"
                         prop="startPoint"
                         required>
            <kye-select v-model="ruleForm.startPoint"
                        value-key="pointId"
                        filterable
                        remote
                        :remote-method="queryFromRemotePlaces"
                        @change="startPointChange"
                        :loading="loading"
                        placeholder="">
              <kye-option v-for="item in fromRemotePlacesOption"
                          :key="item.pointId"
                          :label="item.nodeName"
                          :value="item">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="目的地"
                         prop="endPoint"
                         required>
            <kye-select v-model="ruleForm.endPoint"
                        value-key="pointId"
                        filterable
                        remote
                        :remote-method="queryToRemotePlaces"
                        @change="endPointChange"
                        :loading="loading"
                        placeholder="">
              <kye-option v-for="item in toRemotePlacesOption"
                          :key="item.pointId"
                          :label="item.nodeName"
                          :value="item">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否往返"
                         prop="isGoBack"
                         required>
            <kye-select v-model="ruleForm.isGoBack"
                        @change="handleGoBack"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否经停"
                         prop="isPause"
                         required>
            <kye-select v-model="ruleForm.isPause"
                        @change="handleStopOver"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row v-if="ruleForm.isGoBack==='1'">
        <kye-col :span="4">
          <kye-form-item label="返程时间"
                         prop="backTimeAt"
                         required>
            <kye-date-picker v-model="ruleForm.backTimeAt"
                             type="datetime"
                             :picker-options="pickerOptions">
            </kye-date-picker>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="返程时效"
                         prop="backConsumerTime"
                         required>
            <kye-number v-model="ruleForm.backConsumerTime"
                        type="text"
                        :precision="1"
                        :min="0.1"
                        :max="99.9"
                        unit="h">
            </kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <div v-if="ruleForm.isPause==='1' && ruleForm.landArr.length>0">
        <kye-row v-for="(item,index) in ruleForm.landArr"
                 v-bind:key="item.pointId+'-'+index">
          <kye-col :span="8">
            <kye-form-item :label="'经停地'+(index+1)"
                           :key="item.key"
                           :prop="'landArr.' + index + '.pointId'"
                           :rules="{
                              required: true, message: '经停地不能为空', trigger: 'change'
                            }">
              <kye-select v-model="ruleForm.landArr[index]"
                          value-key="pointId"
                          filterable
                          remote
                          :remote-method="queryRemotePlaces"
                          @change="landPointChange"
                          :loading="loading"
                          placeholder="">
                <kye-option v-for="(item, index) in remotePlacesOption"
                            :key="item.pointId+'-'+index"
                            :label="item.nodeName"
                            :value="item">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <span class="remove-add"
                  v-if="ruleForm.landArr.length>1&&!isDisabled"
                  @click="handleRemove(item)">删除</span>
            <span class="remove-add"
                  @click="handleNewLand"
                  v-if="ruleForm.landArr.length < 4 && ruleForm.landArr.length === index+1 && !isDisabled">增加</span>
          </kye-col>
        </kye-row>
      </div>
    </kye-form>
  </div>
</template>
<script>
  import rules from 'public/utils/rules'
  import URL from '../takeCar.api'
  import mixins from 'public/mixins'

  export default {
    mixins: [mixins],
    props: {
      isDisabled: {
        type: Boolean,
        default: false
      },
      detailData: {
        type: Object,
        default () {
          return {}
        }
      },
      carTypeOption: Array,
      carLengthOption: Array
    },
    watch: {
      // 为防止经停地删除查询条件时，landArr被清空
      'ruleForm.landArr': function (val) {
        let hasNull = false
        const cloneLandArr = val.map(item => {
          if (item === null) {
            hasNull = true
            return {
              key: Date.now(),
              pointId: '',
              type: '3'
            }
          } else {
            return item
          }
        })
        if (hasNull) {
          this.ruleForm.landArr = cloneLandArr
        }
      }
    },
    computed: {
      // 是否编辑
      isEdit: function () {
        // 没有taskCode 和 状态为100 可编辑
        return !this.detailData.taskCode || this.detailData.status === 100
      }
    },
    data () {
      var checkGoodsWeight = (rule, value, callback) => {
        if (value <= 0) {
          return callback(new Error('请输入预估重量'))
        }
        setTimeout(() => {
          if (value > 999999.99) {
            callback(new Error('超过最大重量'))
          } else {
            callback()
          }
        }, 0)
      }
      var checkGoodsVolume = (rule, value, callback) => {
        if (value <= 0) {
          return callback(new Error('请输入预估体积'))
        }
        setTimeout(() => {
          if (value > 999999.99) {
            callback(new Error('超过最大重量'))
          } else if (value <= 0) {
            callback(new Error('最小重量不能为0'))
          } else {
            callback()
          }
        }, 0)
      }
      return {
        URL: URL,
        fromRemotePlacesOption: [], // 拿货地
        toRemotePlacesOption: [], // 目的地
        remotePlacesOption: [], // 经停
        loading: false,
        list: [],
        totalMiles: 0, // 总里程
        milesArr: [],
        pickerOptions: {
          disabledDate (time) {
            return time.getTime() < Date.now() - 8.64e7
          }
        },
        ruleForm: {
          takeType: '',
          loadingTimeAt: '',
          backTimeAt: '',
          backConsumerTime: '',
          goodsWeight: '',
          goodsVolume: '',
          isTailboard: '2',
          carType: '',
          carTypeName: '',
          carLength: '',
          isExpressway: '2',
          consumeTime: '',
          postRequirements: '',
          startPoint: null,
          endPoint: null,
          isGoBack: '2',
          isPause: '2',
          totalMiles: 0,
          landArr: [], // 经停集合
        },
        rules: {
          takeType: rules.str('请选择要车类型', true, 'change'),
          loadingTimeAt: rules.str('请选择时间', true, ''),
          goodsWeight: [{ validator: checkGoodsWeight, trigger: '' }],
          goodsVolume: [{ validator: checkGoodsVolume, trigger: '' }],
          isExpressway: rules.str('请选择是否高速', true, 'change'),
          isTailboard: rules.str('请选择尾板需求', true, 'change'),
          carType: rules.str('请选择需求车型', true, 'change'),
          carLength: rules.str('请选择需求车长', true, 'change'),
          consumeTime: rules.str('请输入去程时效', true, ''),
          startPoint: rules.str('请输入拿货地', true, 'change'),
          endPoint: rules.str('请输入目的地', true, 'change'),
          isGoBack: rules.str('请选择是否往返', true, 'change'),
          isPause: rules.str('请选择是否经停', true, 'change'),
          backTimeAt: rules.str('请选择时间', true, ''),
          backConsumerTime: rules.str('请输入返程时效', true, ''),
        }
      }
    },
    mounted () {
      this.setFormData()
    },
    methods: {
      // 将数据赋值给详情
      setFormData () {
        if (!this.detailData.takeType) return false
        this.ruleForm.landArr = []
        for (let key in this.detailData) {
          if (['carLength', 'isExpressway', 'isGoBack', 'isPause', 'isTailboard', 'takeType', 'type'].indexOf(key) > -1) {
            this.ruleForm[key] = this.detailData[key] + ''
          } else if (key === 'trunkTaskStopPointEntities') {
            this.detailData[key].forEach(item => {
              if (item.type === 1) {
                this.ruleForm.startPoint = item
                this.fromRemotePlacesOption = [item]
              } else if (item.type === 2) {
                this.toRemotePlacesOption = [item]
                this.ruleForm.endPoint = item
              } else {
                if (this.remotePlacesOption.indexOf(item) === -1) {
                  this.remotePlacesOption.push(item)
                }
                this.ruleForm.landArr.push(item)
              }
            })
          } else if (key === 'carType') {
            this.ruleForm[key] = {
              dictKey: this.detailData[key] + '',
              dictValue: this.detailData['carTypeName']
            }
          } else if (['backTimeAt', 'backConsumerTime'].indexOf(key) > -1) {
            if (this.detailData[key] === 0) {
              this.ruleForm[key] = ''
            } else {
              this.ruleForm[key] = this.detailData[key]
            }
          } else {
            this.ruleForm[key] = this.detailData[key]
          }
        }
        this.isEdit && this.getAllLand()
      },
      // 获取远程地址
      async queryRemotePlaces (query) {
        const param = {
          nodeName: query
        }
        this.loading = true
        const data = await this.$http(URL.findByNodeNameAndFlag, param)
        this.remotePlacesOption = data
        this.remotePlacesOption && this.remotePlacesOption.forEach(item => {
          item.pointId = item.id
        })
        this.loading = false
      },
      async queryFromRemotePlaces (query) {
        const param = {
          nodeName: query
        }
        this.loading = true
        const data = await this.$http(URL.findByNodeNameAndFlag, param)
        this.fromRemotePlacesOption = data
        this.fromRemotePlacesOption && this.fromRemotePlacesOption.forEach(item => {
          item.pointId = item.id
        })
        this.loading = false
      },
      async queryToRemotePlaces (query) {
        const param = {
          nodeName: query
        }
        this.loading = true
        const data = await this.$http(URL.findByNodeNameAndFlag, param)
        this.toRemotePlacesOption = data
        this.toRemotePlacesOption && this.toRemotePlacesOption.forEach(item => {
          item.pointId = item.id
        })
        this.loading = false
      },
      // 是否往返变化
      handleGoBack (val) {
        if (val !== '1') {
          this.ruleForm.backConsumerTime = ''
          this.ruleForm.backTimeAt = ''
        }
      },
      handleStopOver (val) {
        if (val === '1') {
          if (!this.ruleForm.startPoint || !this.ruleForm.endPoint) {
            this.$message('请先选择拿货地和目的地')
            this.ruleForm.isPause = '2'
            return false
          }
          this.ruleForm.landArr = []
          this.ruleForm.landArr.push({
            key: Date.now(),
            pointId: '',
            type: '3'
          })
        } else {
          this.ruleForm.landArr = []
        }
      },
      // 新增经停点，最多4个
      handleNewLand () {
        if (this.ruleForm.landArr.length > 4) return
        this.ruleForm.landArr.push({
          key: Date.now(),
          pointId: '',
          type: '3'
        })
      },
      // 删除经停点
      handleRemove (item) {
        var index = this.ruleForm.landArr.indexOf(item)
        if (index !== -1) {
          this.ruleForm.landArr.splice(index, 1)
        }
        if (item.pointId) {
          this.getAllLand()
        }
      },
      startPointChange (item) {
        this.ruleForm.startPoint = {
          pointId: item.id,
          longitude: item.longitude,
          latitude: item.latitude,
          type: '1',
          nextPointDistance: 0
        }
        this.getAllLand()
      },
      endPointChange (item) {
        this.ruleForm.endPoint = {
          pointId: item.id,
          longitude: item.longitude,
          latitude: item.latitude,
          type: '2',
          nextPointDistance: 0
        }
        this.getAllLand()
      },
      // 经停地变化
      landPointChange (item) {
        this.getAllLand()
      },
      // 汇总所有点
      getAllLand () {
        if (!this.ruleForm.startPoint || !this.ruleForm.endPoint) {
          return false
        }
        const milesArr = []
        milesArr[0] = this.ruleForm.startPoint
        if (milesArr.length === 1) {
          milesArr[1] = this.ruleForm.endPoint
        } else {
          milesArr[this.milesArr.length - 1] = this.ruleForm.endPoint
        }
        if (!milesArr[0].longitude || !milesArr[1].longitude) {
          return false
        }
        milesArr.splice(1, 0, ...this.ruleForm.landArr)
        this.setSaveDisabled(true)
        setTimeout(() => {
          this.setSaveDisabled(false)
        }, 7000)
        this.getAllOrigin(milesArr)
      },
      // 计算所有点坐标
      getAllOrigin (arr) {
        const originArr = []
        arr.forEach((item, index, arr) => {
          if (index < arr.length - 1) {
            const obj = {
              origin: `${item.longitude},${item.latitude}`,
              destination: `${arr[index + 1].longitude},${arr[index + 1].latitude}`
            }
            originArr.push(obj)
          }
        })
        this.getAllDistance(arr, originArr)
      },
      // 分组计算坐标距离
      getAllDistance (arr, originArr) {
        const length = originArr.length
        const promiseArr = []
        for (let i = 1; i <= length; i++) {
          promiseArr.push(this.$http(URL.getDistance, originArr[i - 1]))
        }
        Promise.all(promiseArr).then(result => {
          result.forEach((item, index) => {
            arr[index].nextPointDistance = parseInt(Math.round(item / 1000))
          })
          let totalMiles = 0
          // 计算总里程
          arr.forEach(item => {
            totalMiles += item.nextPointDistance
          })
          // 计算宽度
          arr.forEach(item => {
            item.width = (item.nextPointDistance / totalMiles * 600) || 0
          })
          this.totalMiles = totalMiles
          this.ruleForm.totalMiles = totalMiles
          console.log('this.ruleForm.totalMiles', this.ruleForm.totalMiles)
          this.milesArr = arr
          this.setSaveDisabled(false)
        })
      },
      setSaveDisabled (data) {
        this.$emit('setSaveDisabled', data)
      },
      carTypeChange (item) {
        this.ruleForm.carTypeName = item.dictValue
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const currentTime = new Date()
            const loadingTimeAt = Number(new Date(this.ruleForm.loadingTimeAt))
            if (currentTime >= loadingTimeAt) {
              this.ruleForm.loadingTimeAt = ''
              this.$alert('用车时间不能小于当前时间！')
              return
            }
            const backTimeAt = Number(new Date(this.ruleForm.backTimeAt))
            if ((!backTimeAt && this.ruleForm.isGoBack === '1') || (backTimeAt && loadingTimeAt >= backTimeAt)) {
              this.ruleForm.backTimeAt = ''
              this.$alert('返程时间不能小于用车时间！')
              return
            }
            let trunkTaskStopPointIVos = ''
            if (this.ruleForm.landArr && this.ruleForm.landArr.length > 0) {
              const landArr = this.ruleForm.landArr.map(item => {
                return {
                  pointId: item.pointId,
                  longitude: item.longitude,
                  latitude: item.latitude,
                  type: '3',
                  nextPointDistance: item.nextPointDistance
                }
              })
              trunkTaskStopPointIVos = JSON.stringify([
                this.ruleForm.startPoint,
                ...landArr,
                this.ruleForm.endPoint
              ])
            } else {
              trunkTaskStopPointIVos = JSON.stringify([
                this.ruleForm.startPoint,
                this.ruleForm.endPoint
              ])
            }
            const param = {
              loadingTimeAt: loadingTimeAt,
              takeType: this.ruleForm.takeType,
              carType: this.ruleForm.carType.dictKey,
              carLength: this.ruleForm.carLength,
              goodsWeight: this.ruleForm.goodsWeight,
              goodsVolume: this.ruleForm.goodsVolume,
              isTailboard: this.ruleForm.isTailboard,
              isExpressway: this.ruleForm.isExpressway,
              consumeTime: this.ruleForm.consumeTime,
              postRequirements: this.ruleForm.postRequirements,
              isGoBack: this.ruleForm.isGoBack,
              backTimeAt: backTimeAt,
              backConsumerTime: this.ruleForm.backConsumerTime,
              isPause: this.ruleForm.isPause,
              estimateCarType: this.ruleForm.carType.dictKey,
              estimateCarLength: this.ruleForm.carLength,
              estimateDistance: this.totalMiles,
              carTypeName: this.ruleForm.carType.dictValue,
              estimateCarTypeName: '',
              trunkTaskStopPointIVos: trunkTaskStopPointIVos
            }
            this.doSaveTrunkTask(param)
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 重置表单
      resetForm (formName) {
        this.ruleForm = {
          takeType: '',
          loadingTimeAt: '',
          goodsWeight: '',
          goodsVolume: '',
          isTailboard: '2',
          carType: '',
          carTypeName: '',
          carLength: '',
          isExpressway: '2',
          consumeTime: '',
          postRequirements: '',
          startPoint: null,
          endPoint: null,
          isGoBack: '2',
          isPause: '2',
          totalMiles: 0,
          landArr: [] // 经停集合
        }
        this.$refs[formName].resetFields()
      },
      // 修改新增接口
      async doSaveTrunkTask (param) {
        let taskCode = this.ruleForm.taskCode
        if (!this.detailData.id || (this.detailData.status === 500 && this.detailData.offerPriceNum === 0)) {
          taskCode = await this.$http(URL.saveTrunkTask, param)
        } else {
          param.id = this.detailData.id
          param.taskCode = this.detailData.taskCode
          await this.$http(URL.editTrunkTask, param)
        }
        this.$message({
          type: 'success',
          message: '操作成功'
        })
        this.$refreshMainQueryTable()
        this.$router.push(`/ecms/take-car/main-detail/${taskCode}`)
      }
    }
  }
</script>
<style scoped>
  .remove-add {
    margin-left: 10px;
    line-height: 28px;
    height: 28px;
    display: inline-block;
    cursor: pointer;
  }
  .remove-add:hover {
    color: #7352bf;
  }
</style>
