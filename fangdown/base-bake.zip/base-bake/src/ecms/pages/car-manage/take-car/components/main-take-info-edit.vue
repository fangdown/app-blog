<template>
  <div>
    <div class="kye-block-title">要车信息
    </div>
    <kye-form :model="ruleForm"
              :rules="rules"
              ref="mainTakeInfo">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="要车编号">
            <kye-input v-model="ruleForm.taskCode"
                       disabled
                       placeholder="">
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="要车类型">
            <kye-select v-model="ruleForm.takeType"
                        disabled
                        placeholder="">
              <kye-option label="取派"
                          value="1"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用车时间"
                         prop="loadingTimeAt"
                         required>
            <kye-date-picker v-model="ruleForm.loadingTimeAt"
                             type="datetime"
                             :picker-options="pickerOptions">
            </kye-date-picker>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车型"
                         prop="carTypeObj"
                         required>
            <kye-select v-model="ruleForm.carTypeObj"
                        value-key="dictKey"
                        placeholder=""
                        @change="changeCarType">
              <kye-option v-for="item in carTypeOption"
                          :key="item.dictKey"
                          :label="item.dictValue"
                          :value="item">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车长"
                         :prop="isRequired?'carLength':''"
                         :required="isRequired">
            <kye-select v-model="ruleForm.carLength"
                        placeholder=""
                        :disabled="isTwoWheels">
              <kye-option v-for="item in carLengthOption"
                          :key="item.dictKey"
                          :label="item.dictValue"
                          :value="item.dictKey">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="尾板需求"
                         :prop="isRequired?'isTailboard':''"
                         :required="isRequired">
            <kye-select v-model="ruleForm.isTailboard"
                        placeholder=""
                        :disabled="isTwoWheels">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="小推车否"
                         :prop="isRequired?'isSmallCar':''"
                         :required="isRequired">
            <kye-select v-model="ruleForm.isSmallCar"
                        placeholder=""
                        :disabled="isTwoWheels">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="走高速否"
                         :prop="isRequired?'isExpressway':''"
                         :required="isRequired">
            <kye-select v-model="ruleForm.isExpressway"
                        placeholder=""
                        :disabled="isTwoWheels">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="完成时效"
                         prop="consumeTime"
                         required>
            <kye-number v-model="ruleForm.consumeTime"
                        type="text"
                        :precision="1"
                        :min="0.1"
                        :max="99.99"
                        unit="h">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否返仓"
                         prop="isGoBack"
                         required>
            <kye-select v-model="ruleForm.isGoBack"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否搬运"
                         prop="isCarry"
                         required>
            <kye-select v-model="ruleForm.isCarry"
                        placeholder="">
              <kye-option v-for="item in lookUpOptions['ecs_common_yes_no']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="上岗说明">
            <kye-input v-model="ruleForm.postRequirements"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="拿货地"
                         prop="startPoint"
                         required>
            <kye-select v-model="ruleForm.startPoint"
                        value-key="pointId"
                        filterable
                        remote
                        reserve-keyword
                        placeholder=""
                        :remote-method="queryFromRemotePlaces"
                        @change="startPointChange"
                        :loading="loading">
              <kye-option v-for="item in fromRemotePlacesOption"
                          :key="item.pointId"
                          :label="item.nodeName"
                          :value="item">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <carrier-info :listData="listData"
                  @rowDelete="rowDelete"
                  @handleAdd="handleAdd"
                  @getwaybill="getwaybill"
                  :estimate="estimate"></carrier-info>
  </div>
</template>
<script>
  import URL from '../takeCar.api'
  // 承运信息
  import carrierInfo from './carrier-info'
  import rules from 'public/utils/rules'
  import mixins from 'public/mixins'
  export default {
    mixins: [mixins],
    components: {
      carrierInfo
    },
    props: {
      detailData: {
        type: Object,
        default () {
          return {}
        }
      },
      tableData: {
        type: Array,
        default () {
          return []
        }
      },
      carTypeOption: Array,
      carLengthOption: Array
    },
    data () {
      return {
        URL: URL,
        listData: [],
        selectedRow: [],
        isTwoWheels: false,
        isRequired: true,
        ruleForm: {
          status: null,
          taskCode: '',
          offerPriceNum: 0,
          takeType: '1',
          loadingTimeAt: '',
          carType: '',
          carLength: '',
          isTailboard: '1',
          isSmallCar: '1',
          isExpressway: '1',
          consumeTime: '',
          isGoBack: '1',
          isCarry: '1',
          postRequirements: '',
          startPointId: '',
          startPointName: '',
          startPointCode: '',
          startPointAddress: '',
          startPointLongitude: '',
          startPointLatitude: '',
          startPoint: null,
          carTypeObj: null
        },
        estimate: { // 预估承运信息
          goodsWeight: 0,
          goodsVolume: 0,
          waybillNum: 0,
          goodsNum: 0,
          estimateDistance: 0
        },
        pickerOptions: { // 用车时间不能小于当前时间
          disabledDate (time) {
            return time.getTime() < Date.now() - 8.64e7
          }
        },
        fromRemotePlacesOption: [],
        loading: false,
        rules: {
          loadingTimeAt: rules.str('请输入用车时间', true, ''),
          carTypeObj: rules.str('请选择需求车型', true, 'change'),
          carLength: rules.str('请选择需求车长', true, 'change'),
          isTailboard: rules.str('请选择尾板', true, 'change'),
          isSmallCar: rules.str('请选择小推车', true, 'change'),
          isExpressway: rules.str('请选择是否走高速', true, 'change'),
          consumeTime: rules.str('请输入完成时效', true, ''),
          isGoBack: rules.str('请选择是否返仓', true, 'change'),
          isCarry: rules.str('请选择是否搬运', true, 'change'),
          startPoint: rules.str('请选择拿货地', true, '')
        }
      }
    },
    mounted () {
      this.setFormData()
    },
    methods: {
      // 将数据赋值给详情
      setFormData () {
        if (!this.detailData.startPointId) return false
        for (let key in this.ruleForm) {
          if (key === 'startPoint') {
            let startPoint = {}
            startPoint.pointId = this.detailData.startPointId
            startPoint.longitude = this.detailData.startPointLongitude
            startPoint.latitude = this.detailData.startPointLatitude
            this.ruleForm.startPoint = startPoint
            let pointArr = { ...startPoint, nodeName: this.detailData.startPointName }
            this.fromRemotePlacesOption = [pointArr]
          } else if (key === 'carTypeObj') {
            const carTypeObj = {}
            carTypeObj.dictKey = this.detailData.carType + ''
            carTypeObj.dictValue = this.detailData.carTypeName
            this.ruleForm.carTypeObj = carTypeObj
          } else if (['takeType', 'isTailboard', 'isSmallCar', 'isExpressway', 'isGoBack', 'isCarry'].indexOf(key) > -1) {
            this.ruleForm[key] = this.detailData[key] + ''
          } else {
            this.ruleForm[key] = this.detailData[key]
          }
        }
        for (let key in this.estimate) {
          this.estimate[key] = this.detailData[key]
        }
        if (this.detailData.carType === '1011' || this.detailData.carType === '1012') {
          this.isTwoWheels = true
          this.isRequired = false
          this.ruleForm.carLength = 0
          this.ruleForm.isTailboard = 2
          this.ruleForm.isSmallCar = 2
          this.ruleForm.isExpressway = 2
        }
        this.listData = this.tableData
      },
      // 查询拿货地信息
      async queryFromRemotePlaces (query) {
        const param = {
          nodeName: query
        }
        this.loading = true
        const data = await this.$http(URL.findByNodeNameAndFlag, param)
        this.fromRemotePlacesOption = data
        this.fromRemotePlacesOption && this.fromRemotePlacesOption.forEach(item => {
          item.pointId = item.id
        })
        this.loading = false
      },
      startPointChange (item) {
        this.ruleForm.startPoint = {
          pointId: item.id,
          longitude: item.longitude,
          latitude: item.latitude
        }
        this.getAllLand()
      },
      // 选择车型为二轮车、三轮车时车长、是否需尾板...不能选
      changeCarType (item) {
        if (item.dictKey === '1011' || item.dictKey === '1012') {
          this.isTwoWheels = true
          this.isRequired = false
          this.ruleForm.carLength = 0
          this.ruleForm.isTailboard = 2
          this.ruleForm.isSmallCar = 2
          this.ruleForm.isExpressway = 2
        } else {
          this.isTwoWheels = false
          this.isRequired = true
        }
      },
      // 提交取派信息
      createTakePieTask (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            this.listData.forEach((item, index) => {
              if (item.add) {
                this.listData.splice(index, 1)
              }
            })
            if (this.listData.length > 0) {
              this.ruleForm.taskWaybillIVos = JSON.stringify(this.listData)
            } else {
              this.ruleForm.taskWaybillIVos = ''
              this.$alert('承运信息不能为空')
              return
            }
            for (let key in this.estimate) {
              this.ruleForm[key] = this.estimate[key]
            }
            const loadingTimeAt = new Date(this.ruleForm.loadingTimeAt).getTime()
            const currentTime = new Date()
            if (currentTime >= loadingTimeAt) {
              this.ruleForm.loadingTimeAt = ''
              this.$alert('用车时间不能小于当前时间！')
              return
            }
            this.ruleForm.loadingTimeAt = loadingTimeAt
            this.ruleForm.carType = this.ruleForm.carTypeObj.dictKey
            this.ruleForm.carTypeName = this.ruleForm.carTypeObj.dictValue
            this.ruleForm.startPointId = this.ruleForm.startPoint.pointId
            this.ruleForm.startPointLongitude = this.ruleForm.startPoint.longitude
            this.ruleForm.startPointLatitude = this.ruleForm.startPoint.latitude
            let taskCode = this.ruleForm.taskCode
            if (!this.$route.params.id || (this.ruleForm.status === 500 && this.ruleForm.offerPriceNum === 0)) {
              this.ruleForm.taskCode = ''
              taskCode = await this.$http(URL.createTakePieTask, this.ruleForm)
            } else {
              await this.$http(URL.updateTakePieTask, this.ruleForm)
            }
            this.$message.success('操作成功')
            this.$refreshMainQueryTable()
            this.$router.push(`/ecms/take-car/main-detail/${taskCode}`)
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 清空表单数据
      resetForm (formName) {
        this.listData = []
        this.selectedRow = []
        this.isTwoWheels = false
        this.isRequired = true
        this.ruleForm = {
          takeType: '1',
          loadingTimeAt: '',
          carType: '',
          carLength: '',
          isTailboard: '1',
          isSmallCar: '1',
          isExpressway: '1',
          consumeTime: '',
          isGoBack: '1',
          isCarry: '1',
          postRequirements: '',
          startPointId: '',
          startPointName: '',
          startPointCode: '',
          startPointAddress: '',
          startPointLongitude: '',
          startPointLatitude: '',
          startPoint: null,
          carTypeObj: null
        }
        this.estimate = {
          goodsWeight: 0,
          goodsVolume: 0,
          waybillNum: 0,
          goodsNum: 0,
          estimateDistance: 0
        }
        this.fromRemotePlacesOption = []
        this.$refs[formName].resetFields()
      },
      // 增加运单信息
      handleAdd () {
        let param = {
          add: true,
          addWaybillCode: '',
          waybillCode: '',
          unloadingAddress: '',
          goodsName: '',
          taskCode: '',
          goodsNum: '',
          goodsWeight: '',
          type: '',
          avgCost: '',
          status: ''
        }
        this.listData.push(param)
      },
      // 新增运单行
      getwaybill (data) {
        this.listData.forEach((item, index, arr) => {
          if (item.add) {
            this.listData.splice(index, 1)
          }
        })
        this.listData = [...this.listData, ...data]
        this.prospect()
        this.getAllLand()
      },
      // 行删除
      rowDelete (index) {
        this.listData.splice(index, 1)
        this.prospect()
        this.getAllLand()
      },
      // 预估体积等
      prospect () {
        this.estimate.goodsWeight = 0
        this.estimate.goodsVolume = 0
        this.estimate.waybillNum = 0
        this.estimate.goodsNum = 0
        if (this.listData.length > 0) {
          this.listData.forEach((item, index, arr) => {
            if (item.goodsWeight) {
              this.estimate.goodsWeight += parseFloat(item.goodsWeight)
            }
            if (item.goodsVolume) {
              this.estimate.goodsVolume += parseFloat(item.goodsVolume)
            }
            if (item.waybillNum) {
              this.estimate.waybillNum += parseFloat(item.waybillNum)
            }
            if (item.goodsNumber) {
              this.estimate.goodsNum += parseFloat(item.goodsNumber)
            }
          })
          this.estimate.waybillNum = this.listData.length
        }
      },
      // 汇总所有点
      getAllLand () {
        let arr = []
        this.listData.forEach(item => {
          if (!item.add) {
            arr.push(item)
          }
        })
        if (!this.ruleForm.startPoint || arr.length === 0) {
          this.estimate.estimateDistance = 0
          return false
        }
        const milesArr = []
        milesArr[0] = this.ruleForm.startPoint
        milesArr.splice(1, 0, ...arr)
        this.getAllOrigin(milesArr)
        this.setSaveDisabled(true)
        setTimeout(() => {
          this.setSaveDisabled(false)
        }, 7000)
      },
      setSaveDisabled (data) {
        this.$emit('setSaveDisabled', data)
      },
      // 计算所有点坐标
      getAllOrigin (arr) {
        const originArr = []
        arr.forEach((item, index, arr) => {
          if (index < arr.length - 1) {
            const obj = {
              origin: `${item.longitude},${item.latitude}`,
              destination: `${arr[index + 1].longitude},${arr[index + 1].latitude}`
            }
            originArr.push(obj)
          }
        })
        this.getAllDistance(arr, originArr)
      },
      // 分组计算坐标距离
      getAllDistance (arr, originArr) {
        const length = originArr.length
        const promiseArr = []
        for (let i = 1; i <= length; i++) {
          promiseArr.push(this.$http(URL.getDistance, originArr[i - 1]))
        }
        Promise.all(promiseArr).then(result => {
          result.forEach((item, index) => {
            arr[index].nextPointDistance = parseInt(Math.round(parseInt(item) / 1000))
          })
          let totalMiles = 0
          // 计算总里程
          arr.forEach(item => {
            if (item.nextPointDistance) {
              totalMiles += item.nextPointDistance
            }
          })
          if (totalMiles) {
            this.estimate.estimateDistance = totalMiles
            this.setSaveDisabled(false)
          }
        })
      }
    }
  }
</script>

