<template>
  <div>
    <search-pager :option="option"
                  :tools="formTools"></search-pager>
    <kye-expand-page>
      <kye-tabs v-model="activeName"
                @tab-click="handleClick">
        <kye-tab-pane label="取/派任务"
                      name="first">
          <main-take-info-edit ref="mainTakeInfo"
                               :carLengthOption="carLengthOption"
                               :carTypeOption="carTypeOption"
                               @setSaveDisabled="setSaveDisabled"></main-take-info-edit>
        </kye-tab-pane>
        <kye-tab-pane label="干线任务"
                      name="second">
          <main-line-info-edit ref="mainLineInfo"
                               :carLengthOption="carLengthOption"
                               :carTypeOption="carTypeOption"
                               @setSaveDisabled="setSaveDisabled"></main-line-info-edit>
        </kye-tab-pane>
        <kye-tab-pane label="包车任务"
                      name="three">
          <main-line-info-edit ref="mainCharterInfo"
                               :carLengthOption="carLengthOption"
                               :carTypeOption="carTypeOption"
                               @setSaveDisabled="setSaveDisabled"></main-line-info-edit>
        </kye-tab-pane>
      </kye-tabs>
    </kye-expand-page>
  </div>

</template>
<script>
  import routeHook from 'public/mixins/route-hook'
  // 干线新增
  import mainLineInfoEdit from './main-line-info-edit'
  // 取派新增
  import mainTakeInfoEdit from './main-take-info-edit'
  import URL from '../takeCar.api'
  export default {
    mixins: [routeHook],
    components: {
      mainLineInfoEdit,
      mainTakeInfoEdit
    },
    data () {
      return {
        URL: URL,
        activeName: 'first',
        carLengthOption: [],
        carTypeOption: [],
        carTypeOptionBase: [],
        option: {
          back: '/ecms/take-car/list'
        },
        formTools: [
          {
            label: '保存',
            icon: 'save1',
            disabled: false,
            auth: this.activeName === 'first' ? URL.createTakePieTask : URL.saveTrunkTask,
            func: () => {
              this.SET_SAVE_HOOK_FLAG()
              if (this.activeName === 'first') {
                this.$refs.mainTakeInfo.createTakePieTask('mainTakeInfo')
              } else if (this.activeName === 'second') {
                this.$refs.mainLineInfo.submitForm('mainLineInfo')
              } else {
                this.$refs.mainCharterInfo.submitForm('mainLineInfo')
              }
            }
          },
          {
            auth: URL.searchTaskList,
            label: '取消',
            icon: 'cancel1',
            func: () => {
              this.BACK_HOOK_MODULE()
            }
          }]
      }
    },
    methods: {
      handleClick (tab) {
        if (tab.paneName === 'first') {
          this.carTypeOption = this.carTypeOptionBase
        } else {
          this.carTypeOption = this.carTypeOptionBase.filter(item => {
            return ['面包车', '厢式车'].indexOf(item.dictValue) > -1
          })
        }
      },
      // 获取车型
      async getCarType () {
        const param = {}
        const carTypeOption = await this.$http(URL.getCarType, param) || []
        this.carTypeOptionBase = carTypeOption
        this.carTypeOption = carTypeOption
      },
      // 获取车长
      async getCarLength () {
        const param = {}
        this.carLengthOption = await this.$http(URL.getCarLength, param)
      },
      // 避免距离没有返回保存
      setSaveDisabled (data) {
        this.formTools[0].disabled = data
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (vm.$route.meta.layout) return
        vm.getCarType()
        vm.getCarLength()
        vm.activeName = 'first'
        vm.$nextTick(() => {
          vm.$refs.mainTakeInfo.resetForm('mainTakeInfo')
          vm.$refs.mainLineInfo.resetForm('mainLineInfo')
          vm.$refs.mainCharterInfo.resetForm('mainLineInfo')
          vm.$refs.mainLineInfo.ruleForm.takeType = 2
          vm.$refs.mainCharterInfo.ruleForm.takeType = 1
        })
      })
    }
  }
</script>

