<template>
  <div>
    <div class="kye-block-title">要车信息
    </div>
    <kye-form :model="ruleForm"
              ref="ruleForm">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="要车编号">
            <kye-field>
              {{ruleForm.taskCode}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="要车类型">
            <kye-field>
              取派
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用车时间">
            <kye-field>
              {{ruleForm.loadingTimeAt}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车型">
            <kye-field>
              {{ruleForm.carTypeName}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="需求车长">
            <kye-field>
              {{ruleForm.carLength}}米
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="尾板需求">
            <kye-field>
              {{ruleForm.isTailboard |lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="小推车否">
            <kye-field>
              {{ruleForm.isSmallCar|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="走高速否">
            <kye-field>
              {{ruleForm.isExpressway|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="完成时效">
            <kye-field>
              {{ruleForm.consumeTime}}小时
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否返仓">
            <kye-field>
              {{ruleForm.isGoBack|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否搬运">
            <kye-field>
              {{ruleForm.isCarry|lookup('ecs_common_yes_no')}}
            </kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="上岗说明">
            <kye-field>
              {{ruleForm.postRequirements}}
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="8">
          <kye-form-item label="拿货地">
            <kye-field>
              {{ruleForm.startPoint}}
            </kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  export default {
    props: {
      ruleForm: {
        type: Object,
        default () {
          return {}
        }
      }
    }
  }
</script>

