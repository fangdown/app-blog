<template>
  <div>
    <div class="kye-block-title">{{viewStatus===2||viewStatus===6?'中标信息':'报价信息'}}
    </div>
    <!-- 已报价 报价中 -->
    <div class="box"
         v-if="viewStatus===1"
         :key="'bid-list'+taskCode">
      <div class="box-head">
        <bid-time :isActive="true"
                  :effectDurationTime="effectDurationTime"
                  :key="taskCode"></bid-time>
        <kye-button type="text"
                    :auth="URL.findTaskInfo"
                    @click="refreshDetails">
          <i class="iconfont icon-reset"></i>刷新
        </kye-button>
      </div>
      <bid-list :bidListData="bidListData"
                :isTakeSend="isTakeSend"
                :loading="loading"
                :takeType="takeType"
                :isShowOperator="isShowOperator"
                :isOffering="true"
                :bidLoading="bidLoading"
                @refreshDetails="refreshDetails"
                :key="taskCode"></bid-list>
    </div>
    <!-- 已报价-已中标 -->
    <div class="box"
         v-if="viewStatus===2||viewStatus===6"
         :key="'bid-list'+taskCode">
      <biding :bidingData="bidingData"
              @refreshDetails="refreshDetails"
              :viewStatus="viewStatus"
              key="biding22"></biding>
      <div class="kye-block-title ecs-common-mt12">报价记录</div>
      <bid-list :bidListData="bidListData"
                :loading="loading"
                :takeType="takeType"
                :isShowOperator="isShowOperator"
                :key="taskCode"></bid-list>
    </div>
    <!-- 已报价且取消 -->
    <div class="box"
         v-if="viewStatus===3"
         :key="'bid-list'+taskCode">
      <div class="box-head">
        <bid-time :isActive="false"
                  :effectDurationTime="effectDurationTime"
                  :key="taskCode"></bid-time>
        <span class="box-text-red">取消原因：{{cancelReason}}</span>
      </div>
      <bid-list :bidListData="bidListData"
                :loading="loading"
                :takeType="takeType"
                @refreshDetails="refreshDetails"
                :isShowOperator="isShowOperator"
                :key="taskCode"></bid-list>
    </div>
    <!-- 无人报价 -->
    <div class="box"
         v-if="viewStatus===4 || viewStatus===5 "
         :key="'bid-list'+taskCode">
      <div class="box-head">
        <bid-time :isActive="viewStatus === 4"
                  :effectDurationTime="effectDurationTime"
                  :key="taskCode"></bid-time>
        <span class="box-text-red"
              v-if="viewStatus===5&&cancelReason">取消原因：{{cancelReason}}</span>
        <kye-button type="text"
                    v-if="viewStatus===4"
                    :auth="URL.findTaskInfo"
                    @click="refreshDetails">
          <i class="iconfont icon-reset"></i>刷新</kye-button>
      </div>
      <bid-list :bidListData="[]"
                :loading="loading"
                :takeType="takeType"
                :bidLoading="bidLoading"
                :isShowOperator="isShowOperator"
                :key="taskCode"></bid-list>
    </div>
  </div>
</template>
<script>
  // 报价信息
  import bidList from './bid-list.vue'
  // 报价记录
  import biding from './biding.vue'
  // 报价时间
  import bidTime from './bid-time.vue'
  import URL from '../../takeCar.api'

  export default {
    components: {
      bidList,
      biding,
      bidTime
    },
    props: {
      viewStatus: {
        type: Number,
        default: 0
      },
      isTakeSend: {
        type: Boolean,
        default: false
      },
      offerPriceNum: {
        type: Number,
        default: 0
      },
      isStopPrice: {
        type: Number,
        default: 2
      },
      effectDurationTime: {
        type: String,
        default: ''
      },
      cancelReason: {
        type: String,
        default: ''
      },
      taskCode: {
        type: String,
        default: ''
      },
      bidListData: {
        type: Array,
        default: () => {
          return []
        }
      },
      bidingData: {
        type: Array,
        default: () => {
          return []
        }
      },
      isShowOperator: {
        type: Boolean,
        default: false
      },
      takeType: {
        type: Number,
        default: 0
      },
      bidLoading: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        URL: URL,
        loading: false,
        isActive: false, // 是否活跃
        cancelVisble: false, // 注明原因弹窗
        remark: '', // 备注
      }
    },
    methods: {
      // 确认要车后刷新详情信息
      refreshDetails () {
        this.$emit('refreshDetails')
      }
    },
  }
</script>

<style scoped>
  .box {
    width: 100%;
  }
  .box-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 28px;
    line-height: 28px;
    margin-top: -10px;
  }
  .box-text-red {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #ff5555;
  }
  .ecs-common-mt12 {
    margin-top: 12px;
  }
</style>


