// 取派
export const takeAndSendObj = {
  '1': '干线',
  '2': '取件',
  '3': '派送'
}
// 取派
export const takeAndSendFullNameObj = {
  '200': '干线',
  '300': '取/派'
}

// 要车状态
export const takeCarStautsObj = {
  '100': '未要车',
  '200': '报价中',
  '300': '已要车',
  '400': '已结束',
  '500': '已取消'
}

// 供应商类型
export const driverTypeObj = {
  '1': '非合同个人',
  '2': '非合同企业',
  '3': '合同个体',
  '4': '合同企业',
  '5': '第三方平台',
}

// 运单状态
export const orderStatusObj = {
  '1': '未装车',
  '2': '进行中',
  '3': '完成'
}
// 干线要车类型
export const lineTakeType = {
  '1': '包车',
  '2': '干线',
  '3': '支线',
}

// 是、否
export const isTrue = {
  '1': '是',
  '2': '否',
}
// 调度标识
export const isDispatch = {
  '1': '已调度',
  '2': '未调度',
}

export default {
  takeAndSendObj,
  takeAndSendFullNameObj,
  takeCarStautsObj,
  driverTypeObj,
  orderStatusObj,
  lineTakeType,
  isDispatch
}
