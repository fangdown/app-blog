<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="formTools"
                  :key="taskCode+status"></search-pager>
    <kye-expand-page v-loading="loading">
      <!-- 取派基本信息 -->
      <main-take-info-detail v-if="takeDetailData!==null"
                             :ruleForm="takeDetailData"
                             :key="'main-take-info-detail'+taskCode"></main-take-info-detail>
      <!-- 取派详情 承运信息 -->
      <carrier-info v-if="tableData!==null"
                    :listData="tableData"
                    :estimate="estimate"
                    :isDisabled="true"
                    :taskCode="taskCode"
                    :status="status"
                    :key="'carrier-info'+taskCode"></carrier-info>
      <!-- 干线 -->
      <main-line-info-detail v-if="lineDetailData!==null"
                             :ruleForm="lineDetailData"
                             :key="'main-line-info-detail'+taskCode">
      </main-line-info-detail>
      <!-- 干线实际承运信息 -->
      <div v-if="carrierData"
           :key="'carrier-info'+taskCode"
           class="carrier-info">
        <div class="kye-block-title">
          货物信息</div>
        <table-list :column="column"
                    :data="carrierData"
                    :options="tableOption"
                    :key="'carrier-table'+taskCode"></table-list>
        <div style="margin-top:10px"
             v-if="page.pageTotal > 1">
          <kye-pagination layout="sizes,total,prev,pager,next"
                          background
                          :total="page.pageTotal"
                          :page-sizes="pageSizes"
                          :current-page="page.currentPage"
                          :page-size.sync="page.pageSize"
                          @current-change="handleCurrentChange"
                          @size-change="handleSizeChange">
          </kye-pagination>
        </div>
      </div>
      <bid-content-edit :viewStatus="viewStatus"
                        v-if="status!==0&& viewStatus!==0"
                        :offerPriceNum="offerPriceNum"
                        :isStopPrice="isStopPrice"
                        :effectDurationTime="effectDurationTime"
                        :cancelReason="cancelReason"
                        :taskCode="taskCode"
                        :takeType="takeType"
                        :bidListData="bidListData"
                        :bidingData="bidingData"
                        :isShowOperator="isShowOperator"
                        :bidLoading="bidLoading"
                        @refreshDetails="getFormInfo"></bid-content-edit>
      <kye-dialog :title="dialogTitle"
                  :visible.sync="cancelVisble"
                  width="500px"
                  center>
        <div class="content">
          <p class="wbyl-mb20">{{dialogTips}}</p>
          <p>
            <kye-input type="textarea"
                       :rows="5"
                       :placeholder="dialogPlaceholder"
                       v-model="remark">
            </kye-input>
          </p>
        </div>
        <span slot="footer"
              class="dialog-footer">
          <kye-button type="primary"
                      hotkey="ctrl+s"
                      @click="doCancelTask">保存(S)</kye-button>
          <kye-button @click="closeCancelTask">取消</kye-button>
        </span>
      </kye-dialog>
    </kye-expand-page>
  </div>
</template>
<script>
  import moment from 'moment'
  import { formatTime } from '../../../utils/format'
  // 取派详情
  import mainTakeInfoDetail from './main-take-info-detail'
  // 报价信息
  import bidContentEdit from './detail/bid-content-edit.vue'
  // 干线详情
  import mainLineInfoDetail from './main-line-info-detail.vue'
  // 取派承运信息
  import carrierInfo from './carrier-info'
  import URL from '../takeCar.api'
  import { money } from 'public/utils/filter.js'
  let durationInterval = null
  export default {
    components: {
      mainTakeInfoDetail,
      bidContentEdit,
      mainLineInfoDetail,
      carrierInfo
    },
    data () {
      return {
        URL: URL,
        option: {
          back: '/ecms/take-car/list',
          method: URL.searchTaskList,
          searchCode: 'ecs_yc_task_list_field',
          idKey: 'taskCode',
        },
        lineDetailData: null, // 干线详情数据
        carrierData: null, // 实际承运信息
        takeDetailData: null, // 取派详情数据
        tableData: null, // 取派承运信息
        carLengthOption: [],
        carTypeOption: [],
        estimate: { // 取派预估数据
          goodsWeight: 0,
          goodsVolume: 0,
          waybillNum: 0,
          goodsNum: 0,
          estimateDistance: 0
        },
        taskCode: this.$route.params.id, // 任务编码
        offerPriceNum: 0, // 报价人数
        status: 0, // 任务状态
        orderStatus: 0, // orderStatus为0未添加车辆信息  1已添加车辆信息 2已出车
        bidListData: [], // 报价记录
        bidLoading: false,
        bidingData: [], // 报价信息
        loading: false,
        takeType: '', // 200 干线 300取派、包车 由于包车逻辑、调用接口跟干线一样将包车takeType设为200
        isStopPrice: 2, // 是否已停止竞价 1，否， 2 是
        publishTimeAt: 0, // 发布时间
        cancelReason: '', // 取消原因
        dialogType: 1, // 弹窗类型
        dialogTitle: '', // 弹窗标题
        dialogTips: '', // 弹窗说明
        dialogPlaceholder: '', // 弹窗placeholder
        effectDurationTime: '', // 报价时长
        isShowOperator: false, // 是否显示操作栏
        cancelVisble: false, // 注明原因弹窗
        remark: '', // 备注
        page: {
          currentPage: 1,
          pageSize: 50,
          pageTotal: 0
        },
        pageSizes: [50],
        column: [
          {
            key: 'waybillCode',
            label: '运单号',
            show: true,
            width: '90px'
          },
          {
            key: 'goodsWeight',
            label: '运单实重（kg）',
            show: true,
            width: '100px'
          },
          {
            key: 'goodsVolume',
            label: '运单体积（m³）',
            show: true,
            width: '100px'
          },
          {
            key: 'subWaybillCode',
            label: '子件编号',
            show: true,
            width: '150px'
          },
          {
            key: 'loadingPointName',
            label: '装货地',
            show: true,
            width: '100px'
          },
          {
            key: 'loadingTimeAt',
            label: '装货时间',
            show: true,
            width: '120px',
            filter: 'time'
          },
          {
            key: 'loadingOperater',
            label: '装货扫描人',
            show: true,
            width: '80px'
          },
          {
            key: 'unloadingPointName',
            label: '卸货地',
            show: true,
            width: '100px'
          },
          {
            key: 'unloadingTimeAt',
            label: '卸货时间',
            show: true,
            width: '120px',
            filter: 'time'
          },
          {
            key: 'unloadingOperater',
            label: '卸货扫描人',
            show: true,
            width: '80px'
          },
          {
            key: 'goodsNum',
            label: '件数',
            show: true,
            width: '60px'
          }
        ],
        tableOption: {
          moduleCode: 'ecs_yc',
          stripe: true
        },
      }
    },
    computed: {
      // 任务状态 100:待要车,200:报价中,300:已要车,400:要车完成,500:要车取消
      // 0:未要车,1:已报价, 2:已报价且中标 ,3:已报价且取消, 4:无人报价未结束, 5:无人报价且结束,
      formTools: function () {
        let tool = []
        if (this.offerPriceNum !== 0) {
          if (this.status === 200) {
            tool = [{
              label: '停止报价',
              auth: URL.stopTaskQuotePrice,
              disabled: this.isStopPrice === 1,
              icon: 'ecs-tingzhijingjia',
              func: () => {
                this.stopBid()
              }
            },
            {
              label: '取消报价',
              auth: URL.cancelTaskbidding,
              icon: 'cancel1',
              func: () => {
                this.openCancelTask(1)
              }
            }]
            return tool
          } else if (this.status === 300) {
            if (this.orderStatus === 2) {
              tool = [
                {
                  label: '强制结束',
                  auth: URL.forceCompleteTask,
                  icon: 'cancel1',
                  func: () => {
                    this.openCancelTask(3)
                  }
                }
              ]
            }
            tool.push({
              label: '取消用车',
              auth: URL.cancelTaskOrder,
              icon: 'cancel1',
              func: () => {
                this.openCancelTask(2)
              }
            })
            return tool
          }
        } else {
          if (this.status === 100) {
            tool = [{
              label: '修改',
              icon: 'pen',
              auth: URL.findTaskInfo,
              func: () => {
                this.toEdit()
              }
            }]
            return tool
          } else if (this.status === 500) {
            tool = [{
              label: '重新发布',
              auth: URL.findTaskInfo,
              icon: 'ecs-zhongxinfabu',
              func: () => {
                this.toEdit()
              }
            }]
            return tool
          } else {
            tool = [{
              label: '取消报价',
              icon: 'cancel1',
              auth: URL.cancelTaskQuotePrice,
              func: () => {
                this.cancelTask()
              }
            }]
            return tool
          }
        }
      },
      viewStatus: function () {
        if (this.status === 100) {
          return 0
        }
        if (this.offerPriceNum !== 0) {
          if (this.status === 200) {
            return 1
          } else if (this.status === 300) {
            return 2
          } else if (this.status === 500) {
            return 3
          } else if (this.status === 400) {
            return 6
          }
        } else {
          if (this.status === 500) {
            return 5
          } else {
            return 4
          }
        }
      }
    },
    methods: {
      // 状态变化后重新加载表单数据
      async getFormInfo () {
        const data = await this.$http(URL.findTaskInfo, { taskCode: this.taskCode })
        let detailData = null
        if (this.takeType === 200) {
          detailData = data.trunkTaskInfoRVo
        } else {
          detailData = data.takePieTaskRVo
        }
        this.orderStatus = data.orderStatus
        this.status = detailData.status
        this.offerPriceNum = detailData.offerPriceNum
        this.isStopPrice = detailData.isStopPrice
        this.cancelReason = detailData.cancelReason
        this.loadOfferList()
      },
      /**
       * 设置详情数据
       * @param data: 取派、干线数据
       * @param takeType: 取派干线类型
       */
      setDetailData (data, takeType) {
        if (takeType === 200) {
          this.takeDetailData = null
          this.tableData = null
          data.loadingTimeAt = formatTime(data.loadingTimeAt, 'M')
          data.backTimeAt = formatTime(data.backTimeAt, 'M')
          data.landArr = []
          data.trunkTaskStopPointEntities.forEach(item => {
            if (item.type === 1) {
              data.startPoint = item.nodeName
            } else if (item.type === 2) {
              data.endPoint = item.nodeName
            } else {
              data.landArr.push(item.nodeName)
            }
          })
          this.lineDetailData = data
        } else {
          this.carrierData = null
          this.lineDetailData = null
          data.startPoint = data.startPointName
          data.loadingTimeAt = formatTime(data.loadingTimeAt, 'M')
          this.takeDetailData = data
          for (let key in this.estimate) {
            this.estimate[key] = data[key]
          }
        }
        this.status = data.status
        this.offerPriceNum = data.offerPriceNum
        this.isStopPrice = data.isStopPrice
        this.cancelReason = data.cancelReason
        if ([200, 500].indexOf(data.status) > -1) {
          this.publishTimeAt = data.publishTimeAt
          if (data.effectDurationTime < 10) {
            data.effectDurationTime = `0${data.effectDurationTime}`
          }
          this.effectDurationTime = `00:${data.effectDurationTime}:00`
        }
        // 报价中
        if ([200].indexOf(data.status) > -1) {
          // 因后台定时任务原因，存在超过60分钟仍是报价中状态的单子，兼容处理
          if (data.effectDurationTime >= 60) {
            this.status = 500
            return false
          }
          this.getDurationTime()
        }
        if (this.status === 100 || this.status === 500) {
          this.getCarType()
          this.getCarLength()
        }
      },
      // 干线实际承运信息
      async findTrunkWaybillList () {
        const page = {
          taskCode: this.taskCode,
          page: this.page.currentPage,
          size: this.page.pageSize
        }
        this.carrierData = null
        const data = await this.$http(URL.findTrunkWaybillList, page)
        if (data.rows.length > 0) {
          this.page.pageTotal = data.pageTotal
          this.carrierData = data.rows
        }
      },
      // 取派实际承运信息
      async getWayBillList () {
        const param = { taskCode: this.taskCode }
        const data = await this.$http(URL.findTaskWaybillListByDispatch, param)
        if (data.length > 0) {
          data.forEach(element => {
            element.avgCost = money(element.avgCost)
          })
        }
        this.tableData = data
      },
      handleSizeChange (val) {
        this.page.pageSize = val
        this.findTrunkWaybillList()
      },
      handleCurrentChange (val) {
        this.page.currentPage = val
        this.findTrunkWaybillList()
      },
      // 计算报价时长
      getDurationTime () {
        // 定时器
        durationInterval = setInterval(() => {
          const publishTime = moment(this.publishTimeAt)
          // const publishTime = moment(+new Date('2019-01-26 09:46:00'))
          const now = moment(Date.now())
          const du = moment.duration(now - publishTime, 'ms')
          // 时差大于60分钟，手动改状态，停止计时器，否则获取倒计时
          if (du >= 3600000) {
            this.status = 500
            this.effectDurationTime = '00:60:00'
            clearInterval(durationInterval)
          } else {
            const mins = du.get('minutes') < 10 ? `0${du.get('minutes')}` : `${du.get('minutes')}`
            const ss = du.get('seconds') < 10 ? `0${du.get('seconds')}` : `${du.get('seconds')}`
            const effectDurationTime = `00:${mins}:${ss}`
            this.effectDurationTime = effectDurationTime
          }
        }, 1000)
      },
      // 获取详情
      async getDetail (id = this.$route.params.id) {
        this.taskCode = id
        this.loading = true
        clearInterval(durationInterval)
        const detailData = await this.$http(URL.findTaskInfo, { taskCode: id })
        if (detailData.status === 300) {
          this.getWayBillList()
          this.setDetailData(detailData.takePieTaskRVo, 300)
        } else {
          this.findTrunkWaybillList()
          this.setDetailData(detailData.trunkTaskInfoRVo, 200)
        }
        this.takeType = detailData.status === 300 ? 300 : 200
        this.orderStatus = detailData.orderStatus
        this.bidListData = []
        this.bidingData = []
        this.loading = false
        this.loadOfferList()
      },
      // 加载报价列表和中标信息
      loadOfferList () {
        const arr = [1, 2, 3, 6]
        arr.indexOf(this.viewStatus) > -1 && this.findTaskDriverOfferBidingList()
        if (this.viewStatus === 2 || this.viewStatus === 6) {
          this.findTaskOrderByWinBid()
        }
      },
      // 查询中标信息
      async findTaskOrderByWinBid () {
        const data = await this.$http(URL.findTaskOrderByWinBid, { taskCode: this.taskCode })
        this.bidingData = [data]
      },
      // 查询报价列表
      async findTaskDriverOfferBidingList () {
        this.bidLoading = true
        // 详情分页时taskCode变化时重新请求接口,可能上一条数据haveContract为true
        const param = { taskCode: this.taskCode }
        let data = {}
        data = await this.$http(URL.findTaskDriverOfferBidingList, param)
        this.bidLoading = false
        if (data.priceList) {
          this.isShowOperator = false
          data.priceList.forEach(item => {
            if (item.driverType === 3 || item.driverType === 4 || this.viewStatus === 1) {
              this.isShowOperator = true
              return false
            }
          })
          this.bidListData = data.priceList
        }
      },
      // 停止竞价
      async stopBid () {
        this.$confirm('停止报价后，新司机将不再参与报价，您只能从当前报价中选择司机，您真的要停止吗？', '确定要停止报价吗', {
          distinguishCancelAndClose: true,
          confirmButtonText: '保存',
          cancelButtonText: '取消'

        }).then(async () => {
          await this.$http(URL.stopTaskQuotePrice, { taskCode: this.taskCode })
          this.getFormInfo()
        })
      },
      // 取消竞价
      async cancelTask () {
        const successFunc = () => {
          this.$message.success('取消报价成功！')
          this.getFormInfo()
          clearInterval(durationInterval)
          this.$refreshMainQueryTable()
        }
        if (this.offerPriceNum === 0) {
          this.$confirm('确认取消报价吗？', '提示').then(async () => {
            const data = await this.$http(URL.cancelTaskQuotePrice, { taskCode: this.taskCode })
            if (data) {
              successFunc()
            }
          }).catch(() => {
            console.log('取消报价')
          })
        }
        if (this.offerPriceNum !== 0) {
          const data = await this.$http(URL.cancelTaskbidding, { taskCode: this.taskCode, reason: this.remark })
          if (data) {
            successFunc()
          }
        }
      },
      // 取消弹窗
      closeCancelTask () {
        this.cancelVisble = false
        this.remark = ''
      },
      // 弹窗显示
      // type: 1:取消报价，2：取消用车 3： 强制结束
      openCancelTask (type = 1) {
        this.dialogType = type
        if (type === 1) {
          this.dialogTitle = '原因'
          this.dialogTips = '原因'
          this.dialogPlaceholder = '请填写原因，并注明取消责任'
        } else if (type === 2) {
          this.dialogTitle = '原因'
          this.dialogTips = '原因'
          this.dialogPlaceholder = '请填写原因，并注明取消责任'
        } else if (type === 3) {
          this.dialogTitle = '提示'
          this.dialogTips = '选择保存会导致任务立即变为已完成状态，请谨慎操作！'
          this.dialogPlaceholder = '请填写强制结束原因'
        }
        this.cancelVisble = true
      },
      // 确认弹窗动作
      doCancelTask () {
        if (!this.remark) {
          this.$message({
            message: '请填写原因',
            type: 'warning'
          })
          return false
        }
        if (this.dialogType === 1) {
          this.cancelTask()
        } else if (this.dialogType === 2) {
          this.cancelTaskOrder()
        } else if (this.dialogType === 3) {
          this.finishTask()
        }
        this.closeCancelTask()
      },
      // 取消用车
      async cancelTaskOrder () {
        await this.$http(URL.cancelTaskOrder, { taskCode: this.taskCode, remark: this.remark })
        this.$message({
          message: '取消成功',
          type: 'success'
        })
        this.getFormInfo()
        this.findTrunkWaybillList()
        this.$refreshMainQueryTable()
      },
      // 强制结束
      async finishTask () {
        await this.$http(URL.forceCompleteTask, { taskCode: this.taskCode, remark: this.remark })
        this.$message({
          message: '操作成功',
          type: 'success'
        })
        this.getFormInfo()
        this.findTrunkWaybillList()
        this.$refreshMainQueryTable()
      },
      // 获取车型
      async getCarType () {
        const param = {}
        const carTypeOption = await this.$http(URL.getCarType, param) || []
        if (this.takeType === 200) {
          this.carTypeOption = carTypeOption.filter(item => {
            return ['面包车', '厢式车'].indexOf(item.dictValue) > -1
          })
        } else {
          this.carTypeOption = carTypeOption
        }
      },
      // 获取车长
      async getCarLength () {
        const param = {}
        this.carLengthOption = await this.$http(URL.getCarLength, param)
      },
      // 跳转到编辑页
      toEdit () {
        this.$router.push(`/ecms/take-car/main-edit/${this.taskCode}`)
      }
    },
    beforeRouteEnter (to, from, next) {
      next((vm) => {
        if (!vm.$route.meta.layout) {
          vm.publishTimeAt = ''
          vm.taskCode = vm.$route.params.id
          vm.getDetail(vm.$route.params.id)
        }
      })
    },
    async beforeRouteUpdate (to, from, next) {
      this.publishTimeAt = ''
      this.taskCode = to.params.id
      this.getDetail(to.params.id)
      next()
    },
  }
</script>
<style lang="scss" scoped>
  .carrier-info {
    margin-bottom: 12px;
  }
</style>
