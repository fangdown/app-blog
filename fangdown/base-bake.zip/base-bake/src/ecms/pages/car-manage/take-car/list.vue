<template>
  <div class="container">
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :form-model="formModel"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
    <kye-dialog title="添加车辆"
                key="dialogFormVisible"
                :visible.sync="dialogFormVisible"
                width="600px"
                append-to-body
                @close="cancelBidCar('ruleForm')">
      <kye-form :model="ruleForm"
                size="mini"
                :rules="rules"
                ref="ruleForm"
                label-width="auto">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="司机姓名"
                           prop="carrierDriverName"
                           :label-width="formLabelWidth">
              <kye-input v-model="ruleForm.carrierDriverName"
                         autocomplete="off"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="司机电话"
                           prop="carrierDriverPhone"
                           :label-width="formLabelWidth">
              <kye-input v-model="ruleForm.carrierDriverPhone"
                         autocomplete="off"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="司机车牌"
                           prop="carPlate"
                           :label-width="formLabelWidth">
              <kye-input v-model="ruleForm.carPlate"
                         autocomplete="off"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    :auth="URL.assignCarrierDriver"
                    @click="saveBidCar('ruleForm')">保存(S)</kye-button>
        <kye-button @click="cancelBidCar('ruleForm')">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from './takeCar.api'
  import rules from 'public/utils/rules'

  export default {
    data () {
      // 填充车辆信息手机号校验
      var checkPhone = (rule, value, callback) => {
        const phone = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
        if (!phone.test(value)) {
          callback(new Error('请填写正确手机号'))
        } else {
          callback()
        }
      }
      return {
        URL: URL,
        dialogFormVisible: false,
        formLabelWidth: '80px',
        codeType: 'taskCode', // 默认查询编码
        ruleForm: { // 添加车辆信息默认值
          taskCode: '',
          driverId: '',
          carrierDriverName: '',
          carrierDriverPhone: '',
          carPlate: ''
        },
        selectedRow: [], // 选中数据
        rules: {
          carrierDriverName: rules.str('请输入司机姓名', true, 'blur'),
          carrierDriverPhone: [{ required: 'required', validator: checkPhone, trigger: 'blur' }],
          carPlate: rules.str('请输入车牌号码', true, 'blur')
        },
        formTools: [
          {
            label: '刷新',
            auth: URL.searchTaskList,
            icon: 'reset',
            func: () => {
              this.$refs.queryTable.loadData()
            }
          },
          {
            auth: URL.saveTrunkTask || URL.createTakePieTask,
            label: '新增',
            hotkey: 'ctrl+o',
            icon: 'plus',
            func: () => {
              this.handleNew()
            }
          },
          {
            label: '发布要车',
            auth: URL.publishCarNeed,
            icon: 'ecs-fabuyaoche',
            disabled: () => this.selectedRow.length === 0 || this.selectedRow.filter(item => item.status !== 100).length > 0,
            func: () => {
              this.batchPublic()
            }
          },
          {
            label: '删除',
            icon: 'delete',
            hotkey: 'ctrl+d',
            auth: URL.deleteTaskQuotePrice,
            disabled: () => this.selectedRow.length === 0 || this.selectedRow.filter(item => item.status !== 100).length > 0,
            func: () => {
              this.handleDelete()
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          },
        ],
        // 通用查询
        generic: {
          method: URL.searchTaskList,
          searchCode: 'ecs_yc_basic_search'
        },
        option: {
          module: true,
          searchCode: 'ecs_yc_task_list_search_define',
          // 日期类型
          codeType: {
            change: ({ key, value, model }) => {
              this.codeType = key
            }
          },
        },
        tools: [
        ],
        // 用车时间处理
        formModel: {
          loadingTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
        },
        tables: [
          {
            searchCode: 'ecs_yc_task_list_field',
            url: { method: URL.searchTaskList },
            defaultSort: {
              // 通用查询对应字段的 propertyName, columnName 的值
              keys: ['loadingTime', 'loading_time'],
              prop: 'loadingTime', // 自定义列的 key
              order: 'ascending' // 默认排序 ascending:升序，descending:降序
            },
            option: {
              load: false, // 是否自动加载数据，默认 true
              type: 'selection',
              idKey: 'taskCode',
              moduleCode: 'ecs_yc',
              detailAuth: URL.findTaskInfo,
              rowDblClick: this.toDetail,
              // 将搜索表单参数赋值给请求中去，时间转时间戳
              beforeFormSubmit: (data, model) => {
                let isEmpty = true // 是否有条件
                delete data.startLoadingTime
                delete data.endLoadingTime
                delete data.taskCode
                delete data.waybillCode
                delete data.orderNumber
                const obj = {}
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'loadingTime') {
                      if (model.loadingTime && model.loadingTime.length === 2) {
                        isEmpty = false
                        const startLoadingTime = +new Date(model.loadingTime[0] + ' 00:00:00')
                        const endLoadingTime = +new Date(model.loadingTime[1] + ' 23:59:59')
                        Object.assign(obj, {
                          startLoadingTime,
                          endLoadingTime
                        })
                      }
                    } else if (['taskCode', 'waybillCode', 'orderNumber'].indexOf(key) > -1) {
                      isEmpty = false
                      if (this.codeType === key) {
                        obj[key] = model[key]
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
              selectionChange: (rows) => {
                this.selectedRow = rows
              },
            },
            operation: {
              label: '操作',
              fixed: 'left',
              width: '60px',
              options: row => {
                if (row.status === 100) {
                  return [{
                    btnType: 'link',
                    label: '发布要车',
                    auth: URL.publishCarNeed,
                    func: row => {
                      this.singlePublic([row.id])
                    }
                  }]
                } else if (row.status === 200 && row.offerPriceNum === 0) {
                  return [{
                    type: 'button',
                    label: '取消报价',
                    auth: URL.cancelTaskQuotePrice,
                    func: row => {
                      this.cancelBid(row)
                    }
                  }]
                } else if (row.status === 200 && row.offerPriceNum !== 0) {
                  let authUrl = ''
                  if (row.type === 300) {
                    authUrl = URL.confirmCar
                  } else {
                    authUrl = URL.affirmTrunkTask
                  }
                  return [{
                    type: 'button',
                    label: '确认要车',
                    auth: authUrl,
                    func: row => {
                      this.toDetail(row)
                    }
                  }]
                } else if (row.status === 300 && [3, 4].indexOf(row.driverType) > -1 && (row.orderStatus === '0' || row.orderStatus === '1')) {
                  // status 300为已要车正常是查看详情，除了合同已要车后添加车辆详情，driverType 3、4为合同； orderStatus为0未添加车辆信息  1已添加车辆信息 2已出车
                  return [{
                    type: 'button',
                    label: '添加车辆',
                    auth: URL.assignCarrierDriver,
                    func: row => {
                      this.addCar(row)
                    }
                  }]
                } else if (row.status === 300 && [3, 4].indexOf(row.driverType) > -1 && row.orderStatus !== '0' && row.orderStatus !== '1') {
                  return [{
                    type: 'button',
                    label: '查看详情',
                    auth: URL.findTaskInfo,
                    func: row => {
                      this.toDetail(row)
                    }
                  }]
                } else if (row.status === 300 && [3, 4].indexOf(row.driverType) === -1) {
                  return [{
                    type: 'button',
                    label: '查看详情',
                    auth: URL.findTaskInfo,
                    func: row => {
                      this.toDetail(row)
                    }
                  }]
                } else if ((row.status === 500 || row.status === 400) && row.offerPriceNum === 0) {
                  return [{
                    type: 'button',
                    label: '重新要车',
                    auth: URL.findTaskInfo,
                    func: row => {
                      this.afreshCar(row)
                    }
                  }]
                } else {
                  return [{
                    type: 'button',
                    label: '查看详情',
                    auth: URL.findTaskInfo,
                    func: row => {
                      this.toDetail(row)
                    }
                  }]
                }
              }
            },
            // 表单数据处理
            formatter: {
              offerPriceNum: (row, column, val) => {
                // 未发布要车要车人为‘-’
                if (row.status === 100) {
                  return '-'
                } else {
                  return row.offerPriceNum
                }
              },
              effectDurationTime: (row, column, val) => {
                // 未发布要车报价时长为‘-’
                if (row.status === 100) {
                  return '-'
                } else {
                  return row.effectDurationTime
                }
              },
            },
            // 为报价中 报价人、报价时间变红
            buttonOptions: {
              'offerPriceNum': {
                type: 'link',
                color: row => {
                  if (row.status === 200) {
                    return '#ff5555'
                  }
                },
                func: (row) => {
                  this.toDetail(row)
                }
              },
              'effectDurationTime': {
                type: 'link',
                color: row => {
                  if (row.status === 200) {
                    return '#ff5555'
                  }
                },
                func: (row) => {
                  this.toDetail(row)
                }
              }
            }
          }
        ],
      }
    },
    methods: {
      // 发布操作
      async doPublic (taskIds) {
        if (!taskIds) return
        this.$confirm('确认发布选中记录？', '提示').then(async () => {
          if (!Array.isArray(taskIds)) return
          const data = await this.$http(URL.publishCarNeed, { taskIds: taskIds.join(',') })
          if (data.length === 0) {
            this.$message.success('发布成功')
            this.$refreshMainQueryTable()
          } else {
            this.$alert('要车时间必须大于当前时间', '温馨提示')
          }
        }).catch(() => {
          console.log('取消发布')
        })
      },
      // 删除
      async handleDelete () {
        const ids = this.checkSelectIds()
        this.$confirm('确定删除选中记录？', '提示').then(async () => {
          if (!Array.isArray(ids)) return
          await this.$http(URL.deleteTaskQuotePrice, { ids: JSON.stringify(ids) })
          this.$message.success('删除成功')
          this.$refreshMainQueryTable()
        }).catch(() => {
          console.log('取消删除')
        })
      },
      // 检查选中ids
      checkSelectIds () {
        let selectArr = []
        selectArr = this.selectedRow && this.selectedRow.filter(item => item.status === 100)
        selectArr = selectArr.map(item => item.id)
        return selectArr || []
      },
      // 新增
      handleNew () {
        this.$router.push('/ecms/take-car/new')
      },
      // 批量发布
      batchPublic () {
        const taskIds = this.checkSelectIds()
        this.doPublic(taskIds)
      },
      // 取消报价
      cancelBid (row) {
        this.$confirm('确认取消报价吗？', '提示').then(async () => {
          let data = ''
          data = await this.$http(URL.cancelTaskQuotePrice, { taskCode: row.taskCode })
          if (data) {
            this.$message.success('取消报价成功！')
            this.$refreshMainQueryTable()
          }
        }).catch(() => {
          console.log('取消报价')
        })
      },
      // 确认要车
      confirmBid (row) {
        this.toDetail(row)
      },
      // 添加车辆弹窗
      addCar (row) {
        this.ruleForm.taskCode = row.taskCode
        this.ruleForm.driverId = row.driverId
        this.dialogFormVisible = true
      },
      // 保存车辆
      saveBidCar (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            await this.$http(URL.assignCarrierDriver, this.ruleForm)
            this.dialogFormVisible = false
            this.$refs[formName].resetFields()
            // 关闭弹框清空数据
            this.ruleForm = {
              carrierDriverName: '',
              carrierDriverPhone: '',
              carPlate: ''
            }
            this.$refreshMainQueryTable()
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 取消保存车辆
      cancelBidCar (formName) {
        this.dialogFormVisible = false
        this.$refs[formName].resetFields()
        // 关闭弹框清空数据
        this.ruleForm = {
          carrierDriverName: '',
          carrierDriverPhone: '',
          carPlate: ''
        }
      },
      // 重新要车
      afreshCar (row) {
        this.$router.push({ path: `/ecms/take-car/main-edit/${row.taskCode}` })
      },
      // 单个发布
      singlePublic (taskId) {
        this.doPublic(taskId)
      },
      // 双击到详情页
      toDetail (row) {
        this.$router.push({ path: `/ecms/take-car/main-detail/${row.taskCode}` })
      },
    }
  }
</script>

<style scoped>
</style>
