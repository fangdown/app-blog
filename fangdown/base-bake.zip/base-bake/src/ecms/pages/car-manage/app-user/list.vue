<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :form-model="formModel"
                 :tables="tables">
      <div slot="desc">
        <kye-button type="text"
                    icon="iconfont icon-ecs-dongjie"
                    @click="handleFrozen"
                    :auth="Api.updateStateDriver"
                    :disabled="selectData.length !== 1">冻结</kye-button>
        <kye-button type="text"
                    icon="iconfont icon-ecs-jiechudongjie"
                    :auth="Api.updateStateDriver"
                    @click="handleNotFrozen"
                    :disabled="selectData.length !== 1">解冻</kye-button>
      </div>
    </query-table>
  </div>
</template>
<script>
  // API接口
  import Api from './app-user.api.js'
  // 时间格式化，日期加减
  import { formatTime, dateAdd } from '../../utils/format.js'

  export default {
    data () {
      return {
        Api,
        selectData: [],
        generic: {
          method: Api.queryDriverInfoList,
          searchCode: 'ecs_yc_app_search'
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: Api.queryDriverInfoList,
            func: () => {
              this.$refs.queryTable.loadData()
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'ecs_yc_app_list_search_define'
        },
        tools: [
        ],
        formModel: {
          registTime: [this.$options.filters.date(+new Date(dateAdd(new Date(), -1))), this.$options.filters.date(+new Date())]
        },
        tables: [
          {
            searchCode: 'ecs_yc_app_list_field',
            url: { method: Api.queryDriverInfoList },
            option: {
              load: false, // 是否自动加载数据，默认 true
              type: 'selection', // 选择框
              moduleCode: 'ecs_yc',
              idKey: 'driverId',
              defaultSort: {
                keys: ['checkState', 'check_state'],
                prop: 'checkState',
                order: 'descending'
              },
              detailAuth: Api.getIdCardInfo,
              rowDblClick: (row) => {
                this.$router.push(`/ecms/app-user/detail/${row.driverId}`)
              },
              beforeFormSubmit: (data, model) => {
                const obj = {}
                let isEmpty = true // 是否有条件
                delete data.startTime
                delete data.endTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'registTime') {
                      if (model.registTime && model.registTime.length === 2) {
                        isEmpty = false
                        const startTime = +new Date(formatTime(model.registTime[0]) + ' 00:00:00')
                        const endTime = +new Date(formatTime(model.registTime[1]) + ' 23:59:59')
                        Object.assign(obj, {
                          startTime,
                          endTime
                        })
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
              selectionChange: (rows) => {
                this.selectData = rows
              },
            }
          }
        ]
      }
    },
    methods: {
      // 冻结
      async handleFrozen (index) {
        this.$confirm('确认冻结当前用户吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warn'
        }).then(async () => {
          await this.$http(Api.updateStateDriver, { driverIds: this.selectData[0].driverId, state: 3 })
          this.$message.success('冻结成功')
          this.$refreshMainQueryTable()
        })
      },
      // 解冻
      async handleNotFrozen (index) {
        this.$confirm('确认解冻当前用户吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warn'
        }).then(async () => {
          await this.$http(Api.updateStateDriver, { driverIds: this.selectData[0].driverId, state: 1 })
          this.$message.success('已取消冻结')
          this.$refreshMainQueryTable()
        })
      }
    }
  }
</script>



