<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>驾驶证正面</div>
        <span v-if="checkState!=='100'">当前审核状态：{{employData.driveCardFrontCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.driveCardFrontPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="employData.driveCardFrontPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名">
                  <kye-field v-model="employData.driverCardName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="准驾车型">
                  <kye-field v-model="employData.driveCardType"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="性别">
                  <kye-field>{{typeOption.driveGender['' +employData.driveGender]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="国籍">
                  <kye-field v-model="employData.driveCountry" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="驾驶证号"
                               prop="driveCardNum">
                  <kye-field v-model="employData.driveCardNum"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="有效期">
                  <kye-field>{{employData.drivingLicenceValidateDate}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +employData.driveCardFrontCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="employData.driveCardFrontCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>驾驶证副页</div>
        <span v-if="checkState!=='100'">当前审核状态：{{employData.driveCardViceCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.driveCardVicePhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="employData.driveCardVicePhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名">
                  <kye-field v-model="employData.driverCardName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="employData.driveCardViceCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +employData.driveCardViceCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>

            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>道路运输从业资格证</div>
        <span v-if="checkState!=='100'">当前审核状态：{{employData.freightageCardCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.freightageCardPhoto"
                 @click="dialogVisible3 = !dialogVisible3"
                 :src="employData.freightageCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名">
                  <kye-field v-model="employData.freightageCardName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-row>
                  <kye-form-item label="地址">
                    <div class="ecs-app-user-hack-height41">
                      <kye-col :span="5">
                        <kye-field>{{employData.freightageCardProvince?employData.freightageCardProvince:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{employData.freightageCardCity?employData.freightageCardCity:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{employData.freightageCardArea?employData.freightageCardArea:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="9">
                        <kye-field>{{employData.freightageCardAddress?employData.freightageCardAddress:''}}</kye-field>
                      </kye-col>
                    </div>
                  </kye-form-item>
                </kye-row>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="资格证号"
                               class="qualification">
                  <kye-field v-model="employData.freightageCardNum" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="有效期">
                  <kye-field>{{employData.validDateStr}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="发证机关">
                  <kye-field v-model="employData.freightageCardDep" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +employData.freightageCardCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="employData.freightageCardCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible3"
                         class="_imgBox"
                         :config="config3" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 本地数据字典
  import typeOption from '../selectOption.js'

  export default {
    props: {
      checkState: {
        type: String,
        default: ''
      },
      employData: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        typeOption,
        dialogVisible1: false,
        dialogVisible2: false,
        dialogVisible3: false,
        config1: {
          imgSrc: this.employData.driveCardFrontPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.employData.driveCardVicePhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        config3: {
          imgSrc: this.employData.freightageCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible3 = !this.dialogVisible3
              }
            }
          ]
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
    padding-right: 12px;
  }
</style>
