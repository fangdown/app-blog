<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>行驶证正面</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.carCardFrontCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carCardFrontPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="form.carCardFrontPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="车牌号码">
                  <kye-field v-model="form.carCardNo"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="所有人">
                  <kye-field v-model="form.carCardProprietorName" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="车辆类型">
                  <kye-field>{{form.carTypeName}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="发动机号">
                  <kye-field v-model="form.carCardEngineNum"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="车架号码">
                  <kye-field v-model="form.carCardNum" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="注册日期">
                  <kye-field v-model="form.carCardRegisterDate" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="15">
                <kye-row>
                  <kye-form-item label="地址">
                    <div class="ecs-app-user-hack-height41">
                      <kye-col :span="5">
                        <kye-field>{{form.carCardProvince?form.carCardProvince:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.carCardCity?form.carCardCity:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.carCardArea?form.carCardArea:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="9">
                        <kye-field>{{form.carCardAddress?form.carCardAddress:''}}</kye-field>
                      </kye-col>
                    </div>
                  </kye-form-item>
                </kye-row>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="使用性质">
                  <kye-field>{{typeOption.carCardProperty['' +form.carCardProperty]}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +form.carCardFrontCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.carCardFrontCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>行驶证反面</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.carCardBackCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carCardBackPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="form.carCardBackPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="年检有效期">
                  <kye-field>{{form.carCardValidEndDate}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="车长(米)">
                  <kye-field v-model="form.carLength"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="载重(kg)">
                  <kye-field v-model="form.approvedLoad"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +form.carCardBackCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.carCardBackCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title">
        <div>车辆运输证许可证</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.roadCardCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.roadCardPhoto"
                 @click="dialogVisible3 = !dialogVisible3"
                 :src="form.roadCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="9">
                <kye-form-item label="业户姓名">
                  <kye-field v-model="form.roadCardName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="10">
                <kye-form-item label="有效期">
                  <kye-field>{{form.validTimeStr}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="3">
                <kye-form-item label="运输证号">
                  <kye-field v-model="form.roadCardShortKey" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="交运管">
                  <kye-field>{{form.roadCardWord?form.roadCardWord+'字':''}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="2">
                <kye-field v-model="form.roadCardNumber" />
              </kye-col>
              <kye-col :span="10">
                <kye-form-item label="发证机关">
                  <kye-field v-model="form.roadCheckOffice"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +form.roadCardCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.roadCardCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible3"
                         class="_imgBox"
                         :config="config3" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 本地数据字典
  import typeOption from '../selectOption.js'

  export default {
    props: {
      checkState: {
        type: String,
        default: ''
      },
      form: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        typeOption,
        dialogVisible1: false,
        dialogVisible2: false,
        dialogVisible3: false,
        config1: {
          imgSrc: this.form.carCardFrontPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.carCardBackPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        config3: {
          imgSrc: this.form.roadCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible3 = !this.dialogVisible3
              }
            }
          ]
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
    padding-right: 12px;
  }
</style>
