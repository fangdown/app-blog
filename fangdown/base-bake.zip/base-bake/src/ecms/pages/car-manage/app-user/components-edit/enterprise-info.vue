<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>营业执照</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.operationCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewErpBusinessLicensePass"
                      @click="reviewBusiness">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.operationPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="form.operationPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model.sync="form"
                    :rules="rules">
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="企业名称"
                               prop="operatingName">
                  <kye-input v-model="form.operatingName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="法人姓名"
                               prop="operationJuridicalPerson">
                  <kye-input v-model="form.operationJuridicalPerson" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="信用代码"
                               prop="operationNum">
                  <kye-input v-model="form.operationNum" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="14">
                <addressSelector @addr="getAddress"
                                 :data="form.address"
                                 :span1="5"
                                 :span2="5"
                                 :span3="5"
                                 :span4="9" />
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="公司类型">
                  <kye-select placeholder=""
                              v-model="form.operationCompanyType">
                    <kye-option label="有限责任公司"
                                value="100"></kye-option>
                    <kye-option label="有限股份公司"
                                value="101"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="有效期"
                               prop="operationTime">
                  <kye-date-picker v-model="form.operationTime"
                                   type="daterange"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="经营范围">
                  <kye-input v-model="form.operationScope" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="operationCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.operationCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.operationCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title">
        <div>道路运输经营许可证</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.roadCardCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewErpEnterpriseRoadTransportLicensePass"
                      @click="reviewEnterpriseRoad">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.roadCardPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="form.roadCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm2"
                    :model.sync="form"
                    :rules="rules2">
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="业户名称">
                  <kye-input v-model="form.roadCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="3">
                <kye-form-item label="运营许可">
                  <kye-input v-model="form.roadCardNumber" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <div class="el-form-item__label driverFont">字</div>
                <kye-input class="fontInput"
                           v-model="form.roadCardWord"
                           size="mini" />
              </kye-col>
              <kye-col :span="1">
                <span class="driverNum">号</span>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="12">
                <addressSelector @addr="getRoadAddress"
                                 :data="form.roadAddress" />
              </kye-col>
              <kye-col :span="7">
                <kye-form-item label="有效期">
                  <kye-date-picker size="mini"
                                   v-model="form.roadValidTime"
                                   type="daterange"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-form-item label="经营范围">
                  <kye-input v-model="form.roadCardOperate" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="roadCardCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.roadCardCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="备注">
                  <kye-input v-model="form.roadCardCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 地址选择器
  import addressSelector from '../../../../components/addr-selector/address-selector.vue'
  // API接口
  import Api from '../../app-user/app-user.api'
  // 表单校验模块
  import rules from 'public/utils/rules'
  // 表单校验方法
  import { submitForm } from '../../../utils/validate'

  export default {
    components: {
      addressSelector
    },
    props: {
      checkState: {
        type: String,
        default: ''
      },
      form: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        Api,
        dialogVisible1: false,
        dialogVisible2: false,
        config1: {
          imgSrc: this.form.operationPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.roadCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        rules: {
          operatingName: rules.str('不能为空', true, 'blur'),
          operationJuridicalPerson: rules.str('不能为空', true, 'blur'),
          operationNum: rules.str('不能为空', true, 'blur'),
          operationTime: rules.str('不能为空', true, 'change'),
          operationCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules2: {
          roadCardCheckStatus: rules.str('不能为空', true, 'change'),
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    },
    methods: {
      // 营业执照审核
      async reviewBusiness () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        // 转时间戳
        let params = {}
        if (this.form.operationTime && this.form.operationTime[0] && this.form.operationTime[1]) {
          const operationStartValidDate = new Date(this.form.operationTime[0]).getTime()
          const operationEndValidDate = new Date(this.form.operationTime[1]).getTime()
          params = Object.assign({}, this.form, { operationStartValidDate, operationEndValidDate })
        } else {
          params = this.form
        }
        delete params.operationTime
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          if (this.form.operationCheckStatus === '102') {
            await this.$http(Api.reviewErpBusinessLicensePass, params)
            this.form.operationCheckStatusShow = '102' // 营业执照审核状态（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewErpBusinessLicenseNotPass, params)
            this.form.operationCheckStatusShow = '103' // 营业执照审核状态（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 道路运输许可证审核
      async reviewEnterpriseRoad () {
        // 表单校验
        if (typeof submitForm('ruleForm2', this) === 'object') {
          return false
        }
        // 转时间戳
        let params = {}
        if (this.form.roadValidTime && this.form.roadValidTime[0] && this.form.roadValidTime[1]) {
          const roadCardValidStartDate = new Date(this.form.roadValidTime[0]).getTime()
          const roadCardValidEndDate = new Date(this.form.roadValidTime[1]).getTime()
          params = Object.assign({}, this.form, { roadCardValidStartDate, roadCardValidEndDate })
        } else {
          params = this.form
        }
        delete params.roadValidTime
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          if (this.form.roadCardCheckStatus === '102') {
            await this.$http(Api.reviewErpEnterpriseRoadTransportLicensePass, params)
            this.form.roadCardCheckStatusShow = '102' // 道路运输经营许可证审核状态（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewErpEnterpriseRoadTransportLicenseNotPass, params)
            this.form.roadCardCheckStatusShow = '103' // 道路运输经营许可证审核状态（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 获取营业执照五级地址
      getAddress (data) {
        this.form.operationProvince = data.province
        this.form.operationProvinceId = data.provinceId
        this.form.operationCity = data.city
        this.form.operationCityId = data.cityId
        this.form.operationArea = data.area
        this.form.operationAreaId = data.areaId
        this.form.operationAddress = data.detail
      },
      // 获取道路运输五级地址
      getRoadAddress (data) {
        this.form.roadCardProvince = data.province
        this.form.roadCardProvinceId = data.provinceId
        this.form.roadCardCity = data.city
        this.form.roadCardCityId = data.cityId
        this.form.roadCardArea = data.area
        this.form.roadCardAreaId = data.areaId
        this.form.roadCardAddress = data.detail
      },
    }
  }
</script>

<style lang="scss" scoped>
  .driverFont {
    width: 40px;
    text-align: center !important;
  }
  .driverNum {
    display: inline-block;
    height: 40px;
    line-height: 30px;
    text-align: right;
  }
  .fontInput {
    width: 70%;
  }
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
