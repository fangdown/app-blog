
<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>身份证正面</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{idCardData.idCardFrontCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewIdCardFrontInfoPass"
                      @click="reviewIdCardFront"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="idCardData.idCardFrontPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="idCardData.idCardFrontPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    module-code="ecs_yc"
                    :biz-id="idCardData.driverId"
                    :model.sync="idCardData"
                    :rules="rules">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名"
                               prop="idCardName">
                  <kye-input v-model="idCardData.idCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="身份证号"
                               prop="idCardNum">
                  <kye-input v-model="idCardData.idCardNum"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="性别">
                  <kye-select placeholder=""
                              v-model="idCardData.idCardGender">
                    <kye-option label="未选择"
                                :value="null"
                                :disabled="true"></kye-option>
                    <kye-option label="男"
                                value="1"></kye-option>
                    <kye-option label="女"
                                value="2"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <!-- <addressSelector @addr="getAddress"
                                 :data="idCardData.address"
                                 :span1="5"
                                 :span2="5"
                                 :span3="5"
                                 :span4="9" /> -->
                <kye-form-item label="地址">
                  <kye-input v-model="idCardData.idCardAddress"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="idCardFrontCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="idCardData.idCardFrontCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="idCardData.idCardFrontCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>身份证反面</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{idCardData.idCardBackCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewIdCardBackInfoPass"
                      @click="reviewIdCardBack"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="idCardData.idCardBackPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="idCardData.idCardBackPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm2"
                    :model.sync="idCardData"
                    :rules="rules2">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="发证机关"
                               prop="idCardIssuedBy">
                  <kye-input v-model="idCardData.idCardIssuedBy"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="有效期"
                               prop="idCardTime">
                  <kye-date-picker v-model="idCardData.idCardTime"
                                   type="daterange"
                                   size="mini"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="idCardBackCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="idCardData.idCardBackCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="idCardData.idCardBackCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <!-- <div>
      <div class="kye-block-title">
        <div>手持身份证</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{idCardData.personAndIdCardCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewDriverHandCardInfoPass"
                      @click="reviewDriverHand"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="idCardData.personAndIdCardPhoto"
                 @click="dialogVisible3 = !dialogVisible3"
                 :src="idCardData.personAndIdCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm3"
                    :model.sync="idCardData"
                    :rules="rules3">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="personAndIdCardCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="idCardData.personAndIdCardCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="idCardData.personAndIdCardCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible3"
                         class="_imgBox"
                         :config="config3" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div> -->
  </div>
</template>

<script>
  // 地址选择器
  import addressSelector from '../../../../components/addr-selector/address-selector.vue'
  // API接口
  import Api from '../../app-user/app-user.api'
  // 表单校验模块
  import rules from 'public/utils/rules'
  // 表单校验方法
  import { submitForm } from '../../../utils/validate'

  export default {
    components: {
      addressSelector
    },
    props: {
      idCardData: {
        type: Object,
        default: () => ({})
      },
      checkState: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        Api,
        baseInfoEditable: true,
        isAudit: false,
        dialogVisible1: false,
        dialogVisible2: false,
        dialogVisible3: false,
        config1: {
          imgSrc: this.idCardData.idCardFrontPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.idCardData.idCardBackPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        config3: {
          imgSrc: this.idCardData.personAndIdCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible3 = !this.dialogVisible3
              }
            }
          ]
        },
        rules: {
          idCardName: rules.str('不能为空', true, 'blur'),
          idCardNum: rules.str('不能为空', true, 'blur'),
          idCardFrontCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules2: {
          idCardIssuedBy: rules.str('不能为空', true, 'blur'),
          idCardTime: rules.str('不能为空', true, 'blur'),
          idCardBackCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules3: {
          personAndIdCardCheckStatus: rules.str('不能为空', true, 'change'),
        }
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    },
    methods: {
      // 身份证正面提交
      async reviewIdCardFront () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          if (this.idCardData.idCardFrontCheckStatus === '102') {
            await this.$http(Api.reviewIdCardFrontInfoPass, this.$diff(this.idCardData, '**'))
            this.idCardData.idCardFrontCheckStatusShow = '102'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewIdCardFrontInfoNotPass, this.$diff(this.idCardData, '**'))
            this.idCardData.idCardFrontCheckStatusShow = '103'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 身份证背面提交
      async reviewIdCardBack () {
        // 表单校验
        if (typeof submitForm('ruleForm2', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.idCardData.idCardTime && this.idCardData.idCardTime[0] && this.idCardData.idCardTime[1]) {
            const idCardStartValidDate = new Date(this.idCardData.idCardTime[0]).getTime()
            const idCardEndValidDate = new Date(this.idCardData.idCardTime[1]).getTime()
            params = Object.assign({}, this.idCardData, { idCardStartValidDate, idCardEndValidDate })
          } else {
            params = this.idCardData
          }
          delete params.idCardTime
          if (this.idCardData.idCardBackCheckStatus === '102') {
            await this.$http(Api.reviewIdCardBackInfoPass, params)
            this.idCardData.idCardBackCheckStatusShow = '102'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewIdCardBackInfoNotPass, params)
            this.idCardData.idCardBackCheckStatusShow = '103'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 手持身份证提交
      async reviewDriverHand () {
        // 表单校验
        if (typeof submitForm('ruleForm3', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          if (this.idCardData.personAndIdCardCheckStatus === '102') {
            await this.$http(Api.reviewDriverHandCardInfoPass, this.idCardData)
            this.idCardData.personAndIdCardCheckStatusShow = '102'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDriverHandCardInfoNotPass, this.idCardData)
            this.idCardData.personAndIdCardCheckStatusShow = '103'
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 获取五级地址
      // getAddress (data) {
      //   this.idCardData.idCardProvince = data.province
      //   this.idCardData.idCardProvinceId = data.provinceId
      //   this.idCardData.idCardCity = data.city
      //   this.idCardData.idCardCityId = data.cityId
      //   this.idCardData.idCardArea = data.area
      //   this.idCardData.idCardAreaId = data.areaId
      //   this.idCardData.idCardAddress = data.detail
      // }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>



