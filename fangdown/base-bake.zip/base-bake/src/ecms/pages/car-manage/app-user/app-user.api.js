const perfix = 'ecs.yc.'
const URL = {
  queryDriverInfoList: `${perfix}driverManager.erp_queryDriverInfoList.do`, // 新ERP:用户管理-查询运力信息列表
  updateStateDriver: `${perfix}driverManager.updateStateDriver.do`, // 新ERP:更新为冻结或不冻结
  getErpDriverDetail: `${perfix}driverManager.getErpDriverDetailByDriverId.do`, // 查看用户(个体司机/非合同企业)详情 (V1.0)
  modifyDriverInfo: `${perfix}driverManager.modifyDriverInfo.do`, // 新ERP:修改用户(个体司机/非合同企业)详情
  getBankCardInfo: `${perfix}driverManager.getBankCardInfo.do`, // 新ERP:用户管理-查询银行卡信息
  getIdCardInfo: `${perfix}driverManager.getIdCardInfo.do`, // 新ERP:用户管理-查询实名认证信息
  reviewIdCardFrontInfoPass: `${perfix}driverManager.reviewIdCardFrontInfoPass.do`, // 新ERP:身份证正面审核通过接口
  reviewIdCardFrontInfoNotPass: `${perfix}driverManager.reviewIdCardFrontInfoNotPass.do`, // 新ERP:身份证正面审核不通过接口
  reviewIdCardBackInfoPass: `${perfix}driverManager.reviewIdCardBackInfoPass.do`, // 新ERP:身份证反面审核通过接口
  reviewIdCardBackInfoNotPass: `${perfix}driverManager.reviewIdCardBackInfoNotPass.do`, // 新ERP:身份证反面审核不通过接口
  reviewDriverHandCardInfoPass: `${perfix}driverManager.reviewDriverHandCardInfoPass.do`, // 新ERP:手持身份证审核通过接口
  reviewDriverHandCardInfoNotPass: `${perfix}driverManager.reviewDriverHandCardInfoNotPass.do`, // 新ERP:手持身份证审核不通过接口
  getDriverCardInfo: `${perfix}driverManager.getDriverCardInfo.do`, // 新ERP:用户管理-查询从业信息
  reviewDriverLicenseFrontPass: `${perfix}driverManager.reviewDriverLicenseFrontPass.do`, // 新ERP:驾驶证正面审核通过接口
  reviewDriverLicenseFrontNotPass: `${perfix}driverManager.reviewDriverLicenseFrontNotPass.do`, // 新ERP:驾驶证正面审核不通过接口
  reviewDriverLicenseBackPass: `${perfix}driverManager.reviewDriverLicenseBackPass.do`, // 新ERP:驾驶证反面审核通过接口
  reviewDriverLicenseBackNotPass: `${perfix}driverManager.reviewDriverLicenseBackNotPass.do`, // 新ERP:驾驶证反面审核不通过接口
  reviewDriverQualificationCertificatePass: `${perfix}driverManager.reviewDriverQualificationCertificatePass.do`, // 新ERP:从业资格证信息审核通过接口
  reviewDriverQualificationCertificateNotPass: `${perfix}driverManager.driverQualificationCertificateNotPass.do`, // 新ERP:从业资格证信息审核不通过接口
  getMyBindingInfo: `${perfix}driverManager.getMyBindingInfo.do`, // 新ERP:用户管理-查询绑定信息
  deleteUpdateDriver: `${perfix}driverManager.deleteUpdateDriver.do`, // 新ERP:解除绑定司机信息
  getEnterpriseInfo: `${perfix}driverManager.getEnterpriseInfo.do`, // 新ERP:用户管理-查询企业信息
  reviewErpBusinessLicensePass: `${perfix}driverManager.reviewErpBusinessLicensePass.do`, // 新ERP:营业执照审核通过接口
  reviewErpBusinessLicenseNotPass: `${perfix}driverManager.reviewErpBusinessLicenseNotPass.do`, // 新ERP:营业执照审核不通过接口
  reviewErpEnterpriseRoadTransportLicensePass: `${perfix}driverManager.enterpriseRoadTransportLicensePass.do`, // 新ERP:道路运输许可证审核通过接口
  reviewErpEnterpriseRoadTransportLicenseNotPass: `${perfix}driverManager.reviewEnterpriseRoadNotPass.do`, // 新ERP:道路运输许可证审核不通过接口
  getCarInfo: `${perfix}driverManager.getCarInfo.do`, // 新ERP:用户管理-查询车辆信息

  reviewDrivingLicenseFrontPass: `${perfix}driverManager.reviewDrivingLicenseFrontPass.do`, // 新ERP:行驶证正面审核通过接口
  reviewDrivingLicenseFrontNotPass: `${perfix}driverManager.reviewDrivingLicenseFrontNotPass.do`, // 新ERP:行驶证正面审核不通过接口
  reviewDrivingLicenseBackPass: `${perfix}driverManager.reviewDrivingLicenseBackPass.do`, // 新ERP:行驶证反面审核通过接口
  reviewDrivingLicenseBackNotPass: `${perfix}driverManager.reviewDrivingLicenseBackNotPass.do`, // 新ERP:行驶证反面审核不通过接口
  reviewErpPersonalRoadTransportLicensePass: `${perfix}driverManager.personalRoadTransportLicensePass.do`, // 新ERP:车辆信息-车辆道路运输证审核通过接口
  reviewErpPersonalRoadTransportLicenseNotPass: `${perfix}driverManager.reviewErpPersonalRoadTransportNotPass.do`, // 新ERP:车辆道路运输证审核不通过接口
  // getCalType: `${perfix}signedCompanyManage.GetCarStandardType.do`, // 系统基础:获取车辆类型数据
  getCalType: `${perfix}erpBaseCar.erp.getCarType.do`, // 系统基础:获取车辆类型数据
  findAllEntrustPlatformList: `${perfix}driverManager.findAllEntrustPlatformList.do`, // 新ERP:查询可用的挂靠平台列表
  getSmallCarDetail: `${perfix}driverManager.getSmallCarDetail.do`, // 查询二轮车，三轮车人车合影信息
  reviewCarPhotoCheck: `${perfix}driverManager.reviewCarPhotoCheck.do`, // 非汽车-汽车照片审核接口
  reviewManCarPhotoCheck: `${perfix}driverManager.reviewManCarPhotoCheck.do`, // 二轮车，三轮车-人车合影照片审核接口
  firstLevelReview: `${perfix}signedCompanyManage.firstLevelReview.do`, // 合同企业管理-一级审核操作
  companyArea: `fms.companyArea.getByArea`, // 公司信息-通过业务区域查询公司信息 (V1.0)
  supplierSearch: `ims.supplier.search`, // 查询供应商信息
}
export default URL

