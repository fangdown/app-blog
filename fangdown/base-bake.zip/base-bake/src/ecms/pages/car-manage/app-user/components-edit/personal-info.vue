<template>
  <div>
    <div class="kye-block-title">
      <div>用户信息</div>
      <div class="right">
        <kye-button type="text"
                    icon="iconfont icon-save1"
                    :auth="Api.modifyDriverInfo"
                    @click="modifyBaseInfo">保存
        </kye-button>
      </div>
    </div>
    <kye-form ref="personalInfo"
              :model.sync="form"
              module-code="ecs_yc"
              :biz-id="form.driverId">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="手机号"
                         prop="phone">
            <kye-input disabled
                       v-model="form.phone"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用户类型">
            <kye-select placeholder=""
                        v-model="form.driverType"
                        disabled>
              <kye-option label="个体司机"
                          value="1"></kye-option>
              <kye-option label="非合同企业"
                          value="3"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="车辆类型">
            <kye-select placeholder=""
                        v-model="form.carType"
                        disabled>
              <kye-option label="汽车"
                          value="5000"></kye-option>
              <kye-option label="二轮车"
                          value="1011"></kye-option>
              <kye-option label="三轮车"
                          value="1012"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册日期">
            <kye-input disabled
                       v-model="form.createTime"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册来源">
            <kye-select placeholder=""
                        disabled
                        v-model="form.registerChannel">
              <kye-option label="APP"
                          value="101"></kye-option>
              <kye-option label="导入"
                          value="102"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="实名信息">
            <kye-input disabled
                       v-model="form.name"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="车牌号">
            <kye-input disabled
                       v-model="form.plateNum"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="挂靠平台">
            <kye-select placeholder="请选择"
                        @change="entrustPlatformChange"
                        v-model="form.entrustPlatform">
              <kye-option value="0"
                          label="未填写"
                          disabled></kye-option>
              <kye-option value="1"
                          label="无需挂靠"></kye-option>
              <kye-option v-for="item in entrustPlatforms"
                          :key="item.entrustId"
                          :value="item.entrustId+''"
                          :label="item.entrustName"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="自行开票">
            <kye-select placeholder=""
                        v-model="form.isInvoicing"
                        disabled>
              <kye-option label="是"
                          value="1"></kye-option>
              <kye-option label="否"
                          value="2"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="开票公司">
            <kye-input disabled
                       v-model="form.belongCompany"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="推荐人">
            <kye-input disabled
                       v-model="form.invitePerson"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="付款方式">
            <kye-select placeholder=""
                        v-model="form.paymentMethod"
                        disabled>
              <kye-option label="未填写"
                          value="1"></kye-option>
              <kye-option label="网传"
                          value="201"></kye-option>
              <kye-option label="电汇"
                          value="202"></kye-option>
              <kye-option label="支票"
                          value="203"></kye-option>
              <kye-option label="现金"
                          value="204"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="用户状态">
            <kye-select placeholder=""
                        disabled
                        v-model="form.checkState">
              <kye-option label="未审核"
                          value="100"></kye-option>
              <kye-option label="待审核"
                          value="101"></kye-option>
              <kye-option label="审核通过"
                          value="102"></kye-option>
              <kye-option label="审核失败"
                          value="103"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账类型">
            <kye-select placeholder=""
                        v-model="form.payType">
              <kye-option label="未填写"
                          disabled
                          value="1"></kye-option>
              <kye-option label="提现"
                          value="102"></kye-option>
              <kye-option label="月结"
                          value="101"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账周期">
            <kye-select placeholder=""
                        v-model="form.payPeriod">
              <kye-option label="30天"
                          value="100"></kye-option>
              <kye-option label="45天"
                          value="101"></kye-option>
              <kye-option label="60天"
                          value="102"></kye-option>
              <kye-option label="90天"
                          value="103"></kye-option>
              <kye-option label="实时"
                          value="0"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="修改人">
            <kye-input disabled
                       v-model="form.updatePerson"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="修改时间">
            <kye-input disabled
                       v-model="form.updateTime"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="载重">
            <kye-number v-model="form.approvedLoad"
                        disabled
                        unit="kg"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="驻车地址">
            <kye-input v-model="form.address"
                       disabled />
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注">
            <kye-input v-model="form.checkNote" />
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>

<script>
  // API接口
  import Api from '../app-user.api'

  export default {
    props: {
      baseInfo: {
        type: Object,
        default: () => ({})
      }
    },
    data () {
      return {
        Api,
        entrustPlatforms: [],
        form: this.baseInfo
      }
    },
    watch: {
      baseInfo (newVal) { // 使用watch是为了解决加密字段解密报错问题
        if (newVal) {
          this.form = newVal
        }
      }
    },
    mounted () {
      this.findAllEntrustPlatformList()
    },
    methods: {
      // 查询挂靠平台列表
      async findAllEntrustPlatformList () {
        const data = await this.$http(Api.findAllEntrustPlatformList, {})
        this.entrustPlatforms = data
      },
      // 保存提交数据
      async modifyBaseInfo () {
        await this.$http(Api.modifyDriverInfo, this.$diff(this.form, '**'))
        this.isModify = true
        this.$message({
          message: '保存成功!',
          type: 'success'
        })
      },
      // 更改挂靠平台
      entrustPlatformChange (val) {
        console.log(val)
        if (val === '1') {
          this.form.isInvoicing = '1'
        } else {
          this.form.isInvoicing = '2'
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
