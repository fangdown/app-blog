<template>
  <div class="ecs-common-mt4">
    <kye-table :data="bankCarData"
               stripe
               :header-cell-style="{background:'#F1F1F5',textAlign:'left'}">
      <kye-table-column prop="bankAccountName"
                        width="200px"
                        label="开户名"
                        align="left">
      </kye-table-column>
      <kye-table-column prop="bankName"
                        label="开户行"
                        width="200px"
                        align="left">
      </kye-table-column>
      <kye-table-column prop="bankAccount"
                        label="账号"
                        align="left">
      </kye-table-column>
    </kye-table>
  </div>
</template>

<script>
  export default {
    props: {
      bankCarData: {
        type: Array,
        default: () => ([])
      }
    }
  }
</script>

