// // 取派
// export const driverType = {
//   '1': '个体司机',
//   '3': '企业'
// }
const typeOption = {
  driverType: {
    '1': '个体司机',
    '3': '企业',
    'null': ''
  },
  temCarType: {
    '5000': '汽车',
    '1011': '二轮车',
    '1012': '三轮车',
    'null': ''
  },
  registerChannel: {
    '101': 'APP',
    '102': '导入',
    'null': ''
  },
  isInvoicing: {
    '1': '是',
    '2': '否',
    'null': ''
  },
  paymentMethod: {
    '1': '未填写',
    '201': '网传',
    '202': '电汇',
    '203': '支票',
    '204': '现金'
  },
  checkState: {
    '100': '未审核',
    '101': '待审核',
    '102': '审核通过',
    '103': '审核失败',
    'null': ''
  },
  payType: {
    '101': '月结',
    '102': '提现',
    '1': '未填写'
  },
  payPeriod: {
    '100': '30天',
    '101': '45天',
    '102': '60天',
    '103': '90天',
    '0': '实时',
    'null': '',
    'undefined': ''
  },
  invoiceType: {
    'null': '',
    '101': '公司普票',
    '102': '增值税发票',
    '103': '其它发票'
  },
  driveGender: {
    '1': ' 男',
    '2': ' 女',
    'null': ' 未选择',
  },
  driveCardFrontCheckStatus: {
    '102': '通过',
    '103': '不通过',
    'null': ''
  },
  carCardProperty: {
    '1': '货运',
    '2': '非营运',
    'null': ''
  },
  operationCompanyType: {
    '100': '有限责任公司',
    '101': '有限股份公司',
    'null': ''
  }

}

export default typeOption
