<template>
  <div class="kye-detail">
    <search-pager :option="option"></search-pager>
    <kye-expand-page>
      <!-- 个体司机 -->
      <personal-info v-if="driverType===1"
                     :baseInfo="baseInfo" />
      <!-- 非合同企业 -->
      <company-info v-if="driverType===3"
                    :baseInfo="baseInfo" />
      <div class="kye-block-title wbyl-mt12"
           v-if="driverType===1||driverType===3">认证信息</div>
      <!-- 个体司机（汽车） -->
      <kye-tabs v-if="driverType===1&&isSmallCar===2"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <id-card-positive v-if="idCardData"
                            :checkState="baseInfo&&baseInfo.checkState"
                            :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="从业信息"
                      name="second">
          <drivingPositive v-if="employData"
                           :checkState="baseInfo&&baseInfo.checkState"
                           :employData="employData" />
        </kye-tab-pane>
        <kye-tab-pane label="车辆信息"
                      name="third">
          <vehicle-positive v-if="carData"
                            :checkState="baseInfo&&baseInfo.checkState"
                            :form="carData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="fourth">
          <bank-card v-if="bankCarData"
                     :bankCarData="bankCarData" />
        </kye-tab-pane>
      </kye-tabs>
      <!-- 个体司机(三轮车)  -->
      <kye-tabs v-if="driverType===1&&isSmallCar===1"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <id-card-positive v-if="idCardData"
                            :checkState="baseInfo.checkState"
                            :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="车辆信息"
                      name="third">
          <two-wheels v-if="twoWheelsCarData"
                      :checkState="baseInfo.checkState"
                      :form="twoWheelsCarData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="fourth">
          <bank-card v-if="bankCarData"
                     :bankCarData="bankCarData" />
        </kye-tab-pane>
      </kye-tabs>
      <!-- 非合同企业 -->
      <kye-tabs v-if="driverType===3"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <id-card-positive v-if="idCardData"
                            :checkState="baseInfo&&baseInfo.checkState"
                            :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="企业信息"
                      name="second">
          <enterprise-info v-if="enterpriseData"
                           :checkState="baseInfo&&baseInfo.checkState"
                           :form="enterpriseData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="third">
          <bank-card v-if="bankCarData"
                     :bankCarData="bankCarData" />
        </kye-tab-pane>
        <kye-tab-pane label="司机信息"
                      name="fourth">
          <driver-binding v-if="driverData"
                          :driverData="driverData"
                          :activeName="activeName" />
        </kye-tab-pane>
      </kye-tabs>
    </kye-expand-page>
  </div>
</template>
<script>
  //  从编辑页返回，提示是否保存数据弹窗
  import routeHook from 'public/mixins/route-hook'
  // 个体司机信息
  import personalInfo from './components-edit/personal-info'
  // 非合同企业信息
  import companyInfo from './components-edit/company-info'
  // 实名信息
  import idCardPositive from './components-edit/id-card-positive'
  // 从业信息
  import drivingPositive from './components-edit/driving-positive'
  // 车辆信息（汽车）
  import vehiclePositive from './components-edit/vehicle-positive'
  // 企业信息
  import enterpriseInfo from './components-edit/enterprise-info'
  // 银行卡信息
  import bankCard from './components-edit/bank-card'
  // 司机信息
  import driverBinding from './components-edit/driver-binding'
  // 车辆信息(二轮车、三轮车)
  import twoWheels from './components-edit/two-wheels'
  // 时间格式化
  import { formatTime } from '../../utils/format'
  // 本地数据字典
  import { approveStatus, bindStatus } from '../../utils/driverSelect'
  // API接口
  import Api from '../app-user/app-user.api'

  export default {
    mixins: [routeHook],
    components: {
      personalInfo,
      companyInfo,
      idCardPositive,
      drivingPositive,
      vehiclePositive,
      enterpriseInfo,
      bankCard,
      driverBinding,
      twoWheels
    },
    data () {
      return {
        activeName: 'first',
        baseInfo: {}, // 基础信息
        idCardData: null, // 实名信息
        employData: null, // 从业信息
        carData: null, // 车辆信息
        twoWheelsCarData: null, // 二、三轮车车辆信息
        bankCarData: null, // 银行卡信息
        driverData: null, // 司机信息
        enterpriseData: null, // 企业信息
        driverId: '',
        driverType: '',
        isSmallCar: '', // 是否二轮车，三轮车（'1'是，'2'否）
        option: {
          back: ''
        },
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (!vm.$route.meta.layout) {
          vm.activeName = 'first'
          vm.driverType = Number(vm.$route.query.driverType)
          vm.isSmallCar = Number(vm.$route.query.isSmallCar)
          vm.option.back = `/ecms/app-user/detail/${vm.$route.query.driverId}`
          // 清空数据
          vm.baseInfo = {} // 基础信息
          vm.idCardData = null // 实名信息
          vm.employData = null // 从业信息
          vm.carData = null // 车辆信息
          vm.twoWheelsCarData = null // 二、三轮车车辆信息
          vm.bankCarData = null // 银行卡信息
          vm.driverData = null // 司机信息
          vm.enterpriseData = null // 企业信息
          vm.getUserInfo() // 获取用户信息
        }
      })
    },
    methods: {
      // 获取用户信息
      async getUserInfo (driverId = this.$route.query.driverId) {
        const data = await this.$http(Api.getErpDriverDetail, { driverId })
        this.driverType = Number(data.driverType)
        this.isSmallCar = Number(data.isSmallCar)
        this.getCertificateInfo(this.driverType, this.isSmallCar, data)
      },
      // 获取认证信息
      async getCertificateInfo (driverType, isSmallCar, data) {
        this.getIdCardInfo() // 实名信息
        this.getBankCardInfo() // 获取银行卡信息
        if (driverType === 1) { // 个体司机
          this.personalInit(data)
          this.getEmployInfo() // 从业信息
          if (isSmallCar === 1) { // 二、三轮车
            this.getSmallCarDetail() // 二轮车、三轮车信息
          } else if (isSmallCar === 2) { // 汽车
            this.getCarInfo() // 车辆信息
          }
        } else if (driverType === 3) { // 非合同企业
          this.companyInit(data)
          this.getDriverInfo() // 获取司机信息
          this.getEnterpriseInfo() // 获取企业信息
        }
      },
      // 格式化非合同企业基本信息
      async companyInit (data) {
        if (data.createTime) {
          data.createTime = formatTime(data.createTime)
        }
        if (data.updateTime) {
          data.updateTime = formatTime(data.updateTime)
        }
        data.taxRate = data.taxRate * 100
        data.paymentMethod = String(data.paymentMethod)
        this.baseInfo = data
      },
      // 格式化个体司机基本信息
      async personalInit (data) {
        if (data.createTime) {
          data.createTime = formatTime(data.createTime)
        }
        if (data.updateTime) {
          data.updateTime = formatTime(data.updateTime)
        }
        // 数据转换
        data.isInvoicing = String(data.isInvoicing)
        data.payType = String(data.payType)
        data.payPeriod = String(data.payPeriod)
        data.paymentMethod = String(data.paymentMethod)
        // 除二轮车、三轮车外，均显示为汽车
        if (data.isSmallCar === '2') {
          data.carType = '5000'
        }
        this.baseInfo = data
      },
      // 获取实名信息（个体司机和非合同企业）
      async getIdCardInfo () {
        const params = { driverId: this.$route.query.driverId, driverType: this.$route.query.driverType }
        const data = await this.$http(Api.getIdCardInfo, params)
        if (data) {
          // 审核状态（显示值）
          data.idCardFrontCheckStatusShow = data.idCardFrontCheckStatus
          data.idCardBackCheckStatusShow = data.idCardBackCheckStatus
          data.personAndIdCardCheckStatusShow = data.personAndIdCardCheckStatus
          // 审核操作，只允许存在【通过】【不通过】两种操作
          if (data.idCardFrontCheckStatus !== 102 && data.idCardFrontCheckStatus !== 103) {
            data.idCardFrontCheckStatus = ''
          }
          if (data.idCardBackCheckStatus !== 102 && data.idCardBackCheckStatus !== 103) {
            data.idCardBackCheckStatus = ''
          }
          if (data.personAndIdCardCheckStatus !== 102 && data.personAndIdCardCheckStatus !== 103) {
            data.personAndIdCardCheckStatus = ''
          }
          // 转字符串|删除字段防止触发表单change事件校验
          if (data.idCardFrontCheckStatus) {
            data.idCardFrontCheckStatus = String(data.idCardFrontCheckStatus)
          } else {
            delete data.idCardFrontCheckStatus
          }
          if (data.idCardBackCheckStatus) {
            data.idCardBackCheckStatus = String(data.idCardBackCheckStatus)
          } else {
            delete data.idCardBackCheckStatus
          }
          if (data.personAndIdCardCheckStatus) {
            data.personAndIdCardCheckStatus = String(data.personAndIdCardCheckStatus)
          } else {
            delete data.personAndIdCardCheckStatus
          }
          // 日期转换
          if (data.idCardStartValidDate && data.idCardEndValidDate) {
            data.idCardTime = []
            data.idCardTime.push(new Date(data.idCardStartValidDate))
            data.idCardTime.push(new Date(data.idCardEndValidDate))
          }
          // 地址转换
          const tempAddr = {}
          tempAddr.province = data.idCardProvince
          tempAddr.provinceId = data.idCardProvinceId
          tempAddr.city = data.idCardCity
          tempAddr.cityId = data.idCardCityId
          tempAddr.area = data.idCardArea
          tempAddr.areaId = data.idCardAreaId
          tempAddr.detail = data.idCardAddress
          data.address = tempAddr
          // 性别转换
          if (data.idCardGender) {
            data.idCardGender = String(data.idCardGender)
          }
          this.idCardData = data
          // 保存时要用
          this.idCardData.driverId = this.$route.query.driverId
          this.idCardData.driverType = this.$route.query.driverType
        }
      },
      // 获取从业信息
      async getEmployInfo () {
        const data = await this.$http(Api.getDriverCardInfo, { driverId: this.$route.query.driverId })
        // 审核状态（显示值）
        data.driveCardFrontCheckStatusShow = data.driveCardFrontCheckStatus // 驾驶证正面
        data.driveCardViceCheckStatusShow = data.driveCardViceCheckStatus // 驾驶证副页
        data.freightageCardCheckStatusShow = data.freightageCardCheckStatus // 道路运输从业资格证
        // 数据转换
        if (data.driveCardFrontCheckStatus !== 102 && data.driveCardFrontCheckStatus !== 103) {
          data.driveCardFrontCheckStatus = ''
        }
        if (data.freightageCardCheckStatus !== 102 && data.freightageCardCheckStatus !== 103) {
          data.freightageCardCheckStatus = ''
        }
        if (data.driveCardViceCheckStatus !== 102 && data.driveCardViceCheckStatus !== 103) {
          data.driveCardViceCheckStatus = ''
        }
        // 数据转换|删除无用字段避免触发change表单事件
        if (data.driveCardFrontCheckStatus) {
          data.driveCardFrontCheckStatus = String(data.driveCardFrontCheckStatus)
        } else {
          delete data.driveCardFrontCheckStatus
        }
        if (data.freightageCardCheckStatus) {
          data.freightageCardCheckStatus = String(data.freightageCardCheckStatus)
        } else {
          delete data.freightageCardCheckStatus
        }
        if (data.driveCardViceCheckStatus) {
          data.driveCardViceCheckStatus = String(data.driveCardViceCheckStatus)
        } else {
          delete data.driveCardViceCheckStatus
        }
        // 驾驶证正面有效期
        if (data.driveStartCardValidDate && data.driveEndCardValidDate) {
          data.drivingLicenceValidateDate = []
          data.drivingLicenceValidateDate.push(new Date(data.driveStartCardValidDate))
          data.drivingLicenceValidateDate.push(new Date(data.driveEndCardValidDate))
        }
        // 道路运输从业资格证有效期
        if (data.freightageStartCardValidDate && data.freightageEndCardValidDate) {
          data.validDate = []
          data.validDate.push(data.freightageStartCardValidDate)
          data.validDate.push(data.freightageEndCardValidDate)
        }
        // 道路运输从业资格证地址
        const tempAddr = {}
        tempAddr.province = data.freightageCardProvince
        tempAddr.provinceId = data.freightageCardProvinceId
        tempAddr.city = data.freightageCardCity
        tempAddr.cityId = data.freightageCardCityId
        tempAddr.area = data.freightageCardArea
        tempAddr.areaId = data.freightageCardAreaId
        tempAddr.detail = data.freightageCardAddress
        data.freightageCardAddr = tempAddr
        this.employData = data
        // 保存时需要
        this.employData.driverId = this.$route.query.driverId
        this.employData.driverType = this.$route.query.driverType
      },
      // 获取车辆信息
      async getCarInfo () {
        const data = await this.$http(Api.getCarInfo, { driverId: this.$route.query.driverId })
        if (data) {
          // 审核状态（显示值）
          data.carCardFrontCheckStatusShow = data.carCardFrontCheckStatus
          data.carCardBackCheckStatusShow = data.carCardBackCheckStatus
          data.roadCardCheckStatusShow = data.roadCardCheckStatus
          // 数据转换
          if (data.carCardFrontCheckStatus !== 102 && data.carCardFrontCheckStatus !== 103) {
            data.carCardFrontCheckStatus = ''
          }
          if (data.carCardBackCheckStatus !== 102 && data.carCardBackCheckStatus !== 103) {
            data.carCardBackCheckStatus = ''
          }
          if (data.roadCardCheckStatus !== 102 && data.roadCardCheckStatus !== 103) {
            data.roadCardCheckStatus = ''
          }
          // 数据转换、避免表单change事件使框变红
          if (data.carCardFrontCheckStatus) {
            data.carCardFrontCheckStatus = String(data.carCardFrontCheckStatus)
          } else {
            delete data.carCardFrontCheckStatus
          }
          if (data.carCardBackCheckStatus) {
            data.carCardBackCheckStatus = String(data.carCardBackCheckStatus)
          } else {
            delete data.carCardBackCheckStatus
          }
          if (data.roadCardCheckStatus) {
            data.roadCardCheckStatus = String(data.roadCardCheckStatus)
          } else {
            delete data.roadCardCheckStatus
          }
          if (!data.carTypeId) {
            delete data.carTypeId
          }
          if (!data.carCardRegisterDate) {
            delete data.carCardRegisterDate
          }
          if (!data.carCardValidEndDate) {
            delete data.carCardValidEndDate
          }
          // 行驶证正面-注册地址-数据回显
          const tempData = {}
          tempData.province = data.carCardProvince
          tempData.provinceId = data.carCardProvinceId
          tempData.city = data.carCardCity
          tempData.cityId = data.carCardCityId
          tempData.area = data.carCardArea
          tempData.areaId = data.carCardAreaId
          tempData.detail = data.carCardAddress
          data.address = tempData
          // 车辆运输证许可证有效期
          data.validTime = []
          if (data.roadCardValidStartDate && data.roadCardValidEndDate) {
            data.validTime.push(new Date(data.roadCardValidStartDate))
            data.validTime.push(new Date(data.roadCardValidEndDate))
          }
          this.carData = data
          // 保存时需要
          this.carData.driverId = this.$route.query.driverId
          this.carData.driverType = this.$route.query.driverType
        }
      },
      // 获取二轮车，三轮车信息
      async getSmallCarDetail () {
        const data = await this.$http(Api.getSmallCarDetail, { driverId: this.$route.query.driverId })
        // 审核状态（显示值）
        data.carPhotoCheckStatusShow = data.carPhotoCheckStatus
        data.manCarPhotoCheckStatusShow = data.manCarPhotoCheckStatus
        // 数据转换
        if (data.carPhotoCheckStatus !== 102 && data.carPhotoCheckStatus !== 103) {
          data.carPhotoCheckStatus = ''
        }
        if (data.manCarPhotoCheckStatus !== 102 && data.manCarPhotoCheckStatus !== 103) {
          data.manCarPhotoCheckStatus = ''
        }
        // 数据转换、避免表单change事件使框变红
        if (data.carPhotoCheckStatus) {
          data.carPhotoCheckStatus = String(data.carPhotoCheckStatus)
        } else {
          delete data.carPhotoCheckStatus
        }
        if (data.manCarPhotoCheckStatus) {
          data.manCarPhotoCheckStatus = String(data.manCarPhotoCheckStatus)
        } else {
          delete data.manCarPhotoCheckStatus
        }
        this.twoWheelsCarData = data
      },
      // 获取银行卡信息（个体）
      async getBankCardInfo () {
        const data = await this.$http(Api.getBankCardInfo, { driverId: this.$route.query.driverId })
        this.bankCarData = data
      },
      // 获取司机信息
      async getDriverInfo () {
        const { rows } = await this.$http(Api.getMyBindingInfo, { driverId: this.$route.query.driverId })
        this.driverData = rows
        this.driverData.map((item) => {
          item.workStatus = bindStatus[item.workStatus]
          item.approveStatus = approveStatus[item.approveStatus]
          if (item.createTime) {
            item.createTime = formatTime(item.createTime, 'D')
          }
        })
      },
      // 获取企业信息
      async getEnterpriseInfo () {
        const data = await this.$http(Api.getEnterpriseInfo, { driverId: this.$route.query.driverId, driverType: this.driverType })
        if (data) {
          // 审核状态（显示值）
          data.operationCheckStatusShow = data.operationCheckStatus // 营业执照审核状态（显示值）
          data.roadCardCheckStatusShow = data.roadCardCheckStatus // 道路运输经营许可证审核状态（显示值）
          // 数据转换
          if (data.operationCheckStatus !== 102 && data.operationCheckStatus !== 103) {
            data.operationCheckStatus = ''
          }
          if (data.roadCardCheckStatus !== 102 && data.roadCardCheckStatus !== 103) {
            data.roadCardCheckStatus = ''
          }
          // 数据转换|防止数据为空时触发表单change事件
          if (data.operationCheckStatus) {
            data.operationCheckStatus = String(data.operationCheckStatus)
          } else {
            delete data.operationCheckStatus
          }
          if (data.roadCardCheckStatus) {
            data.roadCardCheckStatus = String(data.roadCardCheckStatus)
          } else {
            delete data.roadCardCheckStatus
          }
          // 日期转换
          if (data.operationStartValidDate && data.operationEndValidDate) {
            data.operationTime = []
            data.operationTime.push(new Date(data.operationStartValidDate))
            data.operationTime.push(new Date(data.operationEndValidDate))
          }
          if (!data.operationTime) {
            delete data.operationTime
          }
          if (data.roadCardValidStartDate && data.roadCardValidEndDate) {
            data.roadValidTime = []
            data.roadValidTime.push(new Date(data.roadCardValidStartDate))
            data.roadValidTime.push(new Date(data.roadCardValidEndDate))
          }
          if (!data.roadValidTime) {
            delete data.roadValidTime
          }
          // 地址转换
          const addr = {}
          addr.province = data.operationProvince
          addr.provinceId = data.operationProvinceId
          addr.city = data.operationCity
          addr.cityId = data.operationCityId
          addr.area = data.operationArea
          addr.areaId = data.operationAreaId
          addr.detail = data.operationAddress
          data.address = addr
          const roadAddr = {}
          roadAddr.province = data.roadCardProvince
          roadAddr.provinceId = data.roadCardProvinceId
          roadAddr.city = data.roadCardCity
          roadAddr.cityId = data.roadCardCityId
          roadAddr.area = data.roadCardArea
          roadAddr.areaId = data.roadCardAreaId
          roadAddr.detail = data.roadCardAddress
          data.roadAddress = roadAddr
          this.enterpriseData = data
        }
      }
    }
  }
</script>
<style lang="scss">
  .kye-detail {
    .app-piclan {
      text-align: left;
      font-weight: 500;
      font-size: 14px;
    }
    .audit-result {
      height: 40px;
      line-height: 40px;
    }
    .app-border-bottom {
      padding-bottom: 5px;
    }
    .wbyl-imgBox {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 200px;
      height: 125x;
      overflow: hidden;
      img {
        width: 100%;
      }
    }
    ._imgBox {
      > div {
        width: 100% !important;
        > img {
          width: 80% !important;
        }
      }
    }
    .ecs-common-mt4 {
      margin-top: 4px;
    }
    .wbyl-mt12 {
      margin-top: 12px;
    }
  }
</style>
