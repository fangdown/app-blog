<template>
  <div class="ecs-common-mt4">
    <div class="tab-operation">
      <kye-button type="text"
                  :auth="Api.deleteUpdateDriver"
                  icon="iconfont icon-unlock"
                  @click="deleteUpdateDrive">解除绑定
      </kye-button>
    </div>
    <table-list ref="driverBindingTable"
                :column="column"
                :data="driverData"
                :options="tableOption" />
  </div>
</template>

<script>
  // API接口
  import Api from '../../app-user/app-user.api'

  export default {
    props: {
      activeName: {
        type: String,
        default: ''
      },
      driverData: {
        type: Array,
        default: () => ([])
      }
    },
    data () {
      return {
        Api,
        selectData: [],
        column: [
          {
            key: 'driverName',
            label: '姓名',
            show: true,
            width: '60px',
          },
          {
            key: 'driverPhone',
            label: '手机号码',
            show: true,
            width: '100px',
          },
          {
            key: 'plateNum',
            label: '车牌号',
            show: true,
            width: '90px',
          },
          {
            key: 'carTypeName',
            label: '车型',
            show: true,
            width: '80px',
          },
          {
            key: 'workStatus',
            label: '工作状态',
            show: true,
            width: '70px'
          },
          {
            key: 'createTime',
            label: '绑定日期',
            show: true,
            width: '100px'
          },
          {
            key: 'residentAddress',
            label: '驻车地址',
            show: true,
            width: '100px'
          },
          {
            key: 'approveStatus',
            label: '认证状态',
            show: true,
            width: '60px'
          },
          {
            key: 'remark',
            label: '备注',
            show: true,
            width: '100px'
          },
        ],
        tableOption: {
          type: 'selection',
          stripe: true,
          moduleCode: 'ecs_yc', // 设置对应的 模块编码
          selectionChange: (val) => {
            this.selectData = val
          }
        },
      }
    },
    watch: {
      activeName (newVal) {
        if (newVal === 'fourth') {
          this.$refs.driverBindingTable.setCanvasWidth()
        }
      }
    },
    methods: {
      // 选中数据
      handleSelectionChange (val) {
        this.selectData = val
      },
      // 解除司机信息
      async deleteUpdateDrive () {
        let ids = ''
        if (this.selectData.length > 0) {
          this.selectData.map((item, index, dataList) => {
            ids += item.id + ','
          })
          await this.$http(Api.deleteUpdateDriver, { ids })
          this.$message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          })
          this.init({ driverId: this.$route.query.driverId })
        } else {
          this.$message({
            showClose: true,
            message: '请先选择数据!',
            type: 'warn'
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .tab-operation {
    text-align: left;
  }
</style>
