<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="editTools"></search-pager>
    <kye-expand-page>
      <!-- 个体司机 -->
      <personalInfo v-if="driverType===1"
                    :formData="formData" />
      <!-- 非合同企业 -->
      <companyInfo v-if="driverType===3"
                   :formData="formData" />
      <div class="kye-block-title wbyl-mt12"
           v-if="driverType===1||driverType===3">认证信息</div>
      <!-- 个体司机 （汽车）-->
      <kye-tabs v-if="driverType===1&&isSmallCar===2"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <idCardPositive v-if="idCardData"
                          :checkState="formData.checkState"
                          :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="从业信息"
                      name="second">
          <drivingPositive v-if="employData"
                           :checkState="formData.checkState"
                           :employData="employData" />
        </kye-tab-pane>
        <kye-tab-pane label="车辆信息"
                      name="third">
          <vehiclePositive v-if="carData"
                           :checkState="formData.checkState"
                           :form="carData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="fourth">
          <bankCard v-if="bankCarData"
                    :bankCarData="bankCarData" />
        </kye-tab-pane>
      </kye-tabs>
      <!-- 个体司机(三轮车) -->
      <kye-tabs v-if="driverType===1&&isSmallCar===1"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <idCardPositive v-if="idCardData"
                          :checkState="formData.checkState"
                          :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="车辆信息"
                      name="third">
          <twoWheels v-if="twoWheelsCarData"
                     :checkState="formData.checkState"
                     :form="twoWheelsCarData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="fourth">
          <bankCard v-if="bankCarData"
                    :bankCarData="bankCarData" />
        </kye-tab-pane>
      </kye-tabs>
      <!-- 非合同企业 -->
      <kye-tabs v-if="driverType===3"
                v-model="activeName">
        <kye-tab-pane label="实名信息"
                      name="first">
          <idCardPositive v-if="idCardData"
                          :checkState="formData.checkState"
                          :idCardData="idCardData" />
        </kye-tab-pane>
        <kye-tab-pane label="企业信息"
                      name="second">
          <enterpriseInfo v-if="enterpriseData"
                          :checkState="formData.checkState"
                          :form="enterpriseData" />
        </kye-tab-pane>
        <kye-tab-pane label="银行卡信息"
                      name="third">
          <bankCard v-if="bankCarData"
                    :bankCarData="bankCarData" />
        </kye-tab-pane>
        <kye-tab-pane label="司机信息"
                      name="fourth">
          <driverBinding v-if="driverData"
                         :activeName="activeName"
                         :driverData="driverData"
                         ref="driverBinding" />
        </kye-tab-pane>
      </kye-tabs>
    </kye-expand-page>
  </div>
</template>
<script>
  // 个体司机信息
  import personalInfo from './components-view/personal-info'
  // 非合同企业信息
  import companyInfo from './components-view/company-info'
  // 实名信息
  import idCardPositive from './components-view/id-card-positive'
  // 从业信息
  import drivingPositive from './components-view/driving-positive'
  // 车辆信息（汽车）
  import vehiclePositive from './components-view/vehicle-positive'
  // 企业信息
  import enterpriseInfo from './components-view/enterprise-info'
  // 银行卡信息
  import bankCard from './components-view/bank-card'
  // 司机信息
  import driverBinding from './components-view/driver-binding'
  // 车辆信息(二轮车、三轮车)
  import twoWheels from './components-view/two-wheels'
  // 时间格式化
  import { formatTime } from '../../utils/format'
  // 本地数据字典
  import { approveStatus, bindStatus } from '../../utils/driverSelect'
  // API接口
  import Api from '../app-user/app-user.api'

  export default {
    components: {
      personalInfo,
      companyInfo,
      idCardPositive,
      drivingPositive,
      vehiclePositive,
      enterpriseInfo,
      bankCard,
      driverBinding,
      twoWheels,
    },
    data () {
      return {
        activeName: 'first',
        isSmallCar: '', // 是否二轮车，三轮车（'1'是，'2'否）
        driverId: '',
        driverType: '',
        formData: {}, // 用户信息
        idCardData: null, // 实名信息
        employData: null, // 从业信息
        carData: null, // 车辆信息（汽车）
        twoWheelsCarData: null, // 车辆信息（ 二、三轮车）
        bankCarData: null, // 银行卡信息
        driverData: null, // 司机信息
        enterpriseData: null, // 企业信息
        option: {
          back: '/ecms/app-user/list',
          method: Api.queryDriverInfoList,
          searchCode: 'ecs_yc_app_list_field',
          idKey: 'driverId',
        },
        editTools: [
          {
            label: '修改',
            icon: 'pen',
            auth: 'ecs.yc.driverManager.reviewDriverHandCardInfoPass.do',
            func: () => {
              this.$router.push({
                path: `/ecms/app-user/edit`,
                query: {
                  driverId: this.$route.params.id,
                  driverType: this.driverType,
                  isSmallCar: this.isSmallCar
                }
              })
            },
          }
        ]
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (!vm.$route.meta.layout) {
          vm.getUserInfo()
          // 清空数据
          vm.formData = {} // 用户信息
          vm.idCardData = null // 实名信息
          vm.employData = null // 从业信息
          vm.carData = null // 车辆信息（汽车）
          vm.twoWheelsCarData = null // 车辆信息（ 二、三轮车）
          vm.bankCarData = null // 银行卡信息
          vm.driverData = null // 司机信息
          vm.enterpriseData = null // 企业信息
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.getUserInfo(to.params.id) // 注意这里的取值 to.params.id
      // 清空数据
      this.formData = {} // 用户信息
      this.idCardData = null // 实名信息
      this.employData = null // 从业信息
      this.carData = null // 车辆信息（汽车）
      this.twoWheelsCarData = null // 车辆信息（ 二、三轮车）
      this.bankCarData = null // 银行卡信息
      this.driverData = null // 司机信息
      this.enterpriseData = null // 企业信息
      next()
    },
    methods: {
      async getUserInfo (driverId = this.$route.params.id) {
        const data = await this.$http(Api.getErpDriverDetail, { driverId })
        this.driverType = ''
        this.driverType = Number(data.driverType)
        this.isSmallCar = Number(data.isSmallCar)
        this.activeName = 'first'
        this.getCertificateInfo(this.driverType, this.isSmallCar, data)
      },
      // 获取认证信息
      async getCertificateInfo (driverType, isSmallCar, data) {
        this.getIdCardInfo() // 实名信息
        this.getBankCardInfo() // 获取银行卡信息
        if (driverType === 1) { // 个体司机
          this.personalInit(data)
          this.getEmployInfo() // 从业信息
          if (isSmallCar === 1) { // 二、三轮车
            this.getSmallCarDetail() // 二轮车、三轮车信息
          } else if (isSmallCar === 2) { // 汽车
            this.getCarInfo() // 车辆信息
          }
        } else if (driverType === 3) { // 非合同企业
          this.companyInit(data)
          this.getDriverInfo() // 获取司机信息
          this.getEnterpriseInfo() // 获取企业信息
        }
      },
      // 获取实名信息（个体&非合同企业）
      async getIdCardInfo () {
        const data = await this.$http(Api.getIdCardInfo, { driverId: this.$route.params.id, driverType: this.driverType })
        if (data) {
          data.idCardFrontCheckStatus = String(data.idCardFrontCheckStatus)
          data.idCardBackCheckStatus = String(data.idCardBackCheckStatus)
          data.personAndIdCardCheckStatus = String(data.personAndIdCardCheckStatus)
          data.idCardGender = String(data.idCardGender)
          if (data.idCardStartValidDate && data.idCardEndValidDate) {
            data.idCardTimeStr = `${formatTime(new Date(data.idCardStartValidDate))} - ${formatTime(new Date(data.idCardEndValidDate))}`
          }
          this.idCardData = data
        }
      },
      // 获取从业信息
      async getEmployInfo () {
        const data = await this.$http(Api.getDriverCardInfo, { driverId: this.$route.params.id, driverType: this.driverType })
        data.driveCardFrontCheckStatus = String(data.driveCardFrontCheckStatus)
        data.freightageCardCheckStatus = String(data.freightageCardCheckStatus)
        data.driveCardViceCheckStatus = String(data.driveCardViceCheckStatus)
        // 驾驶证正面有效期
        if (data.driveStartCardValidDate && data.driveEndCardValidDate) {
          data.drivingLicenceValidateDate = `${formatTime(data.driveStartCardValidDate)} - ${formatTime(data.driveEndCardValidDate)}`
        }
        // 路运输从业资格证-有效期
        if (data.freightageStartCardValidDate && data.freightageEndCardValidDate) {
          data.validDateStr = `${formatTime(data.freightageStartCardValidDate)}  -  ${formatTime(data.freightageEndCardValidDate)}`
        }
        this.employData = data
      },
      // 获取从车辆息
      async getCarInfo () {
        const data = await this.$http(Api.getCarInfo, { driverId: this.$route.params.id, driverType: this.driverType })
        if (data) {
          data.carCardFrontCheckStatus = String(data.carCardFrontCheckStatus)
          data.carCardBackCheckStatus = String(data.carCardBackCheckStatus)
          data.roadCardCheckStatus = String(data.roadCardCheckStatus)
          // 年检有效期
          if (data.carCardValidEndDate) {
            data.carCardValidEndDate = formatTime(data.carCardValidEndDate)
          }
          if (data.roadCardValidStartDate && data.roadCardValidEndDate) {
            data.validTimeStr = `${formatTime(data.roadCardValidStartDate)} - ${formatTime(data.roadCardValidEndDate)}`
          }
          // 注册日期
          if (data.carCardRegisterDate) {
            data.carCardRegisterDate = formatTime(data.carCardRegisterDate)
          }
          this.carData = data
        }
      },
      // 获取车辆信息（二轮车，三轮车）
      async getSmallCarDetail () {
        const params = { driverId: this.$route.params.id, driverType: this.driverType }
        const data = await this.$http(Api.getSmallCarDetail, params)
        if (data) {
          // 审核状态（显示值）
          data.carPhotoCheckStatus = String(data.carPhotoCheckStatus)
          data.manCarPhotoCheckStatus = String(data.manCarPhotoCheckStatus)
          this.twoWheelsCarData = data
        }
      },
      // 获取银行卡信息（个体）
      async getBankCardInfo () {
        const params = { driverId: this.$route.params.id, driverType: this.driverType }
        const data = await this.$http(Api.getBankCardInfo, params)
        this.bankCarData = data
      },
      // 获取企业信息
      async getEnterpriseInfo () {
        const params = { driverId: this.$route.params.id, driverType: this.driverType }
        const data = await this.$http(Api.getEnterpriseInfo, params)
        if (data) {
          data.operationCheckStatus = String(data.operationCheckStatus)
          data.roadCardCheckStatus = String(data.roadCardCheckStatus)
          if (data.operationStartValidDate && data.operationEndValidDate) {
            data.operationTimeStr = `${formatTime(new Date(data.operationStartValidDate))} - ${formatTime(new Date(data.operationEndValidDate))}`
          }
          if (data.roadCardValidStartDate && data.roadCardValidEndDate) {
            data.roadValidTimeStr = `${formatTime(new Date(data.roadCardValidStartDate))} - ${formatTime(new Date(data.roadCardValidEndDate))}`
          }
          this.enterpriseData = data
        }
      },
      // 获取司机信息
      async getDriverInfo (param) {
        const params = { driverId: this.$route.params.id, driverType: this.driverType }
        const { rows } = await this.$http(Api.getMyBindingInfo, params)
        this.driverData = rows
        this.driverData.map(function (item) {
          item.workStatus = bindStatus[item.workStatus]
          item.approveStatus = approveStatus[item.approveStatus]
          if (item.createTime) {
            item.createTime = formatTime(item.createTime, 'D')
          }
        })
      },
      // 格式化非合同企业基本信息
      async companyInit (data) {
        if (data.createTime) {
          data.createTime = formatTime(data.createTime)
        }
        if (data.updateTime) {
          data.updateTime = formatTime(data.updateTime)
        }
        data.taxRate = data.taxRate * 100
        data.paymentMethod = String(data.paymentMethod)
        this.formData = data
      },
      // 格式化个体司机基本信息
      async personalInit (data) {
        // 数据类型转换
        data.isInvoicing = String(data.isInvoicing)
        data.payType = String(data.payType)
        data.payPeriod = String(data.payPeriod)
        data.paymentMethod = String(data.paymentMethod)
        // 时间转换
        if (data.createTime) {
          data.createTime = formatTime(data.createTime)
        }
        if (data.updateTime) {
          data.updateTime = formatTime(data.updateTime)
        }
        if (data.isSmallCar === '1') { // 非汽车
          if (Number(data.carType) === 1011) {
            data.carType = '二轮车'
          } else if (Number(data.carType) === 1012) {
            data.carType = '三轮车'
          }
        } else {
          data.carType = '汽车'
        }
        this.formData = data
      }
    }
  }
</script>
<style lang="scss">
  .kye-detail {
    .app-piclan {
      text-align: left;
      font-weight: 500;
      font-size: 14px;
    }
    .audit-result {
      height: 40px;
      line-height: 40px;
    }
    .app-border-bottom {
      padding-bottom: 5px;
    }
    .wbyl-imgBox {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 200px;
      height: 125px;
      overflow: hidden;
      img {
        width: 100%;
      }
    }
    ._imgBox {
      > div {
        width: 100% !important;
        > img {
          width: 80% !important;
        }
      }
    }
    .ecs-common-mt4 {
      margin-top: 4px;
    }
    .wbyl-mt12 {
      margin-top: 12px;
    }
    .ecs-app-user-hack-height41 {
      height: 41px;
      overflow: hidden;
    }
  }
</style>
