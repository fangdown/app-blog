<template>
  <div class="ecs-common-mt4">
    <div>
      <div class="kye-block-title">
        <div>车辆信息</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.carPhotoCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewCarPhotoCheck"
                      :auth="Api.reviewCarPhotoCheck"
                      v-if="baseInfoEditable">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carPhoto"
                 @click="dialogVisible1=!dialogVisible1"
                 :src="form.carPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model.sync="form"
                    :rules="rules">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="carPhotoCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.carPhotoCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.carPhotoCheckRemark"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-image v-if="dialogVisible1"
                           class="_imgBox"
                           :config="config1" />
              </kye-col>
              <kye-col :span="5"></kye-col>
            </kye-row>
          </kye-form>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title wbyl-mt12">
        <div>人车合照</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.manCarPhotoCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewManCarPhotoCheck"
                      :auth="Api.reviewManCarPhotoCheck"
                      v-if="baseInfoEditable">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.manCarPhoto"
                 @click="dialogVisible2=!dialogVisible2"
                 :src="form.manCarPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm2"
                    :model.sync="form"
                    :rules="rules2">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="manCarPhotoCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.manCarPhotoCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.manCarPhotoCheckRemark"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-image v-if="dialogVisible2"
                           class="_imgBox"
                           :config="config2" />
              </kye-col>
              <kye-col :span="5"></kye-col>
            </kye-row>
          </kye-form>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // API接口
  import Api from '../../app-user/app-user.api'
  // 表单校验模块
  import rules from 'public/utils/rules'
  // 表单校验方法
  import { submitForm } from '../../../utils/validate'

  export default {
    props: {
      form: {
        type: Object,
        default: () => ({})
      },
      checkState: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        Api,
        dialogVisible1: false,
        dialogVisible2: false,
        baseInfoEditable: true,
        config1: {
          imgSrc: this.form.carPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.manCarPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        rules: {
          carPhotoCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules2: {
          manCarPhotoCheckStatus: rules.str('不能为空', true, 'change'),
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    },
    methods: {
      // 照片审核接口
      async reviewCarPhotoCheck () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          await this.$http(Api.reviewCarPhotoCheck, this.form)
          // 刷新审核状态（显示值）
          if (this.form.carPhotoCheckStatus === '102') {
            this.form.carPhotoCheckStatusShow = '102'
          } else if (this.form.carPhotoCheckStatus === '103') {
            this.form.carPhotoCheckStatusShow = '103'
          }
          this.$message({
            type: 'success',
            message: '操作成功'
          })
        })
      },
      // 人车合影照片审核接口
      async reviewManCarPhotoCheck () {
        // 表单校验
        if (typeof submitForm('ruleForm2', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          await this.$http(Api.reviewManCarPhotoCheck, this.form)
          // 刷新审核状态（显示值）
          if (this.form.manCarPhotoCheckStatus === '102') {
            this.form.manCarPhotoCheckStatusShow = '102'
          } else if (this.form.manCarPhotoCheckStatus === '103') {
            this.form.manCarPhotoCheckStatusShow = '103'
          }
          this.$message({
            type: 'success',
            message: '操作成功'
          })
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>


