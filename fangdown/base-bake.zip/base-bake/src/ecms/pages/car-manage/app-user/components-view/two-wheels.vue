<template>
  <div class="ecs-common-mt4">
    <div>
      <div class="kye-block-title">
        <div>车辆信息</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.carPhotoCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="form.carPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果">
                  <kye-field>{{form.carPhotoCheckStatus|statusTranslate}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.carPhotoCheckRemark"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-image v-if="dialogVisible1"
                           class="_imgBox"
                           :config="config1" />
              </kye-col>
              <kye-col :span="5"></kye-col>
            </kye-row>
          </kye-form>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title wbyl-mt12">
        <div>人车合照</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.manCarPhotoCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.manCarPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="form.manCarPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果">
                  <kye-field>{{form.carPhotoCheckStatus|statusTranslate}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.manCarPhotoCheckRemark"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-image v-if="dialogVisible2"
                           class="_imgBox"
                           :config="config2" />
              </kye-col>
              <kye-col :span="5"></kye-col>
            </kye-row>
          </kye-form>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      checkState: {
        type: String,
        default: ''
      },
      form: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        dialogVisible1: false,
        dialogVisible2: false,
        config1: {
          imgSrc: this.form.carPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.manCarPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
    padding-right: 12px;
  }
</style>


