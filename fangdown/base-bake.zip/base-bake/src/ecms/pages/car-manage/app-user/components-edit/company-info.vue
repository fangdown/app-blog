<template>
  <div>
    <div class="kye-block-title">
      <div>用户信息</div>
      <div class="right">
        <kye-button type="text"
                    icon="iconfont icon-save1"
                    @click="modifyBaseInfo"
                    :auth="Api.modifyDriverInfo">保存
        </kye-button>
      </div>
    </div>
    <kye-form module-code="ecs_yc"
              :biz-id="form.driverId"
              :model.sync="form"
              class="form-details">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="手机号"
                         prop="phone">
            <kye-input disabled
                       v-model="form.phone"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用户类型">
            <kye-select placeholder=""
                        disabled
                        v-model="form.driverType">
              <kye-option label="个体司机"
                          value="1"></kye-option>
              <kye-option label="非合同企业"
                          value="3"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册日期">
            <kye-input disabled
                       v-model="form.createTime"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册来源">
            <kye-select placeholder=""
                        disabled
                        v-model="form.registerChannel">
              <kye-option label="APP"
                          value="101"></kye-option>
              <kye-option label="导入"
                          value="102"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="实名信息">
            <kye-input disabled
                       v-model="form.name"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="车辆信息">
            <kye-input disabled
                       v-model="form.plateNum"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="推荐人">
            <kye-input disabled
                       v-model="form.invitePerson"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="是否开票">
            <kye-select placeholder=""
                        v-model="form.isInvoicing">
              <kye-option label="是"
                          value="1"></kye-option>
              <kye-option label="否"
                          value="2"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="开票公司">
            <kye-input disabled
                       v-model="form.belongCompany"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="付款方式">
            <kye-select placeholder=""
                        disabled
                        v-model="form.paymentMethod">
              <kye-option label="未填写"
                          disabled
                          value="1"></kye-option>
              <kye-option label="网传"
                          value="201"></kye-option>
              <kye-option label="电汇"
                          value="202"></kye-option>
              <kye-option label="支票"
                          value="203"></kye-option>
              <kye-option label="现金"
                          value="204"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票类型">
            <kye-select placeholder=""
                        v-model="form.invoiceType">
              <kye-option label="未填写"
                          disabled
                          :value="null"></kye-option>
              <kye-option label="公司普票"
                          value="101"></kye-option>
              <kye-option label="增值税发票"
                          value="102"></kye-option>
              <kye-option label="其它发票"
                          value="103"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="发票税率">
            <kye-number v-model="form.taxRate"
                        unit="%"
                        :max="100"
                        placeholder=''
                        :clearable="false"
                        :min="0"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账类型">
            <kye-select placeholder=""
                        v-model="form.payType">
              <kye-option label="未填写"
                          disabled
                          value="1"></kye-option>
              <kye-option label="提现"
                          value="102"></kye-option>
              <kye-option label="月结"
                          value="101"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账周期">
            <kye-select placeholder=""
                        v-model="form.payPeriod">
              <kye-option label="未填写"
                          disabled
                          value="0"></kye-option>
              <kye-option label="30天"
                          value="100"></kye-option>
              <kye-option label="45天"
                          value="101"></kye-option>
              <kye-option label="60天"
                          value="102"></kye-option>
              <kye-option label="90天"
                          value="103"></kye-option>
              <kye-option label="实时"
                          value="104"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="修改人">
            <kye-input disabled
                       v-model="form.updatePerson"></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="修改时间">
            <kye-date-picker disabled
                             v-model="form.updateTime"></kye-date-picker>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="状态">
            <kye-select placeholder=""
                        disabled
                        v-model="form.checkState">
              <kye-option label="未审核"
                          value="100"></kye-option>
              <kye-option label="待审核"
                          value="101"></kye-option>
              <kye-option label="审核通过"
                          value="102"></kye-option>
              <kye-option label="审核失败"
                          value="103"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="企业地址">
            <kye-input v-model="form.address"
                       disabled />
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注">
            <kye-input v-model="form.checkNote" />
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>

<script>
  // API接口
  import Api from '../../app-user/app-user.api'

  export default {
    props: {
      baseInfo: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        Api,
        form: this.baseInfo,
        isModify: true
      }
    },
    watch: {
      baseInfo (newVal) { // 使用watch是为了解决加密字段解密报错问题
        if (newVal) {
          this.form = newVal
        }
      }
    },
    methods: {
      // 保存提交数据
      async modifyBaseInfo () {
        let tempTaxRate = ''
        tempTaxRate = this.form.taxRate / 100
        const params = Object.assign({}, this.form, { taxRate: tempTaxRate })
        await this.$http(Api.modifyDriverInfo, this.$diff(params, '**'))
        this.isModify = true
        this.$message({
          message: '保存成功!',
          type: 'success'
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
