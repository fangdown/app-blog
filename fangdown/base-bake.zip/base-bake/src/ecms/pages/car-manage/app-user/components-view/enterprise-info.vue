<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>营业执照</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.operationCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.operationPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="form.operationPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model.sync="form"
                    module-code="ecs_yc"
                    :biz-id="form.driverId"
                    size="mini">
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="企业名称">
                  <kye-field v-model="form.operatingName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="法人姓名">
                  <kye-field v-model="form.operationJuridicalPerson" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="信用代码">
                  <kye-field v-model="form.operationNum" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="14">
                <kye-row>
                  <kye-form-item label="地址">
                    <div class="ecs-app-user-hack-height41">
                      <kye-col :span="5">
                        <kye-field>{{form.operationProvince?form.operationProvince:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.operationCity?form.operationCity:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.operationArea?form.operationArea:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="9">
                        <kye-field>{{form.operationAddress?form.operationAddress:''}}</kye-field>
                      </kye-col>
                    </div>
                  </kye-form-item>
                </kye-row>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="公司类型">
                  <kye-field>{{typeOption.operationCompanyType['' +form.operationCompanyType]}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="有效期">
                  <kye-field>{{form.operationTimeStr}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="经营范围">
                  <kye-field v-model="form.operationScope" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +form.operationCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-field v-model="form.operationCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title">
        <div>道路运输经营许可证</div>
        <span v-if="checkState!=='100'">当前审核状态：{{form.roadCardCheckStatus|statusTranslate}}</span>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.roadCardPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="form.roadCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model="form"
                    size="mini">
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="业户名称">
                  <kye-field v-model="form.roadCardName"></kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="3">
                <kye-form-item label="运营许可">
                  <kye-field v-model="form.roadCardNumber" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <div class="el-form-item__label driverFont">字</div>
                <kye-field class="fontInput">{{form.roadCardWord}}</kye-field>
              </kye-col>
              <kye-col :span="1">
                <span class="driverNum">号</span>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="12">
                <kye-row>
                  <kye-form-item label="地址">
                    <div class="ecs-app-user-hack-height41">
                      <kye-col :span="5">
                        <kye-field>{{form.roadCardProvince?form.roadCardProvince:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.roadCardCity?form.roadCardCity:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="5">
                        <kye-field>{{form.roadCardArea?form.roadCardArea:''}}</kye-field>
                      </kye-col>
                      <kye-col :span="9">
                        <kye-field>{{form.roadCardAddress?form.roadCardAddress:''}}</kye-field>
                      </kye-col>
                    </div>
                  </kye-form-item>
                </kye-row>
              </kye-col>
              <kye-col :span="7">
                <kye-form-item label="有效期">
                  <kye-field>{{form.roadValidTimeStr}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="19">
                <kye-form-item label="经营范围">
                  <kye-field v-model="form.roadCardOperate" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果">
                  <kye-field>{{typeOption.driveCardFrontCheckStatus['' +form.roadCardCheckStatus]}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="备注">
                  <kye-field v-model="form.roadCardCheckMemo"></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 本地数据字典
  import typeOption from '../selectOption.js'

  export default {
    props: {
      checkState: {
        type: String,
        default: ''
      },
      form: {
        type: Object,
        default: () => ({})
      },
    },
    data () {
      return {
        typeOption,
        dialogVisible1: false,
        dialogVisible2: false,
        config1: {
          imgSrc: this.form.operationPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.roadCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
    padding-right: 12px;
  }
  .fontInput {
    width: 90%;
    line-height: 29px;
  }
</style>
