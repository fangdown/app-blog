<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>行驶证正面</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.carCardFrontCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      :auth="Api.reviewDrivingLicenseFrontPass"
                      @click="reviewDriverLicenseFront"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carCardFrontPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="form.carCardFrontPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model.sync="form"
                    :rules="rules">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="车牌号码"
                               prop="carCardNo">
                  <kye-input v-model="form.carCardNo"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="所有人"
                               prop="carCardProprietorName">
                  <kye-input v-model="form.carCardProprietorName"
                             maxlength="25" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="车辆类型"
                               prop="carTypeId">
                  <kye-select placeholder=""
                              v-model="form.carTypeId"
                              @change="changeCarInfo">
                    <kye-option v-for="item in baseCarData"
                                :key="item.id"
                                :label="item.dictValue"
                                :value="item.dictKey">
                    </kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="发动机号">
                  <kye-input v-model="form.carCardEngineNum"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="10">
                <kye-form-item label="车架号码">
                  <kye-input v-model="form.carCardNum" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="注册日期"
                               prop="carCardRegisterDate">
                  <kye-date-picker v-model="form.carCardRegisterDate"
                                   type="date">
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="15">
                <addressSelector @addr="getAddress"
                                 :data="form.address" />
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="使用性质">
                  <kye-select placeholder=""
                              v-model="form.carCardProperty">
                    <kye-option label="货运"
                                value="1"></kye-option>
                    <kye-option label="非营运"
                                value="2"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果"
                               prop="carCardFrontCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.carCardFrontCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.carCardFrontCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>行驶证反面</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.carCardBackCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewDriverLicenseBack"
                      :auth="Api.reviewDrivingLicenseBackPass"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.carCardBackPhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="form.carCardBackPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm2"
                    :model.sync="form"
                    :rules="rules2">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="年检有效期"
                               prop="carCardValidEndDate">
                  <kye-date-picker v-model="form.carCardValidEndDate"
                                   type="date">
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="车长(米)"
                               prop="carLength">
                  <kye-input v-model="form.carLength"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="载重(kg)"
                               prop="approvedLoad">
                  <kye-input v-model="form.approvedLoad"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果"
                               prop="carCardBackCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.carCardBackCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.carCardBackCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div>
      <div class="kye-block-title">
        <div>车辆运输证许可证</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{form.roadCardCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewQualifications"
                      :auth="Api.reviewErpPersonalRoadTransportLicensePass"
                      v-if="baseInfoEditable&&!isAudit">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="form.roadCardPhoto"
                 @click="dialogVisible3 = !dialogVisible3"
                 :src="form.roadCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm3"
                    :model.sync="form"
                    :rules="rules3">
            <kye-row>
              <kye-col :span="9">
                <kye-form-item label="业户姓名">
                  <kye-input v-model="form.roadCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="10">
                <kye-form-item label="有效期">
                  <kye-date-picker v-model="form.validTime"
                                   type="daterange"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="3">
                <kye-form-item label="运输证号">
                  <kye-input v-model="form.roadCardShortKey" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="3">
                <kye-form-item label="交运管">
                  <kye-input v-model="form.roadCardWord"
                             placeholder=''
                             width="50%">
                  </kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="1"
                       style="margin-top: 5px">字</kye-col>
              <kye-col :span="2">
                <kye-input v-model="form.roadCardNumber"
                           size="mini" />
              </kye-col>
              <kye-col :span="10">
                <kye-form-item label="发证机关">
                  <kye-input v-model="form.roadCheckOffice"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="审核结果"
                               prop="roadCardCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="form.roadCardCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="form.roadCardCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible3"
                         class="_imgBox"
                         :config="config3" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 地址选择器
  import addressSelector from '../../../../components/addr-selector/address-selector.vue'
  // API接口
  import Api from '../../app-user/app-user.api'
  // 表单校验模块
  import rules from 'public/utils/rules'
  // 表单校验方法
  import { submitForm } from '../../../utils/validate'

  export default {
    components: {
      addressSelector
    },
    props: {
      form: {
        type: Object,
        default: () => ({})
      },
      checkState: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        Api,
        baseInfoEditable: true,
        isAudit: false,
        // 单独一个变量用来存时间
        carCardRegisterDate: '',
        baseCarData: [],
        noRepeatCar: [],
        dialogVisible1: false,
        dialogVisible2: false,
        dialogVisible3: false,
        config1: {
          imgSrc: this.form.carCardFrontPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.form.carCardBackPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        config3: {
          imgSrc: this.form.roadCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible3 = !this.dialogVisible3
              }
            }
          ]
        },
        rules: {
          carCardNo: rules.str('不能为空', true, 'blur'),
          carCardProprietorName: rules.str('不能为空', true, 'blur'),
          carTypeId: rules.str('不能为空', true, 'change'),
          carCardRegisterDate: rules.str('不能为空', true, 'change'),
          carCardFrontCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules2: {
          carCardValidEndDate: rules.str('不能为空', true, 'change'),
          carLength: rules.str('不能为空', true, 'blur'),
          approvedLoad: rules.str('不能为空', true, 'blur'),
          carCardBackCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules3: {
          roadCardCheckStatus: rules.str('不能为空', true, 'change'),
        }
      }
    },
    mounted () {
      this.getCalType()
    },
    activated () {
      this.getCalType()
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    },
    methods: {
      // 获取车型信息
      async getCalType () {
        const data = await this.$http(Api.getCalType, {})
        this.baseCarData = data
      },
      // 行驶证正面
      async reviewDriverLicenseFront () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.form.carCardRegisterDate) {
            const tempDate = new Date(this.form.carCardRegisterDate).getTime()
            params = Object.assign({}, this.form, { carCardRegisterDate: tempDate })
          } else {
            params = this.form
          }
          if (this.form.carCardFrontCheckStatus === '102') {
            await this.$http(Api.reviewDrivingLicenseFrontPass, params)
            // 审核状态（显示值）
            this.form.carCardFrontCheckStatusShow = '102' // 行驶证正面（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDrivingLicenseFrontNotPass, params)
            this.form.carCardFrontCheckStatusShow = '103' // 行驶证正面（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 行驶证副页
      async reviewDriverLicenseBack () {
        // 表单校验
        if (typeof submitForm('ruleForm2', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.form.carCardValidEndDate) {
            const tempDate = new Date(this.form.carCardValidEndDate).getTime()
            params = Object.assign({}, this.form, { carCardValidEndDate: tempDate })
          } else {
            params = this.form
          }
          if (this.form.carCardBackCheckStatus === '102') {
            await this.$http(Api.reviewDrivingLicenseBackPass, params)
            this.form.carCardBackCheckStatusShow = '102' // 行驶证副页（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDrivingLicenseBackNotPass, params)
            this.form.carCardBackCheckStatusShow = '103' // 行驶证副页（显示值）
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 车辆道路运输从业资格证
      async reviewQualifications () {
        // 表单校验
        if (typeof submitForm('ruleForm3', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.form.validTime && this.form.validTime[0] && this.form.validTime[1]) {
            const roadCardValidStartDate = new Date(this.form.validTime[0]).getTime()
            const roadCardValidEndDate = new Date(this.form.validTime[1]).getTime()
            params = Object.assign({}, this.form, { roadCardValidStartDate, roadCardValidEndDate })
          } else {
            params = this.form
          }
          delete params.validTime
          if (this.form.roadCardCheckStatus === '102') {
            await this.$http(Api.reviewErpPersonalRoadTransportLicensePass, params)
            this.form.roadCardCheckStatusShow = '102' // 车辆道路运输从业资格证(显示值)
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewErpPersonalRoadTransportLicenseNotPass, params)
            this.form.roadCardCheckStatusShow = '103' // 车辆道路运输从业资格证(显示值)
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 获取五级地址
      getAddress (data) {
        this.form.carCardProvince = data.province
        this.form.carCardProvinceId = data.provinceId
        this.form.carCardCity = data.city
        this.form.carCardCityId = data.cityId
        this.form.carCardArea = data.area
        this.form.carCardAreaId = data.areaId
        this.form.carCardAddress = data.detail
      },
      // 变更车辆信息
      changeCarInfo (val) {
        this.baseCarData.forEach(item => {
          if (item.dictKey === val) {
            this.form.carTypeName = item.dictValue
            // this.form.carTypeName = item.carTypeName
            // this.form.carLength = item.carLength
            // this.form.approvedLoad = item.carWeight
            // this.form.approvedLoadingVolume = item.carCubage
          }
        })
      },
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
