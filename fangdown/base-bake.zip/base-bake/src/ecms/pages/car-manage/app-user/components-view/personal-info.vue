<template>
  <div>
    <div class="kye-block-title">用户信息</div>
    <kye-form ref="personalInfo"
              :model.sync="form"
              module-code="ecs_yc"
              :biz-id="form.driverId">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="手机号"
                         prop="phone">
            <kye-field v-model="form.phone"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="用户类型">
            <kye-field>{{typeOption.driverType['' +form.driverType]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="车辆类型">
            <kye-field>{{form.carType}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册日期">
            <kye-field v-model="form.createTime"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="注册来源">
            <kye-field>{{typeOption.registerChannel['' +form.registerChannel]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="实名信息">
            <kye-field v-model="form.name"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="车牌号">
            <kye-field v-model="form.plateNum"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="挂靠平台">
            <kye-field>{{form.entrustPlatformName?form.entrustPlatformName+'':'未填写'}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="自行开票">
            <kye-field>{{typeOption.isInvoicing['' +form.isInvoicing]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="开票公司">
            <kye-field v-model="form.belongCompany"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="推荐人">
            <kye-field v-model="form.invitePerson"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="付款方式">
            <kye-field>{{typeOption.paymentMethod['' +form.paymentMethod]}}</kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="用户状态">
            <kye-field>{{typeOption.checkState['' +form.checkState]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账类型">
            <kye-field>{{typeOption.payType['' +form.payType]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="结账周期">
            <kye-field>{{typeOption.payPeriod['' +form.payPeriod]}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="修改人">
            <kye-field v-model="form.updatePerson"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="修改时间">
            <kye-field v-model="form.updateTime"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="载重(kg)">
            <kye-field>{{form.approvedLoad}}</kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="驻车地址">
            <kye-field v-model="form.address" />
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注">
            <kye-field v-model="form.checkNote" />
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>

<script>
  // 本地数据字典
  import typeOption from '../selectOption.js'

  export default {
    props: {
      formData: {
        type: Object,
        default: () => ({})
      }
    },
    data () {
      return {
        typeOption,
        form: this.formData
      }
    },
    watch: {
      formData (newVal) { // 使用watch是为了解决加密字段解密报错问题
        if (newVal) {
          this.form = this.formData
        }
      }
    }
  }
</script>

