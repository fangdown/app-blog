<template>
  <div class="ecs-common-mt4">
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>驾驶证正面</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{employData.driveCardFrontCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewDriverLicenseFront"
                      :auth="Api.reviewDriverLicenseFrontPass"
                      v-if="baseInfoEditable">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.driveCardFrontPhoto"
                 @click="dialogVisible1 = !dialogVisible1"
                 :src="employData.driveCardFrontPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm"
                    :model.sync="employData"
                    :rules="rules">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名"
                               prop="driverCardName">
                  <kye-input v-model="employData.driverCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="准驾车型"
                               prop="driveCardType">
                  <kye-select placeholder=""
                              v-model="employData.driveCardType">
                    <kye-option label="A2"
                                value="A2"></kye-option>
                    <kye-option label="A1"
                                value="A1"></kye-option>
                    <kye-option label="C1"
                                value="C1"></kye-option>
                    <kye-option label="B1"
                                value="B1"></kye-option>
                    <kye-option label="B2"
                                value="B2"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="4">
                <kye-form-item label="性别">
                  <kye-select placeholder=""
                              v-model="employData.driveGender">
                    <kye-option label="未选择"
                                :value="null"
                                :disabled="true"></kye-option>
                    <kye-option label="男"
                                value="1"></kye-option>
                    <kye-option label="女"
                                value="2"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="国籍">
                  <kye-input v-model="employData.driveCountry" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="驾驶证号"
                               prop="driveCardNum">
                  <kye-input v-model="employData.driveCardNum"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="有效期"
                               prop="drivingLicenceValidateDate">
                  <kye-date-picker v-model="employData.drivingLicenceValidateDate"
                                   type="daterange"
                                   size="mini"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果"
                               prop="driveCardFrontCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="employData.driveCardFrontCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="employData.driveCardFrontCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible1"
                         class="_imgBox"
                         :config="config1" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>驾驶证副页</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{employData.driveCardViceCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewDriverLicenseBack"
                      :auth="Api.reviewDriverLicenseBackPass"
                      v-if="baseInfoEditable">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.driveCardVicePhoto"
                 @click="dialogVisible2 = !dialogVisible2"
                 :src="employData.driveCardVicePhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm2"
                    :model.sync="employData"
                    :rules="rules2">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名">
                  <kye-input v-model="employData.driverCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="employData.driveCardViceCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果"
                               prop="driveCardViceCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="employData.driveCardViceCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible2"
                         class="_imgBox"
                         :config="config2" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
    <div class="app-border-bottom">
      <div class="kye-block-title">
        <div>道路运输从业资格证</div>
        <div class="right">
          <span v-if="checkState!=='100'">当前审核状态：{{employData.freightageCardCheckStatusShow|statusTranslate}}</span>
          <kye-button type="text"
                      icon="iconfont icon-save1"
                      @click="reviewQualifications"
                      :auth="Api.reviewDriverQualificationCertificatePass"
                      v-if="baseInfoEditable">保存
          </kye-button>
        </div>
      </div>
      <kye-row>
        <kye-col :span="4">
          <div class="wbyl-imgBox">
            <img v-if="employData.freightageCardPhoto"
                 @click="dialogVisible3 = !dialogVisible3"
                 :src="employData.freightageCardPhoto" />
            <img v-else
                 src="../../../assets/images/pic_nopic.png" />
          </div>
        </kye-col>
        <kye-col :span="20">
          <kye-form ref="ruleForm3"
                    :model.sync="employData"
                    :rules="rules3">
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="姓名">
                  <kye-input v-model="employData.freightageCardName"></kye-input>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <addressSelector @addr="getFreightageAddress"
                                 :data="employData.freightageCardAddr"
                                 :span1="5"
                                 :span2="5"
                                 :span3="5"
                                 :span4="9" />
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5">
                <kye-form-item label="资格证号"
                               class="qualification">
                  <kye-input v-model="employData.freightageCardNum" />
                </kye-form-item>
              </kye-col>
              <kye-col :span="9">
                <kye-form-item label="有效期">
                  <kye-date-picker v-model="employData.validDate"
                                   type="daterange"
                                   range-separator="-"
                                   start-
                                   end->
                  </kye-date-picker>
                </kye-form-item>
              </kye-col>
              <kye-col :span="5">
                <kye-form-item label="发证机关">
                  <kye-input v-model="employData.freightageCardDep" />
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="5"
                       class="audit-result">
                <kye-form-item label="审核结果"
                               prop="freightageCardCheckStatus">
                  <kye-select placeholder="请选择"
                              v-model="employData.freightageCardCheckStatus">
                    <kye-option label="通过"
                                value="102"></kye-option>
                    <kye-option label="不通过"
                                value="103"></kye-option>
                  </kye-select>
                </kye-form-item>
              </kye-col>
              <kye-col :span="14">
                <kye-form-item label="审核备注">
                  <kye-input v-model="employData.freightageCardCheckMemo"></kye-input>
                </kye-form-item>
              </kye-col>
            </kye-row>
          </kye-form>
          <kye-row>
            <kye-col :span="19">
              <kye-image v-if="dialogVisible3"
                         class="_imgBox"
                         :config="config3" />
            </kye-col>
            <kye-col :span="5"></kye-col>
          </kye-row>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  // 地址选择模块
  import addressSelector from '../../../../components/addr-selector/address-selector.vue'
  // API接口
  import Api from '../../app-user/app-user.api'
  // 表单校验模块
  import rules from 'public/utils/rules'
  // 表单校验
  import { submitForm } from '../../../utils/validate'

  export default {
    components: {
      addressSelector
    },
    props: {
      employData: {
        type: Object,
        default: () => ({})
      },
      checkState: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        Api,
        baseInfoEditable: true,
        dialogVisible1: false,
        dialogVisible2: false,
        dialogVisible3: false,
        config1: {
          imgSrc: this.employData.driveCardFrontPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible1 = !this.dialogVisible1
              }
            }
          ]
        },
        config2: {
          imgSrc: this.employData.driveCardVicePhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible2 = !this.dialogVisible2
              }
            }
          ]
        },
        config3: {
          imgSrc: this.employData.freightageCardPhoto,
          height: 430,
          btns: [
            {
              icon: 'icon-close',
              label: '关闭',
              click: () => {
                this.dialogVisible3 = !this.dialogVisible3
              }
            }
          ]
        },
        rules: {
          driverCardName: rules.str('不能为空', true, 'blur'),
          driveCardType: rules.str('不能为空', true, 'blur'),
          driveCardNum: rules.str('不能为空', false, 'blur'),
          drivingLicenceValidateDate: rules.str('不能为空', true, 'change'),
          driveCardFrontCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules2: {
          driveCardArchives: rules.str('不能为空', false, 'blur'),
          driveCardViceCheckStatus: rules.str('不能为空', true, 'change'),
        },
        rules3: {
          freightageCardCheckStatus: rules.str('不能为空', true, 'change'),
        }
      }
    },
    filters: {
      statusTranslate (value) {
        if (!value) return ''
        const stateMap = {
          '100': '未完善',
          '101': '待审核',
          '102': '审核通过',
          '103': '审核失败'
        }
        return stateMap[value + '']
      }
    },
    methods: {
      // 驾驶证正面
      async reviewDriverLicenseFront () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.employData.drivingLicenceValidateDate && this.employData.drivingLicenceValidateDate[0] && this.employData.drivingLicenceValidateDate[1]) {
            const driveStartCardValidDate = new Date(this.employData.drivingLicenceValidateDate[0]).getTime()
            const driveEndCardValidDate = new Date(this.employData.drivingLicenceValidateDate[1]).getTime()
            params = Object.assign({}, this.employData, { driveStartCardValidDate, driveEndCardValidDate })
          } else {
            params = this.employData
          }
          delete params.drivingLicenceValidateDate
          if (this.employData.driveCardFrontCheckStatus === '102') {
            await this.$http(Api.reviewDriverLicenseFrontPass, params)
            this.employData.driveCardFrontCheckStatusShow = '102' // 驾驶证正面
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDriverLicenseFrontNotPass, params)
            this.employData.driveCardFrontCheckStatusShow = '103' // 驾驶证正面
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 驾驶证背面
      async reviewDriverLicenseBack () {
        // 表单校验
        if (typeof submitForm('ruleForm2', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          if (this.employData.driveCardViceCheckStatus === '102') {
            await this.$http(Api.reviewDriverLicenseBackPass, this.employData)
            this.employData.driveCardViceCheckStatusShow = '102' // 驾驶证副页
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDriverLicenseBackNotPass, this.employData)
            this.employData.driveCardViceCheckStatusShow = '103' // 驾驶证副页
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 道路运输从业资格证
      async reviewQualifications () {
        // 表单校验
        if (typeof submitForm('ruleForm3', this) === 'object') {
          return false
        }
        this.$confirm('确定审核状态？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'info'
        }).then(async () => {
          // 转时间戳
          let params = {}
          if (this.employData.validDate && this.employData.validDate[0] && this.employData.validDate[1]) {
            const freightageStartCardValidDate = new Date(this.employData.validDate[0]).getTime()
            const freightageEndCardValidDate = new Date(this.employData.validDate[1]).getTime()
            params = Object.assign({}, this.employData, { freightageStartCardValidDate, freightageEndCardValidDate })
          } else {
            params = this.employData
          }
          delete params.validDate
          if (this.employData.freightageCardCheckStatus === '102') {
            await this.$http(Api.reviewDriverQualificationCertificatePass, params)
            this.employData.freightageCardCheckStatusShow = '102' // 道路运输从业资格证
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          } else {
            await this.$http(Api.reviewDriverQualificationCertificateNotPass, params)
            this.employData.freightageCardCheckStatusShow = '103' // 道路运输从业资格证
            this.$message({
              type: 'success',
              message: '操作成功'
            })
          }
        })
      },
      // 道路运输获取五级地址
      getFreightageAddress (data) {
        this.employData.freightageCardProvince = data.province
        this.employData.freightageCardProvinceId = data.provinceId
        this.employData.freightageCardCity = data.city
        this.employData.freightageCardCityId = data.cityId
        this.employData.freightageCardArea = data.area
        this.employData.freightageCardAreaId = data.areaId
        this.employData.freightageCardAddress = data.detail
      },
    }
  }
</script>

<style lang="scss" scoped>
  .kye-block-title {
    display: flex;
    justify-content: space-between;
  }
</style>
