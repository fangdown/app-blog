<template>
  <div class="ecs-common-mt4">
    <table-list ref="driverBindingTable"
                :column="column"
                :data="driverData"
                :options="tableOption" />
  </div>
</template>

<script>
  export default {
    props: {
      // 当前tab页，用户重新设置table-list的宽度
      activeName: {
        type: String,
        default: ''
      },
      driverData: {
        type: Array,
        default: () => ([])
      }
    },
    data () {
      return {
        column: [
          {
            key: 'driverName',
            label: '姓名',
            show: true,
            width: '60px',
          },
          {
            key: 'driverPhone',
            label: '手机号码',
            show: true,
            width: '100px',
          },
          {
            key: 'plateNum',
            label: '车牌号',
            show: true,
            width: '90px',
          },
          {
            key: 'carTypeName',
            label: '车型',
            show: true,
            width: '80px',
          },
          {
            key: 'workStatus',
            label: '工作状态',
            show: true,
            width: '70px'
          },
          {
            key: 'createTime',
            label: '绑定日期',
            show: true,
            width: '100px'
          },
          {
            key: 'residentAddress',
            label: '驻车地址',
            show: true,
            width: '140px'
          },
          {
            key: 'approveStatus',
            label: '认证状态',
            show: true,
            width: '60px'
          },
          {
            key: 'remark',
            label: '备注',
            show: true,
            width: '100px'
          },
        ],
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_yc'
        },
      }
    },
    watch: {
      activeName (newVal) {
        if (newVal === 'fourth') {
          this.$refs.driverBindingTable.setCanvasWidth()
        }
      }
    }
  }
</script>

