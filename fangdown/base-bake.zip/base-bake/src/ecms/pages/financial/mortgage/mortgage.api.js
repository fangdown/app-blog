const perfix = 'ecs.finance.deposit.'
const URL = {
  // 押金流水
  selectDriverTradeList: `${perfix}selectDriverTradeList.do`,
  // 押金退款列表
  selectDriverRefundTradeList: `${perfix}selectDriverRefundTradeList.do`,
  // 退款详情页
  selectDriverRefundDetail: `${perfix}selectDriverRefundDetail.do`,
  // 押金退款
  manualDepositRefund: `${perfix}manualDepositRefund.do`
}
export default URL
