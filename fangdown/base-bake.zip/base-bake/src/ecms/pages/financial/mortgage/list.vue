<template>
  <div class="mortgage">
    <search-pager :tools="queryTables[activeName].formTools"></search-pager>
    <kye-tabs v-model="activeName"
              @tab-click="tabClick">
      <kye-tab-pane label="押金流水"
                    name="mortgage">
        <query-table ref="mortgageTable"
                     :generic="queryTables.mortgage.generic"
                     :option="queryTables.mortgage.option"
                     :tools="queryTables.mortgage.tools"
                     :form-model="queryTables.mortgage.formModel"
                     :tables="queryTables.mortgage.tables">
        </query-table>
      </kye-tab-pane>
      <kye-tab-pane label="退款列表"
                    name="refund">
        <morgage-popup :row="rowdata"
                       key="rowdata"
                       @reload='reload'
                       ref="child"></morgage-popup>
        <div class="tab-content">
          <query-table ref="refundTable"
                       :generic="queryTables.refund.generic"
                       :option="queryTables.refund.option"
                       :tools="queryTables.refund.tools"
                       :form-model="queryTables.refund.formModel"
                       :tables="queryTables.refund.tables">
          </query-table>
        </div>
      </kye-tab-pane>
    </kye-tabs>
  </div>
</template>
<script>
  import URL from './mortgage.api'
  // 退款列表详情
  import morgagePopup from './components/mortgage-popup'
  export default {
    components: { morgagePopup },
    data () {
      return {
        rowdata: null,
        activeName: 'mortgage',
        queryTables: {
          // 押金流水
          mortgage: {
            selectedRow: null,
            generic: {
              method: URL.selectDriverTradeList,
              searchCode: 'ecs_cw_mortgage_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.selectDriverTradeList,
                func: () => this.reload('mortgage')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('mortgage')
              }
            ],
            option: {
              searchCode: 'ecs_cw_mortgage_search_define'
            },
            formModel: {
              tradeTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tools: [],
            tables: [
              {
                searchCode: 'ecs_cw_mortgage_list_field',
                url: { method: URL.selectDriverTradeList },
                operation: {},
                option: {
                  label: '押金流水',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.selectDriverRefundTradeList,
                  currentChange: (row) => {
                    this.queryTables['mortgage'].selectedRow = row
                  },
                  rowDblClick: (row) => {
                  },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) {
                      Object.assign(data, obj)
                    } else {
                      return true
                    }
                  },
                }
              }
            ]
          },
          // 退款列表
          refund: {
            selectedRow: null,
            generic: {
              method: URL.selectDriverRefundTradeList,
              searchCode: 'ecs_cw_refund_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.selectDriverRefundTradeList,
                func: () => this.reload('refund')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('refund')
              }
            ],
            option: {
              searchCode: 'ecs_cw_refund_search_define'
            },
            formModel: {
              tradeTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tools: [],
            tables: [
              {
                searchCode: 'ecs_cw_refund_list_filed',
                url: { method: URL.selectDriverRefundTradeList },
                operation: {
                  label: '操作',
                  fixed: 'left',
                  width: '60px',
                  options: row => {
                    if (row.status === 200) {
                      return [{
                        btnType: 'text',
                        label: '查看详情',
                        auth: URL.selectDriverRefundDetail,
                        func: row => {
                          this.fixedRightClick(row)
                        }
                      }]
                    } else if (row.status === 300) {
                      return [{
                        type: 'link',
                        label: '人工处理',
                        auth: URL.selectDriverRefundDetail,
                        func: row => {
                          this.fixedRightClick(row)
                        }
                      }]
                    }
                  }
                },
                option: {
                  label: '退款列表',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.selectDriverTradeList,
                  // idKey: 'order.id',
                  beforeHttp: (data) => {

                  },
                  rowDblClick: (row) => this.toDetail(row),
                  currentChange: (row) => {
                    this.queryTables['refund'].selectedRow = row
                  },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) {
                      Object.assign(data, obj)
                    } else {
                      return true
                    }
                  },
                },
                formatter: {}
              }
            ]
          }
        }
      }
    },
    methods: {
      tabClick (val) {
        this.$refs[`${val.name}Table`].setCanvas()
      },
      reload (type) {
        if (type === 'refund') {
          this.$refs.refundTable.loadData()
        } else {
          this.$refs.mortgageTable.loadData()
        }
      },
      showDragDialog (type) {
        if (type === 'refund') {
          this.$refs.refundTable.showDragDialog()
        } else {
          this.$refs.mortgageTable.showDragDialog()
        }
      },
      toDetail (row) {
      },
      fixedRightClick (row) {
        this.rowdata = row
        if (this.rowdata) {
          this.$refs.child.toView(row.id, row.status)
        }
      },
      // 时间处理
      time (data, model) {
        let isEmpty = true // 是否有条件
        const obj = {}
        // 没有选择时间时清空data里面startTime，endTime
        delete data.tradeStartTime
        delete data.tradeEndTime
        for (let key in model) {
          if (model[key]) {
            if (key === 'tradeTime') {
              // 格式化时间
              if (model.tradeTime && model.tradeTime.length === 2) {
                isEmpty = false
                const tradeStartTime = new Date(model.tradeTime[0]).getTime()
                const tradeEndTime = new Date(model.tradeTime[1]).getTime()
                Object.assign(obj, {
                  tradeStartTime,
                  tradeEndTime
                })
              }
            } else {
              isEmpty = false
              obj[key] = model[key]
            }
          } else {
            delete data[key]
          }
        }
        if (isEmpty) {
          this.$message.warning('请输入查询条件')
          return true
        }
        return obj
      },
    }
  }
</script>
<style>
  .mortgage .query-table-container .query-form-wrap {
    margin: 4px 0 0;
  }
</style>
