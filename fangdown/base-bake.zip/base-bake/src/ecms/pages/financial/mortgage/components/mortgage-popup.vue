<template>
  <div>
    <kye-dialog title="退款申请详情"
                :visible.sync="dialogFormVisible"
                append-to-body
                width='860px'>
      <kye-row>
        <p class="popupTitle"
           style="margin-top: 0px;"><i></i>押金退款详情</p>
        <table-list :column="column"
                    :data="refundList"
                    :options="tableOption"></table-list>
      </kye-row>
      <p class="popupTitle"><i></i>押金扣款详情</p>
      <kye-row>
        <table-list :column="column2"
                    :data="financeDriverFinesFeeVoList"
                    :options="tableOption"></table-list>
      </kye-row>
      <p class="popupTitle"><i></i>押金充值详情</p>
      <kye-row>
        <table-list :column="column3"
                    :data="chargeList"
                    :options="tableOption"></table-list>
      </kye-row>
      <div slot="footer">
        <kye-button type="primary"
                    @click="againRefund()"
                    hotkey="crtl+s"
                    v-if="rowStatus=== 300 ">再次退款</kye-button>
        <kye-button type="primary"
                    v-if="rowStatus!== 300 "
                    @click="dialogFormVisible = false">关闭</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from '../mortgage.api'
  export default {
    props: {
      row: Object,
      default () {
        return {
        }
      }
    },
    data () {
      return {
        rowStus: false,
        URL,
        dialogFormVisible: false,
        formLabelWidth: '80px',
        refundList: [],
        rowStatus: '',
        financeDriverFinesFeeVoList: [],
        chargeList: [],
        column: [{
          'key': 'tradeNo',
          'label': '退款流水号',
          'width': '125px',
          'show': true
        }, {
          'key': 'payTradeNo',
          'label': '交易编号',
          'width': '215px',
          'show': true
        }, {
          'key': 'createTime',
          'label': '申请退款时间',
          'width': '120px',
          'show': true
        }, {
          'key': 'successTime',
          'label': '退款成功时间',
          'width': '120px',
          'show': true
        }, {
          'key': 'amount',
          'label': '退款金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'status',
          'label': '状态',
          'width': '50px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注',
          'width': '80px',
          'show': true
        }],
        tableOption: {
          stripe: true
        },
        column2: [{
          'key': 'waybillCode',
          'label': '运单号',
          'width': '140px',
          'show': true
        }, {
          'key': 'taskCode',
          'label': '任务编码',
          'width': '130px',
          'show': true
        }, {
          'key': 'driverName',
          'label': '用户名',
          'width': '80px',
          'show': true
        }, {
          'key': 'amount',
          'label': '金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'finesTime',
          'label': '扣款时间',
          'width': '120px',
          'show': true
        }, {
          'key': 'finesReason',
          'label': '扣款原因',
          'width': '120px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注',
          'width': '120px',
          'show': true
        }],
        column3: [{
          'key': 'payTradeNo',
          'label': '交易单号',
          'width': '220px',
          'show': true
        }, {
          'key': 'tradeNo',
          'label': '押金流水号',
          'width': '120px',
          'show': true
        }, {
          'key': 'createTime',
          'label': '付款时间',
          'width': '120px',
          'show': true
        }, {
          'key': 'payType',
          'label': '交易渠道',
          'width': '70px',
          'show': true
        }, {
          'key': 'businessType',
          'label': '交易类型',
          'width': '70px',
          'show': true
        }, {
          'key': 'amount',
          'label': '金额',
          'width': '90px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注',
          'width': '100px',
          'show': true
        }]
      }
    },
    mounted () {
    },
    methods: {
      // 格式化函数
      formatData (data) {
        switch (data.payType) {
          case 100:
            data.payType = '支付宝'
            break
          case 200:
            data.payType = '微信'
            break
          default:
            break
        };
        // 101：充值，102：退款
        switch (data.businessType) {
          case 101:
            data.businessType = '充值'
            break
          case 102:
            data.businessType = '退款'
            break
          default:
            break
        };
        // （100：待支付，200：成功, 300：失败）
        switch (data.status) {
          case 100:
            data.status = '待支付'
            break
          case 200:
            data.status = '成功'
            break
          case 300:
            data.status = '失败'
            break
          default:
            break
        };
        return data
      },
      toView (id, status) {
        this.refundList = []
        this.financeDriverFinesFeeVoList = []
        this.chargeList = []
        this.dialogFormVisible = true
        this.selectDriverRefundDetail(id)
        this.rowStatus = status
      },
      // 查看退款详情
      async selectDriverRefundDetail (id) {
        const tradeId = id + ''
        const data = await this.$http(URL.selectDriverRefundDetail, { tradeId: tradeId })
        this.refundList = data.refundList.map(this.formatData)
        this.financeDriverFinesFeeVoList = data.financeDriverFinesFeeVoList
        this.chargeList = data.chargeList.map(this.formatData)
      },
      // 发起退款
      async againRefund () {
        const data = await this.$http(URL.manualDepositRefund, { tradeId: this.row.id + '' })
        if (data) {
          this.$message({
            message: data,
            type: 'success'
          })
        } else {
          this.$message({
            showClose: true,
            message: '操作失败'
          })
        }
        this.dialogFormVisible = false
        this.$emit.reload('refund')
      }
    }
  }
</script>
<style lang="scss" scoped>
  .listTitle {
    font-size: 16px;
    color: #c4c7cd;
    height: 28px;
    line-height: 28px;
  }
  .dialog-footer {
    text-align: center;
  }
  .popupTitle {
    margin-top: 16px;
    margin-bottom: 8px;
    font-size: 14px;
    font-weight: bold;
    height: 28px;
    line-height: 28px;
    color: #333;
    i {
      display: inline-block;
      border-radius: 50%;
      background-color: #ff9300;
      width: 8px;
      height: 8px;
      margin-right: 12px;
    }
  }
</style>

