<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              size="mini"
              label-width="auto">
      <kye-form-item label="完结时间">
        <kye-date-picker v-model="form.finishTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="任务编码">
        <kye-input v-model="form.taskCode"></kye-input>
      </kye-form-item>
      <kye-form-item label="主体公司全称">
        <kye-input v-model="form.subjectCompanyName"></kye-input>
      </kye-form-item>
      <kye-form-item label="主体公司编码">
        <kye-input v-model="form.subjectCompanyNo"></kye-input>
      </kye-form-item>
      <kye-button type="primary"
                  class="kye-button--primary kye-button--mini"
                  :auth="URL.getPlatformWayBillList"
                  @click="submitForm('ruleForm')"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <div class="query-table-container"
         v-loading="loading">
      <table-list :column="column"
                  ref="canvas"
                  :data="tableData"
                  :operation="operation"
                  :options="tableOption"></table-list>
    </div>
    <div>
      <kye-pagination style="margin-top:10px"
                      layout="sizes,total,prev,pager,next"
                      background
                      :total="total"
                      :page-sizes="[200]"
                      class="fixedPagination"
                      :current-page="page"
                      :page-size.sync="size"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange">
      </kye-pagination>
    </div>
    <!-- 修改发送弹窗 -->
    <change-money ref="child"
                  @submitForm='submitForm'></change-money>
  </div>
</template>
<script>
  import URL from '../check.api'
  // 三级地址拼接
  import { formatData } from '../../../utils/formatData'
  // 引入修改弹窗
  import changeMoney from './change-money'
  export default {
    components: { changeMoney },
    data () {
      return {
        URL,
        loading: false,
        auditStatus: true, // 审核
        option: {
          back: '/ecms/financial/check'
        },
        form: {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
          subjectCompanyName: '', // 主体公司全称
          subjectCompanyNo: '' // 主体公司编码
        },
        searchParam: {
          billId: '',
          finishStartTime: '', // 完结开始时间
          finishEndTime: '', // 完结结束时间
          taskCode: '', // 任务编码
          subjectCompanyName: '', // 主体公司全称
          subjectCompanyNo: '', // 主体公司编码
          forceCache: true, // 强制刷新标准
          size: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        tableData: [],
        total: 0,
        page: 0,
        size: 200,
        paperStatus: '每页显示200条', // 分页条数
        multipleSelection: [],
        flowId: '', // 识别ID
        operation: {
          label: '操作',
          fixed: 'left',
          width: 40,
          // 操作按钮数组  array | function(row){return []}
          options: [
            {
              label: '修改',
              btnType: 'text', // el-button type
              auth: URL.updatePlatformBillFeeInfo,
              disabled: row => {
                return this.auditStatus
              },
              func: row => {
                this.$refs.child.toView(row, 'platform')
              }
            }
          ]
        },
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_finance',
        },
        column: [{
          'key': 'reportTime',
          'label': '承运时间',
          'width': '120px',
          'filter': 'time',
          'show': true
        }, {
          'key': 'finishTime',
          'label': '完结时间',
          'width': '120px',
          'filter': 'time',
          'show': true
        }, {
          'key': 'taskCode',
          'label': '任务编码',
          'width': '110px',
          'show': true
        },
        {
          'key': 'provenance',
          'label': '始发地',
          'width': '110px',
          'show': true
        }, {
          'key': 'destination',
          'label': '目的地',
          'width': '110px',
          'show': true
        },
        {
          'key': 'subjectCompanyNo',
          'label': '主体公司编码',
          'width': '90px',
          'show': true
        },
        {
          'key': 'subjectCompanyName',
          'label': '主体公司全称',
          'width': '100px',
          'show': true
        },
        {
          'key': 'carPlateNum',
          'label': '车牌号',
          'width': '80px',
          'show': true
        },
        {
          'key': 'originalPayFee',
          'label': '总金额',
          'filter': 'money',
          'width': '80px',
          'show': true
        },
        {
          'key': 'payFee',
          'label': '支付金额',
          'filter': 'money',
          'width': '80px',
          'show': true
        },
        {
          'key': 'remark',
          'label': '备注',
          'width': '120px',
          'show': true
        }]
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (!vm.$route.meta.layout) {
          vm.getPlatformWayBillList()
        } else {
          return false
        }
      })
    },
    methods: {
      // 列表
      async getPlatformWayBillList (params) {
        this.flowId = this.$route.query.flowId
        const val = params || { ...this.searchParam, billId: this.flowId }
        const data = await this.$http(URL.getPlatformWayBillList, val)
        this.total = data.total
        this.size = data.size
        this.page = data.page
        // 缓存：预加载下一页
        if (this.total > 0 && this.total > this.page * this.size) {
          let preData = { ...val, page: this.page + 1 }
          delete preData.forceCache
          this.$http(URL.getPlatformWayBillList, preData, false)
        }
        if (data.pageResp.rows) {
          this.tableData = data.pageResp.rows.map(formatData)
          if (data.auditStatus === 100 || data.auditStatus === 102) {
            this.auditStatus = false
          } else {
            this.auditStatus = true
          }
        } else {
          this.tableData = []
        }
      },
      // // 格式化函数
      // formatData (data) {
      //   data.provenance = data.startProvince + data.startCity + data.startArea// 始发地
      //   data.destination = data.endProvince + data.endCity + data.endArea// 目的地
      //   return data
      // },
      // 提交表单
      submitForm (formName) {
        const form = this.form
        const finishStartTime = new Date(form.finishTime[0]).getTime()
        const finishEndTime = new Date(form.finishTime[1]).getTime()
        this.searchParam.billId = this.flowId
        this.searchParam.size = this.size
        this.searchParam.finishStartTime = finishStartTime // 完结开始时间
        this.searchParam.finishEndTime = finishEndTime // 完结结束时间
        this.searchParam.taskCode = form.taskCode // 任务编码
        this.searchParam.subjectCompanyName = form.subjectCompanyName // 主体公司全称
        this.searchParam.subjectCompanyNo = form.subjectCompanyNo // 主体公司编码
        let params2 = { ...this.searchParam }
        params2.forceCache = true
        this.getPlatformWayBillList(params2)
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        this.form = {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
          subjectCompanyName: '', // 主体公司全称
          subjectCompanyNo: '' // 主体公司编码
        }
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          size: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.getPlatformWayBillList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          size: this.size,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.getPlatformWayBillList(params)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .top14 {
    margin-top: 14px;
  }
  .submit {
    display: inline-block;
    margin-top: 36px;
  }
  .reset {
    border: none;
  }
  .reset:hover {
    background-color: transparent;
  }
  .kye-col {
    padding-left: 4px;
    padding-right: 4px;
  }
  .wbyl-mt16 {
    margin-top: 10px;
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .input-width-l {
    width: 170px;
  }
  .ky-erp .el-form-item--mini.el-form-item {
    margin-bottom: 4px;
  }
</style>
