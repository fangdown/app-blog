const perfix = 'ecs.finance.'
const URL = {
  // 司机类型总账单
  getDriverTotalBillList: `${perfix}driverbill.getDriverTotalBillList.do`,
  // 司机类型所属公司主体账单
  getDriverPayCompanyBillList: `${perfix}driverbill.getDriverPayCompanyBillList.do`,
  // 司机类型运单维度列表
  getPersonalDriverWayBillList: `${perfix}driverbill.getPersonalDriverWayBillList.do`,
  // 司机类型总账单详情
  getDriverTotalBillDetail: `${perfix}driverbill.getDriverTotalBillDetail.do`,
  // 按账单ID查询司机类型主体公司列表
  getDriverPayCompanyBillListByBillId: `${perfix}driverbill.getDriverPayCompanyBillListByBillId.do`,
  // 司机类型导入共生账单接口
  updateWayBillStatus: `${perfix}driverbill.updateWayBillStatus.do`,
  // 导出司机对账单
  exportDriverBill: `${perfix}driverbill.exportDriverBill.do`,
  //
  // 企业类型总账单
  getCompanyTotalBillList: `${perfix}companybill.getCompanyTotalBillList.do`,
  // 企业类型公司主体账单
  getCompanyPayCompanyBillList: `${perfix}companybill.getCompanyPayCompanyBillList.do`,
  // 企业类型运单维度列表
  getCompanyWayBillList: `${perfix}companybill.getCompanyWayBillList.do`,
  // 企业类型总账单详情
  getCompanyTotalBillDetail: `${perfix}companybill.getCompanyTotalBillDetail.do`,
  // 按账单ID查询企业类型主体公司列表
  getCompanyPayCompanyBillListByBillId: `${perfix}companybill.getCompanyPayCompanyBillListByBillId.do`,
  // 企业类型客服审批
  updateCompanyTotalBill: `${perfix}companybill.updateCompanyTotalBill.do`,
  // 导出企业对账单
  exportCompanyBill: `${perfix}companybill.exportCompanyBill.do`,
  // 非合同企业修改费用
  updateCompanyBillFeeInfo: `${perfix}companybill.updateCompanyBillFeeInfo.do`,
  // 非合同企业账单管理一审
  auditFirstCompanyTotalBill: `${perfix}companybill.auditFirstCompanyTotalBill.do`,
  // 非合同企业账单管理驳回
  auditRejectCompanyTotalBill: `${perfix}companybill.auditRejectCompanyTotalBill.do`,
  //
  // 平台类型公司（第一维度）
  getPlatformTotalBillList: `${perfix}platformbill.getPlatformTotalBillList.do`,
  // 平台类型客服审批
  updatePlatformTotalBill: `${perfix}platformbill.updatePlatformTotalBill.do`,
  // 平台类型运单维度列表
  getPlatformWayBillList: `${perfix}platformbill.getPlatformWayBillList.do`,
  // 平台类型总账单详情
  getPlatformTotalBillDetail: `${perfix}platformbill.getPlatformTotalBillDetail.do`,
  // 平台对账单详情里的主体账单列表
  getPlatformPayCompanyBillListByBillId: `${perfix}platformbill.getPlatformPayCompanyBillListByBillId.do`,
  // 导出平台对账单
  exportPlatformBill: `${perfix}platformbill.exportPlatformBill.do`,
  // 平台类型修改费用
  updatePlatformBillFeeInfo: `${perfix}platformbill.updatePlatformBillFeeInfo.do`,
  // 平台类型账单管理一审
  auditFirstPlatformTotalBill: `${perfix}platformbill.auditFirstPlatformTotalBill.do`,
  // 平台类型账单管理驳回
  auditRejectPlatformTotalBill: `${perfix}platformbill.auditRejectPlatformTotalBill.do`,
  //
  // 合同运力总账单（第一维度账单）
  getContractTotalBillList: `${perfix}contractbill.getContractTotalBillList.do`,
  // 合同运力运单维度账单(第二维度账单)
  getContractWayBillList: `${perfix}contractbill.getContractWayBillList.do`,
  // 合同运力账单客服审批
  updateContractTotalBill: `${perfix}contractbill.updateContractTotalBill.do`,
  // 合同运力对账单详情
  getContractTotalBillDetail: `${perfix}contractbill.getContractTotalBillDetail.do`,
  // 合同运力对账单详情的主体账单列表
  getContractPayCompanyBillByBillId: `${perfix}contractbill.getContractPayCompanyBillListByBillId.do`,
  // 合同运力对账单导出
  exportContractBill: `${perfix}contractbill.exportContractBill.do`,
  // base64上传文件接口
  uploadBase64Files: `zc.system.uploadBase64.do`,
  // 发送平台对账邮件
  sendPlatformBillEmail: `${perfix}platformbill.sendPlatformBillEmail.do`,
  // 发送合同对账邮件
  sendContractBillEmail: `${perfix}contractbill.sendContractBillEmail.do`,
  // 合同类型修改费用
  updateContractBillFeeInfo: `${perfix}contractbill.updateContractBillFeeInfo.do`,
  // 合同类型账单管理一审
  auditFirstContractTotalBill: `${perfix}contractbill.auditFirstContractTotalBill.do`,
  // 合同类型账单管理驳回
  auditRejectContractTotalBill: `${perfix}contractbill.auditRejectContractTotalBill.do`,
}
export default URL


