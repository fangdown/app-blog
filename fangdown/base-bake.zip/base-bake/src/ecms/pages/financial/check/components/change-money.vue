<template>
  <div>
    <kye-dialog title="修改账单"
                :visible.sync="dialogFormVisible"
                append-to-body
                width='500px'>
      <kye-form size="mini"
                labkye-position="left"
                :model="rulesForm"
                :rules="rules"
                ref="ruleForm">
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="任务编码">
              <kye-input v-model="rulesForm.taskCode"
                         :disabled="true"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="支付金额">
              <kye-number v-model="rulesForm.payFee"
                          symbol="￥"
                          unit=""
                          :max="1000000"
                          :min="-1000000">
              </kye-number>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input v-model="rulesForm.remark"></kye-input>
          </kye-form-item>
        </kye-row>
      </kye-form>
      <div slot="footer">
        <kye-button type="primary"
                    @click="againRefund()">保存</kye-button>
        <kye-button @click="cancel">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from '../check.api'
  export default {
    // props: {
    //   row: Object,
    //   default () {
    //     return {
    //     }
    //   }
    // },
    data () {
      var checkAge = (rule, value, callback) => {
        const remark = this.strlen(value)
        if (!value) {
          return callback(new Error('备注不能为空'))
        }
        if (remark > 30) {
          return callback(new Error('备注长度不能超过15个字'))
        } else {
          callback()
        }
      }
      return {
        className: '',
        rulesForm: {
          taskCode: '',
          payFee: '',
          remark: '',
        },
        rules: {
          remark: [
            { validator: checkAge, trigger: 'blur' }
          ]
        },
        URL,
        dialogFormVisible: false,
      }
    },
    mounted () {
    },
    methods: {
      toView (row, className) {
        this.rulesForm.remark = ''
        this.rulesForm.payFee = ''
        this.rulesForm.taskCode = ''
        this.dialogFormVisible = true
        this.rulesForm.taskCode = row.taskCode
        this.rulesForm.payFee = row.payFee
        this.rulesForm.id = row.id
        this.className = className
      },
      strlen (str) {
        var len = 0
        for (var i = 0; i < str.length; i++) {
          var val = str.charCodeAt(i)
          // 单字节加1
          if ((val >= 0x0001 && val <= 0x007e) || (val >= 0xff60 && val <= 0xff9f)) {
            len++
          } else {
            len += 2
          }
        }
        return len
      },
      againRefund () {
        this.$refs.ruleForm.validate(async (valid) => {
          if (valid) {
            const val = {
              'id': this.rulesForm.id,
              'payFee': this.rulesForm.payFee,
              'remark': this.rulesForm.remark
            }
            this.$refs.ruleForm.resetFields()
            const className = this.className
            if (className === 'enterprise') {
              const data = await this.$http(URL.updateCompanyBillFeeInfo, val)
              if (data) {
                this.infoWay(className)
              }
            } else if (className === 'platform') {
              const data = await this.$http(URL.updatePlatformBillFeeInfo, val)
              if (data) {
                this.infoWay(className)
              }
            } else if (className === 'contract') {
              const data = await this.$http(URL.updateContractBillFeeInfo, val)
              if (data) {
                this.infoWay(className)
              }
            }
          } else {
            return false
          }
        })
      },
      infoWay () {
        this.dialogFormVisible = false
        this.$emit('submitForm')
        this.$bus.$emit('GLOBAL_RESIZE')
        this.$store.commit('ecms/SET_ECS_FINACE_ENTERPRISE', 1)
        this.$message({
          showClose: true,
          message: '保存成功',
          type: 'success',
          onClose: () => {
          }
        })
      },
      // 点击取消
      cancel () {
        this.dialogFormVisible = false
        this.$refs.ruleForm.resetFields()
      },
    }
  }
</script>

