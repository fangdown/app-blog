<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              label-width="auto">
      <kye-form-item label="签收月份">
        <kye-date-picker v-model="form.signTime"
                         size="mini"
                         class="input-width-l"
                         type="month">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="应付编号">
        <kye-input v-model="form.kyePayNo"></kye-input>
      </kye-form-item>
      <kye-form-item label="公司编码">
        <kye-input v-model="form.payCompanyNo"></kye-input>
      </kye-form-item>
      <kye-form-item label="公司全称">
        <kye-input v-model="form.payCompanyName"></kye-input>
      </kye-form-item>
      <kye-button type="primary"
                  :auth="URL.getCompanyPayCompanyBillList"
                  @click="submitForm('ruleForm')"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <kye-canvas-table :stripe="true"
                      :isScroll="true"
                      :column="column"
                      :data="tableData"
                      :page="page"
                      @row-dblclick="handleDetail"
                      @row-edit="fixedRightClick" />
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="sizes,total,prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      class="fixedPagination"
                      :current-page="page.currentPage"
                      :page-size.sync="page.pageSize"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  // 端口请求
  import URL from '../check.api'
  // 格式化文件
  import * as utils from '../../../utils'
  export default {
    data () {
      return {
        URL,
        loading: false,
        option: {
          back: '/ecms/financial/check'
        },
        form: {
          payCompanyName: '', // 跨越公司主体
          signTime: '', // 签收月份
          payCompanyNo: '', // 跨越公司主体编码
          kyePayNo: '' // 应付编码
        },
        searchParam: {
          billId: '',
          payCompanyName: '', // 跨越公司主体
          payCompanyNo: '', // 跨越公司主体编码
          signTime: '', // 签收月份
          kyePayNo: '', // 应付编码
          forceCache: true, // 强制刷新标准
          size: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        tableData: [],
        page: {
          pageSize: 200,
          currentPage: 1,
          total: 1
        },
        pageSizes: [200],
        paperStatus: '每页显示200条', // 分页条数
        multipleSelection: [],
        flowId: '', // 识别ID
        column: [
          {
            key: 'signTime',
            label: '签收月份',
            show: true,
            width: '90px',
          },
          {
            key: 'kyePayNo',
            label: '应付编号',
            show: true,
            width: '125px',
          },
          {
            key: 'wayAmount',
            label: '运单数(单)',
            show: true,
            width: '80px',
          },
          {
            key: 'payCompanyNo',
            label: '公司编码',
            show: true,
            width: '90px',
          },
          {
            key: 'payCompanyName',
            label: '公司全称',
            show: true,
            width: '75px'
          },
          {
            key: 'originalTotalFee',
            label: '总金额',
            'filter': 'money',
            show: true,
            width: '80px'
          },
          {
            key: 'totalFee',
            label: '支付金额',
            'filter': 'money',
            show: true,
            width: '80px'
          },
          {
            key: 'payStatus',
            label: '付款状态',
            show: true,
            width: '75px'
          }
        ],
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          const list = vm.$route.query.flowId
          if (list) {
            vm.flowId = list
            vm.getCompanyPayCompanyBillList()
          } else {
            return false
          }
        } else {
          return false
        }
      })
    },
    methods: {
      // 列表
      async getCompanyPayCompanyBillList (params) {
        const val = params || { ...this.searchParam, billId: this.flowId }
        const data = await this.$http(URL.getCompanyPayCompanyBillList, val)
        this.page.total = data.total
        this.page.pageSize = data.size
        this.page.currentPage = data.page
        // 缓存：预加载下一页
        if (this.total > 0 && this.total > this.page * this.size) {
          let preData = { ...val, page: this.page + 1 }
          delete preData.forceCache
          this.$http(URL.getCompanyPayCompanyBillList, preData, false)
        }
        if (data.rows) {
          this.tableData = data.rows.map(this.formatData)
        } else {
          this.tableData = []
        }
      },
      // 格式化函数
      formatData (data) {
        data.signTime = utils.formatTime(data.signTime, 'Month')
        switch (data.payStatus) {
          case 100:
            data.payStatus = '未付款'
            break
          case 200:
            data.payStatus = '已付款'
            break
          default:
            break
        };
        return data
      },
      fixedRightClick (row, column, value, btn) {
        this.handleDetail(row)
      },
      // 提交表单
      submitForm (formName) {
        const form = this.form
        const signTime = new Date(form.signTime).getTime()
        this.searchParam.billId = this.flowId
        this.searchParam.payCompanyName = form.payCompanyName // 跨越公司主体
        this.searchParam.payCompanyNo = form.payCompanyNo // 跨越公司主体编码
        this.searchParam.signTime = signTime // 签收月份
        this.searchParam.kyePayNo = form.kyePayNo // 应付编码
        this.searchParam.page = this.page.currentPage
        this.searchParam.size = this.page.pageSize
        let params2 = { ...this.searchParam }
        params2.forceCache = true
        this.getCompanyPayCompanyBillList(params2)
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        const form = this.form
        form.payCompanyName = '' // 跨越公司主体
        form.signTime = '' // 签收月份
        form.payCompanyNo = '' // 跨越公司主体编码
        form.kyePayNo = '' // 应付编码
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          size: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.getCompanyPayCompanyBillList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          size: this.page.pageSize,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.getCompanyPayCompanyBillList(params)
      },
      // 查看运单详情
      handleDetail (row) {
        // 保存ID
        this.$router.push({ path: '/ecms/financial/check-enterprise-waybill-detail', query: { flowId: row.id } })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .top14 {
    margin-top: 14px;
  }
  .kye-col {
    padding-left: 4px;
    padding-right: 4px;
  }
  .wbyl-mt16 {
    margin-top: 10px;
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .input-width-l {
    width: 110px;
  }
  .input-width-m {
    width: 90px;
  }
  .ky-erp .el-form-item--mini.el-form-item {
    margin-bottom: 4px;
  }
</style>
