<template>
  <div>
    <search-pager :tools="queryTables[activeName].formTools"></search-pager>
    <kye-tabs v-model="activeName"
              @tab-click="tabClick">
      <kye-tab-pane label="个体司机"
                    name="driver">
        <div class="tab-content">
          <query-table ref="driverTable"
                       :generic="queryTables.driver.generic"
                       :option="queryTables.driver.option"
                       :form-model="queryTables.driver.formModel"
                       :tools="queryTables.driver.tools"
                       :tables="queryTables.driver.tables">
            <div slot="desc">
              <div class="audit"
                   id="driver">
                <el-upload class="upload-demo wbyl-uploadClass"
                           action="/router/upload"
                           :limit="1"
                           :headers="{'content-type': 'multipart/form-data', method:'zc.upload.do'}"
                           :before-upload="beforeUploadPapersPic"
                           :on-success="upContractPicSuccess"
                           :disabled="uploadDisable"
                           accept=".xls,.xlsx">
                  <kye-button size="small"
                              type="text"
                              :disabled="uploadDisable"
                              icon="iconfont icon-import">导入账单
                  </kye-button>
                </el-upload>
              </div>
            </div>
          </query-table>
        </div>
      </kye-tab-pane>
      <kye-tab-pane label="非合同企业"
                    name="enterprise">
        <div class="tab-content">
          <query-table ref="enterpriseTable"
                       :generic="queryTables.enterprise.generic"
                       :option="queryTables.enterprise.option"
                       :form-model="queryTables.enterprise.formModel"
                       :tools="queryTables.enterprise.tools"
                       :tables="queryTables.enterprise.tables">
            <div slot="desc">
              <div class="audit">
                <kye-button type="text"
                            :disabled='enterpriseBtn1'
                            :auth="URL.auditFirstCompanyTotalBill"
                            @click="firstAuditBtn('enterprise')"
                            icon="iconfont icon-ecs-shenhe">一审
                </kye-button>
                <kye-button type="text"
                            :disabled='enterpriseBtn2'
                            :auth="URL.auditRejectCompanyTotalBill"
                            @click="rejectBtn('enterprise')"
                            icon="iconfont icon-ecs-fanshen">驳回
                </kye-button>
                <kye-button type="text"
                            :disabled='enterpriseBtn3'
                            :auth="URL.updateCompanyTotalBill"
                            @click="auditBtn('enterprise')"
                            icon="iconfont icon-ecs-shenhe">终审
                </kye-button>
                <span class="auditText">注：以下费用均为含税价</span>
              </div>
            </div>
          </query-table>
        </div>
      </kye-tab-pane>
      <kye-tab-pane label="平台月结"
                    name="platform">
        <div class="tab-content">
          <query-table ref="platformTable"
                       :generic="queryTables.platform.generic"
                       :option="queryTables.platform.option"
                       :form-model="queryTables.platform.formModel"
                       :tools="queryTables.platform.tools"
                       :tables="queryTables.platform.tables">
            <div slot="desc">
              <div class="audit">
                <kye-button type="text"
                            :disabled='platformBtn1'
                            :auth="URL.auditFirstPlatformTotalBill"
                            @click="firstAuditBtn('platform')"
                            icon="iconfont icon-ecs-shenhe">一审
                </kye-button>
                <kye-button type="text"
                            :disabled='platformBtn2'
                            :auth="URL.auditRejectPlatformTotalBill"
                            @click="rejectBtn('platform')"
                            icon="iconfont icon-ecs-fanshen">驳回
                </kye-button>
                <kye-button type="text"
                            :disabled='platformBtn3'
                            :auth="URL.updatePlatformTotalBill"
                            @click="auditBtn('platform')"
                            icon="iconfont icon-ecs-shenhe">终审
                </kye-button>
                <kye-button type="text"
                            :disabled='platformBtn'
                            :auth="URL.sendPlatformBillEmail"
                            @click="mail('platform')">
                  <i class="iconfont icon-ecs-tuidan"></i>发送邮件
                </kye-button>
                <span class="auditText">注：以下费用均为含税价</span>
              </div>
            </div>
          </query-table>
        </div>
      </kye-tab-pane>
      <kye-tab-pane label="合同运力"
                    name="contract">
        <div class="tab-content">
          <query-table ref="contractTable"
                       :generic="queryTables.contract.generic"
                       :option="queryTables.contract.option"
                       :form-model="queryTables.contract.formModel"
                       :tools="queryTables.contract.tools"
                       :tables="queryTables.contract.tables">
            <div slot="desc">
              <div class="audit">
                <kye-button type="text"
                            :disabled='contractBtn1'
                            :auth="URL.auditFirstContractTotalBill"
                            @click="firstAuditBtn('contract')"
                            icon="iconfont icon-ecs-shenhe">一审
                </kye-button>
                <kye-button type="text"
                            :disabled='contractBtn2'
                            :auth="URL.updateContractTotalBill"
                            @click="rejectBtn('contract')"
                            icon="iconfont icon-ecs-fanshen">驳回
                </kye-button>
                <kye-button type="text"
                            :disabled='contractBtn3'
                            :auth="URL.auditRejectContractTotalBill"
                            @click="auditBtn('contract')"
                            icon="iconfont icon-ecs-shenhe">终审
                </kye-button>
                <kye-button type="text"
                            :disabled='contractBtn'
                            :auth="URL.sendContractBillEmail"
                            @click="mail('contract')">
                  <i class="iconfont icon-ecs-tuidan"></i>发送邮件
                </kye-button>
                <span class="auditText">注：以下费用均为含税价</span>
              </div>
            </div>
          </query-table>
        </div>
      </kye-tab-pane>
    </kye-tabs>
    <!-- 邮件发送弹窗 -->
    <email ref="child"></email>
  </div>
</template>
<script>
  import URL from './check.api'
  // vuex，获取当前菜单对象
  import store from 'public/store'
  // 引入邮件弹窗
  import email from './components/email'
  export default {
    components: { email },
    data () {
      return {
        URL,
        enterpriseBtn1: true,
        enterpriseBtn2: true,
        enterpriseBtn3: true,
        platformBtn1: true,
        platformBtn2: true,
        platformBtn3: true,
        platformBtn: false,
        contractBtn1: true,
        contractBtn2: true,
        contractBtn3: true,
        contractBtn: false,
        loading: false,
        enterpriseArray: [], // 非合同企业多选框
        platformArray: [], // 平台多选框
        contractArray: [], // 合同多选框
        enterpriseMail: [], // 非合同企业邮件
        platformMail: [], // 平台邮件
        contractMail: [], // 合同邮件
        activeName: 'driver',
        uploadDisable: true,
        queryTables: {
          // 个体司机
          driver: {
            selectedRow: null,
            generic: {
              method: URL.getDriverTotalBillList,
              searchCode: 'ecs_cw_driver_list_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.getDriverTotalBillList,
                func: () => this.reload('driver')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('driver')
              }
            ],
            option: {
              searchCode: 'ecs_cw_driver_list_search_define'
            },
            tools: [],
            formModel: {
              commitTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tables: [
              {
                searchCode: 'ecs_cw_driver_list_field',
                url: { method: URL.getDriverTotalBillList },
                operation: { // 可选，可操作列
                  label: '操作',
                  fixed: 'right',
                  width: '60px',
                  options: [ // 操作按钮数组  array | function(row){return []}
                    {
                      type: 'link', // link | button
                      label: '打印账单',
                      auth: URL.getDriverTotalBillDetail,
                      func: row => {
                        this.billDetail(row, 'Driver')
                      }
                    },
                  ]
                },
                option: {
                  label: '个体司机',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.getDriverPayCompanyBillList,
                  currentChange: (row) => {
                    this.queryTables['driver'].selectedRow = row
                  },
                  rowDblClick:
                    row => {
                      this.driverDetail(row)
                    },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) { Object.assign(data, obj) } else { return true }
                  },
                },
                formatter: {
                  taxRate: (row, column, val) => { return val * 100 }
                }
              }
            ]
          },
          // 非合同企业
          enterprise: {
            selectedRow: null,
            generic: {
              method: URL.getCompanyTotalBillList, // 调试
              searchCode: 'ecs_cw_enterprise_list_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.getCompanyTotalBillList,
                func: () => this.reload('enterprise')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('enterprise')
              }
            ],
            option: {
              searchCode: 'ecs_cw_enterprise_list_search_define'
            },
            tools: [],
            formModel: {
              commitTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tables: [
              {
                searchCode: 'ecs_cw_enterprise_list_filed',
                url: { method: URL.getCompanyTotalBillList },
                operation: { // 可选，可操作列
                  label: '操作',
                  fixed: 'right',
                  width: '60px',
                  options: [ // 操作按钮数组  array | function(row){return []}
                    {
                      type: 'link', // link | button
                      label: '打印账单',
                      auth: URL.getCompanyTotalBillDetail,
                      func: row => {
                        this.billDetail(row, 'Enterprise')
                      }
                    },
                  ]
                },
                option: {
                  type: 'selection',
                  label: '非合同企业',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.getCompanyPayCompanyBillList,
                  // idKey: 'order.id',
                  beforeHttp: (data) => {

                  },
                  rowDblClick: (row) => this.enterpriseDetail(row),
                  currentChange: (row) => {
                    this.queryTables['enterprise'].selectedRow = row
                  },
                  selectionChange: (val) => {
                    this.selectionChange(val, 'enterprise')
                  },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) { Object.assign(data, obj) } else { return true }
                  },
                },
                formatter: {
                  taxRate: (row, column, val) => { return val * 100 }
                }
              }
            ]
          },
          // 平台月结
          platform: {
            selectedRow: null,
            generic: {
              method: URL.getPlatformTotalBillList,
              searchCode: 'ecs_cw_platform_list_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.getPlatformTotalBillList,
                func: () => this.reload('platform')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('platform')
              }
            ],
            option: {
              searchCode: 'ecs_cw_platform_list_search_define'
            },
            tools: [],
            formModel: {
              commitTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tables: [
              {
                searchCode: 'ecs_cw_platform_list_filed',
                url: { method: URL.getPlatformTotalBillList },
                operation: { // 可选，可操作列
                  label: '操作',
                  fixed: 'right',
                  width: '60px',
                  options: [ // 操作按钮数组  array | function(row){return []}
                    {
                      type: 'link', // link | button
                      label: '打印账单',
                      auth: URL.getPlatformTotalBillList,
                      func: row => {
                        this.billDetail(row, 'Platform')
                      }
                    },
                  ]
                },
                option: {
                  type: 'selection',
                  label: '平台月结',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.getPlatformWayBillList,
                  // idKey: 'order.id',
                  beforeHttp: (data) => {

                  },
                  rowDblClick: (row) => this.platformDetail(row),
                  currentChange: (row) => {
                    this.queryTables['platform'].selectedRow = row
                  },
                  selectionChange: (val) => {
                    this.selectionChange(val, 'platform')
                  },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) { Object.assign(data, obj) } else { return true }
                  },
                },
                formatter: {
                  taxRate: (row, column, val) => { return val * 100 }
                }
              }
            ]
          },
          // 合同运力
          contract: {
            selectedRow: null,
            generic: {
              method: URL.getCompanyTotalBillList,
              searchCode: 'ecs_cw_contract_list_search_define'
            },
            formTools: [
              {
                label: '刷新',
                icon: 'reset',
                auth: URL.getCompanyTotalBillList,
                func: () => this.reload('contract')
              },
              {
                label: '个性设置',
                icon: 'custom',
                func: () => this.showDragDialog('contract')
              }
            ],
            option: {
              searchCode: 'ecs_cw_contract_list_search_define'
            },
            tools: [],
            formModel: {
              commitTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
            },
            tables: [
              {
                searchCode: 'ecs_cw_contract_list_filed',
                url: { method: URL.getContractTotalBillList },
                operation: { // 可选，可操作列
                  label: '操作',
                  fixed: 'right',
                  width: '60px',
                  options: [ // 操作按钮数组  array | function(row){return []}
                    {
                      type: 'link', // link | button
                      label: '打印账单',
                      auth: URL.getContractTotalBillList,
                      func: row => {
                        this.billDetail(row, 'contract')
                      }
                    },
                  ]
                },
                option: {
                  type: 'selection',
                  label: '合同运力',
                  load: false,
                  stripe: true,
                  moduleCode: 'ecs_finance',
                  detailAuth: URL.getContractWayBillList,
                  // idKey: 'order.id',
                  beforeHttp: (data) => {

                  },
                  rowDblClick: (row) => this.contractDetail(row),
                  currentChange: (row) => {
                    this.queryTables['contract'].selectedRow = row
                  },
                  selectionChange: (val) => {
                    this.selectionChange(val, 'contract')
                  },
                  beforeFormSubmit: (data, model) => {
                    const obj = this.time(data, model)
                    if (obj.constructor === Object) { Object.assign(data, obj) } else { return true }
                  },
                },
                formatter: {
                  taxRate: (row, column, val) => { return val * 100 }
                }
              }
            ]
          }
        }
      }
    },
    created () {
      const menus = store.getters.permission.menus
      this.uploadDisable = !menus.includes(URL.updateWayBillStatus)
    },
    methods: {
      tabClick (val) {
        this.$refs[`${val.name}Table`].setCanvas()
      },
      reload (type) {
        if (type === 'enterprise') {
          this.$refs.enterpriseTable.loadData()
        } else if (type === 'driver') {
          this.$refs.driverTable.loadData()
        } else if (type === 'platform') {
          this.$refs.platformTable.loadData()
        } else if (type === 'contract') {
          this.$refs.contractTable.loadData()
        }
      },
      showDragDialog (type) {
        if (type === 'enterprise') {
          this.$refs.enterpriseTable.showDragDialog()
        } else if (type === 'driver') {
          this.$refs.driverTable.showDragDialog()
        } else if (type === 'platform') {
          this.$refs.platformTable.showDragDialog()
        } else if (type === 'contract') {
          this.$refs.contractTable.showDragDialog()
        }
      },
      toDetail (row) {
      },
      // 时间处理
      time (data, model) {
        let isEmpty = true // 是否有条件
        const obj = {}
        // 没有选择时间时清空data里面startTime，endTime
        delete data.commitStartTime
        delete data.commitEndTime
        for (let key in model) {
          if (model[key]) {
            if (key === 'commitTime') {
              // 格式化时间
              if (model.commitTime && model.commitTime.length === 2) {
                const commitStartTime = new Date(model.commitTime[0]).getTime()
                const commitEndTime = new Date(model.commitTime[1]).getTime()
                Object.assign(obj, {
                  commitStartTime,
                  commitEndTime
                })
                isEmpty = false
              }
            } else {
              isEmpty = false
              obj[key] = model[key]
            }
          } else {
            delete data[key]
          }
        }
        if (isEmpty) {
          this.$message.warning('请输入查询条件')
          return true
        }
        return obj
      },
      driverDetail (row) { // 个体司机
        this.$router.push({ path: '/ecms/financial/check-driver-withdraw-detail', query: { flowId: row.id } })
      },
      billDetail (row, className) {
        this.$router.push({ path: '/ecms/financial/check-driver-bills', query: { flowId: row.id, className: className } })
      },
      enterpriseDetail (row) { // 非合同企业
        this.$router.push({ path: '/ecms/financial/check-enterprise-withdraw-detail', query: { flowId: row.id } })
      },
      platformDetail (row) { // 平台
        this.$router.push({ path: '/ecms/financial/check-platform-waybill-detail', query: { flowId: row.id } })
      },
      contractDetail (row) { // 合同运力
        this.$router.push({ path: '/ecms/financial/check-contract-waybill-detail', query: { flowId: row.id } })
      },
      // 上传表格
      async beforeUploadPapersPic (file) {
        const that = this
        let fileName = file.name.split('.')
        let suffix = fileName.length - 1
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = async function (e) {
          const val = { base64Code: this.result, suffix: '.' + fileName[suffix] }
          const data = await that.$http(URL.uploadBase64Files, val)
          that.fileUrl = {
            fileUrl: data
          }
          that.updateWayBillStatus()
        }
        return false
      },
      // 司机类型导入共生账单接口
      async updateWayBillStatus () {
        const val = this.fileUrl
        await this.$http(URL.updateWayBillStatus, val)
        this.$message({
          showClose: true,
          message: '上传成功，支付状态更新完毕',
          type: 'success',
          onClose: this.reload('driver')
        })
      },
      // 上传表格成功
      upContractPicSuccess (response, file, fileList) {
      },
      // 审核
      async auditBtn (className) {
        this.$confirm('是否进行费用审核?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          const array = this[className + 'Array']
          const val = {
            'billIdArray': array[0].id + ''
          }
          if (className === 'enterprise') {
            const data = await this.$http(URL.updateCompanyTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'platform') {
            const data = await this.$http(URL.updatePlatformTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'contract') {
            const data = await this.$http(URL.updateContractTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          }
        })
      },
      // 多选框
      selectionChange (arr, className) {
        this[className + 'Btn1'] = true
        this[className + 'Btn2'] = true
        this[className + 'Btn3'] = true
        this[className + 'Array'] = arr
        this[className + 'Mail'] = arr
        if (arr.length === 1) {
          // 进行状态判断
          if (arr[0].auditStatus === 100 || arr[0].auditStatus === 102) {
            this[className + 'Btn1'] = false
          } else if (arr[0].auditStatus === 101) {
            this[className + 'Btn2'] = false
            this[className + 'Btn3'] = false
          }
        } else {
          this[className + 'Btn1'] = true
          this[className + 'Btn2'] = true
          this[className + 'Btn3'] = true
        }
      },
      // 邮件
      mail (className) {
        const that = this
        this.$confirm('是否发送邮件?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          const array = this[className + 'Mail']
          if (array.length === 1) {
            const emailId = array[0].id
            // 发生请求
            this.$refs.child.toView(emailId, className)
          } else if (array.length === 0) {
            that.$message({
              showClose: true,
              message: '请选择需要发送邮件的账单',
              type: 'info',
              onClose: () => { }
            })
          } else {
            that.$message({
              showClose: true,
              message: '仅支持一个账单数据的发送',
              type: 'warning',
              onClose: () => { }
            })
          }
        })
      },
      // 一审
      firstAuditBtn (className) {
        this.$confirm('是否进行一审?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          const array = this[className + 'Array']
          const val = {
            'billId': array[0].id
          }
          if (className === 'enterprise') {
            const data = await this.$http(URL.auditFirstCompanyTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'platform') {
            const data = await this.$http(URL.auditFirstPlatformTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'contract') {
            const data = await this.$http(URL.auditFirstContractTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          }
        })
      },
      // 驳回
      rejectBtn (className) {
        this.$confirm('是否进行账单驳回?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          const array = this[className + 'Array']
          const val = {
            'billId': array[0].id
          }
          if (className === 'enterprise') {
            const data = await this.$http(URL.auditRejectCompanyTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'platform') {
            const data = await this.$http(URL.auditRejectPlatformTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          } else if (className === 'contract') {
            const data = await this.$http(URL.auditRejectContractTotalBill, val)
            if (data) {
              this.infoWay(className)
            }
          }
        })
      },
      // 操作完后提示
      infoWay (className) {
        this.reload(className)
        this.$message({
          showClose: true,
          message: '操作成功',
          type: 'success',
          onClose: () => {
          }
        })
      },
    }
  }
</script>
<style lang="scss">
  .query-table-container .query-form-wrap {
    margin: 4px 0 0 0;
  }
  #driver {
    height: 28px;
    .el-upload-list__item-name {
      font-size: 12px;
      /* height: 18px; */
    }
    .el-upload-list__item:first-child {
      margin: 0;
    }
    .el-upload-list {
      display: inline-block;
    }
    .kye-upload-list {
      display: inline-block;
    }
    .audit {
      font-size: 12px;
      color: #9571e9;
      line-height: 28px;
      height: 28px;
      text-align: left;
      overflow: hidden;
    }
  }
  .auditText {
    // float: right;
    color: #ff5555;
    // line-height: 28px;
    // margin-right: 300px;
  }
</style>
