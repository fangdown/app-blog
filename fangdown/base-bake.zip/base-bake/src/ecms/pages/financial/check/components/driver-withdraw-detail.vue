<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              size="mini"
              label-width="auto">
      <kye-form-item label="付款时间">
        <kye-date-picker v-model="form.payTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="签收月份">
        <kye-date-picker v-model="form.finishTime"
                         size="mini"
                         type="month"
                         class="input-width">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="应付编号">
        <kye-input v-model="form.keyPayNo"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-form-item label="付款状态">
        <kye-select v-model="form.payStatus"
                    placeholder=""
                    class="input-width-m">
          <kye-option label="全部"
                      value="0"></kye-option>
          <kye-option label="已付款"
                      value="200"></kye-option>
          <kye-option label="未付款"
                      value="100"></kye-option>
        </kye-select>
      </kye-form-item>
      <kye-button type="primary"
                  class="kye-button--primary kye-button--mini"
                  :auth="URL.getDriverPayCompanyBillList"
                  @click="submitForm('ruleForm')"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <div>
      <div class="query-table-container"
           v-loading="loading">
        <table-list :column="column"
                    ref="canvas"
                    :data="tableData"
                    :options="tableOption"></table-list>
      </div>
      <kye-pagination style="margin-top:10px"
                      layout="sizes,total,prev,pager,next"
                      background
                      :total="total"
                      :page-sizes="[200]"
                      class="fixedPagination"
                      :current-page="page"
                      :page-size.sync="pageSize"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  // 端口请求
  import URL from '../check.api'
  // 文件格式化
  import * as utils from '../../../utils'
  export default {
    data () {
      return {
        URL,
        loading: false,
        form: {
          payTime: [], // 付款时间
          finishTime: '', // 签收月份
          keyPayNo: '', // 下单编码
          payStatus: '' // 支付状态
        },
        searchParam: {
          billId: '',
          keyPayNo: '', // 应付编码
          payStatus: '', // 支付状态
          finishTime: '', // 签收月份
          payStartTime: '', // 签收开始时间
          payEndTime: '', // 签收结束时间
          pageSize: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        option: {
          back: '/ecms/financial/check'
        },
        tableData: [],
        total: 0,
        page: 0,
        pageSize: 200,
        paperStatus: '每页显示200条', // 分页条数
        multipleSelection: [],
        flowId: '', // 识别ID
        column: [{
          'key': 'finishTime',
          'label': '签收月份',
          'width': '90px',
          'show': true
        }, {
          'key': 'keyPayNo',
          'label': '应付编号',
          'width': '110px',
          'show': true
        }, {
          'key': 'wayAmount',
          'label': '任务数',
          'width': '60px',
          'show': true
        }, {
          'key': 'payCompanyNo',
          'label': '主体公司编码',
          'width': '110px',
          'show': true
        }, {
          'key': 'payCompanyName',
          'label': '主体公司全称',
          'width': '110px',
          'show': true
        }, {
          'key': 'payTime',
          'label': '付款时间',
          'width': '110px',
          'show': true
        }, {
          'key': 'totalFee',
          'label': '含税总金额',
          'width': '110px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'totalWayFee',
          'label': '总运费',
          'filter': 'money',
          'width': '90px',
          'show': true
        }, {
          'key': 'totalServiceFee',
          'label': '总服务费',
          'width': '98px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'payStatus',
          'label': '付款状态',
          'width': '90px',
          'show': true
        }],
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_finance',
          detailAuth: URL.getPersonalDriverWayBillList,
          rowDblClick: this.handleDetail
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          const list = vm.$route.query.flowId
          if (list) {
            vm.flowId = list
            vm.getDriverPayCompanyBillList()
          } else {
            return false
          }
        } else {
          return false
        }
      })
    },
    methods: {
      // 列表
      async getDriverPayCompanyBillList (params) {
        const val = params || { ...this.searchParam, billId: this.flowId }
        const data = await this.$http(URL.getDriverPayCompanyBillList, val)
        this.total = data.total
        this.pageSize = data.pageSize
        this.page = data.page
        if (data.rows) {
          this.tableData = data.rows.map(this.formatData)
        } else {
          this.tableData = []
        }
      },
      // 格式化函数
      formatData (data) {
        data.finishTime = utils.formatTime(data.finishTime, 'Month')
        switch (data.payStatus) {
          case 100:
            data.payStatus = '未付款'
            break
          case 200:
            data.payStatus = '已付款'
            break
          default:
            break
        };
        return data
      },
      // 提交表单
      submitForm (formName) {
        const form = this.form
        const payStartTime = new Date(form.payTime[0]).getTime()
        const payEndTime = new Date(form.payTime[1]).getTime()
        const finishTime = new Date(form.finishTime).getTime()
        this.searchParam.pageSize = this.pageSize
        this.searchParam.billId = this.flowId
        this.searchParam.keyPayNo = form.keyPayNo // 应付编码
        this.searchParam.payStatus = form.payStatus // 支付状态
        this.searchParam.finishTime = finishTime // 签收月份
        this.searchParam.payStartTime = payStartTime // 签收开始时间
        this.searchParam.payEndTime = payEndTime // 签收结束时间
        let params = { ...this.searchParam }
        params.forceCache = true
        this.getDriverPayCompanyBillList(params)
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        const form = this.form
        form.payTime = []// 付款时间
        form.finishTime = ''// 签收月份
        form.keyPayNo = [] // 下单编码
        form.payStatus = [] // 支付状态
        this.getDriverPayCompanyBillList({ billId: this.flowId })
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          pageSize: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.getDriverPayCompanyBillList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          pageSize: this.pageSize,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.getDriverPayCompanyBillList(params)
      },
      // 查看运单详情
      handleDetail (row) {
        // 保存ID
        this.$router.push({ path: '/ecms/financial/check-driver-withdraw-waybill-detail', query: { flowId: row.id } })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .top14 {
    margin-top: 14px;
  }
  .kye-col {
    padding-left: 4px;
    padding-right: 4px;
  }
  .wbyl-mt16 {
    margin-top: 10px;
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .input-width {
    width: 110px;
  }
  .input-width-l {
    width: 170px;
  }
  .input-width-m {
    width: 75px;
  }
  .ky-erp .el-form-item--mini.el-form-item {
    margin-bottom: 4px;
  }
</style>
