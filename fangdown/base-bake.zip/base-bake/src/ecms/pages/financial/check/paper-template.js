import getLodop from '@/public/utils/lodop-funcs'
export default vm => {
  const LODOP = getLodop()
  const queryModel = vm.queryModel
  // 设定left的全局偏移量 和 top 的全局偏移
  // const globalLeft = 0
  // const globalTop = 0
  let checkList = []
  if (queryModel.payMode !== '' && queryModel.payMode.length > 0) {
    checkList = queryModel.payMode.split(',')
  }
  // TODO处理设置和加密的字段
  // 寄方加密
  if (queryModel.sendEncryptFlag.length > 0) {
    let arr = queryModel.sendEncryptFlag.split(',')
    if (arr.includes('10')) {
      queryModel.sendPhone = '******'
    }
    if (arr.includes('20')) {
      queryModel.sendSmsCode = '******'
    }
    if (arr.includes('30')) {
      let name = queryModel.sendContacts.substr(0, 1)
      queryModel.sendContacts = `${name}^_^`
    }
    if (arr.includes('40')) {
      // 显示省市
      queryModel.sendAddress = '******'
    }
    if (arr.includes('50')) {
      queryModel.sendCustomerShortName = '*******'
    }
    if (arr.includes('60')) {
      queryModel.sendAddress = '******'
    }
  }
  // 收方加密
  if (queryModel.receiveEncryptFlag.length > 0) {
    let arr = queryModel.receiveEncryptFlag.split(',')
    if (arr.includes('10')) {
      queryModel.receivePhone = '******'
    }
    if (arr.includes('20')) {
      queryModel.receiveSmsCode = '******'
    }
    if (arr.includes('30')) {
      let name = queryModel.receiveContacts.substr(0, 1)
      queryModel.receiveContacts = `${name}^_^`
    }
    if (arr.includes('40')) {
      queryModel.receiveAddress = '******'
    }
    if (arr.includes('50')) {
      queryModel.receiveCustomerShortName = '******'
    }
  }

  if (LODOP && typeof LODOP.ADD_PRINT_TEXT === 'function') {
    LODOP.PRINT_INIT('纸质运单打印')
    // LODOP.ADD_PRINT_SETUP_BKIMG('E:\\打印模板\\20180706快递单尺寸标注.jpg')
    // LODOP.SET_SHOW_MODE('BKIMG_WIDTH', '224.9mm')
    // LODOP.SET_SHOW_MODE('BKIMG_HEIGHT', '139.96mm')
    LODOP.ADD_PRINT_TEXT(36, 640, 85, 15, `${queryModel.sendCustomerNumber || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(69, 640, 85, 15, `${queryModel.originalSendAreaCode || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(102, 640, 85, 15, `${queryModel.receiveAreaCode || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(143, 100, 220, 20, `${queryModel.sendCustomerShortName || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(143, 400, 220, 20, `${queryModel.receiveCustomerShortName || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(169, 75, 250, 50, `${queryModel.sendAddress || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(169, 375, 250, 50, `${queryModel.receiveAddress || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(230, 78, 150, 15, `${queryModel.sendPhone || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(230, 265, 50, 15, `${queryModel.sendContacts || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(265, 189, 185, 15, `${queryModel.sendSmsCode || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(230, 392, 150, 15, `${queryModel.receivePhone || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(230, 560, 65, 20, `${queryModel.receiveContacts || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(265, 463, 185, 15, `${queryModel.receiveSmsCode || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    if (checkList.includes('10')) {
      LODOP.ADD_PRINT_TEXT(272, 480, 15, 15, '√')
      LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
      LODOP.SET_PRINT_STYLEA(0, 'FontSize', 16)
    }
    if (checkList.includes('30')) {
      LODOP.ADD_PRINT_TEXT(272, 540, 15, 15, '√')
      LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
      LODOP.SET_PRINT_STYLEA(0, 'FontSize', 16)
    }
    if (checkList.includes('20')) {
      LODOP.ADD_PRINT_TEXT(300, 480, 15, 15, '√')
      LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
      LODOP.SET_PRINT_STYLEA(0, 'FontSize', 16)
    }
    if (checkList.includes('40')) {
      LODOP.ADD_PRINT_TEXT(300, 540, 15, 10, '√')
      LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
      LODOP.SET_PRINT_STYLEA(0, 'FontSize', 16)
    }
    LODOP.ADD_PRINT_TEXT(330, 450, 200, 20, `${queryModel.payCustomerShortName || ''}  ${queryModel.payAccountNumber || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    if (queryModel.signNeedFlag === '10') {
      LODOP.ADD_PRINT_TEXT(344, 634, 15, 15, '√')
      LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
      LODOP.SET_PRINT_STYLEA(0, 'FontSize', 16)
    }
    LODOP.ADD_PRINT_TEXT(320, 36, 85, 30, `${queryModel.goodsName || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
    LODOP.ADD_PRINT_TEXT(440, 590, 150, 40, `${queryModel.remark || ''}`)
    LODOP.SET_PRINT_STYLEA(0, 'FontName', '黑体')
    LODOP.SET_PRINT_STYLEA(0, 'FontSize', 9)
  }
}
