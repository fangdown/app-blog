<template>
  <div>
    <search-pager :option="option"></search-pager>
    <kye-expand-page>
      <div class="bg1">
        <div class="bill">
          <div class="bill-title">联运账单</div>
          <div class="bill-small-title">({{form.signStartTime}}-{{form.signEndTime}})</div>
          <div class="bill-header">
            <div class="info">
              <div class="company">{{form.entrustPlatformName}}</div>
              <div class="tel">tel:{{form.phone}}</div>
            </div>
            <div>
              <kye-button type="primary"
                          @click="printContent"
                          icon="iconfont icon-ecs-dayinrenwu">打印
              </kye-button>
              <kye-button type="primary"
                          :auth="quxian"
                          @click="exportList"
                          icon="iconfont icon-export">导出
              </kye-button>
            </div>
          </div>
          <div class="summary">
            <div class="date">账单日：
              <span>{{form.createTime}}</span>
            </div>
            <div class="batch-num">对账批号：
              <span>{{form.billNo}}</span>
            </div>
            <div class="total-cost">含税总应付费用：
              <span> {{form.totalFee}}</span>
            </div>
          </div>
          <div v-if="className==='Driver'">
            <div class="kye-block-title">费用信息</div>
            <kye-table ref="multipleTable"
                       stripe
                       :data="tableData1"
                       tooltip-effect="dark"
                       max-height="120"
                       style="margin: 0 16px; width: 1078px">
              <kye-table-column prop="itemName"
                                label="费用项目">
              </kye-table-column>
              <kye-table-column prop="amount"
                                label="含税金额">
              </kye-table-column>
            </kye-table>
            <div class="total">
              <span>合计：</span>
              <em> {{form.totalFee}}</em>
            </div>
          </div>
          <div class="kye-block-title">收款账号信息</div>
          <kye-table ref="multipleTable"
                     stripe
                     :data="tableData"
                     tooltip-effect="dark"
                     style="margin: 0 16px;width: 1078px"
                     :header-cell-style="{background:'#EBEBEB'}">
            <kye-table-column prop="bankName"
                              label="开户银行"
                              align="center">
            </kye-table-column>
            <kye-table-column prop="bankAccount"
                              label="银行账号"
                              align="center">
            </kye-table-column>
            <kye-table-column prop="bankAccountName"
                              label="账户名称"
                              align="center">
            </kye-table-column>
          </kye-table>
          <div class="note-wrap">
            <p class="note">1、本对账单为跨越速运集团与贵单位在
              <span class="placeholder"></span>
              <span class="placeholder"></span>年
              <span class="placeholder"></span>月
              <span class="placeholder"></span>日至
              <span class="placeholder"></span>
              <span class="placeholder"></span>年
              <span class="placeholder"></span>月
              <span class="placeholder"></span>日产生的费用总计，请认真审核金额、记账日、任务单号、车型、件数、开户行、银行账号、账户名称、对账批号等信息，自收到本账单之日起三日内提出异议，三日内未提出异议或者点击确认按钮的视为对本账单内容的确认，本公司将按照双方的约定以本账单为标准向贵单位支付款项。 </p>
            <p class="note">2、金额前未做任何标注的为本公司应该支付的款项小计，标记为“-”的为扣除的款项，如罚款、违约金、损失赔偿金等，均以“代缴罚款”字样在系统中体现。 </p>
            <p class="note">3、依据双方之间签订的合同或者其他协议性文件的约定，绩效费用、增值税费、绩效奖金、路桥费、加油费等与订单相关联，本对账单统计的金额与签署表单相冲突的，以计算金额少者为准。</p>
            <p class="note">4、跨越速运集团按照双方的约定，除支付对账单记载的款项外，不再向贵单位支付其他任何款项；本对账单作为双方计算费用的重要凭证，将作为双方发生纠纷时诉讼阶段的证据使用，请慎重对待。如对本账单有异议的请致电400131312进行沟通。</p>
          </div>
          <div class="kye-block-title">跨越速运开票资料与金额</div>
          <div style="margin-left:16px">
            <!-- <table-list :column="column"
                        ref="canvas"
                        :data="tableData"
                        :options="tableOption"></table-list> -->
            <kye-table ref="multipleTable"
                       stripe
                       :data="tableData2"
                       tooltip-effect="dark"
                       style="margin: 0 16px;width: 1078px"
                       :header-cell-style="{background:'#EBEBEB'}">
              <kye-table-column prop="finishTime"
                                label="开票月份"
                                width='80'
                                align="center">
              </kye-table-column>
              <kye-table-column prop="payCompanyName"
                                label="公司名称"
                                show-overflow-tooltip
                                width='180'>
              </kye-table-column>
              <kye-table-column prop="payTaxNo"
                                label="税务登记证号"
                                show-overflow-tooltip
                                width='180'>
              </kye-table-column>
              <kye-table-column prop="payCompanyAddress"
                                show-overflow-tooltip
                                label="地址"
                                width='140'>
              </kye-table-column>
              <kye-table-column prop="payCompanyPhone"
                                show-overflow-tooltip
                                label="联系电话"
                                width='120'>
              </kye-table-column>
              <kye-table-column prop="payBankInf"
                                show-overflow-tooltip
                                label="开户行及账号">
              </kye-table-column>
              <kye-table-column prop="taxRate"
                                label="开票税率%"
                                show-overflow-tooltip
                                width='80'>
              </kye-table-column>
              <kye-table-column prop="totalFee"
                                label="总金额"
                                show-overflow-tooltip
                                width='80'>
              </kye-table-column>
            </kye-table>
          </div>
          <div class="total">
            <span>总计：</span>
            <em> {{totalAmount||'0' | money}}</em>
          </div>
          <div class="note-wrap">
            <p class="note">请根据以上主体公司信息开具对应的增值税专票，并在发票内容附上对账批号和应付编码，例如：对账批号：DZXXXX-XXXXXXXX。 并将对应发票和盖章后的对账单，寄送至跨越速运集团有限公司</p>
            <p class="note">地址：深圳市宝安区福永镇福海街道福园二路跨越速运</p>
            <p class="note">收件人：覃红豆</p>
            <p class="note">联系电话：0755-23303667</p>
          </div>
          <div class="bill-footer">
            <div class="wrap">
              <div class="first-party">
                <p>甲方公司(盖章)</p>
                <p>日期:
                  <span class="placeholder"></span>
                  <span class="placeholder"></span>年
                  <span class="placeholder"></span>月
                  <span class="placeholder"></span>日</p>
              </div>
              <div class="second-party">
                <p>乙方公司(盖章)</p>
                <p>日期:
                  <span class="placeholder"></span>
                  <span class="placeholder"></span>年
                  <span class="placeholder"></span>月
                  <span class="placeholder"></span>日</p>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-wrap">
          <div class="bill-footer-img"></div>
        </div>
      </div>
    </kye-expand-page>
  </div>
</template>

<script>
  // 打印组件
  import getLodop from '@/public/utils/lodop-funcs'
  // 端口请求
  import URL from '../check.api'
  // 格式化文件
  import * as utils from '../../../utils'
  // 金额过滤器
  import { money } from 'public/utils/filter'
  // 解密组件
  import { decrypt } from 'public/utils/common'
  export default {
    // components: { searchPage },
    data () {
      return {
        URL,
        option: {
          back: '/ecms/financial/check'
        },
        tableData: [],
        tableData1: [],
        tableData2: [],
        totalAmount: '',
        quxian: '',
        form: {
          signStartTime: '', // 产生费用开始时间
          signEndTime: '', // 产生费用截止时间
          createTime: '', // 账单日
          entrustPlatformName: '', // 挂靠名称
          phone: '', // 挂靠公司电话
          billNo: '', // 对账编号
          totalFee: '', // 总金额(含税)
          totalServiceFee: '' // 总服务费
        },
        flowId: '', // 识别ID
        className: '', // 识别类别
      }
    },
    // activated () {

    // },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.initData()
        } else {
          return false
        }
      })
    },
    methods: {
      // 进入页面初始化数据
      initData () {
        this.flowId = this.$route.query.flowId
        this.className = this.$route.query.className
        switch (this.className) {
          case 'Driver':
            this.quxian = URL.exportDriverBill
            this.getBillList('getDriverTotalBillDetail', 'getDriverPayCompanyBillListByBillId')
            break
          case 'Enterprise':
            this.quxian = URL.exportCompanyBill
            this.getBillList('getCompanyTotalBillDetail', 'getCompanyPayCompanyBillListByBillId')
            break
          case 'Platform':
            this.quxian = URL.exportPlatformBill
            this.getBillList('getPlatformTotalBillDetail', 'getPlatformPayCompanyBillListByBillId')
            break
          case 'contract':
            this.quxian = URL.exportContractBill
            this.getBillList('getContractTotalBillDetail', 'getContractPayCompanyBillByBillId')
            break
          default:
            break
        }
      },
      // 发起对账单请求
      async getBillList (getTotalBillDetail, getPayCompanyBillListByBillId) {
        // 类型总账单详情
        const data = await this.$http(URL[getTotalBillDetail], { billId: this.flowId })
        this.tableData = [
          { 'bankName': data.bankName, 'bankAccount': data.bankAccount, 'bankAccountName': data.bankAccountName }
        ]
        if (data.costItem) {
          this.tableData1 = data.costItem.map(this.formoney2)
        }
        this.form = this.formatData(data)
        this.$store.commit('ecms/FINACE_BillDetail', data)
        // 按账单ID查询类型主体公司列表
        const data2 = await this.$http(URL[getPayCompanyBillListByBillId], { billId: this.flowId })
        if (data2.entityList) {
          this.tableData2 = data2.entityList.map(this.formatData)
          this.$bus.$emit('GLOBAL_RESIZE')
          this.totalAmount = data2.totalAmount
          this.$store.commit('ecms/FINACE_BillList', data2)
        } else {
          this.tableData2 = []
        }
      },
      // 解密
      async getField (fieldName) {
        if (this.form.phone !== '*****') return
        this.form[fieldName] = await decrypt({
          dataId: '2',
          moduleCode: 'ecs_finance',
          fieldName,
          fieldContent: this.form[fieldName + 'Mask']
        }, 'mask')
      },
      // 打印
      printContent () {
        if (this.form.phone === '*****') {
          this.$message({
            showClose: true,
            message: '请先解密字段，再进行操作',
            type: 'info'
          })
          return false
        }
        this.LODOP = getLodop()
        if (this.LODOP) {
          this.$router.push({ path: '/ecms/financial/check-bills-print', query: { flowId: this.flowId, className: this.className, phone: this.form.phone } })
        } else {
          return false
        }
      },
      // 导出 事件
      exportList () {
        switch (this.className) {
          case 'Driver':
            this.exportBill('exportDriverBill')
            break
          case 'Enterprise':
            this.exportBill('exportCompanyBill')
            break
          case 'Platform':
            this.exportBill('exportPlatformBill')
            break
          case 'contract':
            this.exportBill('exportContractBill')
            break
          default:
            break
        }
      },
      // 导出对账单
      async exportBill (ApiName) {
        const params = { billId: this.flowId }
        const data = await this.$http(URL[ApiName], params)
        window.erpOpen(data)
      },
      // 返回列表
      handleBack () {
        switch (this.className) {
          case 'Driver':
            this.$router.push({ name: 'check', params: { activeName: 'first' } })
            break
          case 'Enterprise':
            this.$router.push({ name: 'check', params: { activeName: 'second' } })
            break
          case 'Platform':
            this.$router.push({ name: 'check', params: { activeName: 'third' } })
            break
          case 'contract':
            this.$router.push({ name: 'check', params: { activeName: 'fourth' } })
            break
          default:
            break
        }
      },
      // 格式化函数
      formatData (data) {
        data.finishTime = utils.formatTime(data.finishTime, 'Month')
        data.signStartTime = utils.formatTime(data.signStartTime, 'S')
        data.signEndTime = utils.formatTime(data.signEndTime, 'S')
        data.createTime = utils.formatTime(data.createTime)
        data.totalFee = money(data.totalFee)
        data.totalServiceFee = money(data.totalServiceFee)
        data.taxRate = (data.taxRate - 0) * 100
        return data
      },
      // 格式化函数
      formatData2 (data) {
        data.finishTime = utils.formatTime(data.finishTime)
        data.totalFee = money(data.totalFee)
        return data
      },
      // 格式化金额
      formoney (data) {
        data = money(data)// 含税总金额
        return data
      },
      // 格式化金额
      formoney2 (data) {
        if (data) {
          data.amount = money(data.amount)
          return data
        }
        return data
      }
    }
  }
</script>

<style lang="scss" scoped>
  .placeholder {
    display: inline-block;
    width: 20px;
    border-bottom: 1px solid #333333;
    vertical-align: bottom;
  }

  .bg1 {
    width: 100%;
    padding-top: 48px;
    box-sizing: border-box;
    font-family: "PingFang-SC-Medium";
    overflow: visible;
    // background: yellow;
    margin-bottom: 40px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-size: 100%;
    background-image: url("../images/picture_bill_bg.png");
    background-position: 0 20px;
    background-repeat: no-repeat;
    .bill {
      // margin: -16px 10px 0 25px;
      width: 95%;
      background: white;
      box-shadow: 0 7px 23px 0 rgba(76, 42, 155, 0.05);
      .bill-title {
        font-size: 24px;
        color: #333333;
        text-align: center;
        padding-top: 42px;
      }
      .bill-small-title {
        font-size: 16px;
        color: #151515;
        text-align: center;
        line-height: 33px;
        padding-bottom: 43px;
      }
      .bill-header {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin: 0 22px;
        border-bottom: 1px dashed #dcdae2;
        margin-bottom: 14px;
        .info {
          display: flex;
          flex-direction: column;
          font-size: 16px;
          color: #333333;
          text-align: center;
          padding-bottom: 16px;
          div {
            margin: 0;
            text-align: left;
            font-weight: bold;
          }
        }
        .print {
          width: 68px;
          height: 32px;
          background: #7352bf;
          border-radius: 4px;
          line-height: 32px;
          font-size: 12px;
          color: #ffffff;
          text-align: center;
          float: left;
          cursor: pointer;
        }
        .print2 {
          background: #fff;
          color: #7352bf;
          margin-left: 20px;
        }
      }
      .summary {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        line-height: 28px;
        margin: 0 22px;
        margin-bottom: 16px;
        div {
          font-size: 16px;
          color: #333333;
          text-align: center;
          font-weight: bold;
          span {
            font-weight: normal;
            color: #151515;
          }
        }
      }
      .cost-head {
        background: #f1f1f5;
        height: 32px;
        line-height: 32px;
        text-align: left;
        padding-left: 12px;
        margin: 0 16px;
        font-size: 14px;
        color: #333333;
        font-weight: bold;
        margin-bottom: 12px;
      }
      .total {
        width: 1080px;
        margin-top: 10px;
        margin-bottom: 15px;
        text-align: right;
        margin-right: 100px;
        font-size: 12px;
        color: #333333;
        line-height: 17px;
        span {
          line-height: 17px;
          vertical-align: middle;
        }
        em {
          vertical-align: middle;
          font-size: 18px;
          color: #ff9300;
          text-align: center;
          line-height: 17px;
          font-weight: bold;
          display: inline-block;
          font-style: normal;
        }
      }
      .total-cost {
        display: flex;
        justify-content: flex-end;
        margin-right: 12px;
        font-size: 12px;
        color: hsl(0, 0%, 20%);
        text-align: right;
        line-height: 28px;
        .em {
          vertical-align: middle;
          font-size: 18px;
          line-height: 18px;
          color: #ff9300;
          text-align: center;
          font-weight: bold;
          display: inline-block;
          font-style: normal;
        }
        .left {
          display: flex;
          flex-direction: column;
          justify-content: flex-end;
        }
        .right {
          display: flex;
          flex-direction: column;
          justify-content: flex-start;
        }
      }
      .note-wrap {
        width: 1080px;
        margin: 12px 22px;
        .note {
          margin: 0;
          font-weight: medium;
          font-size: 12px;
          line-height: 18px;
          color: #333333;
          text-align: left;
        }
      }
      .export {
        font-size: 12px;
        color: #9571e9;
        text-align: left;
        padding-left: 47px;
        margin: 12px 0;
        cursor: pointer;
      }
      .bill-footer {
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
        .wrap {
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          .first-party {
            display: flex;
            flex-direction: column;
            margin-right: 237px;
          }
          .second-party {
            display: flex;
            flex-direction: column;
            margin-right: 22px;
          }
        }
      }
    }
    .footer-wrap {
      background: #f8f6fb;
      width: 95%;
      height: 24px;
      // margin-left: 14px;
      .bill-footer-img {
        width: 100%;
        // margin-left: 14px;
        height: 24px;
        background-image: url("../images/picture_bill_bg02.png");
        background-position: 0 bottom;
        background-repeat: repeat-x;
        box-shadow: 0 7px 23px 0 rgba(76, 42, 155, 0.05);
      }
    }
    .back {
      display: inline-block;
      font-size: 20px;
      text-align: center;
      cursor: pointer;
      color: #7352bf;
      vertical-align: middle;
    }
    .kye-block-title {
      margin-left: 16px;
      margin-right: 16px;
    }
  }
</style>
