<template>
  <div id="billList">
    <div class="bg1"
         style="font-family: 'PingFang-SC-Medium'">
      <div class="bill">
        <div style="width:100%">
          <div class="bill-title">联运账单</div>
          <div class="bill-small-title"
               style="font-size:16px">({{form.signStartTime}}-{{form.signEndTime}})</div>
          <div class="bill-header"
               style="margin-bottom: 16px;border-bottom: 1px dashed #dcdae2;font-size: 20px;padding-bottom: 15px">
            <div class="info">
              <div class="company">{{form.entrustPlatformName}}</div>
              <div class="tel">tel:{{form.phone}}</div>
            </div>
          </div>
          <div class="summary"
               style="height: 28px;
                     line-height: 28px;
                     margin: 0 12px;
                     margin-bottom: 16px;
                     width: 98%">
            <div class="date"
                 style="float:left;margin-right: 50px;">账单日:{{form.createTime}}
            </div>
            <div class="batch-num"
                 style="float:left;margin-right: 50px;">对账批号:{{form.billNo}}
            </div>
            <div class="total-cost"
                 style="float:left;margin-right: 50px;">含税总应付费用:{{form.totalFee}}
            </div>
          </div>
          <div class="cost-head"
               style="font-weight: bold;background: #f1f1f5;
                      height: 32px;
                      line-height: 32px;
                      text-align: left;
                      width: 100%;
                      padding-left: 12px;
                      margin: 20px 0px 12px;
                      font-size: 16px;">费用信息</div>
          <kye-table ref="multipleTable"
                     stripe
                     :data="tableData1"
                     tooltip-effect="dark"
                     style="width: 98%;"
                     :header-cell-style="{background:'#F1F1F5',textAlign:'center',height:'44px',fontSize:'16px'}"
                     :cell-style="{border:'1px solid',textAlign:'center',padding: '4px 0',fontSize:'16px'}">
            <kye-table-column prop="itemName"
                              label="费用项目">
            </kye-table-column>
            <kye-table-column prop="amount"
                              label="含税金额">
            </kye-table-column>
          </kye-table>
          <div class="total"
               style="margin-top: 10px;text-align: right;margin-right: 10px;width:98%">
            <span>合计：</span>
            <em>{{form.totalFee}}</em>
          </div>
          <div class="cost-head"
               style="font-weight: bold;background: #f1f1f5;
                      height: 32px;
                      line-height: 32px;
                      text-align: left;
                      padding-left: 12px;
                      width:100%;
                      margin: 20px 0px 12px;
                      font-size: 16px;">收款账号信息</div>
          <kye-table ref="multipleTable"
                     stripe
                     :data="tableData"
                     tooltip-effect="dark"
                     style="width: 98%"
                     :header-cell-style="{background:'#F1F1F5',textAlign:'center',height:'44px',fontSize:'16px'}"
                     :cell-style="{border:'1px solid',textAlign:'center',padding: '4px 0',fontSize:'16px'}">
            <kye-table-column prop="bankName"
                              label="开户银行">
            </kye-table-column>
            <kye-table-column prop="bankAccount"
                              label="银行账号">
            </kye-table-column>
            <kye-table-column prop="bankAccountName"
                              label="账户名称">
            </kye-table-column>
          </kye-table>
          <div class="note-wrap"
               style="width:98%;margin-top: 10px;">
            <p class="note">1、本对账单为跨越速运集团与贵单位在
              <span class="placeholder"> _ </span>
              <span class="placeholder"> _</span>年
              <span class="placeholder"> _ </span>月
              <span class="placeholder"> _ </span>日至
              <span class="placeholder"> _ </span>
              <span class="placeholder"> _ </span>年
              <span class="placeholder"> _ </span>月
              <span class="placeholder"> _ </span>日产生的费用总计，请认真审核金额、记账日、任务单号、车型、件数、开户行、银行账号、账户名称、对账批号等信息，自收到本账单之日起三日内提出异议，三日内未提出异议或者点击确认按钮的视为对本账单内容的确认，本公司将按照双方的约定以本账单为标准向贵单位支付款项。 </p>
            <p class="note">2、金额前未做任何标注的为本公司应该支付的款项小计，标记为“-”的为扣除的款项，如罚款、违约金、损失赔偿金等，均以“代缴罚款”字样在系统中体现。 </p>
            <p class="note">3、依据双方之间签订的合同或者其他协议性文件的约定，绩效费用、增值税费、绩效奖金、路桥费、加油费等与订单相关联，本对账单统计的金额与签署表单相冲突的，以计算金额少者为准。</p>
            <p class="note">4、跨越速运集团按照双方的约定，除支付对账单记载的款项外，不再向贵单位支付其他任何款项；本对账单作为双方计算费用的重要凭证，将作为双方发生纠纷时诉讼阶段的证据使用，请慎重对待。如对本账单有异议的请致电400131312进行沟通。</p>
          </div>
        </div>
        <div class=""
             style="font-weight: bold;background: #f1f1f5;
                      height: 32px;
                      line-height: 32px;
                      text-align: left;
                      padding-left: 12px;
                      margin: 20px 0px 12px;
                      font-size: 16px;">跨越速运开票资料与金额</div>
        <div style="width:98%">
          <kye-table :data="tableData2"
                     border
                     style="width: 100%"
                     :header-cell-style="{background:'#F1F1F5',textAlign:'center',height:'44px',fontSize:'16px',}"
                     :cell-style="{border:'1px solid',textAlign:'center',padding: '2px',fontSize:'14pxw',wordBreak:'break-all',}">
            <kye-table-column prop="finishTime"
                              label="开票月份">
            </kye-table-column>
            <kye-table-column prop="payCompanyName"
                              label="公司名称">
            </kye-table-column>
            <kye-table-column prop="payTaxNo"
                              label="税务登记证号">
            </kye-table-column>
            <kye-table-column prop="payCompanyAddress"
                              label="地址">
            </kye-table-column>
            <kye-table-column prop="payBankInf"
                              label="开户行及账号">
            </kye-table-column>
            <kye-table-column prop="taxRate"
                              label="开票税率%">
            </kye-table-column>
            <kye-table-column prop="totalFee"
                              label="总金额">
            </kye-table-column>
          </kye-table>
        </div>
        <div class="total"
             style="margin-top: 10px;text-align: right;margin-right: 10px; width:98%">
          <span>总计：</span>
          <em>¥ {{totalAmount}}</em>
        </div>
        <div class="note-wrap"
             style="
             width:98%
        font-size: 18px;
        text-align: left;
        margin-top: 20px;">
          <p class="note"
             style="margin: 0px;padding: 0px;text-align: left;">请根据以上主体公司信息开具对应的增值税专票，并在发票内容附上对账批号和应付编码，例如：对账批号：DZXXXX-XXXXXXXX。 并将对应发票和盖章后的对账单，寄送至跨越速运集团有限公司</p>
          <p class="note"
             style="margin: 0px;padding: 0px;text-align: left;">地址：深圳市宝安区福永镇福海街道福园二路跨越速运</p>
          <p class="note"
             style="margin: 0px;padding: 0px;text-align: left;">收件人：覃红豆</p>
          <p class="note"
             style="margin: 0px;padding: 0px;text-align: left;">联系电话：0755-23303667</p>
        </div>
        <div class="bill-footer"
             style="margin-top: 30px;">
          <div class="wrap">
            <div class="first-party"
                 style=" float: left;
          margin:0 200px 0 200px;">
              <p>甲方公司(盖章)</p>
              <p style="margin-top:50px">日期:
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>年
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>月
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>日
              </p>
            </div>
            <div class="second-party"
                 style=" float: left;
          ">
              <p>乙方公司(盖章)</p>
              <p style="margin-top:50px">日期:
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>年
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>月
                <span class="placeholder"
                      style="display: inline-block;width:30px"></span>日
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  // 格式化文件
  import * as utils from '../../../utils'
  // 金额过滤器
  import { money } from 'public/utils/filter'
  // 打印组件
  import getLodop from '@/public/utils/lodop-funcs'
  export default {
    data () {
      return {
        tableData: [],
        tableData1: [],
        tableData2: [],
        totalAmount: '',
        form: {
          signStartTime: '', // 产生费用开始时间
          signEndTime: '', // 产生费用截止时间
          createTime: '', // 账单日
          entrustPlatformName: '', // 挂靠名称
          phone: '', // 挂靠公司电话
          billNo: '', // 对账编号
          totalFee: '', // 总金额(含税)
          totalServiceFee: '' // 总服务费
        },
        flowId: '', // 识别ID
        className: '' // 识别类别
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.initData()
        } else {
          return false
        }
      })
    },
    methods: {
      // 进入界面初始化
      initData () {
        this.flowId = this.$route.query.flowId
        this.className = this.$route.query.className
        this.options()
      },
      // 格式化时间和金钱
      formatting (data) {
        data.finishTime = utils.formatTime(data.finishTime)
        data.totalFee = money(data.totalFee)
        data.taxRate = data.taxRate * 100
        return data
      },
      // 调用打印
      /* eslint-disable */
      options () {
        const BillDetail = this.$store.getters['ecms/FINACE_BillDetail']
        this.tableData = [
          {
            'bankName': BillDetail.bankName,
            'bankAccount': BillDetail.bankAccount,
            'bankAccountName': BillDetail.bankAccountName
          }
        ]
        this.tableData1 = BillDetail.costItem
        this.form = BillDetail
        const BillList = this.$store.getters['ecms/FINACE_BillList']
        this.tableData2 = BillList.entityList.map(this.formatting)
        this.totalAmount = BillList.totalAmount
        this.form.phone = this.$route.query.phone
        setTimeout(() => {
          // window.print()
          this.LODOP = getLodop()
          this.LODOP.PRINT_INIT('') // 首先一个初始化语句
          this.LODOP.ADD_PRINT_TEXT(0, 0, 0, 20, '1') // 然后多个ADD语句及SET语句
          let ecsBodyStyle = '<style>.bill-title,.bill-small-title {font-size: 24px;  text-align: center;padding-top: 0px;}html,body,#bill {min-width:200mm}bill-footer {display: flex;flex-direction: row;justify-content: flex-end;margin-top: 50px;</style> '
          let ecsBodyHtml = ecsBodyStyle + '<body>' + document.getElementById('billList').innerHTML + '</body>'
          // this.LODOP.ADD_PRINT_HTM(20, 40, 700, 700, strBodyHtml)
          this.LODOP.ADD_PRINT_HTM(50, 25, '100%', '98%', ecsBodyHtml)
          this.LODOP.SET_PRINT_PAGESIZE(1, 0, 0, 'A4')
          this.LODOP.SET_PRINT_MODE("FULL_WIDTH_FOR_OVERFLOW", true);
          this.LODOP.PREVIEW()
          this.$router.push({ path: '/ecms/financial/check-driver-bills', query: { flowId: this.flowId, className: this.className } })
        }, 1000)
        return 0
      }
    },
    computed: {
    },
    /* eslint-disable */
  }
</script>

<style lang="scss">
  .placeholder {
    display: inline-block;
    width: 20px;
    border-bottom: 1px solid #333333;
    vertical-align: bottom;
  }
  .ky-erp .kye-table .cellClass .cell {
    white-space: normal !important;
    display: none;
  }
</style>
