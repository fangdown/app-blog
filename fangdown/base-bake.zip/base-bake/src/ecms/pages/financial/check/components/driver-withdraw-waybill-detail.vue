<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              label-width="auto">
      <kye-form-item label="完结时间">
        <kye-date-picker v-model="form.finishTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="任务编码">
        <kye-input v-model="form.taskCode"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-form-item label="司机姓名">
        <kye-input v-model="form.driverName"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-form-item label="手机号码">
        <kye-input v-model="form.driverPhone"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-form-item label="车牌号">
        <kye-input v-model="form.carPlateNum"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-form-item label="到账状态">
        <kye-select v-model="form.withdrawStatus"
                    placeholder=""
                    class="input-width">
          <kye-option label="全部"
                      value="0"></kye-option>
          <kye-option label="已到账"
                      value="300"></kye-option>
          <kye-option label="未到账"
                      value="200"></kye-option>
        </kye-select>
      </kye-form-item>
      <kye-button type="primary"
                  class="kye-button--primary kye-button--mini"
                  :auth="URL.getPersonalDriverWayBillList"
                  @click="submitForm('ruleForm')"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <div>
      <div class="query-table-container"
           v-loading="loading">
        <table-list :column="column"
                    ref="canvas"
                    :data="tableData"
                    :options="tableOption"></table-list>
      </div>
      <kye-pagination style="margin-top:10px"
                      layout="sizes,total,prev,pager,next"
                      background
                      :total="total"
                      :page-sizes="[200]"
                      class="fixedPagination"
                      :current-page="page"
                      :page-size.sync="size"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  // 端口请求
  import URL from '../check.api'
  // 文件格式化
  import * as utils from '../../../utils'
  // 三级地址拼接
  import { formatData } from '../../../utils/formatData'
  export default {
    data () {
      return {
        loading: false,
        URL,
        option: {
          back: '/ecms/financial/check-driver-withdraw-detail'
        },
        form: {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
          driverName: '', // 司机姓名
          driverPhone: '', // 司机电话
          carPlateNum: '', // 车牌号
          withdrawStatus: '' // 支付状态
        },
        searchParam: {
          billId: '',
          finishStartTime: '', // 完结开始时间
          finishEndTime: '', // 完结结束时间
          taskCode: '', // 任务编码
          driverName: '', // 司机姓名
          driverPhone: '', // 司机电话
          carPlateNum: '', // 车牌号
          withdrawStatus: '', // 支付状态
          size: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        tableData: [],
        total: 0,
        page: 0,
        size: 200,
        paperStatus: '每页显示200条', // 分页条数
        multipleSelection: [],
        flowId: '', // 识别ID
        column: [
          {
            key: 'reportTime',
            label: '承运时间',
            show: true,
            width: '120px',
            filter: 'time'
          }, {
            key: 'finishTime',
            label: '完结时间',
            show: true,
            width: '120px',
            filter: 'time'
          }, {
            key: 'taskCode',
            label: '任务编码',
            show: true,
            width: '110px'

          }, {
            key: 'driverName',
            label: '司机',
            show: true,
            width: '60px'

          }, {
            key: 'driverPhone',
            label: '手机号码',
            show: true,
            width: '100px'

          }, {
            key: 'carPlateNum',
            label: '车牌号',
            show: true,
            width: '80px'

          }, {
            key: 'provenance',
            label: '始发地',
            show: true,
            width: '100px'

          }, {
            key: 'destination',
            label: '目的地',
            show: true,
            width: '100px'

          }, {
            key: 'withdrawStatus',
            label: '到账状态',
            show: true,
            width: '60px'

          }, {
            key: 'payTime',
            label: '到账时间',
            show: true,
            width: '100px'

          }, {
            key: 'totalFee',
            label: '总金额',
            'filter': 'money',
            show: true,
            width: '80px'

          }],
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_finance',
        }
      }
    },
    activated () {
      this.flowId = this.$route.query.flowId
      this.getPersonalDriverWayBillList()
    },
    methods: {
      // 列表
      async getPersonalDriverWayBillList (params) {
        this.loading = true
        const val = params || { ...this.searchParam, billId: this.flowId }
        const data = await this.$http(URL.getPersonalDriverWayBillList, val)
        this.total = data.total
        this.size = data.size
        this.page = data.page
        this.loading = false
        // 缓存：预加载下一页
        if (this.total > 0 && this.total > this.page * this.size) {
          let preData = { ...val, page: this.page + 1 }
          delete preData.forceCache
          this.$http(URL.getPersonalDriverWayBillList, preData, false)
        }
        if (data.rows) {
          this.tableData = data.rows.map(this.formatData2)
        } else {
          this.tableData = []
        }
      },
      // 格式化函数
      formatData2 (data) {
        data.finishTime = utils.formatTime(data.finishTime, 'M')// 完结时间
        data.payTime = utils.formatTime(data.payTime, 'M')// 到账时间
        data.reportTime = utils.formatTime(data.reportTime, 'M')// 承运时间
        formatData(data)
        switch (data.withdrawStatus) {
          case 200:
            data.withdrawStatus = '未到账'
            break
          case 300:
            data.withdrawStatus = '已到账'
            break
          default:
            break
        };
        return data
      },
      // 提交表单
      submitForm (formName) {
        const form = this.form
        this.searchParam.billId = this.flowId
        this.searchParam.finishStartTime = new Date(form.finishTime[0]).getTime() // 完结开始时间
        this.searchParam.finishEndTime = new Date(form.finishTime[1]).getTime() // 完结结束时间
        this.searchParam.taskCode = form.taskCode // 任务编码
        this.searchParam.driverName = form.driverName // 司机姓名
        this.searchParam.driverPhone = form.driverPhone // 司机电话
        this.searchParam.carPlateNum = form.carPlateNum // 车牌号
        this.searchParam.withdrawStatus = form.withdrawStatus // 支付状态
        let params2 = { ...this.searchParam }
        params2.forceCache = true
        this.getPersonalDriverWayBillList(params2)
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        this.form = {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
          driverName: '', // 司机姓名
          driverPhone: '', // 司机电话
          carPlateNum: '', // 车牌号
          withdrawStatus: '' // 支付状态
        }
        this.getPersonalDriverWayBillList({ billId: this.flowId })
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          size: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.getPersonalDriverWayBillList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          size: this.size,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.getPersonalDriverWayBillList(params)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .top14 {
    margin-top: 14px;
  }
  .submit {
    display: inline-block;
    margin-top: 36px;
  }
  .reset {
    border: none;
  }
  .reset:hover {
    background-color: transparent;
  }
  .kye-col {
    padding-left: 4px;
    padding-right: 4px;
  }
  .wbyl-mt16 {
    margin-top: 10px;
  }
  .input-width-l {
    width: 170px;
  }
  .input-width {
    width: 100px;
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .ky-erp .el-form-item--mini.el-form-item {
    margin-bottom: 4px;
  }
</style>
