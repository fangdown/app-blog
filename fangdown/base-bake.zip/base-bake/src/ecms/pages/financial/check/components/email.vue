<template>
  <div>
    <kye-dialog title="提示"
                :visible.sync="dialogFormVisible"
                append-to-body>
      <kye-form size="mini"
                labkye-position="left"
                :model="rulesForm"
                :rules="rules"
                ref="ruleForm">
        <kye-row>
          <kye-form-item label="供应商邮箱"
                         prop="email">
            <kye-input v-model="rulesForm.email"></kye-input>
          </kye-form-item>
        </kye-row>
      </kye-form>
      <div slot="footer">
        <kye-button type="primary"
                    @click="againRefund()">确定</kye-button>
        <kye-button @click="cancel">取消</kye-button>
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from '../check.api'
  export default {
    // props: {
    //   row: Object,
    //   default () {
    //     return {
    //     }
    //   }
    // },
    data () {
      var checkAge = (rule, value, callback) => {
        const email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/
        if (!value) {
          return callback(new Error('邮箱不能为空'))
        }
        if (!email.test(value)) {
          return callback(new Error('请填写正确的邮箱地址'))
        } else {
          callback()
        }
      }
      return {
        emailID: '',
        className: '',
        rulesForm: {
          email: ''
        },
        rules: {
          email: [
            { validator: checkAge, trigger: 'blur' }
          ]
        },
        URL,
        dialogFormVisible: false,
      }
    },
    mounted () {
    },
    methods: {
      toView (id, className) {
        this.dialogFormVisible = true
        this.className = className
        this.emailID = id
        this.rulesForm.email = ''
      },
      againRefund () {
        console.log(12344)
        this.$refs.ruleForm.validate((valid) => {
          if (valid) {
            const val = {
              'billId': this.emailID,
              'toEmail': this.rulesForm.email
            }
            if (this.className === 'platform') {
              const data = this.$http(URL.sendPlatformBillEmail, val)
              if (data) {
                this.infoWay()
              }
            } else if (this.className === 'contract') {
              const data = this.$http(URL.sendContractBillEmail, val)
              if (data) {
                this.infoWay()
              }
            }
            this.$refs.ruleForm.resetFields()
          } else {
            return false
          }
        })
      },
      infoWay () {
        this.dialogFormVisible = false
        this.$message({
          showClose: true,
          message: '发送邮件成功',
          type: 'success',
          onClose: () => {
          }
        })
      },
      // 点击取消
      cancel () {
        this.dialogFormVisible = false
        this.$refs.ruleForm.resetFields()
      },
    }
  }
</script>

