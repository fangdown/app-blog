<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              label-width="auto">
      <kye-form-item label="完结时间">
        <kye-date-picker v-model="form.finishTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="任务编码">
        <kye-input v-model="form.taskCode"
                   class="input-width"></kye-input>
      </kye-form-item>
      <kye-button type="primary"
                  :auth="URL.getCompanyWayBillList"
                  @click="submitForm('form')"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <!-- <kye-canvas-table :stripe="true"
                      :isScroll="true"
                      :column="column"
                      :data="tableData"
                      :selection="true"
                      :operation="operation"
                      :page="page" /> -->
    <div class="query-table-container">
      <table-list :column="column"
                  ref="canvas"
                  :data="tableData"
                  :operation="operation"
                  :options="tableOption"></table-list>
    </div>
    <div class="paging-wrap"
         v-if="page.total > 0">
      <kye-pagination layout="sizes,total,prev,pager,next"
                      background
                      :total="page.total"
                      :page-sizes="pageSizes"
                      :current-page="page.currentPage"
                      class="fixedPagination"
                      :page-size.sync="page.pageSize"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange">
      </kye-pagination>
    </div>
    <!-- 修改发送弹窗 -->
    <change-money ref="child"
                  @submitForm='submitForm'></change-money>
  </div>
</template>
<script>
  // 端口请求
  import URL from '../check.api'
  // 文件格式化
  import * as utils from '../../../utils'
  // 三级地址拼接
  import { formatData } from '../../../utils/formatData'
  // 引入修改弹窗
  import changeMoney from './change-money'
  export default {
    components: { changeMoney },
    data () {
      return {
        URL,
        loading: false,
        auditStatus: true, // 审核
        option: {
          back: '/ecms/financial/check-enterprise-withdraw-detail'
        },
        form: {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
        },
        searchParam: {
          billId: '',
          finishStartTime: '', // 完结开始时间
          finishEndTime: '', // 完结结束时间
          taskCode: '', // 任务编码
          forceCache: true, // 强制刷新标准
          size: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        tableData: [],
        page: {
          pageSize: 200,
          currentPage: 1,
          total: 1
        },
        pageSizes: [200],
        paperStatus: '每页显示200条', // 分页条数
        multipleSelection: [],
        flowId: '', // 识别ID
        operation: {
          label: '操作',
          fixed: 'left',
          width: 40,
          // 操作按钮数组  array | function(row){return []}
          options: [
            {
              label: '修改',
              btnType: 'text', // el-button type
              auth: URL.updateCompanyBillFeeInfo,
              disabled: row => {
                return this.auditStatus
              },
              func: row => {
                this.$refs.child.toView(row, 'enterprise')
              }
            }
          ]
        },
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_finance',
        },
        column: [
          {
            key: 'reportTime',
            label: '承运时间',
            show: true,
            width: '120px',
            filter: 'time'
          },
          {
            key: 'finishTime',
            label: '完结时间',
            show: true,
            width: '120px',
            filter: 'time'
          },
          {
            key: 'taskCode',
            label: '任务编码',
            show: true,
            width: '120px',
          },
          {
            key: 'provenance',
            label: '始发地',
            show: true,
            width: '120px'
          },
          {
            key: 'destination',
            label: '目的地',
            show: true,
            width: '120px'
          },
          {
            key: 'carPlateNum',
            label: '车牌号',
            width: '80px',
            show: true
          },
          {
            key: 'originalPayFee',
            label: '总金额',
            'filter': 'money',
            show: true,
            width: '80px'
          },
          {
            key: 'payFee',
            label: '支付金额',
            'filter': 'money',
            show: true,
            width: '80px'
          },
          {
            key: 'remark',
            label: '备注',
            width: '120px',
            show: true
          }
        ]
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          const list = vm.$route.query.flowId
          if (list) {
            vm.flowId = list
            vm.getCompanyWayBillList()
          } else {
            return false
          }
        } else {
          return false
        }
      })
    },
    methods: {
      // 列表
      async getCompanyWayBillList (params) {
        const val = params || { ...this.searchParam, billId: this.flowId }
        const data = await this.$http(URL.getCompanyWayBillList, val)
        this.page.total = data.total
        this.page.pageSize = data.size
        this.page.currentPage = data.page
        // 缓存：预加载下一页
        if (this.total > 0 && this.total > this.page * this.size) {
          let preData = { ...val, page: this.page + 1 }
          delete preData.forceCache
          this.$http(URL.getCompanyWayBillList, preData, false)
        }
        if (data.pageResp.rows) {
          this.tableData = data.pageResp.rows.map(this.formatData2)
          if (data.auditStatus === 100 || data.auditStatus === 102) {
            this.auditStatus = false
          } else {
            this.auditStatus = true
          }
        } else {
          this.tableData = []
        }
      },
      // 格式化函数
      formatData2 (data) {
        data.finishTime = utils.formatTime(data.finishTime, 'M')// 完结时间
        data.payTime = utils.formatTime(data.payTime, 'M')// 到账时间
        data.reportTime = utils.formatTime(data.reportTime, 'M')// 承运时间
        // data.provenance = data.startProvince + data.startCity + data.startArea// 始发地
        // data.destination = data.endProvince + data.endCity + data.endArea// 目的地
        formatData(data)
        return data
      },
      // 提交表单
      submitForm () {
        const finishStartTime = new Date(this.form.finishTime[0]).getTime()
        const finishEndTime = new Date(this.form.finishTime[1]).getTime()
        const form = this.form
        this.searchParam.billId = this.flowId
        this.searchParam.finishStartTime = finishStartTime // 完结开始时间
        this.searchParam.finishEndTime = finishEndTime // 完结结束时间
        this.searchParam.taskCode = form.taskCode // 任务编码
        this.searchParam.page = this.page.currentPage
        this.searchParam.size = this.page.pageSize
        let params2 = { ...this.searchParam }
        params2.forceCache = true
        this.getCompanyWayBillList(params2)
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        this.form = {
          finishTime: [], // 完结时间
          taskCode: '', // 任务编码
        }
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          size: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.getCompanyWayBillList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          size: this.page.pageSize,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.getCompanyWayBillList(params)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .top14 {
    margin-top: 14px;
  }
  .submit {
    display: inline-block;
    margin-top: 36px;
  }
  .reset {
    border: none;
  }
  .reset:hover {
    background-color: transparent;
  }
  .kye-col {
    padding-left: 4px;
    padding-right: 4px;
  }
  .wbyl-mt16 {
    margin-top: 10px;
  }
  .input-width-l {
    width: 170px;
  }
  .input-width {
    width: 110px;
  }
  .input-width-s {
    width: 70px;
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .ky-erp .el-form-item--mini.el-form-item {
    margin-bottom: 4px;
  }
</style>
