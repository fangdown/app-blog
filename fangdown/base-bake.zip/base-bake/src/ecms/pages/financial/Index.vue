<template>
  <div class="ky-list">
    <searchPage>
      财务管理
    </searchPage>
    <router-view/>
  </div>
</template>
<script>
import searchPage from '@/components/search-page/index'
export default {
  components: {
    searchPage
  }
}
</script>
<style>
  .grey-bg-title{
    height: 32px;
    line-height: 32px;
    padding-left: 12px;
    margin-bottom: 12px;
    background: #f1f1f5;
    font-weight: bold;
    font-size: 14px;
    color: #333333;
     text-align: left;
  }
</style>
