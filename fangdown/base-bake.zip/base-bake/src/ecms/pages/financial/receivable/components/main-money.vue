<template>
  <div>
    <div class="kye-block-title">
      <span>费用项明细</span>
    </div>
    <kye-form ref="ruleForm"
              labkye-width="64px"
              size="mini"
              module-code="ecs_finance"
              :biz-id="$route.query.billID"
              class="form-details"
              :model="ruleForm"
              :rules="rules">
      <kye-row class="useInfo"
               style="margin-left: 0px;
    margin-right: 0px;">
        <kye-col :span="3">
          <kye-form-item label="客户名："
                         prop="companyName">
            <kye-field type="text"
                       v-model="ruleForm.companyName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="3">
          <span>付款类型：</span>
          <span v-if="ruleForm.payType===101">月结</span>
          <span v-else>非月结</span>
        </kye-col>
        <kye-col :span="3">
          <kye-form-item label="托寄物："
                         prop="goodsName">
            <kye-field type="text"
                       v-model="ruleForm.goodsName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="5">
          <kye-form-item label="始发地："
                         prop="startAddress">
            <kye-field type="text"
                       v-model="ruleForm.start"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="5">
          <kye-form-item label="目的地："
                         prop="endAddress">
            <kye-field type="text"
                       v-model="ruleForm.end"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="运费"
                         prop="transportFee">
            <kye-number v-model="ruleForm.transportFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="保价费"
                         prop="insuredFee">
            <kye-number v-model="ruleForm.insuredFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="回单费"
                         prop="receiptFee">
            <kye-number v-model="ruleForm.receiptFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="压车费"
                         prop="escortFee">
            <kye-number v-model="ruleForm.escortFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="装卸费"
                         prop="loadFee">
            <kye-number v-model="ruleForm.loadFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="超里程费"
                         prop="exceedMileageFee">
            <kye-number v-model="ruleForm.exceedMileageFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="空驶费"
                         prop="emptyPlyFee">
            <kye-number v-model="ruleForm.emptyPlyFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="其他费用"
                         prop="otherFee">
            <kye-number v-model="ruleForm.otherFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="发票类型">
            <kye-input :value="ruleForm.invoiceType|lookup('ecs_cw_invoiceType')"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="总金额">
            <kye-input v-model="totalNumber"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input v-model="ruleForm.remark">
            </kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  import URL from '../receivable.api'
  import rules from 'public/utils/rules'
  import { money } from 'public/utils/filter'
  export default {
    props: {
      rowdata: Object,
      required: true
    },
    data () {
      return {
        URL,
        ruleForm: {
          'transportFee': '',
          'insuredFee': '',
          'receiptFee': '',
          'escortFee': '',
          'loadFee': '',
          'exceedMileageFee': '',
          'emptyPlyFee': '',
          'otherFee': '',
          'taxRate': '',
          'end': '',
          'start': '',
          'remark': ''
        },
        totalNumber: '', // 总数
        isModify: true,
        isBan: false, // 禁用
        symbol: false, // 金钱符号
        taskCode: '',
        id: '',
        btnShow: false, // 按钮的展示
        // 校验规则
        rules: {
          // moneyNum: [
          //   { type: 'date', required: true, message: '请选择日期', trigger: 'blur' }
          // ],
          transportFee: rules.str('请输入运费', true, 'blur'),
          insuredFee: rules.str('请输入保价金额', true, 'blur'),
          receiptFee: rules.str('请输入回单费', true, 'blur'),
          escortFee: rules.str('请输入压车费', true, 'blur'),
          loadFee: rules.str('请输入装卸费', true, 'blur'),
          exceedMileageFee: rules.str('请输入超里程费', true, 'blur'),
          emptyPlyFee: rules.str('请输入空驶费', true, 'blur'),
          otherFee: rules.str('请输入其他费用', true, 'blur'),
          remark: rules.str('备注内容不能为空', true, 'blur')
        }
      }
    },
    mounted () {
      this.ruleForm = this.rowdata
      // 始发地和目的地的三级拼接
      this.ruleForm.start = this.rowdata.startProvince + this.rowdata.startCity + this.rowdata.startArea
      this.ruleForm.end = this.rowdata.endProvince + this.rowdata.endCity + this.rowdata.endArea
      this.totalNumber = money(this.rowdata.totalFee)
    },
    methods: {
      // 进入页面初始化数据
      initData () {
        this.id = this.$route.params.id
        this.customerSlipDetailByTaskCode()
      },
      // 请求应收费用录入详情
      async customerSlipDetailByTaskCode () {
        const data = await this.$http(URL.customerSlipDetailByTaskCode, { id: this.id })
        this.ruleForm = data
        this.totalNumber = data.totalFee
      },
      // 计算总和
      addNumber () {
        this.totalNumber = null
        const ruleForm = this.ruleForm
        const taxRate = ruleForm.taxRate
        this.totalNumber = (ruleForm.transportFee - 0) + (ruleForm.insuredFee - 0) + (ruleForm.receiptFee - 0) + (ruleForm.escortFee - 0) + (ruleForm.loadFee - 0) + (ruleForm.exceedMileageFee - 0) + (ruleForm.emptyPlyFee - 0) + (ruleForm.otherFee - 0)
        this.totalNumber = this.totalNumber / (1 - taxRate)
        this.totalNumber = money(this.totalNumber)
      },
      // 点击修改，解锁数据可修改
      modifyFunc () {
        this.isBan = false
        this.symbol = true
        this.btnShow = false
      },
      // 取消数据还原
      resetForm (formName) {
        this.$emit('goBackDetail')
      },
      // 保存提交数据
      async submitForm (formName) {
        this.id = this.$route.params.id
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            const ruleForm = this.ruleForm
            const len = ruleForm.remark.replace(/[^x00-xff]/g, 'xx').length
            if (len > 100) {
              this.$message({
                message: '备注信息不能超过50字',
                type: 'info'
              })
              return false
            }
            const param = {
              'id': this.id,
              'receiptFee': ruleForm.receiptFee,
              'escortFee': ruleForm.escortFee,
              'loadFee': ruleForm.loadFee,
              'exceedMileageFee': ruleForm.exceedMileageFee,
              'emptyPlyFee': ruleForm.emptyPlyFee,
              'otherFee': ruleForm.otherFee,
              'remark': ruleForm.remark,
              'transportFee': ruleForm.transportFee,
              'insuredFee': ruleForm.insuredFee
            }
            await this.$http(URL.addCustomerFee, param)
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            // this.btnShow = true
            // // this.isBan = true
            // this.$emit('changelog')
            this.$emit('goBackDetail')
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .useInfo {
    margin: 0 0 10px;
    height: 28px;
    line-height: 28px;
    overflow: hidden;
    background: #f8f8fa;
    font-size: 12px;
    padding: 0 16px;
    .kye-field-content {
      border: none;
      height: 28px;
      line-height: 28px;
      color: #666;
    }
    .kye-col {
      span:first-child {
        color: #666;
      }
      span:last-child {
        color: #333;
      }
      .moneyColor {
        color: #ff9300 !important;
      }
    }
  }
</style>
