<template>
  <div class="receivable kye-detail">
    <kye-expand-page>
      <search-pager :option="option"
                    :tools="searchTools"></search-pager>
      <div class="kye-block-title">费用项明细</div>
      <kye-form ref="ruleForm"
                labkye-width="64px"
                size="mini"
                module-code="ecs_finance"
                :biz-id="$route.query.billID"
                class="form-details"
                :model="ruleForm">
        <kye-row class="useInfo"
                 style="margin-left: 0px;
    margin-right: 0px;">
          <kye-col :span="3">
            <kye-form-item label="客户名："
                           prop="companyName">
              <kye-field type="text"
                         v-model="ruleForm.companyName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="3">
            <span>付款类型：</span>
            <span v-if="ruleForm.payType===101">月结</span>
            <span v-else>非月结</span>
          </kye-col>
          <kye-col :span="3">
            <kye-form-item label="托寄物："
                           prop="goodsName">
              <kye-field type="text"
                         v-model="ruleForm.goodsName"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="5">
            <kye-form-item label="始发地："
                           prop="startAddress">
              <kye-field type="text"
                         v-model="ruleForm.start"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="5">
            <kye-form-item label="目的地："
                           prop="endAddress">
              <kye-field type="text"
                         v-model="ruleForm.end"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="运费"
                           prop="transportFee">
              <kye-field type="text"
                         v-model="ruleForm.transportFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="保价费"
                           prop="insuredFee">
              <kye-field type="text"
                         v-model="ruleForm.insuredFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="回单费"
                           prop="receiptFee">
              <kye-field type="text"
                         v-model="ruleForm.receiptFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="压车费"
                           prop="escortFee">
              <kye-field type="text"
                         v-model="ruleForm.escortFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="装卸费"
                           prop="loadFee">
              <kye-field type="text"
                         v-model="ruleForm.loadFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="超里程费"
                           prop="exceedMileageFee">
              <kye-field type="text"
                         v-model="ruleForm.exceedMileageFee"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="空驶费"
                           prop="emptyPlyFee">
              <kye-field type="text"
                         v-model="ruleForm.emptyPlyFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="其他费用"
                           prop="otherFee">
              <kye-field type="text"
                         v-model="ruleForm.otherFee"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="总金额">
              <kye-field type="text"
                         v-model="totalNumber"></kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="发票类型">
              <kye-field>{{ruleForm.invoiceType|lookup('ecs_cw_invoiceType')}}</kye-field>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="备注"
                           prop="remark">
              <kye-field type="text"
                         v-model="ruleForm.remark"></kye-field>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
      <div class="kye-block-title">费用单据信息</div>
      <div style="margin-bottom:12px">
        <table-list :column="column2"
                    :data="dataInfo"
                    :options="tableOption"
                    :operation="operation"></table-list>
      </div>
      <div class="kye-block-title">费用修改日志</div>
      <table-list :column="column"
                  :data="tableData"
                  :options="tableOption"></table-list>
    </kye-expand-page>
    <kye-dialog title="费用单据"
                :visible.sync="showImgVisible"
                width="758px">
      <kye-image :config="configs"
                 v-if="showImgVisible" />
    </kye-dialog>
  </div>

</template>
<script>
  import URL from './receivable.api'
  // import * as utils from '../../utils'
  import { money } from 'public/utils/filter'
  export default {
    data () {
      return {
        URL,
        option: {
          back: '/ecms/financial/accounts-receivable',
          method: URL.customerSlipSummary,
          searchCode: 'ecs_zc_financial_list_search_define',
          idKey: 'id',
        },
        dataInfo: [],
        showImgVisible: false, // 图片弹窗
        configs: {
          width: 724,
          height: 543,
          imgSrc: ''
        },
        btnShow: false, // 按钮的展示
        tableData: [],
        ruleForm: {
          'transportFee': '',
          'insuredFee': '',
          'receiptFee': '',
          'escortFee': '',
          'loadFee': '',
          'exceedMileageFee': '',
          'emptyPlyFee': '',
          'otherFee': '',
          'invoiceType': '',
          'start': '',
          'end': '',
          'remark': ''
        },
        taxRate: '', // 税率
        totalNumber: '', // 总数
        id: '',
        // taskCode: '',
        searchTools: [
          {
          }],
        column: [{
          'key': 'feeName',
          'label': '变更项',
          'width': '60px',
          'show': true
        }, {
          'key': 'newAmount',
          'label': '当前金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'originalAmount',
          'label': '原始金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'entryPerson',
          'label': '操作人',
          'width': '60px',
          'show': true
        }, {
          'key': 'updateTime',
          'label': '录入时间',
          'width': '130px',
          'filter': 'time',
          'show': true
        }],
        column2: [{
          'key': 'costName',
          'label': '费用项目',
          'width': '80px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注说明',
          'width': '100px',
          'show': true
        }, {
          'key': 'uploader',
          'label': '上传人',
          'width': '60px',
          'show': true
        }, {
          'key': 'uploadTime',
          'label': '上传时间',
          'width': '130px',
          'show': true
        }],
        operation: {
          label: '操作',
          fixed: 'right',
          width: '60px',
          // 操作按钮数组  array | function(row){return []}
          options: [
            {
              type: 'button', // link | button
              label: '查看图片',
              // auth: URL.driverFeeDetail,
              func: row => {
                this.imgView(row)
              }
            }
          ]
        },
        tableOption: {
          stripe: true,
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.initData()
        } else {
          return false
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.initData(to.params.id)
      next()
    },
    methods: {
      // 进入页面初始化数据
      initData (id) {
        this.tableData = []
        this.id = id || this.$route.params.id
        this.feeBillList()
        this.customerFeeChangeLog()
        this.customerSlipDetailByTaskCode()
      },
      // 请求应收费用录入详情
      async customerSlipDetailByTaskCode () {
        const data = await this.$http(URL.customerSlipDetailByTaskCode, { id: this.id })
        if (data.auditStatus) {
          switch (data.auditStatus) {
            case 100:
              this.btnShow = true
              break
            default:
              this.btnShow = false
              break
          }
        }
        this.ruleForm = this.toMoney(data)
        // 始发地和目的地的三级拼接
        this.ruleForm.start = data.startProvince + data.startCity + data.startArea
        this.ruleForm.end = data.endProvince + data.endCity + data.endArea
        this.totalNumber = money(data.totalFee)
        this.taxRate = data.taxRate
      },
      // 费用格式转化
      toMoney (data) {
        data.transportFee = money(data.transportFee)
        data.insuredFee = money(data.insuredFee)
        data.receiptFee = money(data.receiptFee)
        data.escortFee = money(data.escortFee)
        data.emptyPlyFee = money(data.emptyPlyFee)
        data.loadFee = money(data.loadFee)
        data.exceedMileageFee = money(data.exceedMileageFee)
        data.otherFee = money(data.otherFee)
        return data
      },
      // 单据信息列表
      async feeBillList () {
        const data = await this.$http(URL.feeBillList, { id: this.id, feeType: '1' })
        this.dataInfo = data
      },
      // 修改
      costsChange () {
        this.$router.push(`/ecms/financial/accounts-receivable-change/${this.id}`)
      },
      // 查看图片
      imgView (row) {
        this.showImgVisible = true
        this.configs.imgSrc = row.picture
      },
      // 取消按钮
      goBack () {
        this.$router.push({ path: '/ecms/financial/accounts-receivable' })
      },
      // 更新日志
      async customerFeeChangeLog () {
        const data = await this.$http(URL.customerFeeChangeLog, { id: this.id })
        this.tableData = data
      },
      audit () { // 审核
      },
    }
  }
</script>
<style lang="scss" scoped>
  .el-table__empty-block {
    min-height: 28px;
  }
  .useInfo {
    height: 28px;
    line-height: 28px;
    overflow: hidden;
    background: #f8f8fa;
    margin: 0 0 10px;
    font-size: 12px;
    padding: 0 16px;
    .kye-field-content {
      border: none;
      height: 28px;
      line-height: 28px;
    }
    .kye-col {
      span:first-child {
        color: #666;
      }
      span:last-child {
        color: #333;
      }
      .moneyColor {
        color: #ff9300 !important;
      }
    }
  }
  .footBtn {
    text-align: center;
    margin: 20px 0;
  }
  .receivable .el-table__empty-block {
    min-height: 28px;
  }
</style>
