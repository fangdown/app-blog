const perfix = 'ecs.finance.receivable.'
const URL = {
  // 应收汇总
  customerSlipSummary: `${perfix}customerSlipSummary.do`,
  // 应收费用修改日志
  customerFeeChangeLog: `${perfix}customerFeeChangeLog.do`,
  // 应收费用录入详情
  customerSlipDetailByTaskCode: `${perfix}customerSlipDetailByTaskCode.do`,
  // 应收费用录入
  addCustomerFee: `${perfix}addCustomerFee.do`,
  // 应收费用审核
  customerFeeAudit: `${perfix}customerFeeAudit.do`,
  // 单据信息列表
  feeBillList: `${perfix}feeReceivableBillList.do`,
  // 新增单据
  addFeeBill: `${perfix}addReceivableFeeBill.do`,
  // 单据删除
  deleteCostBill: `${perfix}deleteReceivableCostBill.do`,
  // 异常导出
  exportAbnormalCustomerFee: `${perfix}exportAbnormalCustomerFee.do`,
  // base64上传接口
  uploadFilesBase64: `ecs.yc.file.uploadBase64CodeFile.do`
}
export default URL
