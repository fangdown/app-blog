<template>
  <div>
    <div class="kye-block-title">
      <span>费用项明细</span>
      <div class="taskStatus"
           v-if="ruleForm.reimburseStatus===200||ruleForm.reimburseStatus===300"><span>报销编号 : </span>
        <span>{{ruleForm.reimburseNo}}</span>
      </div>
      <div class="taskStatus"
           v-if="ruleForm.reimburseStatus!==0"><span>报销状态 : </span>
        <span>{{ruleForm.reimburseStatus|lookup('ecs_cw_reimburseStatus')}}</span>
      </div>
      <div class="taskStatus"><span>运单状态 : </span>
        <span>{{ruleForm.taskStatus|lookup('ecs_cw_taskStatus')}}</span>
      </div>
    </div>
    <kye-form ref="ruleForm"
              labkye-width="64px"
              size="mini"
              class="form-details"
              :model.sync="ruleForm"
              module-code="ecs_finance"
              :biz-id="$route.params.id"
              :rules="rules">
      <kye-row class="useInfo"
               style="margin-left: 0px;
    margin-right: 0px;">
        <kye-col :span="4">
          <kye-form-item label="任务编码："
                         prop="taskCode">
            <kye-field type="text"
                       v-model="ruleForm.taskCode"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="3">
          <kye-form-item label="司机名称："
                         prop="driverName">
            <kye-field type="text"
                       v-model="ruleForm.driverName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="手机号："
                         prop="driverPhone">
            <kye-field type="text"
                       v-model="ruleForm.driverPhone"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="3">
          <span>运力类型：</span>
          <span v-if="ruleForm.driverType===1">非合同个体</span>
          <span v-else-if="ruleForm.driverType===2">平台</span>
          <span v-else-if="ruleForm.driverType===3">非合同企业</span>
          <span v-else-if="ruleForm.driverType===4">合同个人</span>
          <span v-else-if="ruleForm.driverType===5">合同企业</span>
        </kye-col>
        <kye-col :span="5">
          <span>押金剩余：</span>
          <span style="color:#FF9300">{{ruleForm.depositBalance||'0' | money}}</span>
        </kye-col>
      </kye-row>
      <!-- 取派业务 -->
      <kye-row v-if="businessType==='qp'">
        <kye-col :span="4">
          <kye-form-item label="运费"
                         prop="transportFee">
            <kye-number v-model="ruleForm.transportFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="上楼费"
                         prop="climbFee">
            <kye-number v-model="ruleForm.climbFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="装卸费"
                         prop="loadFee">
            <kye-number v-model="ruleForm.loadFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="空驶费"
                         prop="emptyPlyFee">
            <kye-number v-model="ruleForm.emptyPlyFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="压车费"
                         prop="escortFee">
            <kye-number v-model="ruleForm.escortFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="叉车费"
                         prop="forkliftFee">
            <kye-number v-model="ruleForm.forkliftFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <!-- 其他业务 -->
      <kye-row v-else>
        <kye-col :span="4">
          <kye-form-item label="运费"
                         prop="transportFee">
            <kye-number v-model="ruleForm.transportFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="压车费"
                         prop="escortFee">
            <kye-number v-model="ruleForm.escortFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="空驶费"
                         prop="emptyPlyFee">
            <kye-number v-model="ruleForm.emptyPlyFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="超里程费"
                         prop="exceedMileageFee">
            <kye-number v-model="ruleForm.exceedMileageFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="取消费"
                         prop="canclePenaltyFee">
            <kye-number v-model="ruleForm.canclePenaltyFee"
                        symbol="￥"
                        unit=""
                        :max="0"
                        :min="-100000"
                        :disabled='isBan'>
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4"
                 v-show="otherClass">
          <kye-form-item label="其他费用"
                         prop="otherFee">
            <kye-number v-model="ruleForm.otherFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <!-- 取派业务 -->
      <kye-row v-if="businessType==='qp'"
               key="ruleForm">
        <kye-col :span="4">
          <kye-form-item label="入仓费"
                         prop="enterWarehouseFee">
            <kye-number v-model="ruleForm.enterWarehouseFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="报关费"
                         prop="customsDeclarationFee">
            <kye-number v-model="ruleForm.customsDeclarationFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="续票费"
                         prop="continuingTicketFee">
            <kye-number v-model="ruleForm.continuingTicketFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="超时费"
                         prop="overtimeFee">
            <kye-number v-model="ruleForm.overtimeFee"
                        symbol="￥"
                        unit=""
                        :max="0"
                        :min="-100000"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="其他费用"
                         prop="otherFee">
            <kye-number v-model="ruleForm.otherFee"
                        symbol="￥"
                        unit=""
                        :max="100000"
                        :min="0"
                        :disabled='isBan'
                        @change="addNumber()">
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="保险费">
            <kye-input v-model="insurance"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <!-- 其他业务 -->
      <kye-row v-else>
        <kye-col :span="4">
          <kye-form-item label="迟到费"
                         prop="latePenaltyFee">
            <kye-number v-model="ruleForm.latePenaltyFee"
                        symbol="￥"
                        unit=""
                        :max="0"
                        :min="-100000"
                        :disabled='isBan'>
            </kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="保险费">
            <kye-input v-model="insurance"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="总金额">
            <kye-input v-model="totalNumber"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input type="text"
                       :disabled='isBan'
                       v-model="ruleForm.remark"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row v-if="businessType==='qp'"
               key="remark">
        <kye-col :span="4">
          <kye-form-item label="总金额">
            <kye-input v-model="totalNumber"
                       :disabled='true'>
            </kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="10">
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input type="text"
                       :disabled='isBan'
                       v-model="ruleForm.remark"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  import URL from '../cope-with.api'
  // 表单校验规则
  import rules from 'public/utils/rules'
  // 金额过滤器
  import { money } from 'public/utils/filter'
  export default {
    props: {
      rowdata: Object,
      required: true
    },
    data () {
      return {
        URL,
        ruleForm: {
          'transportFee': '',
          'insuredFee': '',
          'receiptFee': '',
          'escortFee': '',
          'loadFee': '',
          'exceedMileageFee': '',
          'emptyPlyFee': '',
          'otherFee': '',
          'climbFee': '',
          'enterWarehouseFee': '',
          'forkliftFee': '',
          'continuingTicketFee': '',
          'overtimeFee': '',
          'customsDeclarationFee': '',
          'insurance': '',
          'taskStatus': '',
          'reimburseStatus': '',
          'reimburseNo': '',
          'remark': ''
        },
        totalNumber: '', // 总数
        insurance: null, // 保险费
        isModify: false,
        isBan: false, // 禁用
        symbol: false, // 金钱符号
        taskCode: '',
        billID: '',
        businessType: '', // 业务类型
        qpClass: false, // 干线类型
        otherClass: true, // 其他业务类型
        btnShow: false, // 按钮的展示
        // 校验规则
        rules: {
          transportFee: rules.str('请输入运费', true, 'blur'),
          escortFee: rules.str('请输入压车费', true, 'blur'),
          emptyPlyFee: rules.str('请输入空驶费', true, 'blur'),
          exceedMileageFee: rules.str('请输入超里程费', true, 'blur'),
          canclePenaltyFee: rules.str('请输入取消费', true, 'blur'),
          otherFee: rules.str('请输入其他费用', true, 'blur'),
          latePenaltyFee: rules.str('请输入迟到费', true, 'blur'),
          remark: rules.str('备注内容不能为空', true, 'blur'),
          // 干派
          climbFee: rules.str('上楼费不能为空', true, 'blur'),
          loadFee: rules.str('装卸费不能为空', true, 'blur'),
          forkliftFee: rules.str('叉车费不能为空', true, 'blur'),
          enterWarehouseFee: rules.str('入仓费不能为空', true, 'blur'),
          overtimeFee: rules.str('超时费不能为空', true, 'blur'),
          customsDeclarationFee: rules.str('报关费不能为空', true, 'blur'),
          continuingTicketFee: rules.str('续票费不能为空', true, 'blur')
        }
      }
    },
    mounted () {
      this.id = this.$route.params.id
      this.driverFeeDetail()
    },
    methods: {
      // 进入页面初始化数据
      initData () {
        this.id = this.$route.params.id
        this.driverFeeDetail()
        // this.isBan = true
      },
      // 请求应收费用录入详情
      async driverFeeDetail () {
        if (this.rowdata.businessType) {
          this.$emit('businessType', this.rowdata.businessType)
          // 判断是否为  取派类型
          switch (this.rowdata.businessType) {
            case 3:
              this.businessType = 'qp'
              break
            default:
              this.businessType = ''
              break
          }
        }
        this.ruleForm = this.rowdata
        this.totalNumber = this.rowdata.payFee
        this.totalNumber = money(this.totalNumber)
        this.insurance = money(this.rowdata.insurance)
      },
      // 计算总和
      addNumber () {
        this.totalNumber = null
        const ruleForm = this.ruleForm
        if (this.businessType === 'qp') {
          this.totalNumber = (ruleForm.transportFee - 0) + (ruleForm.climbFee - 0) + (ruleForm.loadFee - 0) + (ruleForm.emptyPlyFee - 0) + (ruleForm.escortFee - 0) + (ruleForm.forkliftFee - 0) + (ruleForm.enterWarehouseFee - 0) + (ruleForm.customsDeclarationFee - 0) + (ruleForm.continuingTicketFee - 0) + (ruleForm.overtimeFee - 0) + (ruleForm.otherFee - 0) + (ruleForm.insurance - 0)
          this.totalNumber = money(this.totalNumber)
        } else {
          this.totalNumber = (ruleForm.transportFee - 0) + (ruleForm.escortFee - 0) + (ruleForm.emptyPlyFee - 0) + (ruleForm.exceedMileageFee - 0) + (ruleForm.otherFee - 0) + (ruleForm.insurance - 0)
          this.totalNumber = money(this.totalNumber)
        }
      },
      // 点击修改，解锁数据可修改
      modifyFunc () {
        this.isBan = false
        this.symbol = true
        this.btnShow = false
      },
      // 取消数据还原
      resetForm (formName) {
        this.$emit('goBackDetail')
      },
      // 保存提交数据
      submitForm (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            const ruleForm = this.ruleForm
            const len = ruleForm.remark.replace(/[^x00-xff]/g, 'xx').length
            if (len > 100) {
              this.$message({
                message: '备注信息不能超过50字',
                type: 'info'
              })
              return false
            }
            let param = {}
            if (this.businessType === 'qp') {
              param = {
                'id': this.id,
                'taskStatus': 0,
                'escortFee': ruleForm.escortFee, // 压车费
                'loadFee': ruleForm.loadFee, // 装卸费
                'emptyPlyFee': ruleForm.emptyPlyFee, // 空驶费
                'otherFee': ruleForm.otherFee, // 其他费用
                'remark': ruleForm.remark, // 备注
                'transportFee': ruleForm.transportFee, // 运费
                'climbFee': ruleForm.climbFee, // 爬楼费
                'forkliftFee': ruleForm.forkliftFee, // 叉车费
                'enterWarehouseFee': ruleForm.enterWarehouseFee, // 入仓费
                'customsDeclarationFee': ruleForm.customsDeclarationFee, // 报关费
                'continuingTicketFee': ruleForm.continuingTicketFee, // 续票费
                'overtimeFee': ruleForm.overtimeFee// 超时费
              }
            } else {
              param = {
                'id': this.id,
                'taskStatus': 0,
                'escortFee': ruleForm.escortFee, // 压车费
                'exceedMileageFee': ruleForm.exceedMileageFee, // 超里程费
                'emptyPlyFee': ruleForm.emptyPlyFee, // 空驶费
                'otherFee': ruleForm.otherFee, // 其他费用
                'latePenaltyFee': ruleForm.latePenaltyFee, // 司机迟到罚金
                'canclePenaltyFee': ruleForm.canclePenaltyFee, // 司机取消订单罚金
                'remark': ruleForm.remark, // 备注
                'transportFee': ruleForm.transportFee// 运费
              }
            }
            await this.$http(URL.addDriverFee, param)
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            // this.$emit('changelog')
            this.$emit('goBackDetail')
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .useInfo {
    height: 28px;
    line-height: 28px;
    overflow: hidden;
    background: #f8f8fa;
    margin: 0 0 10px;
    font-size: 12px;
    padding: 0 16px;
    .kye-field-content {
      border: none;
      height: 28px;
      line-height: 28px;
      color: #666;
    }
    .el-form-item__label span {
      color: #666;
    }
    span {
      color: #666;
    }
    .el-col {
      height: 28px;
    }
    .kye-col {
      span:first-child {
        color: #666;
      }
      span:last-child {
        color: #666;
      }
    }
  }
  .taskStatus {
    float: right;
    margin-right: 30px;
    color: #666;
    line-height: 28px;
    font-size: 12px;
  }
</style>
