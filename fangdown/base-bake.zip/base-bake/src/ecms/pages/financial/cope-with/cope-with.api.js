const perfix = 'ecs.finance.handle.'
const URL = {
  // 应付汇总
  diverSlipSummary: `${perfix}diverSlipSummary.do`,
  // 应付费用修改日志
  driverFeeChangeLog: `${perfix}driverFeeChangeLog.do`,
  // 应付费用录入详情
  driverFeeDetail: `${perfix}driverFeeDetail.do`,
  // 应付费用录入
  addDriverFee: `${perfix}addDriverFee.do`,
  // 应付费用审核
  driverFeeAudit: `${perfix}driverFeeAudit.do`,
  // 单据信息列表
  feeBillList: `${perfix}feeHandleBillList.do`,
  // 新增单据
  addFeeBill: `${perfix}addHandleFeeBill.do`,
  // 单据删除
  deleteCostBill: `${perfix}deleteHandleCostBill.do`,
  // base64上传接口
  uploadFilesBase64: `ecs.yc.file.uploadBase64CodeFile.do`
}
export default URL
