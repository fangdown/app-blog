<template>
  <div class="ky-list">
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-model="formModel"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
  </div>
</template>
<script>
  import URL from './cope-with.api'
  export default {
    data () {
      return {
        tables: [
          {
            searchCode: 'ecs_yc_financial_list_field',
            url: { method: URL.diverSlipSummary },
            option: {
              load: false,
              stripe: true,
              moduleCode: 'ecs_finance',
              detailAuth: URL.driverFeeDetail,
              rowDblClick:
                row => {
                  this.costsDetail(row)
                },
              beforeFormSubmit: (data, model) => {
                let isEmpty = true // 是否有条件
                const obj = {}
                // 没有选择时间时清空data里面startTime，endTime
                delete data.startConfirmTime
                delete data.endConfirmTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'confirmTime') {
                      // 格式化时间
                      if (model.confirmTime && model.confirmTime.length === 2) {
                        const startConfirmTime = new Date(model.confirmTime[0]).getTime()
                        const endConfirmTime = new Date(model.confirmTime[1]).getTime()
                        Object.assign(obj, {
                          startConfirmTime,
                          endConfirmTime
                        })
                        isEmpty = false
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
            },
            operation: {
              label: '操作',
              fixed: 'right',
              width: '60px',
              // 操作按钮数组  array | function(row){return []}
              options: [
                {
                  type: 'button', // link | button
                  label: '费用修改',
                  auth: URL.driverFeeDetail,
                  disabled: row => {
                    return row.auditStatus !== 100
                  },
                  func: row => {
                    this.costsChange(row)
                  }
                }
              ]
            },
            formatter: {}
          }
        ],
        generic: {
          method: URL.diverSlipSummary,
          searchCode: 'ecs_financial_basic_search'
        },
        formModel: {
          confirmTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
        },
        option: {
          searchCode: 'ecs_yc_financial_list_search_define'
        },
        tools: [
        ],
        formTools: [
          {
            label: '刷新',
            auth: URL.diverSlipSummary,
            icon: 'reset',
            func: () => {
              this.$refs.queryTable.loadData()
            }
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          }]
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // 审核后跳转强刷新
        if (vm.$route.query.reset) {
          vm.$refs.queryTable.loadData()
        } else {
          return false
        }
      })
    },
    methods: {
      // 费用修改
      costsChange (row) {
        this.$router.push(`/ecms/financial/cope-with-change/${row.id}`)
      },
      // 费用详情
      costsDetail (row) {
        this.$router.push(`/ecms/financial/cope-with-detail/${row.id}`)
      },
    }
  }
</script>
