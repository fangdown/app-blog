<template>
  <div>
    <div class="tab-operation"
         style="margin-top: -6px">
      <kye-button type="text"
                  class="kye-button--text kye-button--mini"
                  :auth="URL.addFeeBill"
                  @click="handleShowAddDataDialog"
                  v-if="btnShow"
                  icon="iconfont icon-plus">新增
      </kye-button>
      <kye-button type="text"
                  class="kye-button--text kye-button--mini"
                  :auth="URL.deleteCostBill"
                  @click="deleteSelectedInfo"
                  :disabled='deleteBtn'
                  v-if="btnShow"
                  icon="iconfont icon-delete">删除
      </kye-button>
    </div>
    <div style="margin-bottom:12px">
      <table-list :column="column2"
                  :data="rowdata"
                  :options="tableOption"
                  :operation="operation"></table-list>
    </div>
    <kye-dialog title="新增费用单据"
                :visible.sync="showAddDataDialog"
                @close="cancel"
                style="text-align:left"
                width='390px'>
      <kye-form ref="ruleForm"
                :model="addDataForm"
                size="mini"
                labkye-position="left">
        <kye-row>
          <kye-form-item label="费用项目"
                         prop="attachmentType"
                         :rules="[
                              { required: true, message: '不能为空',trigger:'change'},
                            ]">
            <kye-select v-model="addDataForm.attachmentType"
                        style="width:120px"
                        v-if="businessType==='qp'"
                        autocomplete="off"
                        :maxlength="110"
                        clearable>
              <kye-option v-for="item in lookUpOptions['ecs_cw_copeWith_qp']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
            <kye-select v-model="addDataForm.attachmentType"
                        style="width:100px"
                        v-else
                        autocomplete="off"
                        :maxlength="100"
                        clearable>
              <kye-option v-for="item in lookUpOptions['ecs_cw_copeWith']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
          <kye-form-item label="备注说明"
                         prop="remark"
                         :rules="[
                              { required: true, message: '不能为空',trigger:'blur'},
                            ]">
            <kye-input v-model="addDataForm.remark"
                       autocomplete="off"
                       :maxlength="100"
                       clearable></kye-input>
          </kye-form-item>
        </kye-row>
        <kye-row>
          <kye-col class="ecs_center">
            <el-upload class="avatar-uploader"
                       :show-file-list="false"
                       :accept="'image/*'"
                       action="/router/upload"
                       :auto-upload="true"
                       :before-upload="beforeUploadPapersPic">
              <img v-if="pictureView"
                   :src="pictureView"
                   class="avatar">
              <i v-else
                 class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
            <div class="el-upload__text">点击上传单据图片</div>
          </kye-col>
        </kye-row>
      </kye-form>
      <div slot="footer"
           class="dialog-footer">
        <kye-button type="primary"
                    @click="showAddDataDialogSave"
                    hotkey="crtl+s">保存(S)</kye-button>
        <kye-button @click="cancel">取消</kye-button>
      </div>
    </kye-dialog>
    <kye-dialog title="费用单据"
                :visible.sync="showImgVisible"
                width="758px">
      <div class="imgClass">
        <kye-image :config="configs" />
      </div>
    </kye-dialog>
  </div>
</template>

<script>
  import mixins from 'public/mixins'
  import URL from '../cope-with.api'
  // 表单校验
  import { submitForm } from '../../../utils/validate'
  export default {
    mixins: [mixins],
    props: {
      rowdata: {
        type: Array,
        required: true
      },
      rowtype: {
        type: Number,
        required: true
      }
    },
    data () {
      return {
        URL,
        pictureView: '', // 上传保险照片预览
        deleteBtn: true, // 删除按钮的禁用
        btnShow: true, // 按钮的展示
        addDataForm: {
          'remark': '',
          'attachmentUrl': '',
          'attachmentType': ''
        }, // 证件信息-资料上传-新增资料表单
        dataInfo: [],
        id: '',
        showAddDataDialog: false, // 显示证件信息-资料上传-新增资料弹窗
        showImgVisible: false, // 图片弹窗
        radioArry: [], //  选中的列数据
        businessType: '',
        imgSrc: '',
        configs: {
          width: 724,
          height: 543,
          imgSrc: ''
        },
        column2: [{
          'key': 'costName',
          'label': '费用项目',
          'width': '80px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注说明',
          'width': '100px',
          'show': true
        }, {
          'key': 'uploader',
          'label': '上传人',
          'width': '60px',
          'show': true
        }, {
          'key': 'uploadTime',
          'label': '上传时间',
          'width': '130px',
          'filter': 'time',
          'show': true
        }],
        tableOption: {
          type: 'selection',
          stripe: true,
          moduleCode: 'ecs_finance',
          selectionChange: (val) => {
            this.radioArry = val
            if (val.length === 1) {
              this.deleteBtn = false
            } else {
              this.deleteBtn = true
            }
          }
        },
        operation: {
          label: '操作',
          fixed: 'right',
          width: '60px',
          options: [
            {
              type: 'button', // link | button
              label: '查看图片',
              // auth: URL.driverFeeDetail,
              func: row => {
                this.imgView(row)
              }
            }
          ]
        },
      }
    },
    mounted () {
      this.id = this.$route.params.id
      this.toBusinessType(this.rowtype)
    },
    methods: {
      // 进入页面初始化数据
      initData () {
        this.id = this.id = this.$route.params.id
        this.feeBillList()
      },
      // 判断类型
      toBusinessType (data) {
        switch (data) {
          case 3:
            this.businessType = 'qp'
            break
          default:
            this.businessType = ''
            break
        }
      },
      // 查看图片
      imgView (row) {
        this.showImgVisible = true
        this.configs.imgSrc = row.picture
      },
      // 刷新单据信息列表
      async feeBillList () {
        this.$emit('feeBillList')
      },
      // 显示新增资料上传弹窗
      handleShowAddDataDialog () {
        // if (this.addDataForm.attachmentUrl) {
        //   this.$refs.upload.clearFiles()
        // }
        this.pictureView = ''
        this.addDataForm.attachmentUrl = ''
        this.addDataForm.attachmentType = ''
        this.addDataForm.remark = ''
        this.showAddDataDialog = true
      },
      // 新增资料弹窗--保存
      async showAddDataDialogSave () {
        // 表单校验
        if (typeof submitForm('ruleForm', this) === 'object') {
          return false
        }
        const save = Object.assign({}, this.addDataForm)
        if (!this.addDataForm.attachmentUrl) {
          this.$message({
            type: 'info',
            message: '请上传相关图片'
          })
          return false
        }
        // const addDataForm = this.addDataForm
        const params = {
          feeId: this.id, // 费用id
          remark: save.remark, // 上传附件说明
          picture: save.attachmentUrl, // 附件保存路径
          costName: save.attachmentType, // 费用名称
          feeType: 2 // 应付
        }
        await this.$http(URL.addFeeBill, params)
        this.showAddDataDialog = false
        this.$message({
          message: '操作成功',
          type: 'success'
        })
        this.feeBillList()
        this.$refs.ruleForm.resetFields()
      },
      // 删除选中的数据
      deleteSelectedInfo () {
        const costBillId = this.radioArry[0].costBillId
        if (!costBillId) {
          this.$message({
            showClose: true,
            message: '请选择要删除的数据！',
            type: 'error'
          })
          return
        }
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.$http(URL.deleteCostBill, { 'id': costBillId })
          this.feeBillList() // 重新查询
          this.$message({
            showClose: true,
            message: '删除成功！',
            type: 'success'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      // 点击取消
      cancel () {
        this.showAddDataDialog = false
        this.$refs.ruleForm.resetFields()
      },
      // 上传图片
      async beforeUploadPapersPic (file) {
        const that = this
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = async function (e) {
          const data = await that.$http(URL.uploadFilesBase64, { base64Code: this.result, fileType: 1 })
          that.addDataForm.attachmentUrl = data
          that.pictureView = this.result // 预览
        }
        return false
      }
    }
  }
</script>
<style lang="scss" scoped>
  .ky-table .el-table__empty-block {
    min-height: 28px;
  }
  .ecs_center {
    text-align: center;
  }
  .avatar-uploader .el-upload {
    border: 1px solid #dcdae2;
    border-radius: 6px;
    width: 128px;
    height: 128px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    background-color: #f1f1f5;
  }
  .avatar-uploader .el-upload:hover {
    background-color: #f6f6fa;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 128px;
    height: 128px;
    line-height: 128px;
    text-align: center;
  }
  .avatar {
    width: 128px;
    height: 128px;
    display: block;
  }
  .imgClass {
    // width: 500px;
    margin: 0 auto;
    overflow: scroll;
    text-align: center;
  }
</style>
