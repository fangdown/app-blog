<template>
  <div class="copeWith kye-detail">
    <kye-expand-page>
      <search-pager :option="option"
                    :tools="searchTools"></search-pager>
      <div>
        <div class="kye-block-title">
          <span>费用项明细</span>
          <div class="taskStatus"
               v-if="ruleForm.reimburseStatus===200||ruleForm.reimburseStatus===300"><span>报销编号 : </span>
            <span>{{ruleForm.reimburseNo}}</span>
          </div>
          <div class="taskStatus"
               v-if="ruleForm.reimburseStatus!==0"><span>报销状态 : </span>
            <span>{{ruleForm.reimburseStatus|lookup('ecs_cw_reimburseStatus')}}</span>
          </div>
          <div class="taskStatus"><span>运单状态 : </span>
            <span>{{ruleForm.taskStatus|lookup('ecs_cw_taskStatus')}}</span>
          </div>
        </div>
        <kye-form ref="ruleForm"
                  module-code="ecs_finance"
                  label-position="left"
                  :biz-id="$route.params.id"
                  :model.sync="ruleForm">
          <div class="useInfo"
               style="margin-left: 0px;
    margin-right: 0px;">
            <kye-col :span="4">
              <kye-form-item label="任务编码："
                             prop="taskCode">
                <kye-field type="text"
                           v-model="ruleForm.taskCode"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="3">
              <kye-form-item label="司机名称："
                             prop="driverName">
                <kye-field type="text"
                           v-model="ruleForm.driverName"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="手机号："
                             prop="driverPhone">
                <kye-field type="text"
                           v-model="ruleForm.driverPhone"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="3">
              <span>运力类型：</span>
              <span v-if="ruleForm.driverType===1">非合同个体</span>
              <span v-else-if="ruleForm.driverType===2">平台</span>
              <span v-else-if="ruleForm.driverType===3">非合同企业</span>
              <span v-else-if="ruleForm.driverType===4">合同个人</span>
              <span v-else-if="ruleForm.driverType===5">合同企业</span>
            </kye-col>
            <kye-col :span="5">
              <span>押金剩余：</span>
              <span class="moneyColor">{{ruleForm.depositBalance||'0' | money}}</span>
            </kye-col>
          </div>
          <!-- 取派业务 -->
          <kye-row v-if="businessType==='qp'"
                   key="1">
            <kye-col :span="4">
              <kye-form-item label="运费"
                             prop="transportFee">
                <kye-field type="text"
                           v-model="ruleForm.transportFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="上楼费"
                             prop="climbFee">
                <kye-field type="text"
                           v-model="ruleForm.climbFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="装卸费"
                             prop="loadFee">
                <kye-field type="text"
                           v-model="ruleForm.loadFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="空驶费"
                             prop="emptyPlyFee">
                <kye-field type="text"
                           v-model="ruleForm.emptyPlyFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="压车费"
                             prop="escortFee">
                <kye-field type="text"
                           v-model="ruleForm.escortFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="叉车费"
                             prop="forkliftFee">
                <kye-field type="text"
                           v-model="ruleForm.forkliftFee"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <!-- 其他业务 -->
          <kye-row v-else
                   key="2">
            <kye-col :span="4">
              <kye-form-item label="运费"
                             prop="transportFee">
                <kye-field type="text"
                           v-model="ruleForm.transportFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="压车费"
                             prop="escortFee">
                <kye-field type="text"
                           v-model="ruleForm.escortFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="空驶费"
                             prop="emptyPlyFee">
                <kye-field type="text"
                           v-model="ruleForm.emptyPlyFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超里程费"
                             prop="exceedMileageFee">
                <kye-field type="text"
                           v-model="ruleForm.exceedMileageFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="取消费"
                             prop="canclePenaltyFee">
                <kye-field type="text"
                           v-model="ruleForm.canclePenaltyFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4"
                     v-show="otherClass">
              <kye-form-item label="其他费用"
                             prop="otherFee">
                <kye-field type="text"
                           v-model="ruleForm.otherFee"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <!-- 取派业务 -->
          <kye-row v-if="businessType==='qp'"
                   key="ruleForm">
            <kye-col :span="4">
              <kye-form-item label="入仓费"
                             prop="enterWarehouseFee">
                <kye-field type="text"
                           v-model="ruleForm.enterWarehouseFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="报关费"
                             prop="customsDeclarationFee">
                <kye-field type="text"
                           v-model="ruleForm.customsDeclarationFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="续票费"
                             prop="continuingTicketFee">
                <kye-field type="text"
                           v-model="ruleForm.continuingTicketFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超时费"
                             prop="overtimeFee">
                <kye-field type="text"
                           v-model="ruleForm.overtimeFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="其他费用"
                             prop="otherFee">
                <kye-field type="text"
                           v-model="ruleForm.otherFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="保险费">
                <kye-field type="text"
                           v-model="ruleForm.insurance"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <!-- 其他业务 -->
          <kye-row v-else
                   key="3">
            <kye-col :span="4">
              <kye-form-item label="迟到费"
                             prop="latePenaltyFee">
                <kye-field type="text"
                           v-model="ruleForm.latePenaltyFee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="保险费">
                <kye-field type="text"
                           v-model="ruleForm.insurance"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="总金额">
                <kye-field type="text"
                           v-model="totalNumber"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="12">
              <kye-form-item label="备注"
                             prop="remark">
                <kye-field type="text"
                           v-model="ruleForm.remark"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row v-if="businessType==='qp'"
                   key="remark">
            <kye-col :span="4">
              <kye-form-item label="总金额">
                <kye-field type="text"
                           v-model="totalNumber"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="12">
              <kye-form-item label="备注"
                             prop="remark">
                <kye-field type="text"
                           v-model="ruleForm.remark"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </kye-form>
      </div>
      <div class="kye-block-title">费用单据信息</div>
      <div style="margin-bottom:12px">
        <table-list :column="column2"
                    :data="dataInfo"
                    :options="tableOption"
                    :operation="operation"></table-list>
      </div>
      <div class="kye-block-title">费用修改日志</div>
      <table-list :column="column"
                  :data="tableData"
                  :options="tableOption"></table-list>
    </kye-expand-page>
    <kye-dialog title="费用单据"
                :visible.sync="showImgVisible"
                width="758px">
      <div class="imgClass">
        <kye-image :config="configs" />
      </div>
    </kye-dialog>
  </div>
</template>
<script>
  import URL from './cope-with.api'
  // import * as utils from '../../utils'
  import { money } from 'public/utils/filter'
  export default {
    data () {
      return {
        URL,
        ruleForm: {
          'transportFee': null,
          'insuredFee': null,
          'receiptFee': null,
          'escortFee': null,
          'loadFee': null,
          'exceedMileageFee': null,
          'emptyPlyFee': null,
          'otherFee': null,
          'climbFee': null,
          'enterWarehouseFee': null,
          'forkliftFee': null,
          'continuingTicketFee': null,
          'overtimeFee': null,
          'customsDeclarationFee': null,
          'insurance': '',
          'taskStatus': '',
          'reimburseStatus': '',
          'reimburseNo': '',
          'remark': ''
        },
        dataInfo: [],
        qpClass: false, // 干线类型
        otherClass: true, // 其他业务类型
        businessType: '', // 业务类型
        totalNumber: '', // 总数
        option: {
          back: '/ecms/financial/cope-with',
          method: URL.diverSlipSummary,
          searchCode: 'ecs_yc_financial_list_search_define',
          idKey: 'id'
        },
        btnShow: false, // 按钮的展示
        tableData: [],
        showImgVisible: false, // 图片弹窗
        configs: {
          width: 724,
          height: 543,
          imgSrc: ''
        },
        id: '',
        searchTools: [
          {
            // label: '修改',
            // icon: 'pen',
            // show: true,
            // disabled: row => {
            //   return !this.btnShow
            // },
            // func: () => {
            //   this.audit()
            // }
          }],
        column: [{
          'key': 'feeName',
          'label': '变更项',
          'width': '60px',
          'show': true
        }, {
          'key': 'newAmount',
          'label': '当前金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'originalAmount',
          'label': '原始金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'entryPerson',
          'label': '操作人',
          'width': '60px',
          'show': true
        }, {
          'key': 'updateTime',
          'label': '录入时间',
          'width': '130px',
          'filter': 'time',
          'show': true
        }],
        tableOption: {
          stripe: true,
        },
        column2: [{
          'key': 'costName',
          'label': '费用项目',
          'width': '80px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注说明',
          'width': '100px',
          'show': true
        }, {
          'key': 'uploader',
          'label': '上传人',
          'width': '60px',
          'show': true
        }, {
          'key': 'uploadTime',
          'label': '上传时间',
          'width': '130px',
          'filter': 'time',
          'show': true
        }],
        operation: {
          label: '操作',
          fixed: 'right',
          width: '60px',
          // 操作按钮数组  array | function(row){return []}
          options: [
            {
              type: 'button', // link | button
              label: '查看图片',
              // auth: URL.driverFeeDetail,
              func: row => {
                this.imgView(row)
              }
            }
          ]
        },
      }
    },
    // mounted () {
    //   this.initData()
    // },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.initData()
        } else {
          return false
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.businessType = ''
      this.btnShow = false
      this.initData(to.params.id)
      next()
    },
    methods: {
      // 进入页面初始化数据
      initData (id) {
        this.tableData = []
        this.dataInfo = []
        this.id = id || this.$route.params.id
        this.driverFeeChangeLog()
        this.driverFeeDetail()
        this.feeBillList()
      },
      // 单据信息列表
      async feeBillList () {
        const data = await this.$http(URL.feeBillList, { id: this.id, feeType: '2' })
        this.dataInfo = data
      },
      // 请求应收费用录入详情
      async driverFeeDetail () {
        const data = await this.$http(URL.driverFeeDetail, { id: this.id })
        if (data.businessType) {
          // 判断是否为  取派类型
          switch (data.businessType) {
            case 3:
              this.businessType = 'qp'
              break
            default:
              this.businessType = ''
              break
          }
        }
        this.ruleForm = this.toMoney(data)
        this.totalNumber = money(data.payFee)
      },
      // 费用格式转化
      toMoney (data) {
        data.transportFee = money(data.transportFee)
        data.climbFee = money(data.climbFee)
        data.loadFee = money(data.loadFee)
        data.emptyPlyFee = money(data.emptyPlyFee)
        data.escortFee = money(data.escortFee)
        data.forkliftFee = money(data.forkliftFee)
        data.exceedMileageFee = money(data.exceedMileageFee)
        data.canclePenaltyFee = money(data.canclePenaltyFee)
        data.otherFee = money(data.otherFee)
        data.enterWarehouseFee = money(data.enterWarehouseFee)
        data.customsDeclarationFee = money(data.customsDeclarationFee)
        data.continuingTicketFee = money(data.continuingTicketFee)
        data.overtimeFee = money(data.overtimeFee)
        data.latePenaltyFee = money(data.latePenaltyFee)
        data.insurance = money(data.insurance)
        return data
      },
      // 查看图片
      imgView (row) {
        this.showImgVisible = true
        this.configs.imgSrc = row.picture
      },
      // 取消按钮
      goBack () {
        this.$router.push({ path: '/ecms/financial/cope-with' })
      },
      // 费用修改日志
      async driverFeeChangeLog () {
        const data = await this.$http(URL.driverFeeChangeLog, { id: this.id })
        this.tableData = data
      },
      audit () { // 修改
        this.$router.push(`/ecms/financial/cope-with-change/${this.id}`)
      },
    }
  }
</script>
<style lang="scss" scoped>
  .footBtn {
    text-align: center;
    margin: 20px 0;
  }
  .copeWith .el-table__empty-block {
    min-height: 28px;
  }
  .useInfo {
    height: 28px;
    line-height: 28px;
    background: #f8f8fa;
    margin: 0 0 10px;
    font-size: 12px;
    overflow: hidden;
    padding: 0 16px;
    .kye-field-content {
      border: none;
      height: 28px;
      line-height: 28px;
    }
    .el-col {
      height: 28px;
    }
  }
  .taskStatus {
    float: right;
    margin-right: 30px;
    color: #666;
    line-height: 28px;
    font-size: 12px;
  }
</style>
