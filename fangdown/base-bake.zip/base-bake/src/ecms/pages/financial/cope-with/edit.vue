<template>
  <div class="copeWith kye-detail">
    <kye-expand-page>
      <search-pager :option="option"
                    :tools="searchTools"></search-pager>
      <main-money @changelog='driverFeeChangeLog'
                  @businessType='getBusinessType'
                  @goBackDetail='goBackDetail'
                  ref="money"
                  v-if="mainMoneyData"
                  :rowdata="mainMoneyData"></main-money>
      <div class="kye-block-title">费用单据信息</div>
      <documents ref="documents"
                 v-if="documentsData && businessType"
                 :rowdata="documentsData"
                 :rowtype="businessType"
                 @feeBillList='feeBillList' />
      <div class="kye-block-title">费用修改日志</div>
      <table-list :column="column"
                  ref="changLogTable"
                  :data="tableData"
                  :options="tableOption"></table-list>
    </kye-expand-page>
  </div>
</template>
<script>
  import routeHook from 'public/mixins/route-hook'
  // 费用详情修改
  import mainMoney from './components/main-money'
  // 费用单据信息
  import documents from './components/documents'
  import URL from './cope-with.api'
  export default {
    mixins: [routeHook],
    components: {
      mainMoney,
      documents
    },
    data () {
      return {
        URL,
        mainMoneyData: '', // 费用修改数据
        documentsData: '', // 单据列表数据
        option: {
          back: '/ecms/financial/cope-with'
        },
        businessType: null, // 业务类型
        tableData: [],
        id: '',
        searchTools: [
          {
            label: '审核',
            icon: 'ecs-shenhe',
            auth: URL.driverFeeAudit,
            func: () => {
              this.audit()
            }
          },
          {
            label: '保存',
            icon: 'save1',
            auth: URL.addDriverFee,
            func: () => {
              this.SET_SAVE_HOOK_FLAG()
              this.$refs.money.submitForm('ruleForm')
            }
          },
          {
            label: '取消',
            icon: 'cancel1',
            show: true,
            func: () => {
              this.$refs.money.resetForm()
            }
          }],
        column: [{
          'key': 'feeName',
          'label': '变更项',
          'width': '60px',
          'show': true
        }, {
          'key': 'newAmount',
          'label': '当前金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'originalAmount',
          'label': '原始金额',
          'width': '80px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'entryPerson',
          'label': '操作人',
          'width': '60px',
          'show': true
        }, {
          'key': 'updateTime',
          'label': '录入时间',
          'width': '130px',
          'filter': 'time',
          'show': true
        }],
        tableOption: {
          stripe: true,
        },
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.mainMoneyData = ''
          vm.documentsData = ''
          vm.initData()
        } else {
          return false
        }
      })
    },
    methods: {
      // 返回详情
      goBackDetail () { // 修改
        this.$router.push(`/ecms/financial/cope-with-detail/${this.id}`)
        // this.$router.push({ path: '/ecms/financial/cope-with' })
      },
      // 获取业务类型
      getBusinessType (data) {
        this.businessType = data
        // this.$refs.documents.toBusinessType(data)
      },
      // 进入页面初始化数据
      initData () {
        this.id = this.$route.params.id
        this.driverFeeChangeLog()
        this.driverFeeDetail()
        this.feeBillList()
      },
      // 取消按钮
      goBack () {
        this.$router.push({ path: '/ecms/financial/cope-with' })
      },
      // 费用修改日志
      async driverFeeChangeLog () {
        const data = await this.$http(URL.driverFeeChangeLog, { id: this.id })
        this.tableData = data
        // this.$refs.changLogTable.repaint()
      },
      async audit () { // 审核
        this.$confirm('是否进行费用审核?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          await this.$http(URL.driverFeeAudit, { id: this.id, auditStatus: 200 })
          this.$message({
            message: '审核成功',
            type: 'success'
          })
          this.SET_SAVE_HOOK_FLAG()
          this.$refreshMainQueryTable()
          this.$router.push({ path: '/ecms/financial/cope-with' })
        })
      },
      // 请求应收费用录入详情
      async driverFeeDetail () {
        const data = await this.$http(URL.driverFeeDetail, { id: this.id })
        this.mainMoneyData = data
      },
      // 单据信息列表
      async feeBillList () {
        const data = await this.$http(URL.feeBillList, { id: this.id, feeType: '2' })
        this.documentsData = data
      },
    }
  }
</script>
<style lang="scss" scoped>
  .footBtn {
    text-align: center;
    margin: 20px 0;
  }
  .copeWith .el-table__empty-block {
    min-height: 28px;
  }
  .over {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
