<template>
  <div class="ky-list">
    <search-pager :option="option"></search-pager>
    <kye-form ref="form"
              :inline="true"
              :model="form"
              label-position="left"
              size="mini"
              label-width="auto">
      <kye-form-item label="运单号">
        <kye-input class="input-width"
                   v-model="form.waybillCode"></kye-input>
      </kye-form-item>
      <kye-form-item label="下单编号">
        <kye-input class="input-width"
                   v-model="form.taskCode"></kye-input>
      </kye-form-item>
      <kye-form-item label="下单时间">
        <kye-date-picker v-model="form.confirmTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-form-item label="签收时间">
        <kye-date-picker v-model="form.signTime"
                         size="mini"
                         type="daterange"
                         range-separator="-"
                         start-
                         end-
                         class="input-width-l">
        </kye-date-picker>
      </kye-form-item>
      <kye-button type="primary"
                  class="kye-button--primary kye-button--mini"
                  @click="submitForm('ruleForm')"
                  :auth="URL.geteIdCashManageList"
                  icon="iconfont icon-search">查询
      </kye-button>
    </kye-form>
    <div class="money-num">
      <div><span>总申请金额：</span><span class="color-money">{{totalAmount||'0' | money}}</span></div>
      <div><span>总已支付金额：</span><span class="color-money">{{hasPayAmount||'0' | money}}</span></div>
    </div>
    <div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="tableData"
                  :options="tableOption"></table-list>
    </div>
    <div>
      <kye-pagination style="margin-top:10px"
                      layout="sizes,total,prev,pager,next"
                      background
                      :total="total"
                      :page-sizes="[200]"
                      :current-page="page"
                      :page-size.sync="size"
                      @current-change="handleCurrentChange"
                      @size-change="handleSizeChange"
                      class="fixedPagination">
      </kye-pagination>
    </div>
  </div>
</template>
<script>
  // 端口请求
  import URL from './cash.api'
  // 格式化文件
  import * as utils from '../../utils'
  export default {
    data () {
      return {
        loading: false,
        URL,
        option: {
          back: '/ecms/financial/cash-management'
        },
        form: {
          confirmTime: [], // 下单时间
          signTime: [], // 签收时间
          taskCode: '', // 下单编码
          waybillCode: '' // 运单号
        },
        searchParam: {// 查询条件
          withDrawFlowId: '',
          taskCode: '', // 下单编码
          waybillCode: '', // 运单号
          confirmStartTime: null, // 下单开始时间
          confirmEndTime: null, // 下单结束时间
          signStartTime: null, // 签收开始时间
          signEndTime: null, // 签收结束时间
          size: 200,
          page: 1,
          ERPSearchCacheFlag: true // 缓存表格标记
        },
        tableData: [],
        id: '',
        hasPayAmount: 0, // 已支付总金额
        totalAmount: 0, // 提现总金额
        total: 0,
        page: 0,
        size: 200,
        paperStatus: '每页显示50条', // 分页条数
        multipleSelection: [],
        column: [{
          'key': 'waybillCode',
          'label': '运单号',
          'width': '100px',
          'show': true
        }, {
          'key': 'taskCode',
          'label': '下单编号',
          'width': '120px',
          'show': true
        }, {
          'key': 'carPlateNum',
          'label': '车牌号码',
          'width': '100px',
          'show': true
        }, {
          'key': 'startCity',
          'label': '始发地',
          'width': '100px',
          'show': true
        }, {
          'key': 'endCity',
          'label': '目的地',
          'width': '100px',
          'show': true
        }, {
          'key': 'confirmTime',
          'label': '下单时间',
          'width': '140px',
          'show': true
        }, {
          'key': 'signTime',
          'label': '签收时间',
          'width': '140px',
          'show': true
        }, {
          'key': 'receiptTime',
          'label': '回单整理时间',
          'width': '140px',
          'show': true
        }, {
          'key': 'remark',
          'label': '备注',
          'width': '100px',
          'show': true
        }, {
          'key': 'originalPayFee',
          'label': '总金额',
          'width': '100px',
          'filter': 'money',
          'show': true
        }, {
          'key': 'payFee',
          'label': '到账金额',
          'width': '100px',
          'filter': 'money',
          'show': true
        }],
        tableOption: {
          stripe: true,
          moduleCode: 'ecs_finance',
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        // layout：表示入口是点击菜单或者模块
        if (!vm.$route.meta.layout) {
          vm.geteIdCashManageList()
        } else {
          return false
        }
      })
    },
    methods: {
      // 列表
      async geteIdCashManageList (params) {
        this.id = this.$route.query.withDrawFlowId
        this.loading = true
        const val = params || {
          ...this.searchParam,
          withDrawFlowId: this.id
        }
        const data = await this.$http(URL.geteIdCashManageList, val)
        this.total = data.total
        this.size = data.size
        this.page = data.page
        this.loading = false
        // 缓存：预加载下一页
        if (this.total > 0 && this.total > this.page * this.size) {
          let preData = { ...val, page: this.page + 1 }
          delete preData.forceCache
          this.$http(URL.geteIdCashManageList, preData, false)
        }
        if (data.rows) {
          this.tableData = data.rows.map(this.formatData)
          this.getIdeCashFee()
        } else {
          this.tableData = []
          this.hasPayAmount = ''
          this.totalAmount = ''
        }
      },
      // 流水金额
      async getIdeCashFee () {
        const data = await this.$http(URL.getIdeCashFee, {
          withdrawId: this.id
        })
        this.hasPayAmount = data.hasPayAmount
        this.totalAmount = data.totalAmount
      },
      // 格式化函数
      formatData (data) {
        data.confirmTime = utils.formatTime(data.confirmTime, 'M')
        data.signTime = utils.formatTime(data.signTime, 'M')
        data.receiptTime = utils.formatTime(data.receiptTime, 'M')
        return data
      },
      // 提交表单
      submitForm (formName) {
        const form = this.form
        const confirmStartTime = new Date(form.confirmTime[0]).getTime()
        const confirmEndTime = new Date(form.confirmTime[1]).getTime()
        const signStartTime = new Date(form.signTime[0]).getTime()
        const signEndTime = new Date(form.signTime[1]).getTime()
        this.searchParam.size = this.size
        this.searchParam.withDrawFlowId = this.id
        this.searchParam.taskCode = form.taskCode // 下单编码
        this.searchParam.waybillCode = form.waybillCode // 运单号
        this.searchParam.confirmStartTime = confirmStartTime // 下单开始时间
        this.searchParam.confirmEndTime = confirmEndTime // 下单结束时间
        this.searchParam.signStartTime = signStartTime// 签收开始时间
        this.searchParam.signEndTime = signEndTime // 签收结束时间
        let params2 = { ...this.searchParam }
        params2.forceCache = true
        this.geteIdCashManageList(params2)
        this.getIdeCashFee()
      },
      // 转时间戳
      getTime (date) {
        return date.map(function (item) {
          if (typeof item === 'number') {
            return item
          } else if (typeof item === 'object') {
            return item.getTime()
          }
        })
      },
      handleSelectionChange (val) {
        this.multipleSelection = val
      },
      indexMethod (index) {
        return index
      },
      // 重置
      resetForm (formName) {
        const form = this.form
        form.taskCode = ''// 下单编码
        form.waybillCode = ''// 运单号
        form.confirmTime = [] // 下单时间
        form.signTime = [] // 签收时间
      },
      // 每页显示条数
      handleSizeChange (val) {
        const params2 = {
          size: val,
          page: 1,
        }
        const params = {
          ...this.searchParam,
          ...params2
        }
        this.geteIdCashManageList(params)
      },
      // 当前页码
      handleCurrentChange (val) {
        const page = {
          size: this.size,
          page: val
        }
        const params = {
          ...this.searchParam,
          ...page
        }
        this.geteIdCashManageList(params)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .money-num {
    height: 28px;
    line-height: 28px;
    background-color: #f8f8fa;
    // padding: 0 20px;
    div {
      float: left;
      font-size: 12px;
      span:first-child {
        margin-left: 10px;
      }
      .color-money {
        color: #ff9300;
      }
    }
  }
  .fixedPagination {
    position: fixed;
    left: 176px;
    right: 16px;
    bottom: 16px;
    z-index: 10;
    background-color: #fff;
    padding-top: 12px;
  }
  .input-width-l {
    width: 170px;
  }
  .query-table-container {
    margin-top: 4px;
  }
  .input-width {
    width: 120px;
  }
</style>

