const perfix = 'ecs.finance.withdraw.'
const URL = {
  // 司机类型提现流水报表
  getCashManageList: `${perfix}getDriverWithDrawFlowList.do`,
  // 司机类型提现流水总金额统计
  geteCashFee: `${perfix}getDriverWithDrawTotalFee.do`,
  // 司机类型提现流水ID查询运单列表
  geteIdCashManageList: `${perfix}getDriverWayBillListByFlowId.do`,
  // 司机类型运单总金额统计
  getIdeCashFee: `${perfix}getDriverWayBillTotalFee.do`
}
export default URL
