<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-model="formModel"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :tables="tables"
                 @change="geteCashFee">
      <div slot="desc">
        <div class="money-num">
          <div><span>已支付总金额：</span><span class="color-money">{{hasPayAmount||'0' | money}}</span></div>
          <div><span>总申请金额：</span><span class="color-money">{{totalAmount||'0' | money}}</span></div>
        </div>
      </div>
    </query-table>
  </div>
</template>
<script>
  // 端口请求
  import URL from './cash.api'
  export default {
    data () {
      return {
        URL,
        hasPayAmount: 0,
        totalAmount: 0,
        tables: [
          {
            searchCode: 'ecs_cw_financial_list_field',
            url: { method: URL.getCashManageList },
            option: {
              load: false,
              stripe: true,
              moduleCode: 'ecs_finance',
              defaultSort: {
                keys: ['createTime', 'create_time'],
                prop: 'createTime',
                order: 'descending'
              },
              detailAuth: URL.geteIdCashManageList,
              rowDblClick:
                row => {
                  this.toDetail(row)
                },
              beforeFormSubmit: (data, model) => {
                let isEmpty = true // 是否有条件
                const obj = {}
                // 没有选择时间时清空data里面startTime，endTime
                delete data.startTime
                delete data.endTime
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'createTime') {
                      // 格式化时间
                      if (model.createTime && model.createTime.length === 2) {
                        const startTime = new Date(model.createTime[0]).getTime()
                        const endTime = new Date(model.createTime[1]).getTime()
                        Object.assign(obj, {
                          startTime,
                          endTime
                        })
                        isEmpty = false
                      }
                    } else {
                      isEmpty = false
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                Object.assign(data, obj)
              },
            },
          }
        ],
        generic: {
          method: URL.getCashManageList,
          searchCode: 'ecs_financial_basic_search'
        },
        formModel: {
          createTime: [this.$options.filters.date(+new Date(+new Date() - 24 * 60 * 60 * 1000)), this.$options.filters.date(+new Date())],
        },
        option: {
          searchCode: 'ecs_cw_financial_list_search_define'
        },
        tools: [
        ],
        formTools: [
          {
            label: '刷新',
            auth: URL.getCashManageList,
            icon: 'reset',
            func: () => {
              this.$refs.queryTable.loadData()
            }
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          }]
      }
    },
    methods: {
      // 流水金额
      async geteCashFee () {
        const data = await this.$http(URL.geteCashFee, {})
        this.hasPayAmount = data.hasPayAmount
        this.totalAmount = data.totalAmount
      },
      toDetail (row) {
        this.$router.push({ path: '/ecms/financia/cash-management-detail', query: { withDrawFlowId: row.id } })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .money-num {
    margin-top: 4px;
    height: 28px;
    line-height: 28px;
    background-color: #f8f8fa;
    // padding: 0 20px;
    div {
      float: left;
      font-size: 12px;
      span:first-child {
        margin-left: 10px;
      }
      .color-money {
        color: #ff9300;
      }
    }
  }
</style>

