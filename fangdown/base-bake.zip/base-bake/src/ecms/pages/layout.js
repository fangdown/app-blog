import module from '../store'
import { registerStoreModule, createModuleLayout } from 'public/utils'

registerStoreModule(module, 'ecms')

export default createModuleLayout('ecmsLayout', null, 'font_992283_pggt0phky5.css')
