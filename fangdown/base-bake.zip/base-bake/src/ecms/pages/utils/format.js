/**
 * 格式化时间
 * @param {时间戳} date
 * @param {string} [type='D']  （选填） D表示精确到天，T表示精确到秒，默认是‘D’
 * @param {string} [division='-']  （选填） 默认为‘-’，可以传入任意字符串作为时间连接符
 * @returns
 */
export const formatTime = (date, type = 'D', division = '-') => {
  if (date) {
    date = new Date(date)
    let year = date.getFullYear()
    let month = date.getMonth() + 1
    let day = date.getDate()

    let hour = date.getHours()
    let minute = date.getMinutes()
    let second = date.getSeconds()

    if (type === 'T') {
      return [year, month, day].map(formatNumber).join(division) + ' ' + [hour, minute, second].map(formatNumber).join(':')
    } else if (type === 'M') {
      return [year, month, day].map(formatNumber).join(division) + ' ' + [hour, minute].map(formatNumber).join(':')
    } else if (type === 'D') {
      return [year, month, day].map(formatNumber).join(division)
    } else if (type === 'S') {
      return formatNumber(year) + '年' + formatNumber(month) + '月' + formatNumber(day) + '日'
    } else if (type === 'Month') {
      return [year, month].map(formatNumber).join(division)
    }
  } else {
    return ''
  }
}

export const formatNumber = (n) => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

/**
 * 日期加减函数
 * @param {Date} date 日期对象，也可以是时间戳
 * @param {Number} offsetNum 偏移量，正数表示加，负数表示减
 * @return 返回格式为：年-月-日，例如：2019-01-05
 */
export const dateAdd = (date, offsetNum) => {
  if (date && typeof offsetNum === 'number') {
    date = new Date(date)
    let year = date.getFullYear()
    let month = date.getMonth() + 1
    let day = date.getDate() + Number(offsetNum)
    return [year, month, day].map(formatNumber).join('-')
  } else {
    return ''
  }
}

/**
 * 格式化金额
 * @param {金额} num
 * @param {精度} num 小数点后保留的位数,默认是保留两位。
 * @param {分隔号} [division='-']  （选填） 默认为‘，’，可以传入任意字符串作为金额的分隔符
 * @returns
 */
export const formatMoney = (num, precision, separator) => {
  var precisionNum = precision || 2
  var parts
  // 判断是否为数字
  if (!isNaN(parseFloat(num)) && isFinite(num)) {
    // 把类似 .5, 5. 之类的数据转化成0.5, 5, 为数据精度处理做准, 至于为什么
    // 不在判断中直接写 if (!isNaN(num = parseFloat(num)) && isFinite(num))
    // 是因为parseFloat有一个奇怪的精度问题, 比如 parseFloat(12312312.1234567119)
    // 的值变成了 12312312.123456713
    num = Number(num)
    // 处理小数点位数
    num = (typeof precisionNum !== 'undefined' ? num.toFixed(precisionNum) : num).toString()
    // 分离数字的小数部分和整数部分
    parts = num.split('.')
    // 整数部分加[separator]分隔, 借用一个著名的正则表达式
    parts[0] = parts[0].toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + (separator || ','))

    return parts.join('.')
  }
  return '- -'
}
