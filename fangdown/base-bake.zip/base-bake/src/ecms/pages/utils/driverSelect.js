// 用户类型
export const userTypes = {
  '1': '个体司机',
  '3': '非合同企业'
}

// 用户类型反向
export const userTypesR = {
  '个体司机': '1',
  '非合同企业': '3'
}

// 审核状态
export const reviewStatus = {
  '100': '未审核',
  '101': '待审核',
  '102': '审核通过',
  '103': '审核失败'
}

// 审核状态反向
export const reviewStatusR = {
  '未审核': '100',
  '待审核': '101',
  '审核通过': '102',
  '审核失败': '103'
}

// 认证状态
export const approveStatus = {
  '100': '未认证',
  '101': '认证中',
  '102': '认证成功',
  '103': '认证失败'
}

// 绑定状态
export const bindStatus = {
  '0': '-',
  '100': '空闲中',
  '200': '工作中'
}

// 取派
export const takeAndSend = {
  '1': '干线',
  '2': '取件',
  '3': '派送'
}
// 取派
export const takeAndSendFull = {
  '100': '外部整车',
  '200': '专/干/支线',
  '300': '取/派'
}

// 要车状态
export const takeCatStauts = {
  '100': '未要车',
  '200': '报价中',
  '300': '已要车',
  '400': '已结束',
  '500': '要车取消'
}

// 供应商类型
export const driverType = {
  '1': '合同个人',
  '2': '合同企业',
  '3': '非合同个体',
  '4': '非合同企业',
  '5': '第三方平台'
}

// 运单状态
export const orderStatus = {
  '1': '未装车',
  '2': '进行中',
  '3': '完成'
}

export default {
  userTypes,
  userTypesR,
  reviewStatus,
  reviewStatusR,
  approveStatus,
  bindStatus
}
