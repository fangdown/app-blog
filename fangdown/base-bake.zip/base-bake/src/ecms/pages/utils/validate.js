/**
 * 表单校验结果
 * @param {String} formName // 表单名称
 * @param {Object} self // 组件实例
 * @returns true/false 校验结果
 */
export const submitForm = (formName, self) => {
  let result = ''
  self.$refs[formName].validate((valid, obj) => {
    if (valid) {
      result = true
    } else {
      self.$rule.error(self, self.$refs[formName]) // 表单校验错误，自动跳转到第一个错误的输入框
      result = obj
    }
  })
  return result
}

/**
 * 表单重置
 * @param {String} formName // 表单名称
 * @param {Object} self // 组件实例
 */
export const resetForm = (formName, self) => {
  self.$refs[formName].resetFields()
}
