/*
* url 目标url
* arg 需要替换的参数名称
* argVal 替换后的参数的值
* return url 参数替换后的url
*/
/* eslint-disable */
export const changeURLArg = (url, arg, argVal) => {
  let pattern = arg + '=([^&]*)'
  let replaceText = arg + '=' + argVal
  if (url.match(pattern)) {
    let tmp = `/(${arg}=)([^&]*)/gi`
    /* eslint-disable */
    tmp = url.replace(eval(tmp), replaceText)
    return tmp
  } else {
    if (url.match('[?]')) {
      return url + '&' + replaceText
    } else {
      return url + '?' + replaceText
    }
  }
}
