
/**
 * 数组去重
 * @param {array}
 * @returns
 */
export const arrayGo = (array) => {
  if (array.length) {
    return Array.from(new Set(array))
  } else {
    return []
  }
}
/**
 * 数组去重后用符号连接
 * @param {array}
 * @param {分隔号} [division='-']  （选填） 默认为‘，’，可以传入任意字符串作分隔符
 * @returns
 */
export const stringGo = (array, separator) => {
  let str = separator || ','
  if (array.length) {
    let arrayValue = Array.from(new Set(array))
    const Alaay = arrayValue.join(str)
    return Alaay
  } else {
    return []
  }
}
