/**
 * 格式化地址
 * @param {data}
 * @returns
 */
export const formatData = (data) => {
  if (!data.startProvince) {
    data.startProvince = ''
  }
  if (!data.startCity) {
    data.startCity = ''
  }
  if (!data.startArea) {
    data.startArea = ''
  }
  if (!data.endProvince) {
    data.endProvince = ''
  }
  if (!data.endCity) {
    data.endCity = ''
  }
  if (!data.endArea) {
    data.endArea = ''
  }
  data.provenance = data.startProvince + data.startCity + data.startArea// 始发地
  data.destination = data.endProvince + data.endCity + data.endArea// 目的地
  return data
}
