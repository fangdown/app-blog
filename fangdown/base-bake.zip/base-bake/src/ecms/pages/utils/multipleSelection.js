/**
 * 表单提取选中 行的ID
 * @param {array} []  （选填） 默认为‘-’，可以传入任意字符串作为时间连接符
 * @returns
 */
export const multipleSelection = (date) => {
  if (date) {
    let idNum = date.id
    return idNum
  } else {
    return ''
  }
}
