## 接入新erp说明

### 构建工程
1. git clone http://172.20.8.45/erp-frontend/base.git --recursive
2. cd base
3. git submodule add -b dev http://172.20.8.45/erp-frontend/ecms.git src/ecms
4. git submodule foreach git pull origin dev
5. sudo npm i yarn -g
6. yarn
7. npm run dev
8. cd ext进行开发，更新

### 仓库结构
-- base
  -- ecms
  -- public
  -- layout 
base是主模块，layout/public是公共模块，ecms是业务模块
都需要更新到最新代码 

### 二三级菜单维护
1. 打开菜单管理模块，选择外部运力ECMS，点击添加按钮，根据需要添加二级或三级菜单
2. 打开权限管理模块，选择外部运力ECMS-->内部要车（要车列表）-->新增
3. 新增一个功能（获取接口），如果没有指定模块，随便用一个模块，
4. 打开功能分级模块，选择外部运力ECMS-->内部要车（要车列表），全选按钮，点击右上角分级按钮，保存
5. 打开角色管理模块，选择超级管理行后的修改，选择外部运力ECMS-->内部要车（要车列表），选择全选按钮，点击右上角保存

### 接口权限
页面里使用外部接口，需增加接口权限，如查询网点信息

1. 打开权限管理模块，选择外部运力ECMS-->内部要车（要车列表）-->新增
2. 在弹窗中，输入功能名称，微服务及模块url；
eq:baseconfig.node.findByNodeNameAndFlag,微服务选择base-data,模块选择node，url：选择findByNodeNameAndFlag
3. 打开功能分级模块，选择外部运力ECMS-->内部要车（要车列表），全选按钮，点击右上角分级按钮，保存
4. 打开角色管理模块，选择超级管理行后的修改，选择外部运力ECMS-->内部要车（要车列表），选择全选按钮，点击右上角保存

###账号
1. 开发环境
http://10.125.201.2/#/  000003 123456

2. 测试环境http://edge.test.kye-erp.com 或 http://10.125.2.2  000686 000687 0000688 0000689 0000690 0000691

3. 预发布环境
edge.uat.kye-erp.com  账号前端不用操作，由部门领导申请


### 无效appkey
public/config/index.js中添加zc: '10141'

### 返回code
public/utils/http.js  data.code === 200

### 更新代码
进入到ext目录后更新 git pull origin dev

### 返回码
返回码是0， 返回值默认已经返回data，不用再写data.data

### 路由跳转
同一个页面跳转用同一个tag，不要建立多个，多个会跳新标签
路由跳转需全路径/ecms/take-car/list

### 文件命名规范

为了统一开发规范，文件以及文件夹命名统一，用'-'（横杠）的形式进行命名。例如custome-select.vue的.vue文件 或者 custome-select文件夹。

### 代码规范
js字符串用单引号，html属性用双引号
代码尽量往纵向发展，一行不要太长
不要在钩子函数中写大量业务代码
异步使用aysnc await语法


### git提交
feat： 新增功能用
fix: 修复bug时用，带禅道bug编号 如 #7812
docs: 仅仅修改了文档，比如README 等
style: 仅仅修改了空格、格式缩进、标点符号等等，不改变代码逻辑
refactor: 代码重构，没有加新功能或者修复bug
perf: 优化相关，比如提升性能、体验

###. 页面缓存问题
解决方法有两种
1. 使用beforeRouteEnter
```js
  beforeRouteEnter (to, from, next) {
    next(vm => {
      vm.id = vm.$route.params.id
      if (vm.id) {
        vm.getDetailData()
      }
    })
  }

```
2. 使用activated
```js
activated () {
  this.data = null // 清空对象数据
  this.getDetailData() // 重新请求数据
},
```
### 页面权限接入
> 说明：对所有的按钮做权限控制，如查询、导入、导出、操作按钮等,理论上每个页面上的每个接口都需要列入权限控制

#### 权限设置
对象： 主要是普通按钮和组件内工具条、导出按钮
如果有其他场景，请在该文档中追加更新

1. 查询按钮(举例)
```js
<kye-button type="primary"
  auth="zc.task.erp.searchTaskList.do"
  @click="formSearch">
  <i class="iconfont icon-search"></i>查询
</kye-button>
```
增加auth="zc.task.erp.searchTaskList.do"
如果查询接口有多个可使用:
:auth="xxx? 'zc.task.erp.searchTaskList.do' : 'xxxxx'"

2. 新增按钮
```js
searchTools: [
  {
    label: '刷新',
    icon: 'reset',
    func: () => {
      this.getList()
    }
  },
  {
    auth: 'zc.TrunkTaskController.saveTrunkTask.do',
    label: '新增任务',
    icon: 'plus',
    func: () => {
     this.handleNew()
    }
  }
]
```
重点是要添加auth属性，把该功能对应的接口写上，如zc.TrunkTaskController.saveTrunkTask.do

3. 详情点击
```js
option:{
  // ...
  detailAuth: 'zc.TrunkTaskController.getTaskInfo.do'
  // ...
}

```
4. 操作列
```html
<div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="listData"
                  :operation="operation"
                  :options="tableOption"></table-list>
    </div>
```
```js
// data中定义
operation: {
  label: '操作',
  fixed: 'left',
  width: '80px',
  options: row => {
  }
}
```

#### 监控字段设置
1. 表格内的监控字段
```html
<div v-loading="loading"
         class="query-table-container">
      <table-list :column="column"
                  :data="listData"
                  :operation="operation"
                  :options="tableOption"></table-list>
    </div>
```
```
```js
tableOption: {
          ....
          moduleCode: '***', //设置对应的 模块编码
          .....
        }
```
2. 详情内的监控字段
```html
<kye-form :model.sync="form"
          module-code="ecs_yc"
          :biz-id="$route.query.driverId"
          ref="ruleForm"
          :rules="rules">

          <kye-form-item label="总报价"
                           prop="countFee">
                           <kye-field>{{ruleForm.countFee|money}}
                           </kye-field>
          </kye-form-item>
</kye-form>
```
 module-code属性，就是模块code
 增加biz-id属性，即业务主键id，一般可在路由中获取，特殊情况根据具体业务获取相应的id

> 保存详情
举例：
```js
  async modifyBaseInfo () {
    this.form.taxRate = this.form.taxRate / 100
    await this.$http(Api.modifyDriverInfo, this.$diff(this.form, '**'))
    this.isModify = true
    this.$message({
      message: '保存成功!',
      type: 'success'
    })
  }
```
3. 非表单监控字段
```html
<li class="flter-class">
  <label @click="getField('totalLitreSum')">提油总升数:</label>
  <strong>{{countData.totalLitreSum|fix}} </strong>
  <span>L</span>
</li>
```
```js
async getField (fieldName) {
  this.countData[fieldName] = await decrypt({
    dataId: '2',
    moduleCode: 'ecs_yc',
    fieldName,
    fieldContent: this.countData[fieldName + 'Mask']
  }, 'mask')
}
```


### 数据字典
公共引用：
```js
  import mixins from 'public/mixins'
  export default {
    mixins: [mixins],
    // ...
  }
```
1. 表单中select
```html
 <kye-select v-model="form.transportGoods"
            @change="transportGoodsChange">
  <kye-option v-for="item in lookUpOptions['common_yes_no']"
              :key="item.value"
              :label="item.label"
              :value="item.value">
  </kye-option>
</kye-select>
```
2. input框引用
```html
<kye-input disabled
  :value="form.dawnNodeType|lookup('base_data_node_type')"></kye-input>
  ```
3. kye-field使用
```html 
<kye-form-item label="走高速否">
    <kye-field>
      {{ruleForm.isExpressway|lookup('ecs_yes_no')}}
    </kye-field>
  </kye-form-item>
```
4. kye-table-column中使用
```html
 <kye-table-column prop="status"
                    label="状态"
                    width="120px"
                    :formatter="formatterStatus">
  </kye-table-column>
```
```js
formatterStatus (row, column, cellValue, index) {
  return this.$filter['lookup'](cellValue, 'ecs_ldp_order_status')
},
```

### 详情页上一页下一页
1. 列表页没有【通用查询】功能，详情页需要【上下分页】功能的。如果是这种情况，列表页的queryTable的option需要配置module: true
2. 设置queryTable中的generic属性
以上任选一项即可

### 详情页修改返回详情页
```js
// 修改页
async getDetail (driverId = this.$route.params.id) {
  this.option.back = `/ecms/transit-pool/detail/${driverId}`
}

// 详情页
// 根据id进行查询数据
```
### 功能学习
0. 深入浅出新erp-架构（git结构、webpack优化、登录模块、权限模块）-方志青
1. 列表缓存的原理 - 邓金玉
2. canvas table的原理 - 韩智杰
3. 通用表单的原理 - 黄杰
4. 详情页上一页下一页的的原理 - 林永增
5. 监控字段的原理  - 黄祥

主要分享做法和数据流走向

### 模块划分
1. 要车列表 - 邓金玉、运力池
2. 财务 - 黄杰
3. 合同管理，app用户 - 林永增
4. 落地配 - 黄祥
5. 整车业务 - 韩智杰

### 代码评审
1. 代码能够成功构建，并执行

2. 代码规范是否在严格执行（命名、缩进、函数长度限制、格式、注释）

3. 项目规范是否在严格执行（目录命名规范、代码规范等）

4. 是否存在重复的代码（复制粘贴或者重复开发，有库函数的地方调用库函数）

5. 是否有需要模块化的代码

6. 代码逻辑方面（未结束的循环）

7. 日志是否被正确的使用

8. 代码的可读性和可维护性

9. 代码的性能和安全问题
