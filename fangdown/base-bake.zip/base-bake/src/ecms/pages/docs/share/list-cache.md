## 列表缓存

### 缓存的种类
sessionStorage
localStorage

### 新erp缓存
列表缓存

makeKey

缓存标识

缓存时效及场景

体悟：

+new Date()转时间戳

localforage 学习 优点缺点

代码精简 if等 可读性好

拦截器操作 ，拦截器前加一些代码逻辑处理

能找到数据流向，封装好


