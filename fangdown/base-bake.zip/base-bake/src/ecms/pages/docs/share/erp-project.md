## erp项目架构

### git目录介绍
1. 耳目一新的构建方式
- 主仓库base： 主要负责基本的配置，如webpack配置，dev运行，打包构建
- 子仓库layout： 主要负责主界面布局，引入elementUI、kyeUI、路由、store
- 子仓库public：主要负责kyeUI组件编写，axios请求封装、指令、mixin，store存储，以及公共方法的集合


### 项目的构建
1. 读取package.json文件
```js
"scripts": {
    "dev": "webpack-dev-server --inline --progress --config build/webpack.dev.conf.js",
    "lint": "eslint --ext .js,.vue src --cache --fix",
    "build": "node build/build.js",
    "start": "node start.js",
    "dll": "webpack --config build/webpack.dll.conf.js"
  },
```
2. 打包优化
```js
  entry: {
    kyerplib: ['vue/dist/vue.runtime.esm.js', 'vue-router', 'vuex', 'echarts', 'element-ui', 'lodash', 'axios', 'moment']
  },
  output: {
    path: path.join(__dirname, '../dll'),
    filename: '[name].dll.js',
    library: '[name]'
  },
```
3. 构建优化
- ParallelUglifyPlugin：会开启多个子进程，把对多个文件压缩的工作分别给多个子进程去完成，但是每个子进程还是通过UglifyJS去压缩代码
- HappyPack 使用多个子进程去解析和编译JS,css,等，这样就可以并行处理多个子任务，多个子任务完成后，再将结果发到主进程中
- AddAssetHtmlPlugin 添加指定文件到html中，压缩提取出的css，并解决ExtractTextPlugin分离出的js重复问题(多个文件引入同一css文件)
- ExtractTextPlugin 分离css文件
- HtmlWebpackInlineSourcePlugin 把指定的样式或者js内联到html中


### 登录模块
1. 通过getAccessToken方法， 判断是否有token，进行store里的caslogin 和 logout进行登录
2. 通过第三方http://cas.dev.ky-tech.com.cn进行登录， 登录成功后带回ticket，根据ticket进行caslogin请求，请求成功后设置token，并跳转到首页
3. 在routes.js文件中,beforeEach钩子函数中执行getGlobalData，获取权限、菜单等

### 权限模块
1. 路由页面触发dispatch， 获取全局数据（用户信息、省份、菜单、权限）
2. 按钮的禁用
```js
 attrs.disabled = !menus.includes(self.props.auth) || attrs.disabled
 ```

