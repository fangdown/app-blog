<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :form-model="formModel"
                 :tables="tables">
      <!--统计-->
      <div slot="desc">
        <kye-form :model.sync="totalData"
                  module-code="partner"
                  :biz-id="new Date().getTime()"
                  label-width="auto"
                  inline
                  class="kye-data-rows">
          <kye-form-item label="派送总票数:"
                         prop="summaryDeliveryNumber">
            <strong>{{totalData.summaryDeliveryNumber||0|thousands}}</strong>
          </kye-form-item>
          <kye-form-item label="派送总运费:"
                         prop="summaryDeliveryFee">
            <strong>{{totalData.summaryDeliveryFee||0|money}}</strong>
          </kye-form-item>
          <kye-form-item label="月扣款总额:"
                         prop="summaryAmountDeduction">
            <strong>{{totalData.summaryAmountDeduction||0|money}}</strong>
          </kye-form-item>
          <kye-form-item label="应付总款额:"
                         prop="summaryAmountPay">
            <strong>{{totalData.summaryAmountPay||0|money}}</strong>
          </kye-form-item>
          <kye-form-item label="其它总费:"
                         prop="summaryOtherFee">
            <strong>{{totalData.summaryOtherFee||0|money}}</strong>
          </kye-form-item>
          <kye-form-item label="总重量:"
                         prop="summaryWeight">
            <strong>{{totalData.summaryWeight||0|thousands}}</strong>
          </kye-form-item>
          <kye-form-item label="月度额外奖:"
                         prop="summaryMonthExtraPrize">
            <strong>{{totalData.summaryMonthExtraPrize||0|money}}</strong>
          </kye-form-item>
        </kye-form>
      </div>
    </query-table>

    <kye-dialog v-if="dialogOption.show"
                v-bind="dialogOption"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 @close="handleClose(dialogOption.view)">
      </component>
    </kye-dialog>
  </div>
</template>

<script type="text/jsx">
  import mixins from 'public/mixins'
  // 时间格式化
  import { month } from 'public/utils'
  export default {
    mixins: [mixins],
    data () {
      return {
        // 查询运单号
        waybillNumber: '',
        // 统计对应的key与内容
        totalData: {
          summaryDeliveryNumber: 0,
          summaryDeliveryFee: 0,
          summaryAmountDeduction: 0,
          summaryAmountPay: 0,
          summaryOtherFee: 0,
          summaryWeight: 0,
          summaryMonthExtraPrize: 0
        },
        dialogOption: {
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        selectedRow: null,
        generic: {
          menu: '/tms/partner-reconciliation/list',
          method: 'partner.reconciliation.search',
          searchCode: 'partner_reconciliation_genric_search'
        },
        option: {
          searchCode: 'partner-reconciliation-custom-search',
          menu: '/tms/partner-reconciliation/list',
          'waybillNumber': {
            change: e => {
              !e.value && (this.waybillNumber = e.value)
            }
          }
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: 'partner.reconciliation.search',
            func: () => this.$refs.queryTable.loadData()
          },
          {
            label: '导出',
            icon: 'export',
            auth: 'partner.reconciliation.export',
            func: () => this.handleExport()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        tools: [],
        formModel: {
          'deliveryMonth': month(new Date())
        },
        tables: [
          {
            searchCode: 'partner-reconciliation-custom-col',
            url: {
              method: 'partner.reconciliation.search'
            },
            option: {
              label: '伙伴对账',
              type: 'selection',
              load: false,
              defaultSort: {
                keys: ['auditTime', 't.audit_time'],
                prop: 'auditTime',
                order: 'descending'
              },
              moduleCode: 'partner',
              detailAuth: 'partner.partnerWaybill.search',
              beforeHttp: data => {
                const params = this.resetParams(data)
                this.getTotalData(params)
                this.waybillNumber = params.hasOwnProperty('vo') ? params.vo.waybillNumber : ''
              },
              rowDblClick: (row) => {
                let queryParam = {
                  reconciliationId: row.id,
                  deliveryMonth: row.deliveryMonth,
                  companyName: row.companyName,
                  pointName: row.pointName,
                  departmentName: row.departmentName,
                  auditBy: row.auditBy,
                  auditTime: row.auditTime,
                  monthExtraPrize: row.monthExtraPrize
                }
                Object.keys(queryParam).forEach((v, i) => {
                  if (row[`${v}Mask`]) {
                    queryParam[`${v}Mask`] = row[`${v}Mask`]
                  } else if (!row[v] && v !== 'reconciliationId') {
                    delete queryParam[v]
                  }
                })
                this.waybillNumber && (queryParam.waybillNumber = this.waybillNumber)
                this.$router.push({
                  path: `/tms/partner-reconciliation/detail/${row.partnerId}`,
                  query: queryParam
                })
              },
              currentChange: (row) => {
                this.selectedRow = row
              }
            }
          }
        ]
      }
    },
    methods: {

      showDynamicDialog (view, title, width = '1200px') {
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
        this.dialogOption.show = true
      },
      handleClose (dialog) {
        this.dialogOption.show = false
      },
      // 导出
      async handleExport () {
        let menuId = this.$store.state.menus[this.$route.path].id
        let getParams = this.$refs.queryTable.getParams()
        if (menuId) {
          let params = {
            menuId: menuId,
            searchCode: 'partner-reconciliation-custom-col',
            ...getParams
          }
          try {
            let xlsUrl = await this.$http('partner.reconciliation.export', params)
            window.erpOpen(xlsUrl.url)
            this.$message.success('导出成功！')
          } catch (e) {
            this.$message.warning('导出失败！')
          }
        }
      },
      // 重置请求参数格式
      resetParams (data) {
        data.hasOwnProperty('vo') && delete data.vo
        data.generic.vos.length && data.generic.vos.forEach((val, ind) => {
          if (val.propertyName === 'waybillNumber') {
            data.vo = { waybillNumber: val.values[0] }
            return data.generic.vos.splice(ind, 1)
          }
        })
        return data
      },
      // 获取统计数据
      async getTotalData (param) {
        const res = await this.$http('partner.reconciliation.summarySearch', param)
        this.totalData = { ...res }
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-data-rows {
    height: 28px !important;
    margin: 4px 0;
    .el-form-item--mini.el-form-item {
      margin: 0px 24px 0 0 !important;
      font-size: 12px;
      strong {
        font-size: 12px;
      }
    }
  }
</style>
