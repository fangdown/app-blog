<template>
  <kye-expand-page>
    <query-table ref="queryTable"
                 :tables="table"
                 :form-tools="formTools"
                 :option="option"
                 :form-fields="formFields"
                 :form-model="formModel"
                 @created="refresh">
      <div slot="desc">
        <kye-form :model.sync="reconciliationForm"
                  module-code="partner"
                  :biz-id="$route.params.id"
                  ref="addForm"
                  label-width="auto"
                  label-position="left"
                  class="kye-detail"
                  inline>
          <kye-form-item label="公司全称"
                         prop="companyName">
            <kye-field>{{reconciliationForm.companyName}}</kye-field>
          </kye-form-item>
          <kye-form-item label="一级点部"
                         prop="pointName">
            <kye-field>{{reconciliationForm.pointName}}</kye-field>
          </kye-form-item>
          <kye-form-item label="部门"
                         prop="departmentName">
            <kye-field>{{reconciliationForm.departmentName}}</kye-field>
          </kye-form-item>
          <kye-form-item label="审核人"
                         prop="auditBy">
            <kye-field style="width:86px">{{reconciliationForm.auditBy}}</kye-field>
          </kye-form-item>
          <kye-form-item label="审核时间"
                         prop="auditTime">
            <kye-field style="width:122px">{{+reconciliationForm.auditTime | minute}}</kye-field>
          </kye-form-item>
          <kye-form-item label="月度额外奖"
                         prop="monthExtraPrize">
            <kye-field style="width:90px">{{reconciliationForm.monthExtraPrize | money}}</kye-field>
          </kye-form-item>
        </kye-form>
        <kye-form :model.sync="summaryData"
                  module-code="partner"
                  :biz-id="$route.params.id"
                  label-width="auto"
                  inline
                  class="kye-data-rows backcolor">
          <kye-button type="text"
                      style="margin-right:12px"
                      icon="iconfont icon-ecs-xiugaibaojia"
                      auth="partner.reconciliation.update"
                      @click="modifyMonthExtra">修改月度奖</kye-button>
          <kye-form-item label="应付总款额 :"
                         prop="summaryTotalPayment">
            <strong>{{summaryData.summaryTotalPayment||'0'|money}}</strong>
          </kye-form-item>
          <kye-form-item label="派送总票数 :"
                         prop="deliveryTotalNumber">
            <strong>{{summaryData.deliveryTotalNumber||0|thousands}}</strong>
          </kye-form-item>
          <kye-form-item label="派送总运费 :"
                         prop="deliveryTotalFee">
            <strong>{{summaryData.deliveryTotalFee||'0'|money}}</strong>
          </kye-form-item>
          <kye-form-item label="月扣款总额 :"
                         prop="totalAmountDeduction">
            <strong>{{summaryData.totalAmountDeduction||'0'|money}}</strong>
          </kye-form-item>
          <kye-form-item label="其它总费 :"
                         prop="summaryOtherChargin">
            <strong>{{summaryData.summaryOtherChargin||'0'|money}}</strong>
          </kye-form-item>
          <kye-form-item label="总重量 :"
                         prop="summaryThrowOutWeight">
            <strong>{{summaryData.summaryThrowOutWeight||0|thousands}}</strong>
          </kye-form-item>
          <kye-form-item label="准达率 :"
                         prop="arrivalRate">
            <strong>{{summaryData.arrivalRate||0}}%</strong>
          </kye-form-item>
        </kye-form>
      </div>
    </query-table>
    <kye-data-import code="partner_partnerwaybill_import_template"
                     url="partner.partnerWaybill.importExcel"
                     :visible.sync="isImport"
                     :params="importParam"
                     @success="refresh"
                     append-to-body></kye-data-import>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :data="dialogOption.data"
                 :is="dialogOption.view"
                 :id="$route.query.reconciliationId"
                 @success="searchList"
                 @close="dialogOption.show=false">
      </component>
    </kye-dialog>
  </kye-expand-page>
</template>
<script>
  import mixins from 'public/mixins'
  // 时间格式化
  import { date } from 'public/utils'
  // 倒入模版
  import KyeDataImport from '@/shared/components/kye-data-import'
  // 修改列表数据模版
  import modifyTemplate from './modify-template'
  // 修改月度奖模版
  import modifyExtra from './components/modify-extra'
  export default {
    mixins: [mixins],
    components: {
      KyeDataImport, modifyTemplate, modifyExtra
    },
    computed: {
      // reconciliationForm () {
      //   const query = this.$route.query
      //   return { ...query }
      // },
      importParam () {
        const vo = {
          month: this.$route.query.deliveryMonth ? this.$route.query.deliveryMonth.trim() : '',
          reconciliationId: this.$route.query.reconciliationId ? this.$route.query.reconciliationId.trim() : ''
        }
        return { vo }
      }
    },
    data () {
      return {
        reconciliationForm: {},
        selectedMuti: null,
        summaryData: {},
        menuName: 'deliveryDate',
        waybillNumber: this.$route.query.waybillNumber || '',
        isImport: false,
        dialogOption: {
          show: false
        },
        table: [
          {
            searchCode: 'partner_waybill_custom_col',
            url: {
              method: 'partner.partnerWaybill.search'
            },
            option: {
              type: 'selection',
              moduleCode: 'partner',
              load: false,
              defaultSort: {
                keys: ['deliveryDate', 't.delivery_date'],
                prop: 'deliveryDate',
                order: 'descending'
              },
              selectionChange: val => { this.selectedMuti = val },
              beforeHttp: data => {
                'generic' in data && delete data.generic
                data.elasticsearchFlag = 'N'
                data.vo = {
                  partnerId: this.$route.params.id,
                  reconciliationId: this.$route.query.reconciliationId
                }
                const params = this.getFormValue()
                data.vo[`${this.menuName}`] = data.vo.beginDate = params[`${this.menuName}`][0]
                data.vo.endDate = params[`${this.menuName}`][1]
                data.vo.waybillNumber = params.waybillNumber
                this.getSummary(data)
              },
              beforeFormSubmit: (data, model) => {
                if (!model[`${this.menuName}`]) {
                  this.$message.error('请选择时间')
                  return true
                }
              }
            },
            operation: {
              label: '操作',
              fixed: 'left',
              width: 40,
              options: [
                {
                  label: '修改',
                  btnType: 'text',
                  auth: 'partner.partnerWaybill.update',
                  func: row => {
                    this.dialogOption.data = row
                    this.dialogOption.view = 'modifyTemplate'
                    this.dialogOption.width = '472px'
                    this.dialogOption.title = '伙伴对账修改'
                    this.dialogOption.show = true
                  }
                }
              ]
            },
            buttonOptions: {
              'feeType': {
                color: '#7352bf',
                func: row => {
                  console.log(row)
                }
              }
            }
          }
        ],
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: 'partner.partnerWaybill.search',
            func: () => this.refresh()
          }, {
            label: '删除',
            icon: 'delete',
            auth: 'partner.partnerWaybill.deleteBatch',
            func: () => this.handleDelete()
          },
          {
            label: '审核',
            icon: 'ecs-shenhe',
            auth: 'partner.partnerWaybill.audit',
            func: () => this.handleAudit()
          },
          {
            label: '反审',
            icon: 'ecs-caiwufanshen',
            auth: 'partner.partnerWaybill.cancelAudit',
            func: () => this.handleDeaudit()
          },
          {
            label: '导入',
            icon: 'import',
            auth: 'partner.partnerWaybill.importExcel',
            func: () => { this.isImport = true }
          },
          {
            label: '导出',
            icon: 'export',
            auth: 'partner.partnerWaybill.export',
            func: () => this.handleExport()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'partner_reconciliation_details_search',
          back: '/tms/partner-reconciliation/list'
        },
        formFields: [
          {
            propertyName: 'beginDate',
            type: 'menu',
            show: true,
            options: [
              {
                propertyName: 'deliveryDate',
                columnType: 'string',
                operation: 'between',
                label: '派送时间',
                width: 145,
                type: 'datePicker',
                dateType: 'daterange',
                attr: {
                  clearable: false
                }
              },
              {
                propertyName: 'signDate',
                columnType: 'string',
                operation: 'between',
                label: '签收时间',
                width: 145,
                type: 'datePicker',
                dateType: 'daterange',
                attr: {
                  clearable: false
                }
              }
            ],
            change: (v) => {
              this.menuName = v.key
            }
          },
          {
            propertyName: 'waybillNumber',
            columnName: 'waybill_number',
            frontBrackets: '(',
            postBrackets: ')',
            conditionOperation: 'and',
            operation: 'contain',
            columnType: 'string',
            label: '运单号',
            type: 'text',
            show: true,
            placeholder: '请填写运单号'
          }
        ],
        formModel: {
          'deliveryDate': () => this.resetDate(),
          'signDate': () => this.resetDate(),
          'waybillNumber': () => this.waybillNumber
        }
      }
    },
    methods: {
      // 刷新
      refresh () {
        return this.$refs.queryTable.loadCurrentData()
      },
      // 获取搜索表单的数据
      getFormValue () {
        const model = this.$refs.queryTable.getFormModel()
        return model
      },
      // 获取统计数据
      async getSummary (params) {
        try {
          const data = await this.$http('partner.partnerWaybill.summarySearch', params)
          'id' in data && (this.summaryData = { ...data })
        } catch (err) {
          return false
        }
      },
      // 重制默认时间
      resetDate () {
        const beginDate = date(`${this.$route.query.deliveryMonth}-01 00:00:00`, 'YYYY-MM-DD HH:mm:ss')
        const _y = new Date(beginDate).getFullYear()
        const _m = new Date(beginDate).getMonth() + 1
        const _end = new Date(_y, _m).getTime() - 1000
        const endDate = date(_end, 'YYYY-MM-DD HH:mm:ss')
        return [beginDate, endDate]
      },
      // 修改列表数据成功
      searchList (val) {
        val && (this.reconciliationForm.monthExtraPrize = val)
        return this.refresh()
      },
      // 修改月度奖
      modifyMonthExtra () {
        this.dialogOption.data = {
          monthExtraPrize: this.reconciliationForm.monthExtraPrize,
          monthExtraPrizeMask: this.reconciliationForm.monthExtraPrizeMask
        }
        this.dialogOption.view = 'modifyExtra'
        this.dialogOption.width = '320px'
        this.dialogOption.title = '修改月度奖'
        this.dialogOption.show = true
      },
      // 删除
      async handleDelete () {
        if (this.selectedMuti.length === 0) {
          this.$message.error('请选择要删除的数据')
          return
        }
        this.$confirm('确定删除选中的数据？', '提示').then(async () => {
          const vo = { reconciliationId: this.$route.query.reconciliationId }
          await this.$http('partner.partnerWaybill.deleteBatch', { ids: this.selectedMuti.map(item => item.id), vo })
          this.$message.success('删除成功')
          this.$refreshMainQueryTable()
          this.refresh()
        }).catch(() => {
          return false
        })
      },
      // 审核
      handleAudit () {
        const list = this.$refs.queryTable.getTableData()
        if (!list.length) return this.$message({ type: 'error', message: '暂无数据审核' })
        this.$confirm(`确定审核${this.$route.query.deliveryMonth}月对账？`, '提示').then(async () => {
          let data = {
            vo: {
              partnerId: this.$route.params.id,
              reconciliationId: this.$route.query.reconciliationId,
              deliveryDate: `${this.$route.query.deliveryMonth.trim()}-01 00:00:00`
            }
          }
          await this.$http('partner.partnerWaybill.audit', data)
          this.$message.success('审核成功')
          this.$refreshMainQueryTable()
          this.refresh()
        }).catch(() => {
          return false
        })
      },
      // 反审
      handleDeaudit () {
        const list = this.$refs.queryTable.getTableData()
        if (!list.length) return this.$message({ type: 'error', message: '暂无数据反审' })
        this.$confirm(`确定反审${this.$route.query.deliveryMonth}对账？`, '提示').then(async () => {
          await this.$http('partner.partnerWaybill.cancelAudit', {
            vo: {
              reconciliationId: this.$route.query.reconciliationId
            }
          })
          this.$message.success('反审成功')
          this.$refreshMainQueryTable()
          return this.refresh()
        }).catch(() => {
          return false
        })
      },
      // 导出
      async handleExport () {
        const menuId = this.$store.state.menus[this.$route.meta.tag].id
        const _params = this.$refs.queryTable.getParams()
        if (menuId) {
          let params = {
            menuId,
            searchCode: 'partner_waybill_custom_col',
            page: _params.page,
            pageSize: _params.pageSize,
            vo: _params.vo
          }
          try {
            let xlsUrl = await this.$http('partner.partnerWaybill.export', params)
            window.erpOpen(xlsUrl.url)
            this.$message.success('导出成功！')
          } catch (e) {
            return false
          }
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        const t = setTimeout(() => {
          from.name === 'tms-partner-reconciliation-list' && (vm.reconciliationForm = to.query) && vm.$refs.queryTable.loadData()
          clearTimeout(t)
        }, 0)
      })
    }
  }
</script>
<style lang="scss" scoped>
  .kye-data-rows {
    height: 28px !important;
    margin: 0 0 4px;
    padding: 0 !important;
    background-color: transparent;
    .el-form-item--mini.el-form-item {
      margin: 0px 24px 0 0 !important;
      font-size: 12px;
      strong {
        font-size: 12px;
      }
    }
  }
  .kye-field-content {
    background-color: #f5f5f5;
  }
  .el-form-item--mini.el-form-item {
    margin-bottom: 4px !important;
  }
  .kye-detail {
    .el-col {
      height: 28px;
      margin-bottom: 4px;
    }
    .kye-field-content {
      width: 128px;
      background-color: #ececf5;
    }
  }
</style>
