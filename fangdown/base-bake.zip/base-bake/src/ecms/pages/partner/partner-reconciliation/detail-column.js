export default [
  {
    label: '运单号',
    key: 'waybillNumber',
    width: '98px',
    show: true
  },
  {
    label: '件数',
    key: 'deliveryNumber',
    width: '60px',
    filter: 'thousands',
    show: true
  },
  {
    label: '实际重量',
    key: 'actualWeight',
    width: '64px',
    filter: 'thousands',
    show: true
  },
  {
    label: '计抛重量',
    key: 'throwOutWeight',
    width: '64px',
    filter: 'thousands',
    show: true
  },
  {
    label: '体积',
    key: 'size',
    width: '64px',
    filter: 'thousands',
    show: true
  },
  {
    label: '其他费',
    key: 'otherChargin',
    width: '70px',
    filter: 'money',
    show: true
  },
  {
    label: '费用类别',
    key: 'feeType',
    width: '70px',
    show: true
  },
  {
    label: '超时扣款',
    key: 'timeoutDeductions',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    label: '运费',
    key: 'deliveryFee',
    width: '60px',
    filter: 'money',
    show: true
  },
  {
    label: '小计费',
    key: 'charging',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    label: '派送时间',
    key: 'deliveryDate',
    filter: 'minute',
    width: '124px',
    show: true
  },
  {
    label: '派送人',
    key: 'deliveryPerson',
    width: '56px',
    show: true
  },
  {
    label: '签收时间',
    key: 'signDate',
    width: '124px',
    filter: 'minute',
    show: true
  },
  {
    label: '签收人',
    key: 'signPerson',
    width: '60px',
    show: true
  },
  {
    label: '修改人',
    key: 'updatedBy',
    width: '60px',
    show: true
  },
  {
    label: '修改时间',
    key: 'updationDate',
    width: '124px',
    filter: 'minute',
    show: true
  },
  {
    label: '非服务区自提',
    key: 'deliveryType',
    width: '84px',
    show: true
  },
  {
    label: '到付金额',
    key: 'receiptMoney',
    width: '66px',
    show: true
  },
  {
    label: '上交情况',
    key: 'receiptHandin',
    width: '64px',
    show: true
  },
  {
    label: '点部名称',
    key: 'deliveryPointName',
    width: '66px',
    show: true
  },
  {
    label: '计费重量',
    key: 'billingWeight',
    width: '64px',
    filter: 'thousands',
    show: true
  },
  {
    label: '丢货扣款',
    key: 'lossGoodsMoney',
    width: '70px',
    filter: 'money',
    show: true
  },
  {
    label: '丢单扣款',
    key: 'receiptLossMoney',
    width: '70px',
    filter: 'money',
    show: true
  },
  {
    label: '货损扣款',
    key: 'breakageGoodsMoney',
    width: '70px',
    filter: 'money',
    show: true
  }
]
