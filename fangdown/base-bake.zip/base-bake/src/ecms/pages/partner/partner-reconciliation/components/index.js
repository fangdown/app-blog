import modifyExtra from './modify-extra.vue'
import otherTemplate from './otherFee-template.vue'

export {
  modifyExtra,
  otherTemplate
}
