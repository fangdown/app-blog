<template>
  <section>
    <kye-form class="kye-dialog-body"
              ref="otherFee"
              :model.sync="data"
              :biz-id="id"
              module-code="partner">
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="超区费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.superZoneFee"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="上楼费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.upstairsFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="进厂费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.entranceFee"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="转件费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.transferFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="邮寄回单费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.postalReturnBillFee"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="叉车费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.forkliftFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="退货费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.returnFee"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="耗时费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.timeCostFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="计抛费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.calculationFee"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="专车费">
            <kye-number symbol="￥"
                        :precision="2"
                        placeholder=""
                        :disabled="isRead"
                        v-model.trim="data.specialVehicleFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  v-show="!isRead"
                  @click="confirm">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </section>
</template>
<script>
  // 费用类别
  const preData = {
    superZoneFee: {
      label: '超区费'
    },
    upstairsFee: {
      label: '上楼费'
    },
    entranceFee: {
      label: '进厂费'
    },
    transferFee: {
      label: '转件费'
    },
    postalReturnBillFee: {
      label: '邮寄回单费'
    },
    forkliftFee: {
      label: '叉车费'
    },
    returnFee: {
      label: '退货费'
    },
    timeCostFee: {
      label: '耗时费'
    },
    calculationFee: {
      label: '计抛费'
    },
    specialVehicleFee: {
      label: '专车费'
    }
  }
  export default {
    props: {
      data: Object,
      id: String,
      isRead: Boolean
    },
    methods: {
      // 保存
      confirm () {
        Object.keys(preData).forEach(v => {
          preData[v]['value'] = this.data[v]
        })
        this.$emit('change', preData)
        return this.close()
      },
      // 取消
      close () {
        this.$emit('close')
      }
    }
  }
</script>
