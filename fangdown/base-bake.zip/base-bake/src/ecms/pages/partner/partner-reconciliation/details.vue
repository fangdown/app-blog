<template>
  <div>
    <search-pager :option="option"
                  :tools="formTools"
                  ref="searchPager">
    </search-pager>
    <kye-expand-page>
      <div>
        <div slot="tools">
          <detail-info :data="totalData"
                       :id="$route.query.reconciliationId"
                       :queryParams="$route.query"
                       @change="getParams"
                       @searchList="searchList"></detail-info>
        </div>
        <table-list :column="columns"
                    :data="tableData"
                    :options="tableOptions"
                    :operation="tableOperation"
                    :buttonOptions="buttonOptions"
                    :page="{currentPage:1,pageSize:50}"
                    @sort-change="sortChange"
                    style="margin-top:4px"
                    v-loading="isLoading"></table-list>
      </div>
      <kye-pagination :page-sizes="$pagination.pageSizes"
                      style="margin-top:16px"
                      :layout="$pagination.layout"
                      :total="pages.total"
                      :current-page="currentPage"
                      :page-size="pageSize"
                      @size-change="pageSizeChange"
                      @current-change="pageChange"></kye-pagination>
      <kye-data-import code="partner_partnerwaybill_import_template"
                       url="partner.partnerWaybill.importExcel"
                       :visible.sync="importShow"
                       :params="importParam"
                       @success="reloadList"
                       append-to-body></kye-data-import>
      <kye-dialog v-bind="dialogOption"
                  v-if="dialogOption.show"
                  :visible.sync="dialogOption.show">
        <component :data="dialogOption.data"
                   :is="dialogOption.view"
                   :id="$route.query.reconciliationId"
                   :isRead="dialogOption.isRead"
                   @success="searchList"
                   @close="dialogOption.show=false">
        </component>
      </kye-dialog>
    </kye-expand-page>
  </div>
</template>

<script type="text/jsx">
  import mixins from 'public/mixins'
  // 时间格式化
  import { time } from 'public/utils'
  // 导入模板
  import KyeDataImport from '@/shared/components/kye-data-import'
  // 公司信息拦
  import DetailInfo from '@/ecms/components/partner/partner-reconciliation/detail-info'
  // 表格配置
  import columns from './detail-column'
  // 修改表格数据
  import modifyTemplate from './modify-template'
  // 查看其他费详情
  import { otherTemplate } from './components'
  export default {
    mixins: [mixins],
    components: {
      KyeDataImport, DetailInfo, modifyTemplate, otherTemplate
    },
    computed: {
      importParam () {
        const vo = {
          month: this.$route.query.deliveryMonth ? this.$route.query.deliveryMonth.trim() : '',
          reconciliationId: this.$route.query.reconciliationId ? this.$route.query.reconciliationId.trim() : ''
        }
        return { vo }
      }
    },
    data () {
      return {
        isLoading: false,
        waybillNumber: '',
        resetSearchParam: false,
        pages: { total: 0 },
        currentPage: 1,
        pageSize: 20,
        detailForm: {
          beginDate: '',
          endDate: '',
          waybillNumber: '',
          enabledFlag: '',
          traceId: '',
          type: ''
        },
        orderByClauses: [{ field: 't.delivery_date', orderByMode: 1 }], // 排序
        billId: '',
        totalData: {},
        dialogOption: {
          title: '伙伴对账修改',
          show: false,
          view: 'modifyTemplate',
          width: '472px',
          isRead: false,
          data: {}
        },
        selectedRow: null,
        option: {
          back: '/tms/partner-reconciliation/list'
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: 'partner.partnerWaybill.search',
            func: () => this.reloadList()
          }, {
            label: '删除',
            icon: 'delete',
            auth: 'partner.partnerWaybill.deleteBatch',
            func: () => this.handleDelete()
          },
          {
            label: '审核',
            icon: 'ecs-shenhe',
            auth: 'partner.partnerWaybill.audit',
            func: () => this.handleAudit()
          },
          {
            label: '反审',
            icon: 'ecs-caiwufanshen',
            auth: 'partner.partnerWaybill.cancelAudit',
            func: () => this.handleDeaudit()
          },
          {
            label: '导入',
            icon: 'import',
            auth: 'partner.partnerWaybill.importExcel',
            func: () => { this.importShow = true }
          },
          {
            label: '导出',
            icon: 'export',
            auth: 'partner.partnerWaybill.export',
            func: () => this.handleExport()
          }
        ],
        importShow: false,
        importParams: {},
        tableData: [],
        selectedMuti: [],
        tableOptions: {
          type: 'selection',
          moduleCode: 'partner',
          defaultSort: {
            keys: ['deliveryDate', 't.delivery_date'],
            prop: 'deliveryDate',
            order: 'descending'
          },
          selectionChange: val => { this.selectedMuti = val }
        },
        tableOperation: {
          label: '操作',
          field: 'left',
          width: '54px',
          options: [
            {
              label: '修改',
              btnType: 'text',
              auth: 'partner.partnerWaybill.update',
              func: row => {
                this.dialogOption.data = row
                this.dialogOption.view = 'modifyTemplate'
                this.dialogOption.title = '伙伴对账修改'
                this.dialogOption.show = true
              }
            }
          ]
        },
        buttonOptions: {
          feeType: {
            color: '#9571e9',
            disabled: row => !row.feeType,
            func: val => this.checkOther(val)
          }
        },
        columns
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        const isReload = from.name === 'tms-partner-reconciliation-list'
        if (isReload) {
          vm.billId = to.params.id
          vm.loadDetails()
        }
      })
    },
    methods: {
      // sortChange
      sortChange (e) {
        this.orderByClauses[0].orderByMode = e.order === 'descending' ? 1 : 0
        return this.reloadList()
      },
      reloadList () {
        this.loadDetails()
      },
      // 获取查询条件
      getParams (val = {}) {
        val.type === 1 && (this.currentPage = 1)
        return this.detailForm = { ...this.detailForm, ...val }
      },
      // 查询
      searchList (params) {
        this.getParams(params)
        this.loadDetails()
      },
      handleClose (dialog) {
        this.dialogOption.show = false
      },
      // 加载详情数据
      async loadDetails (id = this.$route.params.id, rId = this.$route.query.reconciliationId) {
        this.isLoading = true
        this.tableData = []
        try {
          let data = {
            page: this.detailForm.type ? 1 : this.currentPage,
            pageSize: this.$pagination.pageSize,
            vo: {
              partnerId: id,
              reconciliationId: rId,
              beginDate: '',
              endDate: '',
              waybillNumber: this.detailForm.waybillNumber
            },
            orderByClauses: this.orderByClauses
          }
          if (this.detailForm.signDate) {
            data.vo.signDate = this.detailForm.signDate[0]
            data.vo.beginDate = this.detailForm.signDate[0]
            data.vo.endDate = this.detailForm.signDate[1]
          } else if (this.detailForm.deliveryDate) {
            data.vo.deliveryDate = this.detailForm.deliveryDate[0]
            data.vo.beginDate = this.detailForm.deliveryDate[0]
            data.vo.endDate = this.detailForm.deliveryDate[1]
          } else {
            const d = new Date(this.$route.query.deliveryMonth)
            d.setHours(0)
            d.setMinutes(0)
            d.setSeconds(0)
            d.setMilliseconds(0)
            data.vo.deliveryDate = time(d)
          }
          this.getTotalData(data)
          let res = await this.$http('partner.partnerWaybill.search', data)
          res.rows.length && res.rows.forEach(val => val.updatedBy < 0 && (val.updatedBy = '暂无'))
          this.tableData = res.rows
          this.pages.total = res.rowTotal
        } finally {
          this.isLoading = false
        }
      },
      // 获取汇总统计数据
      getTotalData (param) {
        this.totalData = {}
        return this.$http('partner.partnerWaybill.summarySearch', param).then(res => {
          this.totalData = res
        }).catch(() => {
          this.totalData = {}
        })
      },
      pageSizeChange (sz) {
        this.detailForm.type = 0
        this.pageSize = sz
        return this.loadDetails()
      },
      pageChange (page) {
        this.detailForm.type = 0
        this.currentPage = page
        return this.loadDetails()
      },
      // 删除
      async handleDelete () {
        if (this.selectedMuti.length === 0) {
          this.$message.error('请选择要删除的数据')
          return
        }
        this.$confirm('确定删除选中的数据？', '提示').then(async () => {
          const vo = { reconciliationId: this.$route.query.reconciliationId }
          await this.$http('partner.partnerWaybill.deleteBatch', { ids: this.selectedMuti.map(item => item.id), vo })
          this.$message.success('删除成功')
          this.$refreshMainQueryTable()
          this.reloadList()
        }).catch(() => {
          return false
        })
      },
      // 审核
      handleAudit () {
        if (!this.tableData.length) return this.$message({ type: 'error', message: '暂无数据审核' })
        this.$confirm(`确定审核${this.$route.query.deliveryMonth}月对账？`, '提示').then(async () => {
          let data = {
            vo: {
              partnerId: this.$route.params.id,
              reconciliationId: this.$route.query.reconciliationId,
              deliveryDate: this.$route.query.deliveryMonth.trim()
            }
          }
          const d = new Date(this.$route.query.deliveryMonth)
          d.setHours(0)
          d.setMinutes(0)
          d.setSeconds(0)
          d.setMilliseconds(0)
          data.vo.deliveryDate = time(d)
          await this.$http('partner.partnerWaybill.audit', data)
          this.$message.success('审核成功')
          this.$refreshMainQueryTable()
          this.reloadList()
        }).catch(() => {
          return false
        })
      },
      // 反审
      handleDeaudit () {
        if (!this.tableData.length) return this.$message({ type: 'error', message: '暂无数据反审' })
        this.$confirm(`确定反审${this.$route.query.deliveryMonth}对账？`, '提示').then(async () => {
          await this.$http('partner.partnerWaybill.cancelAudit', {
            vo: {
              reconciliationId: this.$route.query.reconciliationId
            }
          })
          this.$message.success('反审成功')
          this.$refreshMainQueryTable()
          return this.reloadList()
        }).catch(() => {
          return false
        })
      },
      // 导出
      async handleExport () {
        let menuId = this.$store.state.menus[this.$route.meta.tag].id
        if (menuId) {
          let params = {
            menuId: menuId,
            searchCode: 'partner_waybill_custom_col',
            page: this.currentPage,
            pageSize: this.pageSize,
            vo: {
              partnerId: this.$route.params.id,
              reconciliationId: this.$route.query.reconciliationId,
              beginDate: '',
              endDate: '',
              waybillNumber: this.detailForm.waybillNumber
            }
            // orderByClauses: [
            //   {
            //     field: 'waybillNumber',
            //     orderByMode: 1
            //   }
            // ]
          }
          if (this.detailForm.signDate) {
            params.vo.signDate = this.detailForm.signDate[0]
            params.vo.beginDate = this.detailForm.signDate[0]
            params.vo.endDate = this.detailForm.signDate[1]
          } else if (this.detailForm.deliveryDate) {
            params.vo.deliveryDate = this.detailForm.deliveryDate[0]
            params.vo.beginDate = this.detailForm.deliveryDate[0]
            params.vo.endDate = this.detailForm.deliveryDate[1]
          } else {
            const d = new Date(this.$route.query.deliveryMonth)
            d.setHours(0)
            d.setMinutes(0)
            d.setSeconds(0)
            d.setMilliseconds(0)
            params.vo.deliveryDate = time(d)
          }
          try {
            let xlsUrl = await this.$http('partner.partnerWaybill.export', params)
            window.erpOpen(xlsUrl.url)
            this.$message.success('导出成功！')
          } catch (e) {
            this.$message.error('导出失败！')
          }
        }
      },
      // 定义导入参数
      customParams (val) {
        this.importParams = {
          bizId: this.$route.params.id,
          excelId: val
        }
      },
      // 修改保存
      async handleSave () {
        this.isLoading = true
        let data = []
        let reconciliationId = this.$route.query.reconciliationId
        let tableData = this.$refs.atable.getData()
        tableData.forEach(item => {
          data.push({
            id: item.id,
            feeType: item.feeType,
            otherChargin: item.otherChargin,
            otherCharginMask: item.otherCharginMask,
            lossGoodsMoney: item.lossGoodsMoney,
            lossGoodsMoneyMask: item.lossGoodsMoneyMask,
            receiptLossMoney: item.receiptLossMoney,
            receiptLossMoneyMask: item.receiptLossMoneyMask,
            breakageGoodsMoney: item.breakageGoodsMoney,
            breakageGoodsMoneyMask: item.breakageGoodsMoneyMask,
            monthExtraPrize: item.monthExtraPrize,
            reconciliationId: item.partnerId
          })
        })
        this.$http('partner.partnerWaybill.update', {
          updateList: this.$diff(data),
          vo: { reconciliationId }
        }).then(res => {
          this.isLoading = false
          this.$message.success('修改成功')
          this.cancelEdit()
          this.reloadList()
          this.$refreshMainQueryTable()
        }).catch(() => {
          this.isLoading = false
        })
      },
      checkOther (row) {
        const data = Object.create({})
        Object.keys(row).forEach(v => {
          if (/Fee$/.test(v)) {
            data[v] = row[v]
          }
        })
        this.dialogOption.data = data
        this.dialogOption.view = 'otherTemplate'
        this.dialogOption.isRead = true
        this.dialogOption.title = '费用类别详情'
        this.dialogOption.show = true
      }
    }
  }
</script>
<style lang="scss" scoped>
  .iconfont {
    cursor: pointer;
  }
</style>
