<template>
  <section v-loading="isLoading">
    <kye-form class="kye-dialog-body"
              :model.sync="formData"
              :biz-id="id"
              module-code="partner"
              ref="modifyForm"
              label-width="56px">
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="运单号"
                         prop="waybillNumber">
            <kye-input v-model="formData.waybillNumber"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="点部名称"
                         prop="deliveryPointName">
            <kye-input v-model="formData.deliveryPointName"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="件数"
                         prop="deliveryNumber">
            <kye-input v-model="formData.deliveryNumber"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="体积"
                         prop="size">
            <kye-input v-model="formData.size"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="实际重量"
                         prop="actualWeight">
            <kye-input v-model="formData.actualWeight"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="计抛重量"
                         prop="throwOutWeight"
                         :rules="{validator:checkThrowWeight,trigger:'change'}">
            <kye-input v-model="formData.throwOutWeight"
                       type="number"
                       :precision="2"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="计费重量"
                         prop="billingWeight">
            <kye-input v-model="formData.billingWeight"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="运费"
                         prop="deliveryFee">
            <kye-input :value="formData.deliveryFee|money"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="小计费"
                         prop="charging">
            <kye-input :value="formData.charging|money"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="到付金额"
                         prop="receiptMoney">
            <kye-input v-model="formData.receiptMoney"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="其他费"
                         prop="otherChargin">
            <kye-number v-model="formData.otherChargin"
                        symbol="￥"
                        :precision="2"
                        placeholder=""
                        disabled></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item prop="feeType"
                         class="reset-height">
            <span slot="label"
                  class="kye-label-click"
                  @click="openOtherTemp">费用类别</span>
            <kye-field v-model="formData.feeType"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="超时扣款"
                         prop="timeoutDeductions">
            <kye-input :value="formData.timeoutDeductions|money"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="丢货扣款"
                         prop="lossGoodsMoney">
            <kye-number v-model="formData.lossGoodsMoney"
                        symbol="¥"
                        :precision="2"
                        placeholder=""></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="丢单扣款"
                         prop="receiptLossMoney">
            <kye-number v-model="formData.receiptLossMoney"
                        symbol="¥"
                        :precision="2"
                        placeholder=""></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="货损扣款"
                         prop="breakageGoodsMoney">
            <kye-number v-model="formData.breakageGoodsMoney"
                        symbol="¥"
                        :precision="2"
                        placeholder=""></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="派送时间"
                         prop="deliveryDate">
            <kye-input :value="formData.deliveryDate|minute"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="派送人"
                         prop="deliveryPerson">
            <kye-input v-model="formData.deliveryPerson"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="签收时间"
                         prop="signDate">
            <kye-input :value="formData.signDate|minute"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="签收人"
                         prop="signPerson">
            <kye-input v-model="formData.signPerson"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="修改时间"
                         prop="updationDate">
            <kye-input :value="formData.updationDate|minute"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="修改人"
                         prop="updatedByName">
            <kye-input v-model="formData.updatedByName"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="上交情况"
                         prop="receiptHandin">
            <kye-input v-model="formData.receiptHandin"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  auth="partner.partnerWaybill.update"
                  @click="submit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :data="dialogOption.data"
                 :is="dialogOption.view"
                 :id="id"
                 @change="otherChange"
                 @close="dialogOption.show=false">
      </component>
    </kye-dialog>
  </section>
</template>
<script>
  // 费用类型
  import { otherTemplate } from './components'
  // 费用类别信息
  const _other = {}
  export default {
    components: {
      otherTemplate
    },
    props: {
      data: Object,
      id: String
    },
    data () {
      return {
        isLoading: false,
        formData: {},
        dialogOption: {
          show: false,
          data: {},
          view: 'otherTemplate',
          width: '472px',
          title: '费用类别修改'
        }
      }
    },
    created () {
      this.formData = Object.assign({}, this.data)
    },
    methods: {
      // 保存
      submit () {
        if (this.formData.throwOutWeight <= 0) return false
        this.isLoading = true
        let data = {
          id: this.formData.id,
          throwOutWeight: this.formData.throwOutWeight,
          lossGoodsMoney: this.formData.lossGoodsMoney || 0,
          lossGoodsMoneyMask: this.formData.lossGoodsMoneyMask,
          receiptLossMoney: this.formData.receiptLossMoney || 0,
          receiptLossMoneyMask: this.formData.receiptLossMoneyMask,
          breakageGoodsMoney: this.formData.breakageGoodsMoney || 0,
          breakageGoodsMoneyMask: this.formData.breakageGoodsMoneyMask
        }
        Object.assign(data, _other)
        let upData = {
          updateList: [this.$diff(data)],
          vo: {
            reconciliationId: this.id
          }
        }
        this.$http('partner.partnerWaybill.update', upData).then(res => {
          this.isLoading = false
          this.$message.success('修改成功')
          this.$emit('success')
          return this.close()
        }).catch(() => { this.isLoading = false })
      },
      // 取消
      close () {
        this.isLoading = false
        this.$refs.modifyForm.clearValidate()
        this.$emit('close')
      },
      // 修改费用类别后
      otherChange (val) {
        let otherChargin = 0
        const feeTypes = []
        Object.keys(val).forEach(v => {
          _other[v] = val[v].value
          if (val[v].value && val[v].value > 0) {
            feeTypes.push(val[v].label)
            // this.formData[v] = val[v].value
            otherChargin += parseFloat(val[v].value)
          }
        })
        this.formData.feeType = feeTypes.join('、')
        this.formData.otherChargin = otherChargin
        console.log(this.formData)
      },
      // 打开修改费用类别
      openOtherTemp () {
        const data = Object.create({})
        Object.keys(this.formData).forEach(v => {
          if (/Fee$/.test(v)) {
            data[v] = this.formData[v]
          }
        })
        this.dialogOption.data = data
        this.dialogOption.show = true
      },
      // 验证计抛重量
      checkThrowWeight (rule, value, callback) {
        if (value <= 0) callback(new Error('不能小于或等于0'))
      }
    }
  }
</script>
<style lang="scss">
  .reset-height {
    height: 28px !important;
    line-height: 28px !important;
    .el-form-item__content {
      max-height: 28px !important;
    }
  }
</style>
