<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-model="formModel"
                 :form-tools="formTools"
                 :option="option"
                 :tools="tools"
                 :tables="tables">
      <div slot="desc">
        <kye-form inline
                  label-width="auto"
                  style="padding:0;margin-top:2px"
                  class="kye-data-rows">
          <kye-button type="text"
                      style="margin-right:12px"
                      auth="partner.user.synchronizeAccountBatch"
                      @click="syncAccountBetch">
            <i class="iconfont icon-ecs-piliangtongbu"
               style="margin-right:4px"></i>批量同步</kye-button>
          <kye-form-item class="no-margin"
                         label="同步账号">
            <kye-input v-model="syncQuery.mobile"
                       style="width:120px"
                       type="number"
                       clearable></kye-input>
          </kye-form-item>
          <kye-button auth="partner.user.synchronizeAccount"
                      style="color:#9571e9"
                      @click="syncAccount(syncQuery.mobile)"><i class="iconfont icon-sort"
               style="margin-right:4px"></i>同步</kye-button>
        </kye-form>
      </div>
    </query-table>
    <!-- 模态框 -->
    <kye-dialog v-bind="dialogOption"
                :view.sync="dialogOption.view"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 @close="dialogOption.show = false">
      </component>
    </kye-dialog>
  </div>
</template>

<script type="text/jsx">
  // 格式化时间
  import moment from 'moment'
  import mixins from 'public/mixins'
  export default {
    mixins: [mixins],
    name: 'partnerBackstage',
    data () {
      return {
        dialogOption: {
          loading: false,
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        syncQuery: {
          mobeil: ''
        },
        generic: {
          method: 'partner.user.search',
          searchCode: 'partner_user_search'
        },
        formTools: [
          {
            auth: 'partner.basic.search',
            label: '刷新',
            icon: 'reset',
            func: () => this.reFresh()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'partner_user_search_define'
        },
        tools: [
        ],
        tables: [
          {
            searchCode: 'partner_user_search_field',
            url: { method: 'partner.user.search' },
            option: {
              moduleCode: 'partner',
              load: false,
              defaultSort: {
                keys: ['creationDate', 'creation_date'],
                prop: 'creationDate',
                order: 'descending'
              }
              // detailAuth: 'partner.user.get'
            },
            formatter: {
              province: (row, column, val) => {
                return val.addressName
              }
            }
          }
        ],
        formModel: {
          deliveryTime: [moment().format('YYYY-MM-DD 00:00:00'), moment().format('YYYY-MM-DD 23:59:59')]
        }
      }
    },
    methods: {
      reFresh () {
        return this.$refs.queryTable.loadData()
      },
      // 同步账号至安全部门和整车
      syncAccount (mobile) {
        const isMobile = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/.test(mobile)
        if (!isMobile) return this.$message({ type: 'error', message: '请正确填写账号' })
        this.$http('partner.user.synchronizeAccount', { mobile })
          .then(res => {
            this.$message({ type: 'success', message: '账号同步成功' })
          })
      },
      // 批量同步至安全部门和整车
      syncAccountBetch () {
        this.$http('partner.user.synchronizeAccountBatch')
          .then(res => {
            this.$message({ type: 'success', message: '批量同步成功' })
          })
      }
    }

  }
</script>
<style lang="scss" scoped>
  .no-margin {
    margin-bottom: 0 !important;
  }
  .kye-data-rows {
    background-color: transparent !important;
  }
</style>
