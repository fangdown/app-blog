<template>
  <section>
    <search-pager ref="searchPage"
                  :option="option"
                  :tools="tools"></search-pager>
    <kye-expand-page>
      <kye-form class="kye-self-form form-block"
                :model="formData"
                ref="messageForm"
                :rules="rules">
        <kye-form-item label="标题"
                       prop="title">
          <kye-input v-model="formData.title"></kye-input>
        </kye-form-item>
        <kye-form-item label="发布范围">
          <kye-input disabled
                     value="全体人员"></kye-input>
        </kye-form-item>
        <kye-form-item label="消息内容"
                       prop="content">
          <kye-input type="textarea"
                     :rows="15"
                     v-model="formData.content"></kye-input>
        </kye-form-item>
        <kye-form-item label="图片">
          <kye-upload ref="upload"
                      code="partner_message_image"
                      list-type="picture-card"
                      :disabled="imgList.length>=10"
                      :value="imgList"
                      :id="`${uuid}_message`"
                      :size="2"
                      :accept="['image']"
                      @success="getImages"></kye-upload>
        </kye-form-item>
      </kye-form>
    </kye-expand-page>
  </section>
</template>
<script>
  // 取消前钩子
  import routeHook from 'public/mixins/route-hook'
  export default {
    mixins: [routeHook],
    data () {
      return {
        option: {
          back: '/tms/partner-message/list'
        },
        tools: [
          {
            label: '保存',
            icon: 'save1',
            auth: 'partner.partnerMessage.save',
            func: () => this.save()
          },
          {
            label: '取消',
            icon: 'cancel1',
            func: () => this.handleCancel()
          }
        ],
        formData: {
          title: '',
          content: '',
          imgs: '',
          types: 1
        },
        uuid: '',
        rules: {
          title: {
            required: true,
            message: '请填写标题',
            trigger: 'blur'
          },
          content: {
            required: true,
            message: '请填写消息内容',
            trigger: 'blur'
          }
        },
        imgList: []
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (from.path === '/tms/partner-message/list') {
          vm.init()
          vm.uuid = new Date().getTime().toString(36)
        }
      })
    },
    methods: {
      // 初始化
      init () {
        this.formData = {
          title: '',
          content: '',
          imgs: '',
          types: 1
        }
        this.imgList = []
      },
      // 取消返回上个页面
      handleCancel (formName) {
        this.BACK_HOOK_MODULE()
      },
      // 图片上传成功
      getImages (imgs) {
        this.imgList = imgs
        this.formData.imgs = imgs[0].bizId
      },
      // 保存
      save () {
        this.$refs.messageForm.validate(async valid => {
          if (valid) {
            this.isLoading = true
            try {
              const id = await this.$http('partner.partnerMessage.save', this.formData)
              this.SET_SAVE_HOOK_FLAG()
              this.$message.success('新增成功')
              this.$refreshMainQueryTable()
              this.isLoading = false
              return this.$router.push(`/tms/partner-message/detail/${id}`)
            } finally {
              this.isLoading = false
            }
          } else {
            return this.$rule.error(this, this.$refs.messageForm)
          }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-self-form {
    .el-form-item {
      width: 50%;
    }
  }
</style>
