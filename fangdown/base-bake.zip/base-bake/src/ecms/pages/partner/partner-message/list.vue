<template>
  <section>
    <query-table ref="queryTable"
                 :tables="tables"
                 :option="option"
                 :form-tools="formTools"></query-table>
  </section>
</template>
<script>
  export default {
    data () {
      return {
        tables: [
          {
            searchCode: 'partner_partnerMessage_search_field',
            url: {
              method: 'partner.partnerMessage.search'
            },
            operation: {
              label: '操作',
              fixed: 'left',
              width: 100,
              options: [
                {
                  type: 'button',
                  label: '删除',
                  btnType: 'text',
                  auth: 'partner.partnerMessage.deleteBatch',
                  func: row => this.deleteMessage(row)
                },
                {
                  label: row => row.status === 1 ? '取消发布' : '发布',
                  btnType: 'text',
                  func: row => row.status === 1 ? this.cancelPublish(row) : this.publish(row)
                }
              ]
            },
            option: {
              type: 'index',
              load: false,
              detailAuth: 'partner.partnerMessage.get',
              defaultSort: {
                keys: ['publishTime', 'publish_time'],
                prop: 'publishTime',
                order: 'descending'
              },
              rowDblClick: row => this.$router.push(`/tms/partner-message/detail/${row.id}`)
            }
          }
        ],
        option: { // 可选
          searchCode: 'partner_partnerMessage_search_defined',
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            func: () => this.$refs.queryTable.loadData()
          },
          {
            label: '新增',
            type: 'link',
            icon: 'plus',
            func: '/tms/partner-message/add'
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ]
      }
    },
    methods: {
      // 删除
      deleteMessage (row) {
        const ids = [row.id]
        return this.$http('partner.partnerMessage.deleteBatch', { ids })
          .then(res => {
            return this.$refreshMainQueryTable()
          })
      },
      // 发布
      publish (row) {
        const params = {
          id: row.id,
          status: 1
        }
        return this.$http('partner.partnerMessage.update', params)
          .then(res => {
            this.$message.success('更新成功')
            return this.$refreshMainQueryTable()
          })
      },
      // 取消发布
      cancelPublish (row) {
        const params = {
          id: row.id,
          status: 2
        }
        return this.$http('partner.partnerMessage.update', params)
          .then(res => {
            this.$message.success('更新成功')
            return this.$refreshMainQueryTable()
          })
      }
    }
  }
</script>
