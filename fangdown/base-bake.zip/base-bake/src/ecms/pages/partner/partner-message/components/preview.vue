<template>
  <section>
    <div class="before iconfont icon-previous"
         @click.stop="previos"
         v-show="id"></div>
    <div class="after  iconfont icon-next"
         @click.stop="next"
         v-show="urls[id+1]"></div>
    <div class="content"
         @click="close">
      <div class="view"
           @click.stop>
        <img :src="urls[id]">
      </div>
    </div>
  </section>
</template>
<script>
  export default {
    props: {
      urls: Array,
      index: Number
    },
    data () {
      return {
        id: this.index
      }
    },
    methods: {
      close () {
        return this.$emit('close')
      },
      previos () {
        if (this.id <= 0) {
          return this.id = 0
        }
        this.id--
      },
      next () {
        if (this.id >= this.urls.length - 1) {
          return this.id = this.urls.length - 1
        }
        this.id++
      }
    }
  }
</script>
<style lang="scss" scoped>
  section {
    position: fixed;
    z-index: 100000;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    .content {
      position: absolute;
      left: 50%;
      padding: 100px 0 0;
      transform: translateX(-50%);
      max-width: 50%;
      height: 100%;
      overflow: scroll;
      .view {
        display: flex;
        justify-content: center;
        img {
          width: 50%;
          max-width: 100%;
        }
      }
    }
    .before,
    .after {
      display: flex;
      position: absolute;
      top: 0;
      bottom: 0;
      width: 68px;
      font-size: 50px;
      color: #fff;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.4);
    }
    .before {
      left: 0;
    }
    .after {
      right: 0;
    }
  }
</style>
