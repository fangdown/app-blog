<template>
  <section>
    <search-pager ref="searchPage"
                  :option="option"
                  :tools="tools"></search-pager>
    <kye-expand-page>
      <kye-form class="kye-self-form form-block"
                :model="detailData">
        <kye-form-item label="标题">
          <kye-field>{{detailData.title}}</kye-field>
        </kye-form-item>
        <kye-form-item label="发布范围">
          <kye-input disabled
                     value="全体人员"></kye-input>
        </kye-form-item>
        <kye-form-item label="消息内容">
          <kye-input type="textarea"
                     :rows="15"
                     readonly
                     :value="detailData.content"></kye-input>
        </kye-form-item>
        <kye-form-item label="图片">
          <kye-field v-if="!imgList.length">暂无图片</kye-field>
          <kye-upload ref="upload"
                      code="partner_message_image"
                      list-type="picture-card"
                      class="partner-upload-wrap"
                      disabled
                      :value="imgList"></kye-upload>
        </kye-form-item>
      </kye-form>
    </kye-expand-page>
  </section>
</template>
<script>
  import mixins from 'public/mixins'
  export default {
    beforeRouteEnter (to, from, next) {
      const id = to.params.id
      next(vm => vm.fetchDetal(id))
    },
    beforeRouteUpdate (to, from, next) {
      const id = to.params.id
      this.fetchDetal(id)
      next()
    },
    mixins: [mixins],
    data () {
      return {
        option: {
          back: '/tms/partner-message/list',
          method: 'partner.partnerMessage.search',
          searchCode: 'partner_partnerMessage_search'
        },
        tools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: 'partner.partnerMessage.get',
            func: () => this.fetchDetal(this.$route.params.id)
          }
        ],
        detailData: {},
        text: '',
        imgList: [],
        isPreview: false,
        index: 0
      }
    },
    methods: {
      // 获取消息详情
      fetchDetal (id) {
        this.detailData = {}
        this.imgList = []
        return this.$http('partner.partnerMessage.get', { id })
          .then(res => {
            this.detailData = res
            return res.imgs && this.fetchPictures(res.imgs)
          })
      },
      // 获取图片
      fetchPictures (res) {
        const fileParam = {
          bizCode: 'partner_message_image',
          bizId: res
        }
        return this.$http('file.getByBizCodeAndBizId', fileParam)
          .then(res => {
            this.imgList = res
          })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-self-form {
    .el-form-item {
      width: 50%;
    }
  }
</style>
<style lang="scss">
  .partner-upload-wrap {
    .el-upload--picture-card {
      display: none;
    }
  }
</style>
