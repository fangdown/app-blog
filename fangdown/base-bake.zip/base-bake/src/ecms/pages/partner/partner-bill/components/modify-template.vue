<template>
  <section v-loading="isLoading">
    <kye-form :model.sync="formData"
              module-code="partner"
              :biz-id="id"
              label-width="56px"
              label-position="left"
              class="kye-dialog-body"
              :rules="rules"
              ref="modifyForm">
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="运单号"
                         prop="waybillNumber">
            <kye-input v-model="formData.waybillNumber"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="运费"
                         prop="deliveryFee">
            <kye-input :value="formData.deliveryFee|money"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="计抛重量"
                         prop="throwOutWeight">
            <kye-number unit="kg"
                        :precision="2"
                        placeholder=""
                        v-model="formData.throwOutWeight"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="小计费"
                         prop="charging">
            <kye-input :value="formData.charging|money"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item prop="feeType">
            <span slot="label"
                  class="kye-label-click"
                  @click="openOtherTemp">费用类别</span>
            <kye-field v-model="formData.feeType"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="其他费"
                         prop="otherChargin">
            <kye-number symbol="¥"
                        :precision="2"
                        placeholder=""
                        disabled
                        v-model="formData.otherChargin"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="超时扣款"
                         prop="timeoutDeductions">
            <kye-number symbol="¥"
                        :precision="2"
                        placeholder=""
                        v-model="formData.timeoutDeductions"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="丢货扣款"
                         prop="lossGoodsMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        placeholder=""
                        v-model="formData.lossGoodsMoney"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="丢单扣款"
                         prop="receiptLossMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        placeholder=""
                        v-model="formData.receiptLossMoney"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="货损扣款"
                         prop="breakageGoodsMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        placeholder=""
                        v-model="formData.breakageGoodsMoney"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="派送人"
                         prop="deliveryPerson">
            <kye-input v-model="formData.deliveryPerson"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="派送时间"
                         prop="deliveryDate">
            <kye-input :value="formData.deliveryDate|minute"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="修改人"
                         prop="updatedByName">
            <kye-input v-model="formData.updatedByName"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="修改时间"
                         prop="updationDate">
            <kye-input :value="formData.updationDate|minute"
                       disabled></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col>
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input v-model="formData.remark"></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  auth="partner.partnerBillDetail.update"
                  @click="submit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :data="dialogOption.data"
                 :is="dialogOption.view"
                 :id="id"
                 @change="otherChange"
                 @close="dialogOption.show=false">
      </component>
    </kye-dialog>
  </section>
</template>
<script>
  // 费用类型
  import otherTemplate from './otherFee-template.vue'
  // 费用类别信息
  const _other = {}
  export default {
    components: { otherTemplate },
    props: {
      id: String,
      data: Object
    },
    data () {
      return {
        isLoading: false,
        formData: {},
        rules: {
          throwOutWeight: {
            required: true,
            message: '请填写计抛重量'
          }
        },
        dialogOption: {
          show: false,
          data: {},
          view: 'otherTemplate',
          width: '472px',
          title: '费用类别修改'
        }
      }
    },
    created () {
      this.formData = JSON.parse(JSON.stringify(this.data))
    },
    methods: {
      submit () {
        this.$refs.modifyForm.validate().then(valid => {
          if (valid) {
            this.isLoading = true
            let data = {
              id: this.formData.id,
              charging: this.formData.charging,
              chargingMask: this.formData.chargingMask,
              throwOutWeight: this.formData.throwOutWeight,
              // feeType: this.formData.feeType,
              // otherChargin: this.formData.otherChargin || 0,
              // otherCharginMask: this.formData.otherCharginMask,
              timeoutDeductions: this.formData.timeoutDeductions || 0,
              timeoutDeductionsMask: this.formData.timeoutDeductionsMask,
              lossGoodsMoney: this.formData.lossGoodsMoney || 0,
              lossGoodsMoneyMask: this.formData.lossGoodsMoneyMask,
              receiptLossMoney: this.formData.receiptLossMoney || 0,
              receiptLossMoneyMask: this.formData.receiptLossMoneyMask,
              breakageGoodsMoney: this.formData.breakageGoodsMoney || 0,
              breakageGoodsMoneyMask: this.formData.breakageGoodsMoneyMask,
              remark: this.formData.remark
            }
            Object.assign(data, _other)
            console.log(data)
            let upData = {
              updateList: [this.$diff(data)],
              billId: this.id
            }
            this.$http('partner.partnerBillDetail.update', upData)
              .then(res => {
                this.isLoading = false
                this.$message.success('保存成功')
                this.$emit('success')
                return this.close()
              }).catch(() => { this.isLoading = false })
          }
        })
      },
      close () {
        this.isLoading = false
        this.$refs.modifyForm.clearValidate()
        this.$emit('close')
      },
      // 修改费用类别后
      otherChange (val) {
        let otherChargin = 0
        const feeTypes = []
        Object.keys(val).forEach(v => {
          _other[v] = val[v].value
          if (val[v].value && val[v].value > 0) {
            feeTypes.push(val[v].label)
            otherChargin += parseFloat(val[v].value)
          }
        })
        this.formData.feeType = feeTypes.join('、')
        this.formData.otherChargin = otherChargin
        console.log(this.formData)
      },
      // 打开修改费用类别
      openOtherTemp () {
        const data = Object.create({})
        Object.keys(this.formData).forEach(v => {
          if (/Fee$/.test(v)) {
            data[v] = this.formData[v]
          }
        })
        this.dialogOption.data = data
        this.dialogOption.show = true
      }
    }
  }
</script>
