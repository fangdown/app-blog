<template>
  <section v-loading="isLoading">
    <kye-form :model="formData"
              class="kye-dialog-body"
              ref="addForm"
              :rules="rules">
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="运单号"
                         prop="waybillNumber">
            <kye-input v-model="formData.waybillNumber"
                       placeholder=""
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="运费"
                         prop="deliveryFee">
            <kye-number symbol="¥"
                        :precision="2"
                        clearable
                        placeholder=""
                        v-model="formData.deliveryFee"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="派送人"
                         prop="deliveryPerson">
            <kye-input v-model="formData.deliveryPerson"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="派送时间"
                         prop="deliveryDate">
            <kye-date-picker v-model="formData.deliveryDate"
                             :picker-options="pickerOption"
                             :default-value="new Date(data)"
                             type="datetime"></kye-date-picker>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="计抛重量"
                         prop="throwOutWeight">
            <kye-number unit="KG"
                        :precision="2"
                        placeholder=""
                        v-model="formData.throwOutWeight"
                        clearable></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="费用类别"
                         prop="feeType">
            <kye-input v-model="formData.feeType"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="货损扣款"
                         prop="breakageGoodsMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        clearable
                        placeholder=""
                        v-model="formData.breakageGoodsMoney"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="超时扣款"
                         prop="timeoutDeductions">
            <kye-number symbol="¥"
                        :precision="2"
                        clearable
                        placeholder=""
                        v-model="formData.timeoutDeductions"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="丢货扣款"
                         prop="lossGoodsMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        clearable
                        placeholder=""
                        v-model="formData.lossGoodsMoney"></kye-number>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="丢单扣款"
                         prop="receiptLossMoney">
            <kye-number symbol="¥"
                        :precision="2"
                        clearable
                        placeholder=""
                        v-model="formData.receiptLossMoney"></kye-number>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="其他费"
                         prop="otherChargin">
            <kye-input v-model="formData.otherChargin"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="备注"
                         prop="remark">
            <kye-input v-model="formData.remark"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  auth="partner.partnerBillDetail.save"
                  @click="submit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </section>
</template>
<script>
  export default {
    props: {
      id: String,
      data: String,
      partnerId: String
    },
    data () {
      return {
        isLoading: false,
        formData: {
          billId: '', // 账单列表ID
          partnerId: '', // 伙伴ID
          waybillNumber: '', // 运单号
          deliveryFee: '', // 运费
          throwOutWeight: '', // 计抛重量
          feeType: '', // 费用类别
          otherChargin: '', // 其他费
          timeoutDeductions: '', // 超时扣款
          lossGoodsMoney: '', // 丢货扣款
          receiptLossMoney: '', // 丢单扣款
          breakageGoodsMoney: '', // 货损扣款
          deliveryPerson: '', // 派送人
          deliveryDate: '', // 派送时间
          remark: '' // 备注
        },
        pickerOption: {
          disabledDate: time => {
            return time.getMonth() + 1 !== new Date(this.data).getMonth() + 1
          },
        },
        rules: {
          waybillNumber: {
            required: true,
            message: '请正确填写运单号',
            trigger: 'blur'
          },
          deliveryFee: {
            required: true,
            message: '请填写运费',
            trigger: 'blur'
          },
          deliveryPerson: {
            required: true,
            message: '请填写派送人',
            trigger: 'blur'
          },
          deliveryDate: {
            required: true,
            message: '请选择派送时间',
            trigger: 'change'
          },
          throwOutWeight: {
            required: true,
            message: '请填写计抛重量',
            trigger: 'blur'
          }
        }
      }
    },
    methods: {
      submit () {
        this.formData.billId = this.id
        this.formData.partnerId = this.partnerId
        this.$refs.addForm.validate()
          .then(valid => {
            this.isLoading = true
            valid && this.$http('partner.partnerBillDetail.save', { vo: this.formData })
              .then(res => {
                this.$message({
                  type: 'success',
                  message: '添加账单成功'
                })
                this.$emit('success')
                return this.close()
              })
              .catch(() => { this.isLoading = false })
          })
      },
      close () {
        this.isLoading = false
        this.$emit('close')
      }
    }
  }
</script>
