export default [
  {
    key: 'waybillNumber', // 列字段key， 可以配置a.b.c
    label: '运单号', // 列头部
    width: '98px', // 宽度
    // fixed: 'left', // 是否左固定，注意 这里没有右侧固定，右侧只有操作固定列
    show: true // 是否显示
  },
  {
    key: 'charging',
    label: '小计费',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    key: 'deliveryFee',
    label: '运费',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    key: 'throwOutWeight',
    label: '计抛重量',
    width: '60px',
    show: true
  },
  {
    key: 'feeType',
    label: '费用类别',
    width: '66px',
    show: true
  },
  {
    key: 'otherChargin',
    label: '其他费',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    key: 'timeoutDeductions',
    label: '超时扣款',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    key: 'lossGoodsMoney',
    label: '丢货扣款',
    filter: 'money',
    width: '66px',
    show: true
  },
  {
    key: 'receiptLossMoney',
    label: '丢单扣款',
    filter: 'money',
    width: '66px',
    show: true
  },
  {
    key: 'breakageGoodsMoney',
    label: '货损扣款',
    width: '66px',
    filter: 'money',
    show: true
  },
  {
    key: 'deliveryPerson',
    label: '派送人',
    width: '54px',
    show: true
  },
  {
    key: 'deliveryDate',
    label: '派送时间',
    width: '124px',
    filter: 'minute',
    show: true
  },
  {
    key: 'updatedBy',
    label: '修改人',
    width: '54px',
    show: true
  },
  {
    key: 'updationDate',
    label: '修改时间',
    width: '124px',
    filter: 'minute',
    show: true
  },
  {
    key: 'remark',
    label: '备注',
    width: '72px',
    show: true
  }
]
