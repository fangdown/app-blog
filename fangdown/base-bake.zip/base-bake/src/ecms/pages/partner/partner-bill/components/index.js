import addTemplate from './add-template.vue'
import modifyTemplate from './modify-template'
import otherTemplate from './otherFee-template'
export {
  addTemplate,
  modifyTemplate,
  otherTemplate
}
