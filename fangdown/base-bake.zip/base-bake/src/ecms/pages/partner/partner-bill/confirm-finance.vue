<template>
  <div>
    <section class="kye-dialog-body">
      <kye-form label-position="left"
                :model.sync="selectData"
                :biz-id="selectData.id"
                module-code="partner"
                label-width="56px">
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="总金额"
                           label-width="52px"
                           prop="fmsTotalAmount">
              <kye-input disabled
                         :value="selectData.fmsTotalAmount|money"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="总票数"
                           label-width="52px">
              <kye-input disabled
                         :value="selectData.fmsTotalCount"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="对账批号">
              <kye-input disabled
                         :value="selectData.batchNo"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <!-- </kye-form>
      <kye-form label-position="top"> -->
        <kye-row>
          <kye-col :span="12">
            <kye-form-item label="纳入月份">
              <kye-date-picker type="month"
                               v-model="formData.fmsBelongMonth"
                               value-format="yyyy-MM"
                               style="width:100%"></kye-date-picker>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="应付公司">
              <kye-search-tips v-model="formData.fmsSupplierShortName"
                               url="ims.supplier.sync.search"
                               value-key="supplierName"
                               :keys="['supplierName']"
                               :format-data="supplierFormat"
                               @clear="clearSupplier"
                               @select="selectSupplier">
              </kye-search-tips>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
    </section>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  auth="partner.partnerFinancialBill.confirmation"
                  @click="confirmBill">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>

    </div>
  </div>
</template>
<script>
  export default {
    props: {
      selectRow: Object
    },
    data () {
      return {
        selectData: {},
        formData: {
          fmsSupplierShortName: '',
          fmsSupplierShortId: '',
          fmsBelongMonth: ''
        }
      }
    },
    created () {
      this.selectData = JSON.parse(JSON.stringify(this.selectRow))
    },
    methods: {
      // 财务确认
      async confirmBill () {
        let pdata = {
          vo: {
            id: this.selectRow.id,
            ...this.formData
          }
        }
        await this.$http('partner.partnerFinancialBill.confirmation', pdata)
        this.$message.success('确认成功')
        this.$emit('reload')
        this.$emit('close')
      },
      // 取消
      close () {
        this.$emit('close')
      },
      // 应付公司格式化
      supplierFormat (value) {
        return {
          supplierName: value
        }
      },
      // 选中应付公司
      selectSupplier (item) {
        if (item) {
          this.formData.fmsSupplierShortId = item.id
          this.formData.fmsSupplierShortName = item.supplierName
        }
      },
      // 清除应付公司
      clearSupplier () {
        this.formData.fmsSupplierShortId = ''
        this.formData.fmsSupplierShortName = ''
      }
    }
  }
</script>
