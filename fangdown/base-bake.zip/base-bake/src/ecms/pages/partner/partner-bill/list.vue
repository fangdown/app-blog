<template>
  <div>
    <query-table ref="queryTable"
                 :form-model="formModel"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tables="tables">
      <div slot="desc">
        <kye-form :model.sync="totalData"
                  module-code="partner"
                  :biz-id="new Date().getTime()"
                  class="kye-data-rows"
                  label-width="auto"
                  inline>
          <kye-button type="text"
                      auth="partner.partnerFinancialBill.confirmation"
                      style="margin-right:12px;"
                      icon="iconfont icon-ecs-caiwuqueren"
                      @click="confirmFinance">财务确认</kye-button>
          <kye-form-item label="总金额:"
                         prop="totalAmount">
            <strong>{{totalData.totalAmount||'0' | money}}</strong>
          </kye-form-item>
          <kye-form-item label="总票数:"
                         prop="totalNumber">
            <strong>{{totalData.totalNumber||0 | thousands}}</strong>
          </kye-form-item>
        </kye-form>
      </div>
    </query-table>
    <!-- 模态框 -->
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :view.sync="dialogOption.view"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :selectRow="selectedMuti[0]"
                 @reload="reload"
                 @close="dialogOption.show = false">
      </component>
    </kye-dialog>
  </div>
</template>

<script type="text/jsx">
  import mixins from 'public/mixins'
  // 财务确认
  import ConfirmFinance from './confirm-finance'
  export default {
    mixins: [mixins],
    name: 'partnerBackstage',
    components: {
      ConfirmFinance
    },
    data () {
      return {
        waybillNumber: '', // 查询的单号
        formModel: {
          deliveryMonth () {
            let nowDate = new Date()
            let Y = nowDate.getFullYear()
            let M = nowDate.getMonth() + 1
            let deliveryMonth = `${Y}-${M}`
            return { deliveryMonth }
          }
        },
        dialogOption: {
          loading: false,
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        selectedRow: null,
        selectedMuti: [],
        totalData: {
          totalAmount: 0,
          totalNumber: 0
        },
        generic: {
          method: 'partner.partnerFinancialBill.search',
          searchCode: 'partner_partnerFinancialBill_search'
        },
        formTools: [
          {
            label: '删除',
            icon: 'delete',
            auth: 'partner.partnerFinancialBill.deleteBatch',
            func: () => this.deleteBatch()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'partner_partnerFinancialBill_search_define',
          'waybillNumber': {
            change: e => {
              !e.value && (this.waybillNumber = e.value)
            }
          }
        },
        tables: [
          {
            searchCode: 'partner_partnerFinancialBill_search_field',
            url: { method: 'partner.partnerFinancialBill.search' },
            option: {
              label: '伙伴账单',
              type: 'selection',
              moduleCode: 'partner',
              load: false,
              defaultSort: {
                keys: ['accountTime', 'account_time'],
                prop: 'accountTime',
                order: 'descending'
              },
              detailAuth: 'partner.partnerBillDetail.search',
              beforeHttp: data => {
                const param = this.resetParams(data)
                this.getTotalData(param)
                this.waybillNumber = param.hasOwnProperty('vo') ? param.vo.waybillNumber : ''
              },
              rowDblClick: (row) => {
                let queryParam = {
                  deliveryMonth: row.deliveryMonth,
                  companyName: row.companyName,
                  pointName: row.pointName,
                  departmentName: row.departmentName,
                  batchNo: row.batchNo,
                  fmsPayableNumber: row.fmsPayableNumber,
                  province: row.province
                }
                Object.keys(queryParam).forEach(v => {
                  if (row[`${v}Mask`]) {
                    queryParam[`${v}Mask`] = row[`${v}Mask`]
                  } else if (!row[v]) {
                    delete queryParam[v]
                  }
                })
                this.waybillNumber && (queryParam.waybillNumber = this.waybillNumber)
                this.$router.push({
                  path: `/tms/partner-bill/detail/${row.id}/${row.partnerId}`,
                  query: queryParam
                })
              },
              currentChange: (row) => {
                this.selectedRow = row
              },
              selectionChange: (val) => {
                this.selectedMuti = val
              }
            }
          }
        ]
      }
    },
    methods: {
      reload () {
        return this.$refs.queryTable.loadData()
      },
      showDynamicDialog (view, title, width = '1200px') {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
      },
      // 删除
      async deleteBatch () {
        if (this.selectedMuti.length === 0) {
          return this.$message.error('请选择要删除的数据')
        }
        this.$confirm('确定删除该账单？', '提示').then(async () => {
          await this.$http('partner.partnerFinancialBill.deleteBatch', {
            ids: this.selectedMuti.map(item => item.id)
          })
          this.$message.success('删除成功')
          this.reload()
        }).catch(() => {
          return false
        })
      },
      // 财务确认
      confirmFinance () {
        if (this.selectedMuti.length === 0) {
          return this.$message({ type: 'error', message: '请选择数据' })
        }
        return this.showDynamicDialog('ConfirmFinance', '财务确认', '500px')
      },
      // 重置请求参数格式
      resetParams (data) {
        data.hasOwnProperty('vo') && delete data.vo
        data.generic.vos.length && data.generic.vos.forEach((val, ind) => {
          if (val.propertyName === 'waybillNumber') {
            data.vo = { waybillNumber: val.values[0] }
            return data.generic.vos.splice(ind, 1)
          }
        })
        return data
      },
      // 获取统计数据
      async getTotalData (param) {
        const res = await this.$http('partner.partnerFinancialBill.summarySearch', param)
        this.totalData = { ...res }
      }
    }

  }
</script>
<style lang="scss" scoped>
  .kye-data-rows {
    height: 28px !important;
    margin: 4px 0;
    padding: 0 0;
    background-color: transparent;
    .el-form-item--mini.el-form-item {
      margin: 0px 24px 0 0 !important;
      font-size: 12px;
      strong {
        font-size: 12px;
      }
    }
  }
</style>
