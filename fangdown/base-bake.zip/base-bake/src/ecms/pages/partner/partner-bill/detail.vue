<template>
  <div class="kye-detail">
    <search-pager :option="option"
                  :tools="formTools">
    </search-pager>
    <kye-expand-page>
      <kye-form :model="queryForm"
                inline
                label-width="auto">
        <kye-form-item label="派送时间">
          <kye-date-picker type="daterange"
                           :clearable="false"
                           :editable="false"
                           :picker-options="options"
                           v-model="queryForm.deliveryDate"></kye-date-picker>
        </kye-form-item>
        <kye-form-item label="运单号">
          <kye-input v-model="queryForm.waybillNumber"
                     style="width:116px"
                     clearable></kye-input>
        </kye-form-item>
        <kye-button icon="iconfont icon-search"
                    size="small"
                    @click="searchList(1)"
                    auth="partner.partnerBillDetail.search"
                    type="primary">查询</kye-button>
      </kye-form>
      <kye-form :model.sync="formData"
                module-code="partner"
                :biz-id="$route.params.partnerId"
                inline
                label-width="auto"
                ref="addForm">
        <!--基本信息-->
        <kye-form-item label="派送月份"
                       prop="deliveryMonth">
          <kye-field style="width:66px;background-color:#ECECF5">{{formData.deliveryMonth}}</kye-field>
        </kye-form-item>
        <kye-form-item label="公司全称"
                       prop="companyName">
          <kye-field style="width:128px;background-color:#ECECF5">{{formData.companyName||''}}</kye-field>
        </kye-form-item>
        <kye-form-item label="一级点部"
                       prop="pointName">
          <kye-field style="width:128px;background-color:#ECECF5">{{formData.pointName||''}}</kye-field>
        </kye-form-item>
        <kye-form-item label="部门"
                       prop="departmentName">
          <kye-field style="width:128px;background-color:#ECECF5">{{formData.departmentName||''}}</kye-field>
        </kye-form-item>
        <kye-form-item label="区域省份"
                       prop="province">
          <kye-field style="width:86px;background-color:#ECECF5">
            {{formData.province||''}}
          </kye-field>
        </kye-form-item>
        <kye-form-item label="对账批号"
                       prop="batchNo">
          <kye-field style="width:86px;background-color:#ECECF5">
            {{formData.batchNo||'' }}
          </kye-field>
        </kye-form-item>
        <kye-form-item label="应付编码"
                       prop="fmsPayableNumber">
          <kye-field style="width:86px;background-color:#ECECF5">{{formData.fmsPayableNumber||''}}</kye-field>
        </kye-form-item>
      </kye-form>

      <!--统计信息-->
      <kye-form :model.sync="totalData"
                module-code="partner"
                :biz-id="$route.params.partnerId"
                class="kye-data-rows"
                inline
                label-width="auto">
        <kye-form-item label="总金额 :"
                       prop="totalAmount">
          <strong>{{totalData.totalAmount||'0'|money}}</strong>
        </kye-form-item>
        <kye-form-item label="总票数 :"
                       prop="totalNumber">
          <strong>{{totalData.totalNumber||0|thousands}}</strong>
        </kye-form-item>
      </kye-form>
      <table-list :column="columns"
                  :data="detailData"
                  :options="tableOptions"
                  :operation="operation"
                  :selection="true"
                  :pageable="true"
                  :buttonOptions="buttonOption"
                  :page="{currentPage:1,pageSize:50}"
                  @sort-change="sortChange"
                  style="margin-top:4px"
                  v-loading="isLoading"></table-list>
      <kye-pagination :page-sizes="$pagination.pageSizes"
                      style="margin-top:16px"
                      :layout="$pagination.layout"
                      :total="total"
                      :current-page="page"
                      :page-size="pageSize"
                      @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"></kye-pagination>
      <kye-data-import code="partner_partnerbilldetail_import_template"
                       url="partner.partnerBillDetail.importExcel"
                       :params="importParams"
                       :visible.sync="importShow"
                       @success="searchList"
                       append-to-body></kye-data-import>
      <kye-dialog v-if="dialogOption.show"
                  v-bind="dialogOption"
                  :visible.sync="dialogOption.show">
        <component :is="dialogOption.view"
                   :id="$route.params.id"
                   :partnerId="$route.params.partnerId"
                   :data="dialogOption.data"
                   :isRead="dialogOption.isRead"
                   @success="searchList"
                   @close="dialogOption.show = false"></component>
      </kye-dialog>
    </kye-expand-page>
  </div>
</template>
<script>
  import mixins from 'public/mixins'
  // 时间格式化
  import { time } from 'public/utils'
  // 表格配置
  import columns from './detail-columns.js'
  // 新增账单/修改账单
  import { addTemplate, modifyTemplate, otherTemplate } from './components'
  import KyeDataImport from '@/shared/components/kye-data-import'
  export default {
    mixins: [mixins],
    components: { KyeDataImport, modifyTemplate, addTemplate, otherTemplate },
    computed: {
      curDate () {
        let now = new Date(this.$route.query.deliveryMonth)
        let Y = now.getFullYear()
        let M = now.getMonth() + 1
        return { Y, M }
      },
      // 设置date-picker Picker Options
      options () {
        // 计算可选日期范围
        let disabledDate = val => val.getMonth() + 1 !== this.curDate.M
        return { disabledDate }
      },
      // 设置默认日期范围
      curMonthLastD () {
        let curLastDate = new Date(this.curDate.Y, this.curDate.M)
        return new Date(curLastDate.getTime() - 1000)
      },
      // 设置导入参数
      importParams () {
        let billId = this.$route.params.id
        let deliveryMonth = this.formData.deliveryMonth ? this.formData.deliveryMonth.replace(/\s*$/g, '') : ''
        let pointName = this.formData.pointName
        return { billId, deliveryMonth, pointName }
      },
    },
    data () {
      return {
        isLoading: false,
        isSelectAll: false,
        total: 0,
        page: 1,
        pageSize: 20,
        queryForm: {
          deliveryDate: '',
          waybillNumber: ''
        },
        orderByClauses: [{ field: 't.delivery_date', orderByMode: 1 }], // 排序
        auditParam: {},
        columns,
        detailData: [],
        totalData: {
          totalAmount: 0,
          totalNumber: 0
        },
        importShow: false,
        selectedRows: [],
        tableOptions: {
          type: 'selection',
          moduleCode: 'partner',
          defaultSort: {
            keys: ['deliveryDate', 't.delivery_date'],
            prop: 'deliveryDate',
            order: 'descending'
          },
          selectionChange: val => this.handleSelectionChange(val)
        },
        dialogOption: {
          title: '',
          width: '472px',
          view: '',
          show: false,
          data: {}
        },
        operation: {
          label: '操作',
          fixed: 'left',
          width: '46px',
          // 操作按钮数组  array | function(row){return []}
          options: [
            {
              label: '修改',
              btnType: 'text', // el-button type
              auth: 'partner.partnerBillDetail.update',
              func: row => {
                this.dialogOption.title = '修改伙伴账单'
                this.dialogOption.view = 'modifyTemplate'
                this.dialogOption.data = row
                this.dialogOption.show = true
              }
            }
          ]
        },
        option: {
          back: '/tms/partner-bill/list',
        },
        formTools: [
          {
            label: '删除',
            icon: 'delete',
            auth: 'partner.partnerBillDetail.deleteBatch',
            func: () => this.handleDelete()
          },
          {
            label: '新增',
            icon: 'plus',
            auth: 'partner.partnerBillDetail.save',
            func: () => {
              this.dialogOption.title = '新增伙伴账单'
              this.dialogOption.view = 'addTemplate'
              this.dialogOption.data = this.$route.query.deliveryMonth
              this.dialogOption.show = true
            }
          },
          {
            label: '审核',
            icon: 'ecs-shenhe',
            auth: 'tms.ladingbalanceverify.genCheckAccountNumber',
            func: () => this.handleAudit()
          },
          {
            label: '反审',
            icon: 'ecs-caiwufanshen',
            auth: 'partner.partnerBillDetail.cancelAudit',
            func: () => this.handleDeaudit()
          },
          {
            label: '导入',
            icon: 'import',
            auth: 'partner.partnerBillDetail.importExcel',
            func: () => { this.importShow = true }
          },
          {
            label: '导出',
            icon: 'export',
            auth: 'partner.partnerBillDetail.export',
            func: () => this.handleExport()
          },
        ],
        buttonOption: {
          feeType: {
            color: '#9571e9',
            disabled: row => !row.feeType,
            func: val => this.checkOther(val)
          }
        },
        formData: {},
        billId: ''
      }
    },
    beforeRouteEnter (to, from, next) {
      const fromRoute = from.name === 'tms-partner-bill-list'
      next(vm => {
        if (vm.$route.meta.layout) return
        if (fromRoute) {
          vm.billId = to.params.id
          vm.queryForm.deliveryDate = [time(to.query.deliveryMonth), time(vm.curMonthLastD)]
          vm.queryForm.waybillNumber = to.query.waybillNumber
          vm.searchList()
        }
      })
    },
    methods: {
      // sortChange
      sortChange (e) {
        this.orderByClauses[0].orderByMode = e.order === 'descending' ? 1 : 0
        return this.searchList()
      },
      // 查询
      async searchList (type = 0) {
        this.isLoading = true
        this.detailData = []
        try {
          let pdata = {
            vo: {
              billId: this.billId,
              deliveryDate: this.queryForm.deliveryDate[0],
              beginDate: this.queryForm.deliveryDate[0],
              endDate: this.queryForm.deliveryDate[1],
              waybillNumber: this.queryForm.waybillNumber
            },
            page: type ? 1 : this.page,
            pageSize: this.$pagination.pageSize,
            orderByClauses: this.orderByClauses
          }
          this.auditParam = pdata.vo
          this.formData = this.$route.query
          this.getTotalData(pdata)
          let res = await this.$http('partner.partnerBillDetail.search', pdata)
          this.detailData = res.rows
          this.total = res.rowTotal
        } finally {
          this.isLoading = false
        }
      },
      // 获取统计数据
      async getTotalData (param) {
        this.totalData = {}
        this.$http('partner.partnerBillDetail.summarySearch', param)
          .then(res => {
            this.totalData = res
          }).catch(() => {
            this.totalData = {}
          })
      },
      // 导出
      async handleExport () {
        let menuId = this.$store.state.menus[this.$route.meta.tag].id
        if (menuId) {
          let params = {
            menuId: menuId,
            searchCode: 'partner_partnerBillDetail_search_field',
            page: this.page,
            pageSize: this.pageSize,
            vo: {
              billId: +this.$route.params.id,
              deliveryDate: this.queryForm.deliveryDate[0],
              beginDate: this.queryForm.deliveryDate[0],
              endDate: this.queryForm.deliveryDate[1],
              waybillNumber: this.queryForm.waybillNumber
            }
          }
          try {
            const xlsUrl = await this.$http('partner.partnerBillDetail.export', params)
            window.erpOpen(xlsUrl.url)
            this.$message.success('导出成功！')
          } catch (e) {
            this.$message.error('导出失败！')
          }
        }
      },
      // 审核
      handleAudit () {
        if (!this.detailData.length) return this.$message({ type: 'error', message: '暂无数据审核' })
        this.$confirm(this.selectedRows.length ? '确认审核当前选中数据？' : `确认审核${this.$route.query.deliveryMonth}整月数据？`, '审核确认').then(async () => {
          let res = await this.$http('tms.ladingbalanceverify.genCheckAccountNumber')
          let pdata = {}
          if (this.selectedRows.length) {
            pdata = {
              deliveryMonth: this.$route.query.deliveryMonth.trim(),
              batchNo: res,
              billId: this.$route.params.id,
              ids: this.selectedRows.map(item => item.id),
              vo: this.auditParam
            }
          } else {
            pdata = {
              totalSelection: 1,
              batchNo: res,
              billId: this.$route.params.id,
              vo: this.auditParam
            }
          }
          await this.$http('partner.partnerBillDetail.audit', pdata)
          this.$message.success('审核成功')
          this.$refreshMainQueryTable()
          return this.searchList(1)
        }).catch(() => { return false })
      },
      // 反审
      handleDeaudit () {
        this.$confirm(`确认反审${this.$route.query.deliveryMonth}月数据？`, '反审确认').then(() => {
          this.$http('partner.partnerBillDetail.cancelAudit', { billId: this.$route.params.id })
            .then(res => {
              this.$message.success('反审成功')
              this.$refreshMainQueryTable()
              return this.searchList(1)
            })
        }).catch(() => { return false })
      },
      // 删除
      handleDelete () {
        if (!this.selectedRows.length) {
          return this.$message.error('请选择要删除的数据')
        }
        this.$confirm('确定删除该账单？', '提示').then(() => {
          let pdata = {
            totalSelection: Number(this.isSelectAll),
            ids: this.selectedRows.map(item => item.id),
            billId: this.$route.params.id
          }
          this.$http('partner.partnerBillDetail.deleteBatch', pdata).then(res => {
            this.$message.success('删除成功')
            this.$refreshMainQueryTable()
            return this.searchList(1)
          }).catch(() => {
            return this.$message.err('删除失败')
          })
        }).catch(() => {
          return false
        })
      },
      checkOther (row) {
        const data = Object.create({})
        Object.keys(row).forEach(v => {
          if (/Fee$/.test(v)) {
            data[v] = row[v]
          }
        })
        this.dialogOption.data = data
        this.dialogOption.view = 'otherTemplate'
        this.dialogOption.isRead = true
        this.dialogOption.title = '费用类别详情'
        this.dialogOption.show = true
      },
      handleSelectionChange (val) {
        this.selectedRows = val
      },
      //  分页大小改变
      handleSizeChange (val) {
        this.pageSize = val
        this.searchList()
      },
      //  当前页下标改变
      handleCurrentChange (val) {
        this.page = val
        this.searchList()
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-field-content {
    background-color: #f5f5f5;
  }
  .el-form-item--mini.el-form-item {
    margin-bottom: 4px !important;
  }
  .kye-data-rows {
    height: 28px !important;
    margin: 4px 0;
    .el-form-item--mini.el-form-item {
      margin: 0px 24px 0 0 !important;
      font-size: 12px;
      strong {
        font-size: 12px;
      }
    }
  }
</style>
