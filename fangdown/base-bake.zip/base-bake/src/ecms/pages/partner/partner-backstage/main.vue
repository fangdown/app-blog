<template>
  <div>
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-tools="formTools"
                 :option="option"
                 :tables="tables">
      <div slot="desc"></div>
    </query-table>
    <!-- 模态框 -->
    <kye-dialog v-bind="dialogOption"
                :view.sync="dialogOption.view"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 @goDetail="goDetail"
                 @close="dialogOption.show = false">
      </component>
    </kye-dialog>
  </div>
</template>

<script type="text/jsx">
  // import moment from 'moment'
  import mixins from 'public/mixins'
  // 查询点部弹窗
  import queryBranch from '@/ecms/components/partner/partner-backstage/query-branch.vue'
  export default {
    mixins: [mixins],
    name: 'partnerBackstage',
    components: {
      queryBranch
    },
    data () {
      return {
        dialogOption: {
          loading: false,
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        selectedRow: [],
        generic: {
          method: 'partner.basic.search',
          searchCode: 'partner_basic_search'
        },
        formTools: [
          {
            auth: 'partner.basic.search',
            label: '刷新',
            icon: 'reset',
            func: () => this.reFresh()
          },
          {
            auth: 'partner.basic.save',
            label: '新增',
            icon: 'plus',
            type: 'link',
            func: 'add'
          },
          {
            auth: 'partner.basic.deletebatch',
            label: '删除',
            icon: 'delete',
            func: () => this.delete()
          },
          {
            label: '查询点部',
            icon: 'export',
            func: () => this.showDynamicDialog('queryBranch', '查询点部', '622px')
          },
          {
            label: '导出',
            icon: 'export',
            auth: 'partner.basic.export',
            func: () => this.export()
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          searchCode: 'partner_basic_search_define'
        },
        tables: [
          {
            searchCode: 'partner_basic_search_field',
            url: { method: 'partner.basic.search' },
            operation: {
              label: '操作',
              fixed: 'left',
              width: '40px',
              options: [
                {
                  auth: 'partner.basic.update',
                  type: 'link',
                  label: '修改',
                  func: row => `/tms/partner-backstage/modify/${row.id}`
                }
              ]
            },
            option: {
              type: 'selection',
              moduleCode: 'partner',
              detailAuth: 'partner.basic.get',
              load: false,
              defaultSort: {
                keys: ['creationDate', 'creation_date'],
                prop: 'creationDate',
                order: 'descending'
              },
              selectionChange: (row) => {
                this.selectedRow = row
              },
              rowDblClick: (row) => {
                this.$router.push(`/tms/partner-backstage/detail/${row.id}`)
              }
            }
          }
        ]
      }
    },
    methods: {
      showDynamicDialog (view, title, width) {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
      },
      // 删除
      delete () {
        if (this.selectedRow.length) {
          const ids = this.selectedRow.map(val => val.id)
          this.$confirm('确定删除该记录？', '提示').then(async () => {
            await this.$http('partner.basic.deletebatch', { ids })
            this.$message.success('删除成功')
            this.reFresh()
          }).catch(() => {
            return false
          })
        } else {
          return this.$message.error('请选择要删除的数据')
        }
      },
      // 刷新
      reFresh () {
        return this.$refs.queryTable.loadData()
      },
      // 调整至详情
      goDetail (row) {
        this.dialogOption.show = false
        this.$nextTick(() => {
          this.$route.params.activeTab = row.pointLevel
          this.$router.push(`/tms/partner-backstage/detail/${row.partnerId}`)
        })
      },
      // 导出
      async export () {
        let menuId = this.$store.state.menus[this.$route.path].id
        let getParams = this.$refs.queryTable.getParams()
        if (menuId) {
          let params = {
            menuId: menuId,
            searchCode: 'partner_basic_search_field',
            ...getParams
          }
          try {
            let xlsUrl = await this.$http('partner.basic.export', params)
            window.erpOpen(xlsUrl.url)
            this.$message.success('导出成功！')
          } catch (e) {
            this.$message.warning('导出失败！')
          }
        }
      }
    }

  }
</script>
