<template>
  <div>
    <search-pager :option="option"
                  :tools="formTools"></search-pager>
    <kye-expand-page v-loading="isLoading">
      <kye-form ref="form"
                label-width="72px"
                :model="form">
        <div class="form-block">
          <h3 class="kye-block-title">基本信息</h3>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="公司全称"
                             prop="companyName"
                             class="reset-height">
                <kye-input v-model="form.companyName"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级点部"
                             prop="pointName"
                             class="reset-height"
                             :rules="{required:true,message:'一级点部不能为空',trigger:'change'}">
                <kye-search-tips v-model="form.pointName"
                                 url="baseconfig.node.findByNodeNameAndFlag"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="networkFormat"
                                 @clear="clearNetwork"
                                 @select="selectNetwork">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="负责人"
                             prop="partnerLeader"
                             class="reset-height"
                             :rules="{required:true,message:'请填写负责人'}">
                <kye-input v-model="form.partnerLeader"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服对接"
                             prop="customer"
                             class="reset-height"
                             :rules="{required:true,message:'请填写客服对接人'}">
                <kye-input v-model="form.customer"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域区号"
                             prop="cityCode"
                             class="reset-height"
                             :rules="{required:true,message:'区域区号不能为空',trigger:'blur'}">
                <kye-input v-model="form.cityCode"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="点部地址"
                             prop="secondLevelAddress"
                             class="reset-height"
                             :rules="{required:true,message:'请填写点部地址'}">
                <kye-input v-model="form.secondLevelAddress"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="部门"
                             prop="departmentShortName"
                             class="reset-height"
                             :rules="{required:true,message:'部门不能为空'}">
                <kye-input disabled
                           v-model="form.departmentShortName"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域省份"
                             prop="province"
                             class="reset-height"
                             :rules="{required:true,message:'请填写区域省份'}">
                <kye-input v-model="form.province"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="所属大区"
                             prop="regionCode"
                             class="reset-height"
                             :rules="{required:true,message:'所属大区不能为空'}">
                <kye-select disabled
                            v-model="form.regionCode"
                            placeholder="">
                  <kye-option v-for="item in lookUpOptions['common_region']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"></kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="保证金"
                             prop="bailMoney"
                             class="reset-height"
                             :rules="{required:true,message:'请填写保证金'}">
                <kye-number v-model="form.bailMoney"
                            symbol="￥"
                            :precision="2"></kye-number>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="系统账号"
                             prop="partnerSysAccount"
                             class="reset-height"
                             :rules="{required:true,pattern:/^1[3|4|5|6|7|8|9][0-9]\d{8}$/,message:'请填写正确手机号',trigger:'blur'}">
                <kye-input v-model="form.partnerSysAccount"
                           clearable></kye-input>
              </kye-form-item>
            </kye-col>
            <!-- <kye-col :span="4">
              <kye-form-item label="总系统密码"
                             prop="partnerSysPsw"
                             :rules="$rule.reg(/^\d{6,10}$/, '请输入6-10位的数字密码',true)">
                <kye-input type="partnerSysPsw"
                           v-model="form.partnerSysPsw"></kye-input>
              </kye-form-item>
            </kye-col> -->
            <kye-col :span="4">
              <kye-form-item label="签订日期"
                             class="reset-height">
                <kye-date-picker type="date"
                                 format="yyyy-MM-dd"
                                 value-format="yyyy-MM-dd"
                                 v-model="form.agreementBeginDate"></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="到期日期"
                             class="reset-height">
                <kye-date-picker type="date"
                                 v-model="form.agreementEndDate"
                                 format="yyyy-MM-dd"
                                 value-format="yyyy-MM-dd"></kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">报价信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">小件报价</span>
                <kye-input disabled
                           v-model="hasSmallQuete"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">大件报价</span>
                <kye-input disabled
                           v-model="hasBigQuete"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="抛重系数"
                             prop="throwWeightIndex"
                             class="reset-height"
                             :rules="{required:true,message:'请填写抛重系数'}">
                <kye-number :precision="2"
                            v-model="form.throwWeightIndex"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超时扣款"
                             prop="timeoutDeductions"
                             class="reset-height"
                             :rules="{required:true,message:'请填写超时扣款'}">
                <kye-number symbol="￥"
                            :precision="2"
                            v-model="form.timeoutDeductions"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="是否直飞"
                             prop="ifFlyDirect"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否直飞',trigger:'change'}">
                <kye-select v-model="form.ifFlyDirect">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">伙伴信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="走货否"
                             prop="transportGoods"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否走货',trigger:'change'}">
                <kye-select v-model="form.transportGoods"
                            @change="transportGoodsChange">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="走货时间"
                             class="reset-height">
                <kye-date-picker v-model="form.deliveryTime"
                                 type="datetime"
                                 format="yyyy-MM-dd HH:mm"></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级距离"
                             class="reset-height"
                             prop="firstLevelDistance"
                             :rules="{required:true,message:'请填写一级距离'}">
                <kye-number unit="km"
                            v-model="form.firstLevelDistance"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="对接电话"
                             prop="takeOverTelephone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请填写对接电话',trigger:'blur'}">
                <kye-input v-model="form.takeOverTelephone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一派耗时"
                             prop="trunkCostOne"
                             class="reset-height"
                             :rules="{required:true,message:'请填写一派耗时'}">
                <kye-number unit="h"
                            v-model="form.trunkCostOne"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="二派耗时"
                             class="reset-height"
                             prop="trunkCostTwo">
                <kye-number unit="h"
                            v-model="form.trunkCostTwo"></kye-number>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨交接"
                             prop="handoverMethod"
                             class="reset-height"
                             :rules="{required:true,message:'请选择凌晨交接方式',trigger:'change'}">
                <kye-select v-model="form.handoverMethod"
                            @change="selectedHandover">
                  <kye-option v-for="item in lookUpOptions['common_handover_method']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨网点"
                             prop="dawnNodeName"
                             class="reset-height"
                             :rules="{required:true,message:'请选择我司凌晨网点',trigger:'change'}">
                <!-- <kye-input v-model="form.dawnNodeName"></kye-input> -->
                <kye-search-tips v-model="form.dawnNodeName"
                                 url="baseconfig.node.searchByNodeName"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="nodeFormat"
                                 @clear="clearNode"
                                 @select="selectNode">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地晨"
                             prop="dawnHandoverPlace"
                             class="reset-height"
                             :rules="{required:true,message:'请填写凌晨交接地'}">
                <kye-input v-model="form.dawnHandoverPlace"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨最晚"
                             prop="latestHandoverTime"
                             class="reset-height">
                <kye-time-picker v-model="form.latestHandoverTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择凌晨最晚交接时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨预达"
                             class="reset-height"
                             prop="dawnArriveEstimateTime"
                             :rules="{required:true,message:'请选择凌晨预达时间'}">
                <kye-time-picker v-model="form.dawnArriveEstimateTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择凌晨预达时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="中班交接"
                             class="reset-height"
                             prop="middleHandoverMethod">
                <kye-select v-model="form.middleHandoverMethod">
                  <kye-option v-for="item in lookUpOptions['common_handover_method']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班网点"
                             class="reset-height"
                             prop="middleNodeName">
                <!-- <kye-input v-model="form.middleNodeName"></kye-input> -->
                <kye-search-tips v-model="form.middleNodeName"
                                 url="baseconfig.node.searchByNodeName"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="nodeFormat"
                                 @clear="clearMiddleNode"
                                 @select="selectMiddleNode">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地中"
                             class="reset-height"
                             prop="middleHandoverPlace">
                <kye-input v-model="form.middleHandoverPlace"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班最晚"
                             class="reset-height"
                             prop="middleHandoverTime">
                <kye-time-picker v-model="form.middleHandoverTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择中班最晚交接时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班预达"
                             class="reset-height"
                             prop="middleArriveEstimateTime">
                <kye-time-picker v-model="form.middleArriveEstimateTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择中班预达时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨类型"
                             prop="dawnNodeType"
                             class="reset-height">
                <kye-select disabled
                            v-model="form.dawnNodeType">
                  <kye-option v-for="item in lookUpOptions['base_data_node_type']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班类型"
                             class="reset-height"
                             prop="middleNodeType">
                <kye-select disabled
                            v-model="form.middleNodeType">
                  <kye-option v-for="item in lookUpOptions['base_data_node_type']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="伙伴自提"
                             prop="airport"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否伙伴自提',trigger:'change'}">
                <kye-select v-model="form.airport">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="提货人"
                             prop="consignee"
                             class="reset-height"
                             :rules="{required:true,message:'请输入提货人'}">
                <kye-input v-model="form.consignee"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="放假时间"
                             class="reset-height"
                             prop="holiday">
                <kye-date-picker type="daterange"
                                 v-model="form.holiday">
                </kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">其它信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="kye客服"
                             prop="kyeCustomer"
                             class="reset-height"
                             :rules="{required:true,message:'请输入kye客服'}">
                <kye-input v-model="form.kyeCustomer"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服电话"
                             prop="kyeCustomerTelephone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请正确填写客服电话',trigger:'blur'}">
                <kye-input v-model="form.kyeCustomerTelephone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="kye操作"
                             prop="kyeOperator"
                             class="reset-height"
                             :rules="{required:true,message:'请填写kye操作人员'}">
                <kye-input v-model="form.kyeOperator"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="操作电话"
                             prop="kyeOperatorPhone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请正确填写操作人员电话',trigger:'blur'}">
                <kye-input v-model="form.kyeOperatorPhone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单人"
                             class="reset-height">
                <kye-input v-model="form.createdBy"
                           disabled></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单时间"
                             class="reset-height">
                <kye-date-picker format="yyyy-MM-dd HH:mm"
                                 v-model="form.creationDate"
                                 disabled></kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="修改人"
                             class="reset-height">
                <kye-input v-model="form.updatedBy"
                           disabled></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="修改时间"
                             class="reset-height">
                <kye-date-picker format="yyyy-MM-dd HH:mm"
                                 v-model="form.updationDate"
                                 disabled></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传营业执照','430px',licenseFiles,'10')">营业执照</span>
                <kye-input disabled
                           :value="licenseFiles.length===1?licenseFiles[0].name:`${licenseFiles.length}个附件`"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传保证金凭条','430px',receiptFiles,'20')">保证金凭条</span>
                <kye-input disabled
                           :value="receiptFiles.length===1?receiptFiles[0].name:`${receiptFiles.length}个附件`"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传其它文件','430px',otherFiles,'30')">其它文件</span>
                <kye-input disabled
                           :value="otherFiles.length===1?otherFiles[0].name:`${otherFiles.length}个附件`"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">下级点部信息</h3>
          <div style="position:relative">
            <kye-tabs v-model="tapActive"
                      @tab-click="switchTab">
              <kye-tab-pane label="二级点部"
                            name="branch">
                <kye-edit-table :column="branchColumn"
                                status="edit"
                                :data="secondCoveringAreases"
                                :showIndex="true"
                                ref="branchTable"
                                class="mt10">
                  <template slot="handle">
                    <kye-table-column label="操作"
                                      fixed="left"
                                      width="64px">
                      <template slot-scope="scope">
                        <kye-button @click="deleteRow('branchTable', scope.$index)"
                                    type="text"
                                    size="small">删除</kye-button>
                      </template>
                    </kye-table-column>
                  </template>
                </kye-edit-table>
              </kye-tab-pane>
              <kye-tab-pane label="三级点部"
                            name="branchSmall">
                <kye-edit-table :column="branchSmallColumn"
                                status="edit"
                                :data="thirdCoveringAreases"
                                :showIndex="true"
                                ref="branchSmallTable"
                                class="mt10">
                  <template slot="handle">
                    <kye-table-column fixed="left"
                                      label="操作"
                                      width="64px">
                      <template slot-scope="scope">
                        <kye-button @click="deleteRow('branchSmallTable', scope.$index)"
                                    type="text"
                                    size="small">删除</kye-button>
                      </template>
                    </kye-table-column>
                  </template>
                </kye-edit-table>
              </kye-tab-pane>
            </kye-tabs>
            <kye-row style="text-align:right;margin:4px 0;">
              <kye-button v-show="tapActive=='branch'"
                          type="text"
                          icon="iconfont icon-plus"
                          :disabled="!form.nodeId"
                          @click="addRow('branchTable')">新增</kye-button>
              <kye-button v-show="tapActive=='branchSmall'"
                          type="text"
                          icon="iconfont icon-plus"
                          :disabled="!branchSmallAbled"
                          @click="addRow('branchSmallTable')">新增</kye-button>
            </kye-row>
          </div>
        </div>
        <!-- <div class="kye-form-submit"
             style="margin-top: 0px;">
          <kye-button type="button"
                      @click="handleCancel('form')">取消</kye-button>
          <kye-button auth="partner.basic.save"
                      type="primary"
                      size="small"
                      @click="submit('form')">保存</kye-button>
        </div> -->
      </kye-form>
    </kye-expand-page>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :quoteData="{small:form.partnerSmallPieceQuotation,big:form.partnerLargeQuotation}"
                 :files="fileList"
                 :id="uuid"
                 :type="type"
                 @save="getQuote"
                 @change="getFiles"
                 @close="dialogOption.show=false">
      </component>
    </kye-dialog>
  </div>
</template>

<script>
  // 大小件报价
  import quoteTemplate from '@/ecms/components/partner/partner-backstage/quote-template'
  // 附件上传
  import uploadTemplate from '@/ecms/components/partner/partner-backstage/upload-template'
  import mixins from 'public/mixins'
  // 取消前钩子
  import routeHook from 'public/mixins/route-hook'
  // 格式化时间
  import { time } from 'public/utils'

  export default {
    mixins: [mixins, routeHook],
    data () {
      return {
        isLoading: false,
        fileList: [],
        type: '',
        // 面包屑配置
        option: {
          back: '/tms/partner-backstage/main'
        },
        formTools: [
          {
            label: '保存',
            icon: 'save1',
            auth: 'partner.basic.save',
            func: () => this.submit('form')
          },
          {
            label: '取消',
            icon: 'cancel1',
            func: () => this.handleCancel('form')
          }
        ],
        // 弹窗配置
        dialogOption: {
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        // 弹窗数据
        dialogData: {},
        // tab当前选中name
        tapActive: 'branch',
        branchSmallAbled: 0,
        // 上传的文件
        licenseFiles: [],
        receiptFiles: [],
        otherFiles: [],
        uuid: '',
        secondCoveringAreases: [],
        thirdCoveringAreases: [],
        // 表单数据
        form: {
          nodeId: '',
          agreementBeginDate: '',
          agreementEndDate: '',
          secondLevelAddress: '',
          departmentShortName: '',
          province: '',
          regionCode: '',
          holiday: '',
          dawnNodeType: '',
          middleNodeType: '',
          partnerCoveringAreases: [],
          partnerLargeQuotation: {
            dispatchNum1: 0.5,
            dispatchNum2: 0.3,
            dispatchNum3: 0.2,
            dispatchNum4: 0.1,
            firstWeight: 10,
            weight: 5
          },
          partnerSmallPieceQuotation: {
            dispatchNum1: 10,
            dispatchNum2: 8,
            dispatchNum3: 6,
            dispatchNum4: 5,
            weight: 5
          },
          partnerCertificateses: []
        },
        hasSmallQuete: '有', // 是否有小件报价
        hasBigQuete: '有', // 是否有大件报价
        // 二级点部列
        branchColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'select',
            width: '140px',
            remote: true,
            remotefn: this.remotePointLeaderData,
            change: this.branchPointChange,
            rule: {
              required: true,
              message: '请填写点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'input',
            width: '86px',
            rule: {
              required: true,
              message: '请填写点部负责人',
              trigger: 'blur'
            }
          },
          {
            label: '点部账号',
            key: 'pointAccount',
            type: 'input-number',
            width: '108px',
            rule: [
              {
                required: true,
                message: '请填写点部账号',
                trigger: 'blur'
              },
              {
                pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
                message: '请输入正确的手机号',
                trigger: 'blur'
              }
            ]
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否走货',
              trigger: 'change'
            },
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否全境',
              trigger: 'change'
            },
            dic: 'basic_data_whole',
            filter: {
              type: 'lookup',
              args: [
                'basic_data_whole'
              ]
            }
          },
          {
            label: '一级距离',
            key: 'secondLevelDistance',
            type: 'input-number',
            width: '86px',
            rule: {
              required: true,
              message: '请填写一级距离',
              trigger: 'blur'
            }
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'input',
            width: '140px',
            rule:
              {
                required: true,
                message: '请填写点部地址',
                trigger: 'blur'
              }
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            width: '140px'
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            width: '140px'
          },
        ],
        // 三级点部列
        branchSmallColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'select',
            width: '140px',
            remote: true,
            remotefn: this.remotePointLeaderData,
            change: this.branchSmallPointChange,
            rule: {
              required: true,
              message: '请填写点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '所属二级',
            key: 'alongTo',
            type: 'select',
            width: '140px',
            remote: true,
            remotefn: this.parentNodeSearch,
            // customData: this.parentNodeSearch,
            change: (index, row, data) => {
              row.nodeParentId = data.nodeId
            },
            rule: {
              required: true,
              message: '请填写点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'input',
            width: '86px',
            rule: {
              required: true,
              message: '请填写点部负责人',
              trigger: 'blur'
            }
          },
          {
            label: '点部账号',
            key: 'pointAccount',
            type: 'input-number',
            width: '108px',
            rule: [
              {
                required: true,
                message: '请填写点部账号',
                trigger: 'blur'
              },
              {
                pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
                message: '请输入正确的手机号',
                trigger: 'blur'
              }
            ]
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否走货',
              trigger: 'change'
            },
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否全境',
              trigger: 'change'
            },
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '二级距离',
            key: 'secondLevelDistance',
            type: 'input-number',
            width: '86px',
            rule: {
              required: true,
              message: '请填写二级距离',
              trigger: 'blur'
            }
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'input',
            width: '140px',
            rule:
              {
                required: true,
                message: '请填写点部地址',
                trigger: 'blur'
              }
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            width: '140px'
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            width: '140px'
          },
        ],
        upOption: {
          limit: 3,
          onExceed () {
            return this.$message({
              type: 'error',
              message: '最多上传3张'
            })
          }
        }
      }
    },
    components: {
      quoteTemplate,
      uploadTemplate
    },
    methods: {
      // 选择凌晨交接方式执行
      selectedHandover (val) {
        val === '20' && this.form.secondLevelAddress && (this.form.dawnHandoverPlace = this.form.secondLevelAddress)
      },
      // 获取组件中的文件
      getFiles (files, type) {
        switch (type) {
          case '10':
            this.licenseFiles = files
            break
          case '20':
            this.receiptFiles = files
            break
          case '30':
            this.otherFiles = files
            break
        }
      },
      // 修改报价
      getQuote (val) {
        this.form.partnerSmallPieceQuotation = val.small
        this.form.partnerLargeQuotation = val.big
      },
      dataInt () {
        this.form = {
          nodeId: '',
          agreementBeginDate: '',
          agreementEndDate: '',
          secondLevelAddress: '',
          departmentShortName: '',
          province: '',
          regionCode: '',
          holiday: '',
          dawnNodeType: '',
          middleNodeType: '',
          partnerCoveringAreases: [],
          partnerLargeQuotation: {},
          partnerSmallPieceQuotation: {},
          partnerCertificateses: []
        }
      },
      // 如果为编辑则需要获取数据
      async getData () {
        let res = await this.$http('partner.basic.edit', { id: this.id })
        this.form.vo = res
        this.form.partnerCoveringAreases = res.partnerCoveringAreases
      },
      clearValidate () {
        this.$refs.form.clearValidate()
      },
      // 打开报价弹框
      openQuoteDialog (type) {
        if (type === '10') {
          this.dialogData.data = this.form.partnerLargeQuotation
          this.showDynamicDialog('bigQuote', '大件报价', '670px')
        } else {
          this.dialogData.data = this.form.partnerSmallPieceQuotation
          this.showDynamicDialog('smallQuote', '小件报价', '626px')
        }
      },
      // 子组件报价添加成功
      copyToQuote (val, changeFlag = true) {
        if (changeFlag) {
          if (val.type === '10') {
            this.hasBigQuete = '有'
            this.form.partnerLargeQuotation = {
              weight: val.weight,
              firstWeight: val.firstWeight,
              dispatchNum1: val.dispatchNum1,
              dispatchNum2: val.dispatchNum2,
              dispatchNum3: val.dispatchNum3,
              dispatchNum4: val.dispatchNum4
            }
            this.form.partnerSmallPieceQuotation.weight = val.weight
          } else {
            this.hasSmallQuete = '有'
            this.form.partnerSmallPieceQuotation = {
              weight: val.weight,
              dispatchNum1: val.dispatchNum1,
              dispatchNum2: val.dispatchNum2,
              dispatchNum3: val.dispatchNum3,
              dispatchNum4: val.dispatchNum4
            }
            this.form.partnerLargeQuotation.weight = val.weight
          }
        }
      },
      // 选择走货否，自动带出走货时间
      transportGoodsChange () {
        if (this.form.transportGoods === '10') {
          this.form.deliveryTime = time(new Date())
        } else {
          this.form.deliveryTime = ''
        }
      },
      // 凌晨我司网点请求格式
      nodeFormat (val) {
        return {
          name: val
        }
      },
      // 选中凌晨我司网点
      async selectNode (val) {
        if (val) {
          this.form.dawnNodeName = val.nodeName
          this.form.dawnNodeId = val.id
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.dawnNodeType = res.nodeType
          this.form.handoverMethod === '10' && (this.form.dawnHandoverPlace = res.addressDetail)
        }
      },
      // 清除凌晨我司网点
      clearNode () {
        this.form.dawnNodeName = ''
        this.form.dawnNodeId = ''
        this.form.dawnNodeType = ''
      },
      // 选中中班我司网点
      async selectMiddleNode (val) {
        if (val) {
          this.form.middleNodeName = val.nodeName
          this.form.middleNodeId = val.id
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.middleNodeType = res.nodeType
        }
      },
      // 清除中班我司网点
      clearMiddleNode () {
        this.form.middleNodeName = ''
        this.form.middleNodeId = ''
        this.form.middleNodeType = ''
      },
      submit (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            if (this.hasSmallQuete !== '有') {
              this.$message.warning('小件报价不能为空')
              return
            }
            if (this.hasBigQuete !== '有') {
              this.$message.warning('大件报价不能为空')
              return
            }
            let validate1 = await this.$refs.branchTable.validate()
            let validate2 = await this.$refs.branchSmallTable.validate()
            if (validate1 && validate2) {
              this.savePartner()
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 保存
      async savePartner () {
        try {
          this.isLoading = true
          let postData = {
            partner: {
              agreementBeginDate: this.form.agreementBeginDate,
              agreementEndDate: this.form.agreementEndDate,
              departmentShortName: this.form.departmentShortName,
              departmentId: this.form.departmentId,
              partnerLeader: this.form.partnerLeader,
              partnerSysAccount: this.form.partnerSysAccount,
              telephone: this.form.telephone,
              secondLevelAddress: this.form.secondLevelAddress,
              cityCode: this.form.cityCode,
              regionCode: this.form.regionCode,
              bailMoney: +this.form.bailMoney,
              firstLevelDistance: this.form.firstLevelDistance,
              customer: this.form.customer,
              handoverMethod: this.form.handoverMethod,
              latestHandoverTime: this.form.latestHandoverTime,
              dawnHandoverPlace: this.form.dawnHandoverPlace,
              takeOverTelephone: this.form.takeOverTelephone,
              middleHandoverMethod: this.form.middleHandoverMethod,
              middleHandoverTime: this.form.middleHandoverTime,
              middleHandoverPlace: this.form.middleHandoverPlace,
              kyeCustomer: this.form.kyeCustomer,
              kyeCustomerTelephone: this.form.kyeCustomerTelephone,
              timeoutDeductions: +this.form.timeoutDeductions,
              airport: this.form.airport,
              consignee: this.form.consignee,
              deliveryTime: this.form.deliveryTime,
              transportGoods: this.form.transportGoods,
              companyName: this.form.companyName,
              throwWeightIndex: +this.form.throwWeightIndex,
              ifFlyDirect: this.form.ifFlyDirect,
              trunkCostOne: this.form.trunkCostOne,
              trunkCostTwo: this.form.trunkCostTwo,
              kyeOperator: this.form.kyeOperator,
              kyeOperatorPhone: this.form.kyeOperatorPhone,
              dawnArriveEstimateTime: this.form.dawnArriveEstimateTime,
              middleArriveEstimateTime: this.form.middleArriveEstimateTime,
              dawnNodeId: this.form.dawnNodeId,
              dawnNodeName: this.form.dawnNodeName,
              dawnNodeType: this.form.dawnNodeType,
              middleNodeId: this.form.middleNodeId,
              middleNodeName: this.form.middleNodeName,
              middleNodeType: this.form.middleNodeType,
              pointName: this.form.pointName,
              nodeId: this.form.nodeId,
              province: this.form.province
            },
            partnerCoveringAreases: [],
            partnerCertificateses: [],
            partnerLargeQuotation: this.form.partnerLargeQuotation,
            partnerSmallPieceQuotation: this.form.partnerSmallPieceQuotation
          }
          if (this.form.holiday) {
            postData.partner.holidayBegin = this.form.holiday[0]
            postData.partner.holidayEnd = this.form.holiday[1]
          }
          // 添加营业执照
          for (let item of this.licenseFiles) {
            postData.partnerCertificateses.push({
              type: '10',
              fileId: item.bizId,
              fileName: item.name
            })
          }
          // 添加保证金凭条
          for (let item of this.receiptFiles) {
            postData.partnerCertificateses.push({
              type: '20',
              fileId: item.bizId,
              fileName: item.name
            })
          }
          // 添加其他
          for (let item of this.otherFiles) {
            postData.partnerCertificateses.push({
              type: '30',
              fileId: item.bizId,
              fileName: item.name
            })
          }
          let second = this.$refs.branchTable.getData()
          let third = this.$refs.branchSmallTable.getData()
          postData.partnerCoveringAreases = [...second, ...third]
          const res = await this.$http('partner.basic.save', postData)
          this.isLoading = false
          this.SET_SAVE_HOOK_FLAG()
          this.$message.success('新增成功！')
          this.$refreshMainQueryTable()
          this.$router.push(`/tms/partner-backstage/detail/${res}`)
        } finally {
          this.isLoading = false
        }
      },
      // 取消返回上个页面
      handleCancel (formName) {
        this.BACK_HOOK_MODULE()
      },
      // 表格删除行
      deleteRow (ref, index) {
        let data = this.$refs[ref].getData()[index]
        const nodeId = data.nodeId
        let branchSmallData = []
        let isBelong = false
        if (ref === 'branchTable') {
          branchSmallData = this.$refs.branchSmallTable.getData()
          isBelong = branchSmallData.some(val => val.nodeParentId === nodeId)
        }
        if (isBelong) {
          return this.$confirm('该点部关联的三级点部将被一同删除，是否继续', '温馨提示', { type: 'warning' })
            .then(() => {
              this.$refs[ref].delRow(index)
              this.thirdCoveringAreases = branchSmallData.filter(v => v.nodeParentId !== nodeId)
            })
        }
        this.$refs[ref].delRow(index)
      },
      // 切换tab执行
      switchTab (tab) {
        if (tab.paneName === 'branchSmall') {
          this.branchSmallAbled = this.$refs.branchTable.getData().length
        }
      },
      // 表格添加行
      addRow (ref) {
        const obj = {
          alongTo: '',
          pointName: '',
          pointLeader: '',
          nodeId: '',
          nodeAddress: '',
          whole: '',
          secondLevelDistance: '',
          dawnHandoverTime: '',
          middleHandoverTime: '',
          pointLevel: '',
          pointAccount: '',
          transportGoods: '',
          nodeParentId: '',
          _type: 'edit'
        }
        if (ref === 'branchTable') {
          obj.pointLevel = '20'
          obj.nodeParentId = this.form.nodeId
        } else if (ref === 'branchSmallTable') {
          obj.pointLevel = '30'
        }
        this.$refs[ref].addRow(obj)
      },
      // 网点查询参数
      networkFormat (val) {
        return {
          nodeName: val
        }
      },
      // 选中网点
      async selectNetwork (val) {
        if (val) {
          this.form.pointName = val.nodeName
          this.form.nodeId = val.id
          const partnerAreases = this.$refs.branchTable.getData()
          if (partnerAreases.length) {
            this.$refs.branchTable.getData().map(value => {
              return value.nodeParentId = val.id
            })
          }
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.secondLevelAddress = `${res.province}${res.city}${res.county}${res.addressDetail}`
          this.form.departmentShortName = res.departmentName
          this.form.departmentId = res.departmentId
          this.form.province = res.province
          this.form.provinceId = res.province.id
          this.form.regionCode = res.regionCode
          this.form.cityCode = res.departmentCode
        }
      },
      // 清除网点
      clearNetwork () {
        this.form.pointName = ''
        this.form.nodeId = ''
        this.form.secondLevelAddress = ''
        this.form.departmentShortName = ''
        this.form.departmentId = ''
        this.form.province = ''
        this.form.provinceId = ''
        this.form.regionCode = ''
      },
      // 随机生成文件id
      getUuid () {
        this.uuid = +new Date() + Math.random()
          .toString(36)
          .substring(3, 3 + 7)
      },
      // 远程获取网点点部
      async remotePointLeaderData (query) {
        let res = await this.$http('baseconfig.node.findByNodeNameAndFlag', {
          nodeName: query
        })
        return {
          list: res,
          label: 'nodeName',
          value: 'id'
        }
      },
      // 二级点部名称变化
      branchPointChange (index, row, selectData) {
        let tData = this.$refs.branchTable.getData()
        let branchSmallData = this.$refs.branchSmallTable.getData()
        if (branchSmallData.length) {
          let hasBindParentArr = branchSmallData.filter((v, i) => {
            return v.nodeParentId === tData[index].nodeId
          })
          if (hasBindParentArr.length && tData[index].nodeId !== selectData.id) {
            this.$confirm('该点部已关联三级点部，请前往三级点部修改关联项！', { type: 'warning' }).then(() => {
              hasBindParentArr.map(v => { v.nodeParentId = selectData.id; v.alongTo = selectData.pointName })
            }).catch(() => {
              return false
            })
          }
        }
        tData[index].nodeAddress = `${selectData.province}${selectData.city}${selectData.county}${selectData.addressDetail}`
        tData[index].nodeId = selectData.id
      },
      // 三级点部名称变化
      branchSmallPointChange (index, row, selectData) {
        let tData = this.$refs.branchSmallTable.getData()
        tData[index].nodeAddress = `${selectData.province}${selectData.city}${selectData.county}${selectData.addressDetail}`
        tData[index].nodeId = selectData.id
      },
      // 所属二级
      async parentNodeSearch (query) {
        if (query) {
          let parentList = this.$refs.branchTable.getData()
          let res = parentList.filter(item => item.pointName.indexOf(query) >= 0)
          return {
            list: res,
            label: 'pointName',
            value: 'pointName'
          }
        }
      },
      // 打开弹窗
      showDynamicDialog (view, title, width = '1200px', fileList, type) {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
        this.fileList = fileList
        this.type = type
      },
      // 关闭弹窗
      closeDynamicDialog () {
        this.dialogOption = {
          width: '0px',
          title: '',
          show: false,
          view: ''
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        vm.getUuid()
        // vm.id = vm.$route.params.id
        // if (vm.id) vm.getData()
      })
    },
    beforeRouteLeave (to, from, next) {
      if (to.name === 'tms-partner-backstage-main' || to.name === 'tms-partner-backstage-detail') {
        this.$refs.form.resetFields()
        this.dataInt()
        this.form.partnerCoveringAreases = []
        this.$destroy()
      }
      next()
    }
  }
</script>
<style lang="scss" scoped>
  .kye-block-title {
    height: 28px;
    line-height: 28px;
    margin-bottom: 12px;
  }
</style>
<style lang="scss">
  .reset-height {
    height: 28px !important;
    line-height: 28px !important;
    .el-form-item__content {
      max-height: 28px !important;
    }
  }
</style>
