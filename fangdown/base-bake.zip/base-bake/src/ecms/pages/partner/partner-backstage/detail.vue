<template>
  <div>
    <search-pager :option="option"
                  :tools="tools"
                  ref="searchPager"></search-pager>
    <kye-expand-page v-loading="isLoading">
      <kye-form ref="form"
                label-position="left"
                :model.sync="form"
                module-code="partner"
                :biz-id="$route.params.id"
                label-width="72px">
        <div class="form-block">
          <h3 class="kye-block-title">基本信息</h3>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="公司全称"
                             class="reset-height"
                             prop="companyName">
                <kye-field v-model="form.companyName"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级点部"
                             prop="pointName"
                             class="reset-height">
                <kye-field v-model="form.pointName"></kye-field>

              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="负责人"
                             prop="partnerLeader"
                             class="reset-height">
                <kye-field v-model="form.partnerLeader"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服对接"
                             prop="customer"
                             class="reset-height">
                <kye-field v-model="form.customer"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域区号"
                             prop="cityCode"
                             class="reset-height">
                <kye-field v-model="form.cityCode"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="点部地址"
                             prop="secondLevelAddress"
                             class="reset-height">
                <kye-field disabled
                           v-model="form.secondLevelAddress"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="部门"
                             prop="departmentShortName"
                             class="reset-height">
                <kye-field disabled
                           v-model="form.departmentShortName"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域省份"
                             prop="province"
                             class="reset-height">
                <kye-field disabled
                           v-model="form.province"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="所属大区"
                             prop="regionCode"
                             class="reset-height">
                <kye-field>{{form.regionCode|lookup('common_region')}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="保证金"
                             prop="bailMoney"
                             class="reset-height">
                <kye-field>{{form.bailMoney|money}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="系统账号"
                             prop="partnerSysAccount"
                             class="reset-height">
                <kye-field v-model="form.partnerSysAccount"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4"
                     style="height:40px"></kye-col>
            <kye-col :span="4">
              <kye-form-item label="签订日期"
                             class="reset-height">
                <kye-field>{{form.agreementBeginDate|date}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="到期日期"
                             class="reset-height">
                <kye-field>{{form.agreementEndDate|date}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">报价信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">小件报价</span>
                <kye-field disabled
                           :value="hasSmallQuete?'有':'无'"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">大件报价</span>
                <kye-field disabled
                           :value="hasBigQuete?'有':'无'"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="抛重系数"
                             prop="throwWeightIndex"
                             class="reset-height">
                <kye-field>{{form.throwWeightIndex|decimal}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超时扣款"
                             prop="timeoutDeductions"
                             class="reset-height">
                <kye-field>{{form.timeoutDeductions|money}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="是否直飞"
                             prop="ifFlyDirect"
                             class="reset-height">
                <kye-field>{{form.ifFlyDirect|lookup('common_yes_no')}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">伙伴信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="走货否"
                             prop="transportGoods"
                             class="reset-height">
                <kye-field>{{form.transportGoods|lookup('common_yes_no')}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="走货时间"
                             class="reset-height">
                <kye-field>{{form.deliveryTime|minute}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级距离"
                             prop="firstLevelDistance"
                             class="reset-height">
                <kye-number :value="form.firstLevelDistance|decimal"
                            unit="km"
                            placeholder=""
                            readonly></kye-number>
                <!-- <kye-field>{{form.firstLevelDistance|decimal}}</kye-field> -->
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="对接电话"
                             prop="takeOverTelephone"
                             class="reset-height">
                <kye-field v-model="form.takeOverTelephone"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一派耗时"
                             prop="trunkCostOne"
                             class="reset-height">
                <kye-number :value="form.trunkCostOne|decimal"
                            unit="h"
                            placeholder=""
                            readonly></kye-number>
                <!-- <kye-field>{{form.trunkCostOne|decimal}}</kye-field> -->
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="二派耗时"
                             class="reset-height"
                             prop="trunkCostTwo">
                <kye-number :value="form.trunkCostTwo|decimal"
                            unit="h"
                            placeholder=""
                            readonly></kye-number>
                <!-- <kye-field>{{form.trunkCostTwo|decimal}}</kye-field> -->
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨交接"
                             prop="handoverMethod"
                             class="reset-height">
                <kye-field>{{form.handoverMethod|lookup('common_handover_method')}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨网点"
                             prop="dawnNodeName"
                             class="reset-height">
                <kye-field v-model="form.dawnNodeName"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地晨"
                             prop="dawnHandoverPlace"
                             class="reset-height">
                <kye-field v-model="form.dawnHandoverPlace"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨最晚"
                             class="reset-height">
                <kye-time-picker v-model="form.latestHandoverTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 readonly></kye-time-picker>
                <!-- <kye-field>{{form.latestHandoverTime}}</kye-field> -->
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨预达"
                             class="reset-height"
                             prop="dawnArriveEstimateTime">
                <kye-field>{{form.dawnArriveEstimateTime}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="中班交接"
                             class="reset-height"
                             prop="middleHandoverMethod">
                <kye-field>{{form.middleHandoverMethod|lookup('common_handover_method')}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班网点"
                             class="reset-height"
                             prop="middleNodeName">
                <kye-field v-model="form.middleNodeName"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地中"
                             class="reset-height"
                             prop="middleHandoverPlace">
                <kye-field v-model="form.middleHandoverPlace"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班最晚"
                             class="reset-height">
                <kye-time-picker v-model="form.middleHandoverTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 readonly></kye-time-picker>
                <!-- <kye-field>{{form.middleHandoverTime}}</kye-field> -->
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班预达"
                             class="reset-height"
                             prop="middleArriveEstimateTime">
                <kye-field>{{form.middleArriveEstimateTime}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨类型"
                             prop="dawnNodeType"
                             class="reset-height">
                <kye-input disabled
                           :value="form.dawnNodeType|lookup('base_data_node_type')"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班类型"
                             class="reset-height"
                             prop="middleNodeType">
                <kye-input disabled
                           :value="form.middleNodeType|lookup('base_data_node_type')"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="伙伴自提"
                             prop="airport"
                             class="reset-height">
                <kye-field>{{form.airport|lookup('common_yes_no')}}</kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="提货人"
                             prop="consignee"
                             class="reset-height">
                <kye-field v-model="form.consignee"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="放假时间"
                             class="reset-height"
                             prop="holiday">
                <!-- <kye-field>{{(form.holiday)}}</kye-field> -->
                <kye-date-picker type="daterange"
                                 :disabled="true"
                                 :value="[form.holidayBegin,form.holidayEnd]">
                </kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">其它信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="kye客服"
                             prop="kyeCustomer"
                             class="reset-height">
                <kye-field v-model="form.kyeCustomer"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服电话"
                             prop="kyeCustomerTelephone"
                             class="reset-height">
                <kye-field v-model="form.kyeCustomerTelephone"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="kye操作"
                             prop="kyeOperator"
                             class="reset-height">
                <kye-field v-model="form.kyeOperator"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="操作电话"
                             prop="kyeOperatorPhone"
                             class="reset-height">
                <kye-field v-model="form.kyeOperatorPhone"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单人"
                             class="reset-height">
                <kye-field v-model="form.createdBy"
                           disabled></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单时间"
                             class="reset-height">
                <kye-field>{{form.creationDate|minute}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="修改人"
                             class="reset-height">
                <kye-field v-model="form.updatedBy"
                           disabled></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="修改时间"
                             class="reset-height">
                <kye-field>{{form.updationDate|minute}}</kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">下级点部信息</h3>
          <kye-tabs v-model="tapActive"
                    ref="pointTabs">
            <kye-tab-pane label="二级点部"
                          name="branch">
              <kye-edit-table :column="branchColumn"
                              status="edit"
                              :data="secondCoveringAreases"
                              :showIndex="true"
                              ref="branchTable"
                              class="mt10">
              </kye-edit-table>
            </kye-tab-pane>
            <kye-tab-pane label="三级点部"
                          name="branchSmall">
              <kye-edit-table :column="branchSmallColumn"
                              status="edit"
                              :data="thirdCoveringAreases"
                              :showIndex="true"
                              ref="branchSmallTable"
                              class="mt10">
              </kye-edit-table>

            </kye-tab-pane>
          </kye-tabs>
        </div>
      </kye-form>
    </kye-expand-page>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :quoteData="{small:form.partnerSmallPieceQuotation,big:form.partnerLargeQuotation}"
                 @save="getQuote"
                 @close="dialogOption.show = false">
      </component>
    </kye-dialog>
  </div>
</template>

<script>
  // 大小件展示
  import quoteTemplate from '@/ecms/components/partner/partner-backstage/quote-template'
  import mixins from 'public/mixins'

  export default {
    mixins: [mixins],
    data () {
      return {
        // loading
        isLoading: false,
        // 面包屑配置
        option: {
          back: '/tms/partner-backstage/main',
          method: 'partner.basic.search',
          searchCode: 'partner_basic_search'
        },
        tools: [
          {
            icon: 'reset',
            label: '刷新',
            auth: 'partner.basic.get',
            func: () => this.getDetailData()
          },
          {
            icon: 'plus',
            label: '新增',
            auth: 'partner.basic.save',
            func: () => this.$router.push(`/tms/partner-backstage/add`)
          },
          {
            icon: 'delete',
            auth: 'partner.basic.deletebatch',
            label: '删除',
            func: () => this.deletePartner(this.$route.params.id)
          },
          {
            icon: 'pen',
            label: '修改',
            auth: 'partner.basic.update',
            func: () => this.$router.push(`/tms/partner-backstage/modify/${this.$route.params.id}`)
          }
        ],
        // 弹窗配置
        dialogOption: {
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        // 弹窗数据
        dialogData: {},
        // tab当前选中name
        tapActive: 'branch',
        // 上传的文件
        licenseFiles: [],
        receiptFiles: [],
        otherFiles: [],
        uuid: '',
        secondCoveringAreases: [],
        thirdCoveringAreases: [],
        // 表单数据
        form: {
          secondLevelAddress: '',
          departmentShortName: '',
          province: '',
          regionCode: '',
          holiday: '',
          partnerCoveringAreases: [],
          partnerLargeQuotation: {
            dispatchNum1: 0.5,
            dispatchNum2: 0.3,
            dispatchNum3: 0.2,
            dispatchNum4: 0.1,
            firstWeight: 10,
            weight: 5
          },
          partnerSmallPieceQuotation: {
            dispatchNum1: 10,
            dispatchNum2: 8,
            dispatchNum3: 6,
            dispatchNum4: 5,
            weight: 5
          },
          partnerCertificateses: []
        },
        hasSmallQuete: false, // 是否有小件报价
        hasBigQuete: false, // 是否有大件报价
        // 二级点部列
        branchOption: {
          moduleCode: 'partner'
        },
        branchColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'text',
            width: '120px',
            show: true,
            moduleCode: 'partner',
            bizIdKey: 'pointName',
            fieldName: 'secondCoveringAreases.pointName'
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'text',
            width: '86px',
            show: true,
            moduleCode: 'partner',
            bizIdKey: 'pointLeader',
            fieldName: 'secondCoveringAreases.pointLeader'
          },
          {
            label: '点部账号',
            key: 'pointAccount',
            type: 'text',
            width: '108px',
            show: true,
            moduleCode: 'partner',
            bizIdKey: 'id',
            fieldName: 'secondCoveringAreases.pointAccount'
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'text',
            width: '56px',
            show: true,
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'text',
            width: '56px',
            show: true,
            dic: 'basic_data_whole',
            filter: {
              type: 'lookup',
              args: [
                'basic_data_whole'
              ]
            }
          },
          {
            label: '一级距离',
            key: 'secondLevelDistance',
            type: 'text',
            width: '64px',
            show: true
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'text',
            width: '140px',
            show: true,
            moduleCode: 'partner',
            bizIdKey: 'nodeAddress',
            fieldName: 'secondCoveringAreases.nodeAddress'
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            disabled: true,
            width: '120px',
            show: true
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            disabled: true,
            width: '120px',
            show: true
          },
        ],
        // 三级点部列
        branchSmallColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'text',
            width: '140px',
            moduleCode: 'partner',
            bizIdKey: 'pointName',
            fieldName: 'secondCoveringAreases.pointName'
          },
          {
            label: '所属二级',
            key: 'alongTo',
            type: 'text',
            width: '140px'
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'text',
            width: '86px',
            moduleCode: 'partner',
            bizIdKey: 'pointLeader',
            fieldName: 'secondCoveringAreases.pointLeader'
          },
          {
            label: '点部账号',
            key: 'pointAccount',
            type: 'text',
            width: '108px',
            moduleCode: 'partner',
            bizIdKey: 'id',
            fieldName: 'secondCoveringAreases.pointAccount'
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'text',
            width: '56px',
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'text',
            width: '56px',
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '二级距离',
            key: 'secondLevelDistance',
            type: 'text',
            width: '64px'
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'text',
            width: '140px'
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            disabled: true,
            width: '140px'
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            },
            disabled: true,
            width: '140px'
          }
        ]
      }
    },
    components: {
      quoteTemplate
    },
    methods: {
      // 获取详情
      async getDetailData (id = this.$route.params.id) {
        this.form = {}
        try {
          this.isLoading = true
          let res = await this.$http('partner.basic.get', { id })
          !res.data && this.$message({ type: 'error', message: '请求数据失败，请稍后再试' })
          this.form = res.data || {}
          this.form.latestHandoverTime = this.resetTime(this.form.latestHandoverTime)
          this.form.middleHandoverTime = this.resetTime(this.form.middleHandoverTime)
          if (this.form.partnerCoveringAreases) {
            this.secondCoveringAreases = []
            this.thirdCoveringAreases = []
            for (let item of this.form.partnerCoveringAreases) {
              item.middleHandoverTime = this.resetTime(item.middleHandoverTime)
              item.dawnHandoverTime = this.resetTime(item.dawnHandoverTime)
              if (item.pointLevel === '20') {
                this.secondCoveringAreases.push(item)
              } else if (item.pointLevel === '30') {
                this.thirdCoveringAreases.push(item)
              }
            }
          }
          this.hasSmallQuete = this.quoted(this.form.partnerSmallPieceQuotation)
          this.hasBigQuete = this.quoted(this.form.partnerLargeQuotation)
        } finally {
          this.isLoading = false
        }
      },
      // 判断是否有报价
      quoted (quote) {
        if (quote && quote.hasOwnProperty('weight')) {
          return true
        } else {
          return false
        }
      },
      // 时间格式化
      resetTime (t) {
        if (t && t.indexOf('-') > 0) {
          const time = new Date(t)
          return `${time.getHours()}:${time.getMinutes() < 1 ? '00' : time.getMinutes()}`
        } else if (t && !(t.split(':')[2])) {
          return `${t}:00`
        }
        return t
      },
      clearValidate () {
        this.$refs.form.clearValidate()
      },
      // 打开报价弹框
      openQuoteDialog (type) {
        if (type === '10') {
          this.dialogData.data = this.form.partnerLargeQuotation
          this.showDynamicDialog('bigQuote', '大件报价', '560px')
        } else {
          this.dialogData.data = this.form.partnerSmallPieceQuotation
          this.showDynamicDialog('smallQuote', '小件报价', '508px')
        }
      },
      // 修改报价
      getQuote (val) {
        this.form.partnerSmallPieceQuotation = val.small
        this.form.partnerLargeQuotation = val.big
      },
      // 取消返回上个页面
      handleCancel (formName) {
        this.$refs[formName].resetFields()
        this.form.partnerCoveringAreases = []
        this.$router.push('/tms/partner-backstage/main')
      },
      // 删除
      deletePartner () {
        this.$confirm('确定删除该记录？', '提示').then(() => {
          this.$http('partner.basic.deletebatch', {
            ids: [this.$route.params.id]
          }).then(res => {
            this.$message.success('删除成功')
            this.$refreshMainQueryTable()
            return this.$refs.searchPager.goNext()
          })
        }).catch(() => {
          return false
        })
      },
      // 初始滚动位置
      initScroll () {
        let top = this.$refs.pointTabs.$el.offsetTop
        window.scrollTo(0, top)
      },
      // 打开弹窗
      showDynamicDialog (view, title, width = '498px') {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
      },
      // 关闭弹窗
      closeDynamicDialog () {
        this.dialogOption = {
          width: '0px',
          title: '',
          show: false,
          view: ''
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (vm.$route.meta.layout) return
        vm.id = vm.$route.params.id
        if (from.params.activeTab) {
          if (from.params.activeTab === '二级点部') {
            vm.tapActive = 'branch'
            vm.initScroll()
          } else if (from.params.activeTab === '三级点部') {
            vm.tapActive = 'branchSmall'
            vm.initScroll()
          }
        }
        if (vm.id) {
          vm.getDetailData()
        }
      })
    },
    beforeRouteUpdate (to, from, next) {
      this.form.partnerCoveringAreases = []
      this.getDetailData(to.params.id)
      next()
    },

  }
</script>
<style lang="scss" scoped>
  .upload {
    .el-form-item__content {
      border: none !important;
    }
  }
  .kye-block-title {
    height: 28px;
    line-height: 28px;
    margin-bottom: 12px;
  }
</style>
<style>
  .reset-height {
    height: 28px !important;
    line-height: 28px !important;
  }
  .reset-height .el-form-item__content {
    max-height: 28px !important;
  }
</style>
