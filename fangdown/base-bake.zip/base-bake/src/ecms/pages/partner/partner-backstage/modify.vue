<template>
  <div>
    <search-pager :option="option"
                  :tools="formTools"></search-pager>
    <kye-expand-page v-loading="isLoading">
      <kye-form ref="form"
                :model.sync="form"
                module-code="partner"
                :biz-id="$route.params.id"
                label-width="72px">
        <div class="form-block">
          <h3 class="kye-block-title">基本信息</h3>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="公司全称"
                             class="reset-height"
                             prop="companyName">
                <kye-input v-model="form.companyName"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级点部"
                             prop="pointName"
                             class="reset-height"
                             :rules="{required:true,message:'一级点部不能为空'}">
                <kye-search-tips v-model="form.pointName"
                                 url="baseconfig.node.findByNodeNameAndFlag"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="networkFormat"
                                 @clear="clearNetwork"
                                 @select="selectNetwork">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="负责人"
                             prop="partnerLeader"
                             class="reset-height"
                             :rules="{required:true,message:'请填写负责人'}">
                <kye-input v-model="form.partnerLeader"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服对接"
                             prop="customer"
                             class="reset-height"
                             :rules="{required:true,message:'请填写客服对接人'}">
                <kye-input v-model="form.customer"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域区号"
                             prop="cityCode"
                             class="reset-height"
                             :rules="{required:true,message:'区域区号不能为空',trigger:'blur'}">
                <kye-input disabled
                           v-model="form.cityCode"></kye-input>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="8">
              <kye-form-item label="点部地址"
                             prop="secondLevelAddress"
                             class="reset-height"
                             :rules="{required:true,message:'请填写点部地址'}">
                <kye-input v-model="form.secondLevelAddress"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="部门"
                             prop="departmentShortName"
                             class="reset-height"
                             :rules="{required:true,message:'部门不能为空'}">
                <kye-input disabled
                           v-model="form.departmentShortName"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="区域省份"
                             prop="province"
                             class="reset-height"
                             :rules="{required:true,message:'请填写区域省份'}">
                <kye-input v-model="form.province"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="所属大区"
                             prop="regionCode"
                             class="reset-height"
                             :rules="{required:true,message:'所属大区不能为空'}">
                <kye-select disabled
                            v-model="form.regionCode"
                            placeholder="">
                  <kye-option v-for="item in lookUpOptions['common_region']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"></kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="保证金"
                             prop="bailMoney"
                             class="reset-height"
                             :rules="{required:true,message:'请填写保证金'}">
                <kye-number v-model="form.bailMoney"
                            symbol="￥"
                            :precision="2"></kye-number>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="系统账号"
                             prop="partnerSysAccount"
                             class="reset-height"
                             :rules="{required:true,pattern:/^1[3|4|5|6|7|8|9][0-9]\d{8}$/,message:'请填写正确手机号',trigger:'blur'}">
                <kye-input v-model="form.partnerSysAccount"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4"
                     style="text-align:right">
              <kye-button type="text"
                          :disabled="!/^1[3|4|5|6|7|8|9][0-9]\d{8}$/.test(form.partnerSysAccount)"
                          @click="resetAccoutPwd(form.partnerSysAccount)">重置密码</kye-button>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="签订日期"
                             class="reset-height">
                <kye-date-picker type="date"
                                 format="yyyy-MM-dd"
                                 value-format="yyyy-MM-dd"
                                 v-model="form.agreementBeginDate"></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="到期日期"
                             class="reset-height">
                <kye-date-picker type="date"
                                 v-model="form.agreementEndDate"
                                 format="yyyy-MM-dd"
                                 value-format="yyyy-MM-dd"></kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">报价信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">小件报价</span>
                <kye-input disabled
                           :value="hasSmallQuete?'有':'无'"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item class="reset-height">
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('quoteTemplate', '报价', '762px')">大件报价</span>
                <kye-input disabled
                           :value="hasBigQuete?'有':'无'"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="抛重系数"
                             prop="throwWeightIndex"
                             class="reset-height"
                             :rules="{required:true,message:'请填写抛重系数'}">
                <kye-number :precision="2"
                            v-model="form.throwWeightIndex"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="超时扣款"
                             prop="timeoutDeductions"
                             class="reset-height"
                             :rules="{required:true,message:'请填写超时扣款'}">
                <kye-number symbol="￥"
                            :precision="2"
                            v-model="form.timeoutDeductions"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="是否直飞"
                             prop="ifFlyDirect"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否直飞',trigger:'change'}">
                <kye-select v-model="form.ifFlyDirect">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">伙伴信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="走货否"
                             prop="transportGoods"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否走货',trigger:'change'}">
                <kye-select v-model="form.transportGoods"
                            @change="transportGoodsChange">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="走货时间"
                             class="reset-height">
                <kye-date-picker v-model="form.deliveryTime"
                                 type="datetime"
                                 format="yyyy-MM-dd HH:mm"></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一级距离"
                             prop="firstLevelDistance"
                             class="reset-height"
                             :rules="{required:true,message:'请填写一级距离'}">
                <kye-number unit="km"
                            v-model="form.firstLevelDistance"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="对接电话"
                             prop="takeOverTelephone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请填写对接电话',trigger:'blur'}">
                <kye-input v-model="form.takeOverTelephone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="一派耗时"
                             prop="trunkCostOne"
                             class="reset-height"
                             :rules="{required:true,message:'请填写一派耗时'}">
                <kye-number unit="h"
                            v-model="form.trunkCostOne"></kye-number>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="二派耗时"
                             class="reset-height"
                             prop="trunkCostTwo">
                <kye-number unit="h"
                            v-model="form.trunkCostTwo"></kye-number>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨交接"
                             prop="handoverMethod"
                             class="reset-height"
                             :rules="{required:true,message:'请选择凌晨交接方式',trigger:'change'}">
                <kye-select v-model="form.handoverMethod"
                            @change="selectedHandover">
                  <kye-option v-for="item in lookUpOptions['common_handover_method']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨网点"
                             prop="dawnNodeName"
                             class="reset-height"
                             :rules="{required:true,message:'请选择我司凌晨网点',trigger:'change'}">
                <!-- <kye-input v-model="form.dawnNodeName"></kye-input> -->
                <kye-search-tips v-model="form.dawnNodeName"
                                 url="baseconfig.node.searchByNodeName"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="nodeFormat"
                                 @clear="clearNode"
                                 @select="selectNode">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地晨"
                             prop="dawnHandoverPlace"
                             class="reset-height"
                             :rules="{required:true,message:'请填写凌晨交接地'}">
                <kye-input v-model="form.dawnHandoverPlace"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨最晚"
                             class="reset-height">
                <kye-time-picker v-model="form.latestHandoverTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择凌晨最晚交接时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="凌晨预达"
                             class="reset-height"
                             prop="dawnArriveEstimateTime"
                             :rules="{required:true,message:'请选择凌晨预达时间'}">
                <kye-time-picker v-model="form.dawnArriveEstimateTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择凌晨预达时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="中班交接"
                             class="reset-height"
                             prop="middleHandoverMethod">
                <kye-select v-model="form.middleHandoverMethod">
                  <kye-option v-for="item in lookUpOptions['common_handover_method']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班网点"
                             class="reset-height"
                             prop="middleNodeName">
                <!-- <kye-input v-model="form.middleNodeName"></kye-input> -->
                <kye-search-tips v-model="form.middleNodeName"
                                 url="baseconfig.node.searchByNodeName"
                                 value-key="nodeName"
                                 :keys="['nodeName']"
                                 :format-data="nodeFormat"
                                 @clear="clearMiddleNode"
                                 @select="selectMiddleNode">
                </kye-search-tips>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="交接地中"
                             class="reset-height"
                             prop="middleHandoverPlace">
                <kye-input v-model="form.middleHandoverPlace"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班最晚"
                             class="reset-height"
                             prop="middleHandoverTime">
                <kye-time-picker v-model="form.middleHandoverTime"
                                 type="datetime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择中班最晚交接时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班预达"
                             class="reset-height"
                             prop="middleArriveEstimateTime">
                <kye-time-picker v-model="form.middleArriveEstimateTime"
                                 format="HH:mm"
                                 value-format="HH:mm"
                                 placeholder="选择中班预达时间">
                </kye-time-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="凌晨类型"
                             prop="dawnNodeType"
                             class="reset-height">
                <kye-input disabled
                           :value="form.dawnNodeType|lookup('base_data_node_type')"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="中班类型"
                             class="reset-height"
                             prop="middleNodeType">
                <kye-input disabled
                           :value="form.middleNodeType|lookup('base_data_node_type')"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="伙伴自提"
                             prop="airport"
                             class="reset-height"
                             :rules="{required:true,message:'请选择是否伙伴自提',trigger:'change'}">
                <kye-select v-model="form.airport">
                  <kye-option v-for="item in lookUpOptions['common_yes_no']"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value">
                  </kye-option>
                </kye-select>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="提货人"
                             prop="consignee"
                             class="reset-height"
                             :rules="{required:true,message:'请输入提货人'}">
                <kye-input v-model="form.consignee"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="8">
              <kye-form-item label="放假时间"
                             class="reset-height"
                             prop="holiday">
                <kye-date-picker type="daterange"
                                 v-model="holiday">
                </kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">其它信息</h3>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="kye客服"
                             prop="kyeCustomer"
                             class="reset-height"
                             :rules="{required:true,message:'请输入kye客服'}">
                <kye-input v-model="form.kyeCustomer"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="客服电话"
                             prop="kyeCustomerTelephone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请正确填写客服电话',trigger:'blur'}">
                <kye-input v-model="form.kyeCustomerTelephone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="kye操作"
                             prop="kyeOperator"
                             class="reset-height"
                             :rules="{required:true,message:'请填写kye操作人员'}">
                <kye-input v-model="form.kyeOperator"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="操作电话"
                             prop="kyeOperatorPhone"
                             class="reset-height"
                             :rules="{required:true,pattern:/(^1[3|4|5|6|7|8|9][0-9]\d{8}$)|(^(\d{3,4}-\d{3,8})+(-\d{1,4})?$)/,message:'请正确填写操作人员电话',trigger:'blur'}">
                <kye-input v-model="form.kyeOperatorPhone"></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单人"
                             class="reset-height">
                <kye-input v-model="form.createdBy"
                           disabled></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="录单时间"
                             class="reset-height">
                <kye-date-picker format="yyyy-MM-dd HH:mm"
                                 v-model="form.creationDate"
                                 disabled></kye-date-picker>
              </kye-form-item>
            </kye-col>
          </kye-row>
          <kye-row>
            <kye-col :span="4">
              <kye-form-item label="修改人"
                             class="reset-height">
                <kye-input v-model="form.updatedBy"
                           disabled></kye-input>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item label="修改时间"
                             class="reset-height">
                <kye-date-picker format="yyyy-MM-dd HH:mm"
                                 v-model="form.updationDate"
                                 disabled></kye-date-picker>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传营业执照','430px',licenseFiles,'10')">营业执照</span>
                <kye-field style="background-color:#ECECF5"
                           :value="licenseFiles.length===1?licenseFiles[0].name:`${licenseFiles.length}个附件`"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传保证金凭条','430px',receiptFiles,'20')">保证金凭条</span>
                <kye-field style="background-color:#ECECF5"
                           :value="receiptFiles.length===1?receiptFiles[0].name:`${receiptFiles.length}个附件`"></kye-field>
              </kye-form-item>
            </kye-col>
            <kye-col :span="4">
              <kye-form-item>
                <span slot="label"
                      class="kye-label-click"
                      @click="showDynamicDialog('uploadTemplate','上传其它文件','430px',otherFiles,'30')">其它文件</span>
                <kye-field style="background-color:#ECECF5"
                           :value="otherFiles.length===1?otherFiles[0].name:`${otherFiles.length}个附件`"></kye-field>
              </kye-form-item>
            </kye-col>
          </kye-row>
        </div>
        <div class="form-block">
          <h3 class="kye-block-title">下级点部信息</h3>
          <div style="position:relative">
            <kye-tabs v-model="tapActive">
              <kye-tab-pane label="二级点部"
                            name="branch">
                <kye-edit-table :column="branchColumn"
                                status="edit"
                                :data="secondCoveringAreases"
                                :showIndex="true"
                                ref="branchTable"
                                class="mt10">
                  <template slot="handle">
                    <kye-table-column label="操作"
                                      width="98px"
                                      fixed="left">
                      <template slot-scope="scope">
                        <kye-button @click="deleteRow('branchTable', scope.$index)"
                                    type="text"
                                    size="small">删除</kye-button>
                        <kye-button type="text"
                                    size="small"
                                    :disabled="!scope.row.pointAccount||(scope.row.pointAccount.trim()).length!==11"
                                    @click="resetAccoutPwd(scope.row.pointAccount)">重置密码</kye-button>
                      </template>
                    </kye-table-column>
                  </template>
                </kye-edit-table>
              </kye-tab-pane>
              <kye-tab-pane label="三级点部"
                            name="branchSmall">
                <kye-edit-table :column="branchSmallColumn"
                                status="edit"
                                :data="thirdCoveringAreases"
                                :showIndex="true"
                                ref="branchSmallTable"
                                class="mt10">
                  <template slot="handle">
                    <kye-table-column label="操作"
                                      width="96px"
                                      fixed="left">
                      <template slot-scope="scope">
                        <div>
                          <kye-button @click="deleteRow('branchSmallTable', scope.$index)"
                                      type="text"
                                      size="small">删除</kye-button>
                          <kye-button type="text"
                                      size="small"
                                      :disabled="!scope.row.pointAccount||(scope.row.pointAccount.trim()).length!==11"
                                      @click="resetAccoutPwd(scope.row.pointAccount)">重置密码</kye-button>
                        </div>
                      </template>
                    </kye-table-column>
                  </template>
                </kye-edit-table>
              </kye-tab-pane>
            </kye-tabs>
            <kye-row style="text-align:right;margin:4px 0">
              <kye-button v-show="tapActive=='branch'"
                          type="text"
                          icon="iconfont icon-plus"
                          style="position:absolute;top:-4px;right:6px;z-index:1000"
                          @click="addRow('branchTable')">新增</kye-button>
              <kye-button v-show="tapActive=='branchSmall'"
                          type="text"
                          icon="iconfont icon-plus"
                          style="position:absolute;top:-4px;right:6px;z-index:1000"
                          @click="addRow('branchSmallTable')">新增</kye-button>
            </kye-row>
          </div>
        </div>
      </kye-form>
    </kye-expand-page>
    <kye-dialog v-bind="dialogOption"
                v-if="dialogOption.show"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :quoteData="{small:form.partnerSmallPieceQuotation,big:form.partnerLargeQuotation}"
                 :files="fileList"
                 :id="$route.params.id"
                 :type="type"
                 @save="getQuote"
                 @change="getFiles"
                 @close="dialogOption.show=false">
      </component>
    </kye-dialog>
  </div>
</template>

<script>
  // 大小件报价
  import quoteTemplate from '@/ecms/components/partner/partner-backstage/quote-template'
  // 附件上传
  import uploadTemplate from '@/ecms/components/partner/partner-backstage/upload-template'
  import mixins from 'public/mixins'
  // 取消前钩子
  import routeHook from 'public/mixins/route-hook'
  // 时间格式化
  import { time } from 'public/utils'
  export default {
    mixins: [mixins, routeHook],
    data () {
      return {
        isLoading: false,
        fileList: [],
        type: '',
        billId: '',
        holiday: [], // 放假范围
        // 面包屑配置
        option: {
          back: '/tms/partner-backstage/main'
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            func: () => this.getEditData()
          },
          {
            label: '保存',
            icon: 'save1',
            auth: 'partner.basic.update',
            func: () => this.submit('form')
          },
          {
            label: '取消',
            icon: 'cancel1',
            func: () => this.handleCancel()
          }
        ],
        // 弹窗配置
        dialogOption: {
          width: '1200px',
          title: '',
          show: false,
          view: ''
        },
        // 弹窗数据
        dialogData: {},
        changeBig: false,
        changeSmall: false,
        // tab当前选中name
        tapActive: 'branch',
        // 上传的文件
        licenseFiles: [],
        receiptFiles: [],
        otherFiles: [],
        uuid: '',
        willBeDelFile: {},
        secondCoveringAreases: [],
        thirdCoveringAreases: [],
        // copyPartnerCertificates: [],
        deleteIds: [],
        // 备份账号
        copyAcount: undefined,
        // 表单数据
        form: {
          agreementBeginDate: '',
          agreementEndDate: '',
          secondLevelAddress: '',
          departmentShortName: '',
          province: '',
          regionCode: '',
          holiday: '',
          dawnNodeType: '',
          middleNodeType: '',
          partnerCoveringAreases: [],
          partnerLargeQuotation: {
            dispatchNum1: 0.5,
            dispatchNum2: 0.3,
            dispatchNum3: 0.2,
            dispatchNum4: 0.1,
            firstWeight: 10,
            weight: 5
          },
          partnerSmallPieceQuotation: {
            dispatchNum1: 10,
            dispatchNum2: 8,
            dispatchNum3: 6,
            dispatchNum4: 5,
            weight: 5
          },
          partnerCertificates: []
        },
        hasSmallQuete: false, // 是否有小件报价
        hasBigQuete: false, // 是否有大件报价
        // 二级点部列
        branchColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'select',
            width: '126px',
            remote: true,
            remotefn: this.remotePointLeaderData,
            change: this.branchPointChange,
            moduleCode: 'partner',
            bizIdKey: 'pointName',
            fieldName: 'secondCoveringAreases.pointName',
            rule: {
              required: true,
              message: '请填写点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'input',
            width: '86px',
            moduleCode: 'partner',
            bizIdKey: 'pointLeader',
            fieldName: 'secondCoveringAreases.pointLeader',
            rule: {
              required: true,
              message: '请填写点部负责人',
              trigger: 'blur'
            }
          },
          {
            label: '点部账号',
            key: 'pointAccount',
            type: 'input',
            width: '108px',
            moduleCode: 'partner',
            bizIdKey: 'id',
            fieldName: 'secondCoveringAreases.pointAccount',
            rule: [
              {
                required: true,
                message: '请填写点部账号',
                trigger: 'blur'
              },
              {
                pattern: /^(1[3|4|5|6|7|8|9][0-9]\d{8})|(\*{2})$/,
                message: '请输入正确的手机号',
                trigger: 'blur'
              }
            ]
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'select',
            width: '68px',
            rule: {
              required: true,
              message: '请选择是否走货',
              trigger: 'change'
            },
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'select',
            width: '68px',
            rule: {
              required: true,
              message: '请选择是否全境',
              trigger: 'change'
            },
            dic: 'basic_data_whole',
            filter: {
              type: 'lookup',
              args: [
                'basic_data_whole'
              ]
            }
          },
          {
            label: '一级距离',
            key: 'secondLevelDistance',
            type: 'input-number',
            width: '78px',
            rule: {
              required: true,
              message: '请填写一级距离',
              trigger: 'blur'
            }
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'input',
            width: '140px',
            moduleCode: 'partner',
            bizIdKey: 'nodeAddress',
            fieldName: 'secondCoveringAreases.nodeAddress',
            rule: {
              required: true,
              message: '请填写点部地址',
              trigger: 'blur'
            }
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            width: '140px',
            option: {
              format: 'HH:mm'
            }
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            width: '140px',
            option: {
              format: 'HH:mm'
            }
          },
        ],
        // 三级点部列
        branchSmallColumn: [
          {
            label: '点部名称',
            key: 'pointName',
            type: 'select',
            // width: '140px',
            remote: true,
            remotefn: this.remotePointLeaderData,
            change: this.branchSmallPointChange,
            moduleCode: 'partner',
            bizIdKey: 'pointName',
            fieldName: 'secondCoveringAreases.pointName',
            rule: {
              required: true,
              message: '请填写点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '所属二级',
            key: 'alongTo',
            type: 'select',
            // width: '140px',
            remote: true,
            remotefn: this.parentNodeSearch,
            // customData: this.parentNodeSearch,
            change: (index, row, data) => {
              row.nodeParentId = data.nodeId
            },
            moduleCode: 'partner',
            bizIdKey: 'alongTo',
            fieldName: 'secondCoveringAreases.alongTo',
            rule: {
              required: true,
              message: '请选择点部名称',
              trigger: 'blur'
            }
          },
          {
            label: '点部负责人',
            key: 'pointLeader',
            type: 'input',
            width: '86px',
            moduleCode: 'partner',
            bizIdKey: 'pointLeader',
            fieldName: 'secondCoveringAreases.pointLeader',
            rule: {
              required: true,
              message: '请填写点部负责人',
              trigger: 'blur'
            }
          }, {
            label: '点部账号',
            key: 'pointAccount',
            type: 'input',
            width: '108px',
            moduleCode: 'partner',
            bizIdKey: 'id',
            fieldName: 'secondCoveringAreases.pointAccount',
            rule: [
              {
                required: true,
                message: '请填写点部账号',
                trigger: 'blur'
              },
              {
                pattern: /^(1[3|4|5|6|7|8|9][0-9]\d{8})|(\*{2})$/,
                message: '请输入正确的手机号',
                trigger: 'blur'
              }
            ]
          },
          {
            label: '走货否',
            key: 'transportGoods',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否走货',
              trigger: 'change'
            },
            dic: 'common_yes_no',
            filter: {
              type: 'lookup',
              args: [
                'common_yes_no'
              ]
            }
          },
          {
            label: '全境否',
            key: 'whole',
            type: 'select',
            width: '72px',
            rule: {
              required: true,
              message: '请选择是否全境',
              trigger: 'change'
            },
            dic: 'basic_data_whole',
            filter: {
              type: 'lookup',
              args: [
                'basic_data_whole'
              ]
            }
          },
          {
            label: '二级距离',
            key: 'secondLevelDistance',
            type: 'input-number',
            width: '68px',
            rule: {
              required: true,
              message: '请填写二级距离',
              trigger: 'blur'
            }
          },
          {
            label: '点部地址',
            key: 'nodeAddress',
            type: 'input',
            moduleCode: 'partner',
            bizIdKey: 'nodeAddress',
            fieldName: 'secondCoveringAreases.nodeAddress',
            // width: '140px',
            rule:
              {
                required: true,
                message: '请填写点部地址',
                trigger: 'blur'
              }
          },
          {
            label: '凌晨最晚',
            key: 'dawnHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            }
            // width: '108px'
          },
          {
            label: '中班最晚',
            key: 'middleHandoverTime',
            type: 'time-picker',
            option: {
              format: 'HH:mm'
            }
            // width: '108px'
          }
        ]
      }
    },
    components: {
      quoteTemplate,
      uploadTemplate
    },
    methods: {
      // 选择凌晨交接方式执行
      selectedHandover (val) {
        val === '20' && this.form.secondLevelAddress && (this.form.dawnHandoverPlace = this.form.secondLevelAddress)
      },
      // 如果为编辑则需要获取数据
      async getEditData (id = this.$route.params.id) {
        this.form = {}
        try {
          this.isLoading = true
          let res = await this.$http('partner.basic.edit', { id })
          this.form = res.data || {}
          this.holiday = [this.form.holidayBegin, this.form.holidayEnd]
          this.copyAcount = this.form.partnerSysAccount
          this.secondCoveringAreases = []
          this.thirdCoveringAreases = []
          this.form.latestHandoverTime = this.resetTime(this.form.latestHandoverTime)
          this.form.middleHandoverTime = this.resetTime(this.form.middleHandoverTime)
          if (this.form.partnerCoveringAreases) {
            for (let item of this.form.partnerCoveringAreases) {
              item.middleHandoverTime = this.resetTime(item.middleHandoverTime)
              item.dawnHandoverTime = this.resetTime(item.dawnHandoverTime)
              if (item.pointLevel === '20') {
                this.secondCoveringAreases.push(item)
              } else if (item.pointLevel === '30') {
                this.thirdCoveringAreases.push(item)
              }
            }
          }
          this.hasSmallQuete = this.quoted(this.form.partnerSmallPieceQuotation)
          this.hasBigQuete = this.quoted(this.form.partnerLargeQuotation)
          this.licenseFiles = []
          this.otherFiles = []
          this.receiptFiles = []
          if (this.form.partnerCertificates.length) {
            const bizCode = 'partner_basic_license'
            const license = this.form.partnerCertificates.filter(v => v.type === '10').map(v => v.fileId)
            const receipt = this.form.partnerCertificates.filter(v => v.type === '20').map(v => v.fileId)
            const other = this.form.partnerCertificates.filter(v => v.type === '30').map(v => v.fileId)
            license.length && (await this.$http('file.getByBizCodeAndBizIds', { bizCode, bizIds: license }))
              .forEach(item => {
                this.licenseFiles.push(...item.files)
              })
            receipt.length && (await this.$http('file.getByBizCodeAndBizIds', { bizCode, bizIds: receipt }))
              .forEach(item => {
                this.receiptFiles.push(...item.files)
              })
            other.length && (await this.$http('file.getByBizCodeAndBizIds', { bizCode, bizIds: other }))
              .forEach(item => {
                this.otherFiles.push(...item.files)
              })
          }
        } finally {
          this.isLoading = false
        }
      },
      // 判断是否有报价
      quoted (quote) {
        if (quote && quote.hasOwnProperty('weight')) {
          return true
        } else {
          return false
        }
      },
      // 重置时间
      resetTime (t) {
        if (t && t.indexOf('-') > 0) {
          const time = new Date(t)
          return `${time.getHours()}:${time.getMinutes() < 1 ? '00' : time.getMinutes()}`
        } else if (t && !(t.split(':')[2])) {
          return `${t}:00`
        }
        return t
      },
      // 获取组件中的文件
      getFiles (files, type) {
        switch (type) {
          case '10':
            this.licenseFiles = files
            break
          case '20':
            this.receiptFiles = files
            break
          case '30':
            this.otherFiles = files
            break
        }
      },
      // 删除文件之前
      beforeDeleteF (file, files) {
        this.willBeDelFile = file
        return this.$confirm('文件将永久删除，是否继续?', '温馨提示', { type: 'warning' })
      },
      async deleteFiles () {
        let arr = this.form.partnerCertificates.filter(val => val.fileId === this.willBeDelFile.id)
        arr.length && await this.$http('partner.partnerCertificates.delete', { id: arr[0].id })
      },
      clearValidate () {
        this.$refs.form.clearValidate()
      },
      // 打开报价弹框
      openQuoteDialog (type) {
        if (type === '10') {
          this.dialogData.data = this.form.partnerLargeQuotation
          this.showDynamicDialog('bigQuote', '大件报价', '670px')
        } else {
          this.dialogData.data = this.form.partnerSmallPieceQuotation
          this.showDynamicDialog('smallQuote', '小件报价', '626px')
        }
      },
      // 修改报价
      getQuote (val) {
        this.form.partnerSmallPieceQuotation = val.small
        this.form.partnerLargeQuotation = val.big
        this.hasSmallQuete = this.quoted(this.form.partnerSmallPieceQuotation)
        this.hasBigQuete = this.quoted(this.form.partnerLargeQuotation)
      },
      // 选择走货否，自动带出走货时间
      transportGoodsChange () {
        if (this.form.transportGoods === '10') {
          this.form.deliveryTime = time(new Date())
        } else {
          this.form.deliveryTime = ''
        }
      },
      // 凌晨我司网点请求格式
      nodeFormat (val) {
        return {
          name: val
        }
      },
      // 选中凌晨我司网点
      async selectNode (val) {
        if (val) {
          this.form.dawnNodeName = val.nodeName
          this.form.dawnNodeId = val.id
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.dawnNodeType = res.nodeType
          this.form.handoverMethod === '10' && (this.form.dawnHandoverPlace = res.addressDetail)
        }
      },
      // 清除凌晨我司网点
      clearNode () {
        this.form.dawnNodeName = ''
        this.form.dawnNodeId = ''
        this.form.dawnNodeType = ''
      },
      // 选中中班我司网点
      async selectMiddleNode (val) {
        if (val) {
          this.form.middleNodeName = val.nodeName
          this.form.middleNodeId = val.id
          // this.form.middleNodeType = val.nodeType
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.middleNodeType = res.nodeType
        }
      },
      // 清除中班我司网点
      clearMiddleNode () {
        this.form.middleNodeName = ''
        this.form.middleNodeId = ''
        this.form.middleNodeType = ''
      },
      submit (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            if (!this.hasSmallQuete) {
              return this.$message.error('小件报价不能为空')
            }
            if (!this.hasBigQuete) {
              return this.$message.error('大件报价不能为空')
            }
            const validate1 = await this.$refs.branchTable.validate()
            const validate2 = await this.$refs.branchSmallTable.validate()
            validate1 && validate2 && this.savePartner()
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 保存
      async savePartner () {
        try {
          this.isLoading = true
          let postData = {
            partner: {
              id: this.$route.params.id,
              agreementBeginDate: this.form.agreementBeginDate,
              agreementEndDate: this.form.agreementEndDate,
              departmentShortName: this.form.departmentShortName,
              departmentId: this.form.departmentId,
              partnerLeader: this.form.partnerLeader,
              partnerSysAccount: this.form.partnerSysAccount,
              partnerSysPsw: this.form.partnerSysPsw,
              telephone: this.form.telephone,
              secondLevelAddress: this.form.secondLevelAddress,
              cityCode: this.form.cityCode,
              regionCode: this.form.regionCode,
              bailMoney: +this.form.bailMoney,
              firstLevelDistance: this.form.firstLevelDistance,
              customer: this.form.customer,
              handoverMethod: this.form.handoverMethod,
              latestHandoverTime: this.form.latestHandoverTime,
              dawnHandoverPlace: this.form.dawnHandoverPlace,
              takeOverTelephone: this.form.takeOverTelephone,
              middleHandoverMethod: this.form.middleHandoverMethod,
              middleHandoverTime: this.form.middleHandoverTime,
              middleHandoverPlace: this.form.middleHandoverPlace,
              kyeCustomer: this.form.kyeCustomer,
              kyeCustomerTelephone: this.form.kyeCustomerTelephone,
              timeoutDeductions: +this.form.timeoutDeductions,
              airport: this.form.airport,
              consignee: this.form.consignee,
              deliveryTime: this.form.deliveryTime,
              transportGoods: this.form.transportGoods,
              provinceId: this.form.provinceId,
              companyName: this.form.companyName,
              throwWeightIndex: +this.form.throwWeightIndex,
              ifFlyDirect: this.form.ifFlyDirect,
              trunkCostOne: this.form.trunkCostOne,
              trunkCostTwo: this.form.trunkCostTwo,
              kyeOperator: this.form.kyeOperator,
              kyeOperatorPhone: this.form.kyeOperatorPhone,
              dawnArriveEstimateTime: this.form.dawnArriveEstimateTime,
              middleArriveEstimateTime: this.form.middleArriveEstimateTime,
              dawnNodeId: this.form.dawnNodeId,
              dawnNodeName: this.form.dawnNodeName,
              dawnNodeType: this.form.dawnNodeType,
              middleNodeId: this.form.middleNodeId,
              middleNodeName: this.form.middleNodeName,
              middleNodeType: this.form.middleNodeType,
              pointName: this.form.pointName,
              nodeId: this.form.nodeId,
              province: this.form.province
            },
            partnerCoveringAreases: {
              addList: [],
              updateList: [],
              ids: this.deleteIds
            },
            partnerCertificates: {
              addList: [],
              ids: []
            }
          }
          Object.keys(postData.partner).forEach(v => {
            if (`${v}Mask` in this.form) {
              postData.partner[`${v}Mask`] = this.form[`${v}Mask`]
            }
          })
          postData.partner = this.$diff(postData.partner)
          if (this.form.holiday) {
            postData.partner.holidayBegin = this.form.holiday[0]
            postData.partner.holidayEnd = this.form.holiday[1]
          }
          // 大小件报价
          postData.partnerLargeQuotation = {
            weight: this.form.partnerLargeQuotation.weight,
            firstWeight: this.form.partnerLargeQuotation.firstWeight,
            dispatchNum1: this.form.partnerLargeQuotation.dispatchNum1,
            dispatchNum2: this.form.partnerLargeQuotation.dispatchNum2,
            dispatchNum3: this.form.partnerLargeQuotation.dispatchNum3,
            dispatchNum4: this.form.partnerLargeQuotation.dispatchNum4
          }
          postData.partnerSmallPieceQuotation = {
            weight: this.form.partnerSmallPieceQuotation.weight,
            dispatchNum1: this.form.partnerSmallPieceQuotation.dispatchNum1,
            dispatchNum2: this.form.partnerSmallPieceQuotation.dispatchNum2,
            dispatchNum3: this.form.partnerSmallPieceQuotation.dispatchNum3,
            dispatchNum4: this.form.partnerSmallPieceQuotation.dispatchNum4
          }
          // 添加营业执照
          const licenseFiles = this.form.partnerCertificates.filter(val => val.type === '10')
          const receiptFiles = this.form.partnerCertificates.filter(val => val.type === '20')
          const otherFiles = this.form.partnerCertificates.filter(val => val.type === '30')
          this.licenseFiles.forEach(item => {
            const isInclude = licenseFiles.some(val => val.name === item.fileName)
            if (!isInclude) {
              postData.partnerCertificates.addList.push({
                type: '10',
                fileId: item.bizId, // 传bizId
                fileName: item.name,
                partnerId: this.$route.params.id
              })
            }
          })
          // 添加保证金凭条
          this.receiptFiles.forEach(item => {
            const isInclude = receiptFiles.some(val => val.name === item.fileName)
            if (!isInclude) {
              postData.partnerCertificates.addList.push({
                type: '20',
                fileId: item.bizId,
                fileName: item.name,
                partnerId: this.$route.params.id
              })
            }
          })
          // 添加其他
          this.otherFiles.forEach(item => {
            const isInclude = otherFiles.some(val => val.name === item.fileName)
            if (!isInclude) {
              postData.partnerCertificates.addList.push({
                type: '30',
                fileId: item.bizId,
                fileName: item.name,
                partnerId: this.$route.params.id
              })
            }
          })
          // 点部信息分类
          let second = this.$diff(this.$refs.branchTable.getData())
          let third = this.$diff(this.$refs.branchSmallTable.getData())
          let areas = [...second, ...third]
          for (let item of areas) {
            if (item.id) {
              postData.partnerCoveringAreases.updateList.push(item)
            } else {
              postData.partnerCoveringAreases.addList.push(item)
            }
          }
          let res = await this.$http('partner.basic.update', this.$diff(postData))
          this.isLoading = false
          if (res.code === 0) {
            this.SET_SAVE_HOOK_FLAG()
            this.deleteIds = []
            this.$message.success('修改成功！')
            this.$refreshMainQueryTable()
            this.$router.push(`/tms/partner-backstage/detail/${this.$route.params.id}`)
          } else {
            this.$message.error(res.msg || '')
          }
        } finally {
          this.isLoading = false
        }
      },
      // 取消修改并返回详情页面
      handleCancel () {
        this.$router.push(`/tms/partner-backstage/detail/${this.$route.params.id}`)
      },
      // 表格删除行
      deleteRow (ref, index) {
        let tData = this.$refs[ref].getData()
        const nodeId = tData[index].nodeId
        let smallTableData = []
        let isBelong = false
        if (ref === 'branchTable') {
          smallTableData = this.$refs.branchSmallTable.getData()
          isBelong = smallTableData.some(val => val.nodeParentId === nodeId)
        }
        if (isBelong) {
          return this.$confirm('该点部关联的三级点部将被一同删除，是否继续', '温馨提示', { type: 'warning' })
            .then(() => {
              smallTableData.forEach((v, i) => {
                if (v.nodeParentId === nodeId) {
                  v.id && this.deleteIds.push(v.id)
                }
              })
              tData[index].id && this.deleteIds.push(tData[index].id)
              this.$refs[ref].delRow(index)
              this.thirdCoveringAreases = smallTableData.filter(v => v.nodeParentId !== nodeId)
            })
        }
        tData[index].id && this.deleteIds.push(tData[index].id)
        this.$refs[ref].delRow(index)
      },
      // 表格添加行
      addRow (ref) {
        const obj = {
          alongTo: '',
          pointName: '',
          pointLeader: '',
          nodeId: '',
          nodeAddress: '',
          whole: '',
          dawnTime: '',
          middleCountyTime: '',
          middleTownTime: '',
          coverVillage: '',
          contactTelephone: '',
          secondLevelDistance: '',
          middleTime: '',
          dawnHandoverTime: '',
          middleHandoverTime: '',
          pointLeaderContact: '',
          pointLevel: '',
          pointParentId: '',
          pointAccount: '',
          pointAccountPsw: '',
          transportGoods: '',
          nodeParentId: '',
          _type: 'edit'
        }
        if (ref === 'branchTable') {
          obj.pointLevel = '20'
          obj.nodeParentId = this.form.nodeId
        } else if (ref === 'branchSmallTable') {
          obj.pointLevel = '30'
        }
        this.$refs[ref].addRow(obj)
      },
      // 网点查询参数
      networkFormat (val) {
        return {
          nodeName: val
        }
      },
      // 选中网点
      async selectNetwork (val) {
        if (val) {
          this.form.pointName = val.nodeName
          this.form.nodeId = val.id
          let res = await this.$http('baseconfig.node.get', { id: val.id })
          this.form.secondLevelAddress = `${res.province}${res.city}${res.county}${res.addressDetail}`
          this.form.departmentShortName = res.departmentName
          this.form.departmentId = res.departmentId
          this.form.province = res.province
          this.form.provinceId = res.provinceId
          this.form.regionCode = res.regionCode
          this.form.cityCode = res.departmentCode
        }
      },
      // 清除网点
      clearNetwork () {
        this.form.pointName = ''
        this.form.nodeId = ''
        this.form.secondLevelAddress = ''
        this.form.departmentShortName = ''
        this.form.departmentId = ''
        this.form.province = ''
        this.form.provinceId = ''
        this.form.regionCode = ''
      },
      // 远程获取网点点部
      async remotePointLeaderData (query) {
        let res = await this.$http('baseconfig.node.findByNodeNameAndFlag', {
          nodeName: query
        })
        return {
          list: res,
          label: 'nodeName',
          value: 'id'
        }
      },
      // 二级点部名称变化
      branchPointChange (index, row, selectData) {
        let tData = this.$refs.branchTable.getData()
        tData[index].nodeAddress = `${selectData.province}${selectData.city}${selectData.county}${selectData.addressDetail}`
        tData[index].nodeId = selectData.id
      },
      // 三级点部名称变化
      branchSmallPointChange (index, row, selectData) {
        let tData = this.$refs.branchSmallTable.getData()
        tData[index].nodeAddress = `${selectData.province}${selectData.city}${selectData.county}${selectData.addressDetail}`
        tData[index].nodeId = selectData.id
      },
      // 所属二级
      parentNodeSearch (query) {
        if (query) {
          let parentList = this.$refs.branchTable.getData()
          let res = parentList.filter(item => item.pointName.indexOf(query) >= 0)
          return {
            list: res,
            label: 'pointName',
            value: 'nodeId'
          }
        }
      },
      // 重置账号密码
      async resetAccoutPwd (mobile) {
        if (/^\*{4,}$/.test(mobile)) return this.$message({ type: 'error', message: '请先解密账号' })
        let app_id = 'KR9OFQAqAB-GgDrfcZ1Qcg=='
        await this.$http('cas.casual.userPasswordReset', { mobile, app_id })
        this.$message.success('密码重置成功')
        // this.copyAcount = this.form.partnerSysAccount
      },
      // 打开弹窗
      showDynamicDialog (view, title, width = '1200px', fileList, type) {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
        this.fileList = fileList
        this.type = type
      },
      // 关闭弹窗
      closeDynamicDialog () {
        this.dialogOption = {
          width: '0px',
          title: '',
          show: false,
          view: ''
        }
      }
    },
    beforeRouteEnter (to, from, next) {
      const isLoad = (from.name === 'tms-partner-backstage-main') || (from.name === 'tms-partner-backstage-detail')
      next(vm => {
        if (vm.$route.meta.layout) return
        // let hasId = to.params.hasOwnProperty('id') && to.params.id !== vm.billId
        if (isLoad) {
          vm.billId = to.params.id
          vm.id = vm.$route.params.id
          if (vm.id) vm.getEditData()
        }
      })
    },
  }
</script>
<style lang="scss" scoped>
  .kye-block-title {
    height: 28px;
    line-height: 28px;
    margin-bottom: 12px;
    .el-form-item.is-required {
      .el-form-item__label {
        height: 28px !important;
        line-height: 28px !important;
      }
    }
  }
</style>
<style>
  .reset-height {
    height: 28px !important;
    line-height: 28px !important;
  }
  .reset-height .el-form-item__content {
    max-height: 28px !important;
  }
</style>

