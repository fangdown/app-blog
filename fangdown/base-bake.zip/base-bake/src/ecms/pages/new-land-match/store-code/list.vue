<template>
  <div class="store-code">
    <query-table ref="queryTable"
                 :generic="generic"
                 :form-model="formModel"
                 :form-tools="formTools"
                 :option="option"
                 :tables="tables">
      <div slot="desc">
        <div class="push-operation">
          <kye-button type="text"
                      @click="checkOpen"
                      :disabled="disabled"
                      auth="ldp.ThirdDelivery.V1.Delivery.CityShopAudit"
                      icon="iconfont icon-ecs-shenhe">审核</kye-button>
        </div>
      </div>
    </query-table>
    <!-- 新增start -->
    <kye-dialog v-bind="dialogOption"
                :visible.sync="dialogOption.show"
                v-if="dialogOption.show"
                :title="dialogOption.title"
                append-to-body>
      <component :is="dialogOption.view"
                 :sendModifyObj="sendModifyObj"
                 @close="closeDynamicDialog"
                 @refreshTable="refreshTable"
                 @cancelClose="close">
      </component>
    </kye-dialog>
  </div>
</template>
<script>
  // 新增
  import addInput from './detail/add-input'
  // 修改
  import modifyInput from './detail/modify-input'
  import URL from '../api'
  export default {
    components: {
      addInput,
      modifyInput
    },
    data () {
      return {
        disabled: true, // 是否展示审核
        id: '', // 编码id
        message: '',
        importShow: false,
        importParam: {
        },
        tableData: [], // 表格数据
        sendModifyArr: [], // 修改数据
        sendModifyObj: {}, // 传给修改页的数据
        dialogOption: {
          title: '',
          width: '500px',
          show: false,
          view: ''
        },
        options: {
          back: ''
        },
        formModel: {
        },
        generic: {
          method: URL.cityShopSearch,
          searchCode: 'cod_store_code_search'
        },
        option: {
          auth: false, // 是否开启查询按钮的权限，默认为 true
          searchCode: 'cod_store_code_search_define',
          // 所属点部
          receiverDept: {
            change: ({ key, value, model }) => { },
            labelKey: 'nodeName',
            valueKey: 'nodeName',
            remoteMethod: (val) => this.$http(URL.findByNodeNameAndFlag, { nodeName: val })
          },
          // 门店名称
          name: {
            labelKey: 'name',
            valueKey: 'name',
            remoteMethod: (val) => this.$http(URL.searchShopByName, { name: val }).then(data => data)
          }
        },
        formTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: URL.cityShopSearch,
            disabled: false,
            func: () => {
              let tableData = this.$refs.queryTable.getTableData() || []
              if (tableData.length <= 0) {
                this.$message.warning('无数据！')
                return false
              }
              this.refreshTable()
            }
          },
          {
            label: '新增',
            icon: 'plus',
            // auth: URL.cityShopAdd,
            func: () => {
              this.showDynamicDialog('addInput', '新增门店编码配置', 3)
            }
          },
          {
            label: '删除',
            icon: 'delete',
            auth: URL.cityShopDelete,
            disabled: () => {
              return this.sendModifyArr.length !== 1
            },
            func: () => {
              this.$confirm('是否确定删除', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
                this.id = this.sendModifyArr[0].id
                this.$http(URL.cityShopDelete, { 'id': this.id })
                this.$alert('删除成功', '提示', {
                  confirmButtonText: '我知道了',
                  type: 'success',
                  callback: action => {
                    this.refreshTable()
                  }
                })
              })
            }
          },
          {
            label: '修改',
            icon: 'pen',
            // auth: URL.cityShopUpdate,
            disabled: () => {
              return this.sendModifyArr.length !== 1
            },
            func: () => {
              this.showDynamicDialog('modifyInput', '修改门店编码配置', 3)
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        tables: [
          {
            searchCode: 'cod_store_code_list_field',
            url: { method: URL.cityShopSearch },
            option: {
              load: false,
              type: 'selection',
              moduleCode: 'ecs_ldp',
              detailAuth: false,
              beforeFormSubmit: (data, model) => {
                const obj = {}
                let isEmpty = true
                for (let key in model) {
                  if (model[key]) {
                    isEmpty = false
                    obj[key] = model[key]
                  } else {
                    delete data[key]
                  }
                }
                if (isEmpty) {
                  this.$message.warning('请输入查询条件')
                  return true
                }
                // delete data.generic
                data.vo = {}
                Object.assign(data.vo, obj)
                // Object.assign(data, obj)
              },
              // 勾选
              selectionChange: (rows) => {
                this.sendModifyArr = [...rows]
                this.sendModifyObj = Object.assign({}, rows[0])
                if (rows.length === 1) {
                  rows.forEach(item => {
                    if (item.auditStatus === 10) {
                      this.disabled = true
                      return
                    }
                    this.disabled = false
                  })
                  return
                }
                this.disabled = true
              },
            },
            formatter: {
            }
          }
        ]
      }
    },
    methods: {
      // 刷新
      refreshTable () {
        this.$refs.queryTable.loadData()
      },
      // 点击审核
      checkOpen () {
        if (this.sendModifyArr.length === 1) {
          this.$confirm('是否确定审核', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.getCheckData()
          }).catch(() => {
          })
        } else {
          this.$alert('请选择一条数据审核', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: action => {
            }
          })
        }
      },
      // 调用审核接口
      async getCheckData () {
        let param = {
          id: this.sendModifyArr[0].id
        }
        await this.$http('ldp.ThirdDelivery.V1.Delivery.CityShopAudit', param)
        this.$message({
          type: 'success',
          message: '审核已提交!'
        })
        this.refreshTable()
      },
      // 显示弹框 新增、修改
      showDynamicDialog (view, title, width = '1200px') {
        this.dialogOption.show = true
        this.dialogOption.view = view
        this.dialogOption.title = title
        this.dialogOption.width = width
      },
      // 保存关闭对话框
      closeDynamicDialog () {
        this.dialogOption.show = false
        this.dialogOption.view = null
      },
      // 关闭
      close () {
        this.dialogOption.show = false
        this.dialogOption.view = null
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>

