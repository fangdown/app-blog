<template>
  <div class="add-input">
    <kye-form class="kye-dialog-body_form"
              ref="formArea"
              :model="ruleForm"
              style="padding-bottom:4px"
              :rules="rules">
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="所属区域"
                         prop="regionId"
                         :rules="[{ required: true, message: '请选择所属区域',trigger:'change'}]">
            <kye-select v-model="ruleForm.regionId"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_region_name']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="平台名称"
                         prop="platformId"
                         :rules="[{ required: true, message: '请选择推送平台',trigger:'change'}]">
            <kye-select v-model="ruleForm.platformId"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_platform_id']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店编码"
                         prop="code"
                         :rules="$rule.str('请输入门店编码',true)">
            <kye-input v-model="ruleForm.code"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店类型"
                         prop="type"
                         :rules="[{ required: true, message: '请选择门店类型',trigger:'change'}]">
            <kye-select v-model="ruleForm.type"
                        placeholder=''>
              <kye-option label="真实门店"
                          value="真实门店"></kye-option>
              <kye-option label="虚拟门店"
                          value="虚拟门店"></kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店名称"
                         prop="name"
                         :rules="$rule.str('请输入门店名称',true)">
            <kye-input v-model="ruleForm.name"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店联系人"
                         prop="linkman"
                         :rules="$rule.str('请输入门店联系人',true)">
            <kye-input v-model="ruleForm.linkman"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="联系电话"
                         prop="contactPhone"
                         :rules="$rule.str('请输入门店联系电话',true)">
            <kye-input v-model="ruleForm.contactPhone"
                       maxlength='11'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="路线类型"
                         prop="pathPlanning"
                         :rules="[{ required: true, message: '请选择路线规划类型',trigger:'change'}]">
            <kye-select v-model="ruleForm.pathPlanning"
                        placeholder=''>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_path_planning']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="门店经度"
                         prop='lng'
                         :rules="$rule.reg(/^(\-|\+)?(((\d|[1-9]\d|1[0-7]\d|0{1,3})\.\d{0,6})|(\d|[1-9]\d|1[0-7]\d|0{1,3})|180\.0{0,6}|180)$/, '经度整数部分为0-180,小数部分为0到6位!',true)">
            <kye-input v-model.number="ruleForm.lng"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="门店纬度"
                         prop='lat'
                         :rules="$rule.reg(/^(\-|\+)?([0-8]?\d{1}\.\d{0,6}|90\.0{0,6}|[0-8]?\d{1}|90)$/, '纬度整数部分为0-90,小数部分为0到6位!',true)">
            <kye-input v-model.number="ruleForm.lat"
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="24">
          <kye-form>
            <kye-form-item label="所在地区"
                           class="localArea"
                           prop="regionArr">
              <kye-area-remote :level=3
                               style="width:100%"
                               v-model="ruleForm.regionArr">
              </kye-area-remote>
            </kye-form-item>
          </kye-form>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="24">
          <kye-form-item label="详细地址"
                         prop="detailAddress"
                         :rules="$rule.str('请输入门店详细地址',true)">
            <kye-input v-model="ruleForm.detailAddress"
                       maxlength='100'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="城市名称"
                         prop="cityName"
                         :rules="$rule.str('请输入城市名称',true)">
            <kye-city v-model="ruleForm.cityName"
                      @select="selectCityName"
                      placeholder=''
                      clearable></kye-city>
          </kye-form-item>
        </kye-col>
        <kye-col :span="12">
          <kye-form-item label="城市区号">
            <kye-input v-model="ruleForm.cityCode"
                       maxlength='10'
                       clearable></kye-input>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row :gutter="18">
        <kye-col :span="12">
          <kye-form-item label="城市等级"
                         prop="cityType"
                         :rules="[{ required: true, message: '请选择城市等级',trigger:'change'}]">
            <kye-select v-model="ruleForm.cityType"
                        placeholder=' '>
              <kye-option v-for="item in lookUpOptions['ecs_ldp_city_type']"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  @click="submitForm('formArea')">保存(S)
      </kye-button>
      <kye-button @click="$emit('cancelClose')">取消</kye-button>
    </div>
  </div>
</template>
<script>
  import mixins from 'public/mixins/index'
  import URL from '../../api'
  // 城市组件
  import KyeCity from '@/shared/components/kye-city'
  export default {
    mixins: [mixins],
    components: { KyeCity },
    data () {
      return {
        data: {},
        message: '',
        ruleForm: {
          platformId: null, // 平台ID
          code: '', // 门店编码
          type: '', // 门店类型
          name: '', // 平台门店名称
          linkman: '', // 门店联系人
          contactPhone: '', // 联系电话
          regionId: '', // 所属区域
          lng: '', // 门店经度
          lat: '', // 门店纬度
          region: '', // 所在地区
          regionArr: [], // 所在地区数组
          address: '', // 详细地址
          detailAddress: '', // 详细地址
          cityCode: '', // 城市区号
          cityName: '', // 城市名称
          cityType: '', // 城市等级
          pathPlanning: '', // 路线规划类型
          auditStatus: '0', // 默认未审核状态
          uppdateDT: '' // 更新时间
        },
        rules: {}
      }
    },
    methods: {
      // 点击保存
      async submitForm (formName) {
        this.$refs[formName].validate(async (valid) => {
          if (valid) {
            let regionArr = []
            this.ruleForm.regionArr.forEach(item => {
              regionArr.push(item.addressName)
            })
            delete this.ruleForm.platformName
            // 所在地区
            this.ruleForm.address = regionArr.join().replace(/,/g, '') + '' + this.ruleForm.detailAddress
            await this.$http(URL.cityShopAdd, this.ruleForm)
            this.$message.success('新增成功！')
            this.$emit('cancelClose')
            this.$emit('refreshTable')
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 选择城市名称
      selectCityName (item) {
        if (item) {
          this.ruleForm.cityName = item.addressName
          this.ruleForm.cityCode = item.cityCode
        } else {
          this.$message.warning('没有找到该城市')
        }
      }
    }
  }
</script>
