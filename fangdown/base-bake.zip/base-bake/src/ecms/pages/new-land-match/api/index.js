const URL = {
  findByNodeNameAndFlag: 'baseconfig.node.findByNodeNameAndFlag', // 所属点部
  waybillSearch: 'cod.waybill.search', // 推单查询
  pushDelivery: 'ldp.ThirdDelivery.V1.Delivery.PushDelivery', // 点击推单
  waybillSearchDetail: 'cod.waybill.get', // 推单详情
  cancelDelivery: 'ldp.ThirdDelivery.V1.Delivery.CancelDelivery', // 取消推单
  cityShopSearch: 'cod.shop.search', // 门店查询
  searchShopByName: 'cod.shop.selectByName', // 门店名称
  cityShopAdd: 'cod.shop.save', // 门店新增
  cityShopDelete: 'ldp.ThirdDelivery.V1.Delivery.CityShopDelete', // 门店删除
  cityShopUpdate: 'cod.shop.update', // 门店修改
  ldpSummaryList: 'cod.financialReconciliation.search', // 对账查询
  ldpUpdateFee: 'ecs.finance.ldp.ldpUpdateFee.do', // 对账修改
  driverFeeAudit: 'ecs.finance.ldp.driverFeeAudit.do', // 对账审核
  exportLdpCheckBill: 'ecs.finance.ldp.exportLdpCheckBill.do', // 对账导出
  getPlatformTotalBillList: 'cod.financialAccount.search', // 账单查询
  updatePlatformTotalBill: 'cod.financialAccount.audit', // 账单审核
  exportLDPBillList: 'ecs.finance.ldp.exportLDPBillList.do', // 账单首页导出
  getPlatformWayBillList: 'ecs.finance.ldp.getPlatformWayBillList.do', // 账单详情
  exportLDPWayBillList: 'ecs.finance.ldp.exportLDPWayBillList.do', // 账单详情页导出
}
export default URL
