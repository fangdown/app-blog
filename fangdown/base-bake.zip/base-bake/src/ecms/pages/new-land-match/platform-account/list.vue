<template>
  <div>
    <query-table ref="queryTable"
                 :form-tools="searchTools"
                 :option="option"
                 :tables="tables"
                 :generic="generic">
      <div slot="desc"></div>
    </query-table>
  </div>
</template>
<script>
  import URL from '../api'
  export default {
    data () {
      return {
        downloadData: {}, // 导出接口入参
        generic: {
          method: URL.getPlatformTotalBillList,
          searchCode: 'cod_financialAccount_search'
        },
        tables: [
          {
            searchCode: 'cod_financialAccount_list_field',
            url: { method: URL.getPlatformTotalBillList },
            option: {
              load: false,
              detailAuth: URL.getPlatformWayBillList,
              rowDblClick: this.rowDblClick,
              moduleCode: 'ecs_ldp',
              beforeFormSubmit: (data, model) => {
                const obj = {}
                delete data.accountTimeStart
                delete data.accountTimeEnd
                for (let key in model) {
                  if (model[key]) {
                    if (key === 'accountTime') {
                      if (model.accountTime && model.accountTime.length === 2) {
                        const accountTimeStart = model.accountTime[0]
                        const accountTimeEnd = model.accountTime[1]
                        Object.assign(obj, {
                          accountTimeStart,
                          accountTimeEnd
                        })
                      }
                    } else {
                      obj[key] = model[key]
                    }
                  } else {
                    delete data[key]
                  }
                }
                // obj['businessType'] = 2 // 接口标识

                data.vo = {}
                // delete data.generic
                Object.assign(data.vo, obj)
                // Object.assign(data, obj)
                this.downloadData = {}
                Object.assign(this.downloadData, obj)
              },
            },
            operation: {
              label: '操作',
              fixed: 'left',
              width: '50px',
              options:
                [{
                  btnType: 'button',
                  label: '审核',
                  disabled: row => {
                    return row.auditStatus === 300
                  },
                  // auth: URL.updatePlatformTotalBill,
                  func: row => {
                    this.resData = row
                    this.check()
                  }
                }]
            },
            formatter: {
            }
          }
        ],
        searchTools: [
          {
            label: '刷新',
            icon: 'reset',
            auth: URL.getPlatformTotalBillList,
            func: () => {
              let tableData = this.$refs.queryTable.getTableData() || []
              if (tableData.length <= 0) {
                this.$message.warning('无数据！')
                return false
              }
              this.refreshTable()
            }
          },
          {
            label: '导出',
            icon: 'export',
            disabled: false,
            auth: URL.exportLDPBillList,
            func: () => {
              this.downloadTable()
            }
          },
          {
            label: '通用查询',
            icon: 'search',
            func: () => this.$refs.queryTable.showGenericDialog()
          },
          {
            label: '个性设置',
            icon: 'custom',
            func: () => this.$refs.queryTable.showDragDialog()
          }
        ],
        option: {
          auth: false, // 暂时去掉权限控制
          searchCode: 'cod_financialAccount_search_define'
        },
      }
    },
    methods: {
      // 刷新
      refreshTable () {
        this.$refs.queryTable.loadData()
      },
      // 去详情页
      rowDblClick (row, col) {
        this.$router.push(`/ecms/new-land-match/platform-account-detail/${row.id}`)
      },
      // 导出
      async downloadTable () {
        let tableData = this.$refs.queryTable.getTableData() || []
        if (tableData.length <= 0) {
          this.$message.warning('无数据可导出！')
          return false
        }
        delete this.downloadData['schedulingTime']
        this.downloadData['businessType'] = 2
        try {
          let xlsUrl = await this.$http(URL.exportLDPBillList, this.downloadData)
          window.erpOpen(xlsUrl)
          this.$message.success('导出成功！')
        } catch (e) {
          // this.$message.warning('导出失败！')
        }
      },
      // 点击审核
      check () {
        this.$confirm(`确定审核对账批号为${this.resData.billNo}并提交到财务应付吗？`, '审核', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.getCheckData()
        }).catch(() => {
        })
      },
      // 调用审核接口
      async getCheckData () {
        let param = {
          'id': this.resData.id,
        }
        await this.$http(URL.updatePlatformTotalBill, param)
        this.$confirm('已审核提交到财务应付', '审核成功', {
          confirmButtonText: '我知道了',
          cancelButtonText: '',
          type: 'success'
        }).then(() => {
          // 刷新页面
          this.refreshTable()
        })
      },
    },

  }
</script>
<style lang='scss' scoped>
</style>


