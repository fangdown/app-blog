<template>
  <div class="kye-detail">
    <search-pager :option="options"
                  :tools="formTools">
      <el-input v-model.trim="searchInput"
                class="search-wrap"
                placeholder="请输入运单号">
        <template slot="prepend">
          运单号
        </template>
        <el-button slot="append"
                   icon="iconfont icon-search"
                   :disabled="!searchInput"
                   @click="searchClick">
        </el-button>
      </el-input>
    </search-pager>
    <kye-expand-page v-loading="loading">
      <!-- 快件信息 start -->
      <div class="kye-block-title">
        <span>快件信息</span>
      </div>
      <express-info :expressInfoData="expressInfoData"></express-info>
      <!-- 快件信息 end -->

      <!-- 推送信息 start -->
      <div class="kye-block-title">
        <span>推送信息</span>
      </div>
      <push-info :expressInfoData="expressInfoData"></push-info>
      <!-- 推送信息 end -->

      <!-- 派送费信息 start -->
      <div class="kye-block-title">
        <span>派送费信息</span>
      </div>
      <delivery-info :deliveryInfo="deliveryInfoData"></delivery-info>
      <!-- 派送费信息 end -->

      <!-- 配送日志 start -->
      <div class="kye-block-title"
           style="margin-top:12px">
        <span>配送日志</span>
      </div>
      <delivery-log :deliveryLog="deliveryLog"></delivery-log>
      <!-- 配送日志 end -->
    </kye-expand-page>
  </div>
</template>
<script>
  // 快件信息
  import expressInfo from './express-info'
  // 推送信息
  import pushInfo from './push-info'
  // 派送费信息
  import deliveryInfo from './delivery-charge-info'
  // 配送日志
  import deliveryLog from './delivery-log'
  // 时间YYYY-MM-DD HH:mm / 费用过滤
  import { minute, money } from '@/public/utils/filter'
  import URL from '../../api'
  export default {
    components: {
      expressInfo,
      pushInfo,
      deliveryInfo,
      deliveryLog
    },
    data () {
      return {
        options: {
          back: '/ecms/new-land-match/push-order',
          idKey: 'code',
          method: 'cod.waybill.search',
          searchCode: 'cod_waybill_list_field',
          formFields: [
          ]
        },
        formTools: [
          {
            label: '刷新',
            auth: URL.waybillSearchDetail,
            icon: 'reset',
            func: () => {
              if (this.searchInput) {
                this.getDetailData(this.searchInput)
              } else {
                this.getDetailData(this.$route.params.id)
              }
            }
          }
        ],
        expressInfoData: {}, // 快件信息、推送信息
        deliveryInfoData: [], // 派送费信息
        deliveryLog: [], // 配送日志
        searchInput: '', // 搜索框
        loading: false // 加载
      }
    },
    mounted () {
      let dom = this.$el.querySelector('.search-wrap > .el-input-group__prepend')
      dom.style.padding = '0 8px'
      dom = null
    },
    methods: {
      // 运单搜索
      searchClick () {
        this.getDetailData(this.searchInput, 1)
      },
      // 获取详情数据
      async getDetailData (param, showFlag) {
        this.loading = true
        if (showFlag === -1) {
          this.searchInput = ''
        }
        let params = { code: param }
        try {
          let res = await this.$http(URL.waybillSearchDetail, params)
          this.loading = false
          res.deliveryFees.forEach(item => {
            // switch (item.status) {
            //   case 100:
            //     item.status = '费用有效'
            //     break
            //   case 200:
            //     item.status = '费用无效'
            //     break
            //   default:
            //     break
            // };
            item.pushTime = minute(item.pushTime)
            item.deliveryAmount = money(item.deliveryAmount)
            item.finalDeliveryAmount = money(item.finalDeliveryAmount)
          })
          this.deliveryInfoData = res.deliveryFees || []
          res.deliveryLogs.forEach(item => {
            item.createTime = minute(item.createTime)
          })
          this.deliveryLog = res.deliveryLogs || []
          delete res.deliveryFees
          delete res.deliveryLogs
          this.expressInfoData = res || {}
        } catch (error) {
          this.loading = false
        }
      },
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        if (!vm.$route.meta.layout) {
          vm.getDetailData(to.params.id, -1)
        }
      })
    },
    beforeRouteLeave (to, from, next) {
      this.expressInfoData = {}
      this.deliveryInfoData = []
      this.deliveryLog = []
      next()
    },
    beforeRouteUpdate (to, from, next) {
      this.getDetailData(to.params.id, -1)
      next()
    },
  }
</script>
<style lang="scss" scoped>
</style>
