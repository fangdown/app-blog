<template>
  <div class="push-Info">
    <kye-form ref="formArea"
              :model="expressInfoData">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="派送人">
            <kye-field v-model="expressInfoData.deliveryName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="派送人手机">
            <kye-field v-model="expressInfoData.deliveryPhone"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="订单状态">
            <kye-field>{{expressInfoData.orderStatus|lookup('ecs_ldp_order_status')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="接单时间">
            <kye-field>{{expressInfoData.orderTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="签收时间">
            <kye-field>{{expressInfoData.signTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="收件码">
            <kye-field v-model="expressInfoData.receiverCode"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="推送次数">
            <kye-field v-model="expressInfoData.pushCount"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="推送平台">
            <kye-field>{{expressInfoData.platformId|lookup('ecs_ldp_platform_id')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="推送门店">
            <kye-field v-model="expressInfoData.pushDept"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预送达时间">
            <kye-field>{{expressInfoData.estimatedArrivalTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="取消来源">
            <kye-field v-model="expressInfoData.cancelParty"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="取消原因">
            <kye-field v-model="expressInfoData.cancelReason"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="异常时间">
            <kye-field>{{expressInfoData.abnormalTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="订单说明">
            <kye-field v-model="expressInfoData.operationRemark"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  export default {
    props: {
      expressInfoData: {
        type: Object,
        default () {
          return {}
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>
