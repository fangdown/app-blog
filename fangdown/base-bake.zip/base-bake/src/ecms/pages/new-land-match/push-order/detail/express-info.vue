<template>
  <div class="push-espressInfo">
    <kye-form ref="formArea"
              :model.sync="expressInfo"
              module-code="ecs_ldp"
              :biz-id="$route.params.id">
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="运单号">
            <kye-field v-model="expressInfo.code"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="服务方式">
            <kye-field>{{expressInfo.serviceMode|lookup('common_service_type')}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="提货日期">
            <kye-field>{{expressInfo.expectTakeTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="件数">
            <kye-field v-model="expressInfo.cargoNum"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="实际重量">
            <kye-field>{{expressInfo.chargedWeigth||0}}kg</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="行业类型">
            <kye-field>{{expressInfo.customerType|lookup('ecs_ldp_customer_type')}}</kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="收件公司">
            <kye-field v-model="expressInfo.receiverCompany"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="收件点部">
            <kye-field v-model="expressInfo.receiverDept"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="派送日期">
            <kye-field>{{expressInfo.deliveryTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="预导航距离">
            <kye-field>{{expressInfo.gpsDistance||0}}m</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="托寄物"
                         class="depositum">
            <kye-field v-model="expressInfo.sendThing"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="收件联系人">
            <kye-field v-model="expressInfo.receiverName"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="收件人手机"
                         prop="receiverPhone"
                         module-code="ecs_ldp"
                         :biz-id="$route.params.id">
            <kye-field v-model="expressInfo.receiverPhone"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="收件人电话"
                         prop="receiverTel"
                         module-code="ecs_ldp"
                         :biz-id="$route.params.id">
            <kye-field v-model="expressInfo.receiverTel"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="提货时间">
            <kye-field>{{expressInfo.takeTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="到点部时间">
            <kye-field>{{expressInfo.arrivalTime | minute}}</kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="提后位置">
            <kye-field v-model="expressInfo.pickedAddress"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="4">
          <kye-form-item label="装车派送">
            <kye-field v-model="expressInfo.loadedDeliveryTime"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col style="width:14%">
          <kye-form-item label="所在地区">
            <kye-field v-model="expressInfo.province"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col style="width:9.5%">
          <!-- <kye-form-item> -->
          <kye-field style="line-height:28px"
                     v-model="expressInfo.city"></kye-field>
          <!-- </kye-form-item> -->
        </kye-col>
        <kye-col style="width:9.8%">
          <!-- <kye-form-item> -->
          <kye-field style="line-height:28px"
                     v-model="expressInfo.area"></kye-field>
          <!-- </kye-form-item> -->
        </kye-col>
        <kye-col :span="4">
          <kye-form-item label="镇/街道">
            <kye-field v-model="expressInfo.stress"></kye-field>
          </kye-form-item>
        </kye-col>
        <kye-col :span="8">
          <kye-form-item label="详细地址"
                         class="detailAddress">
            <kye-field v-model="expressInfo.receiverAddress"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
      <kye-row>
        <kye-col :span="12">
          <kye-form-item label="派送备注"
                         class="sendRemark">
            <kye-field v-model="expressInfo.courierRemark"></kye-field>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </div>
</template>
<script>
  export default {
    props: {
      expressInfoData: {
        type: Object,
        default () {
          return {}
        }
      }
    },
    data () {
      return {
        expressInfo: this.expressInfoData
      }
    },
    watch: {
      expressInfoData (newVal) {
        if (newVal) {
          this.expressInfo = newVal
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>

