<template>
  <div class="delivery-log">
    <kye-table ref="deliveryLogTable"
               :data="deliveryLog"
               tooltip-effect="dark"
               module-code="ecs_ldp"
               :biz-id="deliveryLog.id"
               :cell-style="isRed"
               style="width: 100%">
      <kye-table-column type="index"
                        label="序号"
                        width="50">
      </kye-table-column>
      <kye-table-column prop="status"
                        label="状态"
                        width="90px"
                        show-overflow-tooltip
                        :formatter="formatterStatus">
      </kye-table-column>
      <kye-table-column prop="deliveryName"
                        label="更新人"
                        show-overflow-tooltip
                        width="80px">
      </kye-table-column>
      <kye-table-column prop="deliveryPhone"
                        label="联系方式"
                        show-overflow-tooltip
                        width="95px">
      </kye-table-column>
      <kye-table-column prop="createTime"
                        label="更新时间"
                        show-overflow-tooltip
                        width="120px">
      </kye-table-column>
      <kye-table-column prop="operationRemark"
                        label="备注"
                        show-overflow-tooltip
                        width="auto">
      </kye-table-column>
    </kye-table>

  </div>
</template>
<script>
  export default {
    props: {
      deliveryLog: {
        type: Array
      }
    },
    methods: {
      formatterStatus (row, column, cellValue, index) {
        return this.$filter['lookup'](cellValue, 'ecs_ldp_order_status')
      },
      isRed ({ row, column, rowIndex, columnIndex }) {
        if (row.status === 500) return 'color:red'
        if (row.status === 502) return 'color:red'
      }
    }
  }
</script>
<style lang='scss' scoped>
</style>




