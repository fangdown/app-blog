const partnerBillList = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-bill/list')
const partnerBillDetail = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-bill/detail')

export default [
  {
    path: 'partner-bill/list',
    component: partnerBillList,
    meta: { tag: '/tms/partner-bill/list', title: '伙伴账单' }
  },
  {
    path: 'partner-bill/detail/:id/:partnerId',
    component: partnerBillDetail,
    meta: { tag: '/tms/partner-bill/list', title: '伙伴账单详情', pageType: 'detail' }
  }
]
