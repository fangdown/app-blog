const partnerMsgList = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-message/list')
const partnerMsgDetail = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-message/detail')
const partnerMsgAdd = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-message/add')
const tag = '/tms/partner-message/list'
export default [
  {
    path: 'partner-message/list',
    component: partnerMsgList,
    meta: { tag, title: '消息通知' }
  },
  {
    path: 'partner-message/detail/:id',
    component: partnerMsgDetail,
    meta: { tag, title: '消息详情' }
  },
  {
    path: 'partner-message/add',
    component: partnerMsgAdd,
    meta: { tag, title: '消息新增' }
  }
]
