const partnerBackstage = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-account/list')

export default [
  {
    path: 'partner-account/list',
    component: partnerBackstage,
    meta: { tag: '/tms/partner-account/list', title: '账号管理' }
  }
]
