const List = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-reconciliation/list')
const Detail = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-reconciliation/details')

export default [
  {
    path: 'partner-reconciliation/list',
    component: List,
    meta: { tag: '/tms/partner-reconciliation/list', title: '伙伴对账' }
  },
  {
    path: 'partner-reconciliation/detail/:id',
    component: Detail,
    meta: { tag: '/tms/partner-reconciliation/list', title: '伙伴对账详情', pageType: 'detail' }
  }
]
