const tag = '/tms/partner-backstage/main'

const partnerBackstage = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-backstage/main')
const partnerBackstageAdd = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-backstage/add')
const partnerBackstageModify = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-backstage/modify')
const partnerBackstageDetail = () => import(/* webpackChunkName: "ecms" */ '../../pages/partner/partner-backstage/detail')

export default [
  {
    path: 'partner-backstage/main',
    component: partnerBackstage,
    meta: { tag, title: '伙伴后台' }
  },
  {
    path: 'partner-backstage/add',
    component: partnerBackstageAdd,
    meta: { tag, title: '伙伴新增' }
  },
  {
    path: 'partner-backstage/modify/:id',
    component: partnerBackstageModify,
    meta: { tag, title: '伙伴修改' }
  },
  {
    path: 'partner-backstage/detail/:id',
    component: partnerBackstageDetail,
    meta: { tag, title: '伙伴详情', pageType: 'detail' }
  }
]
