const tag = '/ecms/contract/list'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/contract/list')
const edit = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/contract/edit')
const view = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/contract/view')

export default [{
  path: 'contract/list',
  component: list,
  meta: {
    tag,
    title: '合同管理'
  }
},
{
  path: 'contract/edit',
  component: edit,
  meta: {
    tag,
    title: '编辑合同详情'
  }
},
{
  path: 'contract/view/:id',
  component: view,
  meta: {
    tag,
    title: '查看合同详情',
    pageType: 'detail'
  }
}
]
