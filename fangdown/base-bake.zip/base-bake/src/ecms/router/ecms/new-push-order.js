const tag = '/ecms/new-land-match/push-order'
const pushOrder = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/push-order/list')
const pushOrderDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/push-order/detail/push-order-detail')
export default [{
  path: 'new-land-match/push-order',
  component: pushOrder,
  meta: {
    tag,
    title: '推单管理'
  }
},
{
  path: 'new-land-match/push-order-detail/:id',
  component: pushOrderDetail,
  meta: {
    tag,
    title: '推单详情',
    pageType: 'detail'
  }
}
]
