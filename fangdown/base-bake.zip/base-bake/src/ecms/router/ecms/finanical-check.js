const tag = '/ecms/financial/check'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/list')
const driverDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/driver-withdraw-detail')
const driverWaybill = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/driver-withdraw-waybill-detail')
const enterpriseDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/enterprise-withdraw-detail')
const enterpriseWaybill = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/enterprise-waybill-detail')
const driverBills = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/driver-bills')
const platformDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/platform-waybill-detail')
const contractDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/contract-waybill-detail')
const print = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/check/components/bills-print')
export default [{
  path: 'financial/check',
  component: list,
  meta: {
    tag,
    title: '账单管理'
  }
},
{
  path: 'financial/check-driver-withdraw-detail',
  component: driverDetail,
  meta: {
    tag,
    title: '主体公司详情'
  }
},
{
  path: 'financial/check-driver-withdraw-waybill-detail',
  component: driverWaybill,
  meta: {
    tag,
    title: '运单详情'
  }
},
{
  path: 'financial/check-enterprise-withdraw-detail',
  component: enterpriseDetail,
  meta: {
    tag,
    title: '月账单详情'
  }
},
{
  path: 'financial/check-enterprise-waybill-detail',
  component: enterpriseWaybill,
  meta: {
    tag,
    title: '运单详情'
  }
},
{
  path: 'financial/check-driver-bills',
  component: driverBills,
  meta: {
    tag,
    title: '账单'
  }
},
{
  path: 'financial/check-platform-waybill-detail',
  component: platformDetail,
  meta: {
    tag,
    title: '运单详情'
  }
},
{
  path: 'financial/check-contract-waybill-detail',
  component: contractDetail,
  meta: {
    tag,
    title: '运单详情'
  }
},
{
  path: 'financial/check-bills-print',
  component: print,
  meta: {
    tag,
    title: '账单详情'
  }
}
]
