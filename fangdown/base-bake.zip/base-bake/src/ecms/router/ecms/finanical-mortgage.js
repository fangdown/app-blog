const tag = '/ecms/financial/mortgage-management'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/mortgage/list')
export default [{
  path: 'financial/mortgage-management',
  component: list,
  meta: {
    tag,
    title: '押金管理'
  }
}
]
