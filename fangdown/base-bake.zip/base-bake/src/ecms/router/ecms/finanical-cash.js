const tag = '/ecms/financial/cash-management'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/cash/list')
const detail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/cash/management-detail')
export default [{
  path: 'financial/cash-management',
  component: list,
  meta: {
    tag,
    title: '提现管理'
  }
},
{
  path: 'financia/cash-management-detail',
  component: detail,
  meta: {
    tag,
    title: '提现详情'
  }
}
]
