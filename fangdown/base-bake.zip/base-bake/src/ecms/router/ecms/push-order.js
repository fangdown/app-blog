const tag = '/ecms/land-match/push-order'
const pushOrder = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/land-match/push-order/list')
const pushOrderDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/land-match/push-order/detail/push-order-detail')
export default [{
  path: 'land-match/push-order',
  component: pushOrder,
  meta: {
    tag,
    title: '推单管理'
  }
},
{
  path: 'land-match/push-order-detail/:id',
  component: pushOrderDetail,
  meta: {
    tag,
    title: '推单详情',
    pageType: 'detail'
  }
}
]
