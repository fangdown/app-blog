const tag = '/ecms/app-user/list'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/app-user/list')
const detial = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/app-user/detail')
const edit = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/app-user/edit')

export default [{
  path: 'app-user/list',
  component: list,
  meta: {
    tag,
    title: 'APP用户'
  }
},
{
  path: 'app-user/detail/:id',
  component: detial,
  meta: {
    tag,
    title: 'APP用户详情',
    pageType: 'detail'
  }
},
{
  path: 'app-user/edit',
  component: edit,
  meta: {
    tag,
    title: 'APP用户修改'
  }
}
]
