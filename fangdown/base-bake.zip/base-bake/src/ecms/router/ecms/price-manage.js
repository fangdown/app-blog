const priceManage = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/price-manage/list')
const detail = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/price-manage/detail')
const addPrice = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/price-manage/add-inquiry')
const rePrice = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/price-manage/re-inquiry')
const editPrice = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/price-manage/edit')
export default [{
  path: 'whole-car/price-manage/index',
  component: priceManage,
  meta: {
    tag: '/ecms/whole-car/price-manage/index',
    title: '询价管理',
  }
},
{
  path: 'whole-car/price-manage/detail/:id',
  component: detail,
  name: 'priceManageDetail',
  meta: {
    title: '待处理',
    tag: '/ecms/whole-car/price-manage/index',
    pageType: 'detail'
  }
},
{
  path: 'whole-car/price-manage/add',
  component: addPrice,
  name: 'priceManageAdd',
  meta: {
    tag: '/ecms/whole-car/price-manage/index',
    title: '新增询价'
  }
},
{
  path: 'whole-car/price-manage/reInquiry/:id',
  component: rePrice,
  name: 'priceManageRe',
  meta: {
    tag: '/ecms/whole-car/price-manage/index',
    title: '重新询价'
  }
},
{
  path: 'whole-car/price-manage/edit/:id',
  component: editPrice,
  name: 'priceManageEdit',
  meta: {
    tag: '/ecms/whole-car/price-manage/index',
    title: '修改报价'
  }
}
]
