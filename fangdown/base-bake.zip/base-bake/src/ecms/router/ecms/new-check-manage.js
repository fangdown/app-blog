const tag = '/ecms/new-land-match/check-manage'
const checkManage = () => import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/check-manage/list')
export default [{
  path: 'new-land-match/check-manage',
  component: checkManage,
  meta: {
    tag,
    title: '对账管理'
  }
}
]
