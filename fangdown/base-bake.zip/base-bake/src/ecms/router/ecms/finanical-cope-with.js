const tag = '/ecms/financial/cope-with'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/cope-with/list')
const detail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/cope-with/detail')
const change = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/cope-with/edit')
export default [{
  path: 'financial/cope-with',
  component: list,
  meta: {
    tag,
    title: '应付汇总'
  }
},
{
  path: 'financial/cope-with-detail/:id',
  component: detail,
  meta: {
    tag,
    pageType: 'detail',
    title: '应付费用详情'
  }
},
{
  path: 'financial/cope-with-change/:id',
  component: change,
  meta: {
    tag,
    title: '应付费用修改'
  }
}
]
