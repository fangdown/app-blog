// const list = () => import(/* webpackChunkName: "ecms" */ '../../pages/demo/list')
// const detail = () => import(/* webpackChunkName: "ecms" */ '../../pages/demo/detail')
// export default [
//   {
//     path: 'demo/list',
//     component: list,
//     meta: {
//       tag: '/ecms/demo/list',
//       title: '测试'
//     }
//   },
//   {
//     path: 'demo/detail',
//     component: detail,
//     meta: {
//       tag: '/ecms/demo/list',
//       title: '测试'
//     }
//
//   }
// ]
