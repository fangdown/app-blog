const wholeCar = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/dispatch/list')
const detail = () => import(/* webpackChunkName: "ecms" */ '../../pages/whole-car/dispatch/detail')
export default [{
  path: 'whole-car/dispatch/index',
  component: wholeCar,
  meta: {
    tag: '/ecms/whole-car/dispatch/index',
    title: '整车调度',
  }
},
{
  path: 'whole-car/dispatch/detail/:id',
  component: detail,
  // name: 'detail',
  meta: {
    tag: '/ecms/whole-car/dispatch/index',
    title: '整车调度',
    pageType: 'detail'
  }
}
]
