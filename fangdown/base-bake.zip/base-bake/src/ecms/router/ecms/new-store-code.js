const tag = '/ecms/new-land-match/store-code'
const storeCode = () => import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/store-code/list')
export default [{
  path: 'new-land-match/store-code',
  component: storeCode,
  meta: {
    tag,
    title: '门店配置'
  }
}]
