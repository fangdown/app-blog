const tag = '/ecms/financial/accounts-receivable'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/receivable/list')
const detail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/receivable/detail')
const change = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/financial/receivable/edit')
export default [{
  path: 'financial/accounts-receivable',
  component: list,
  meta: {
    tag,
    title: '应收汇总'
  }
},
{
  path: 'financial/accounts-receivable-detail/:id',
  component: detail,
  meta: {
    tag,
    pageType: 'detail',
    title: '应收费用详情'
  }
},
{
  path: 'financial/accounts-receivable-change/:id',
  component: change,
  meta: {
    tag,
    title: '应收费用修改'
  }
}
]
