const tag = '/ecms/new-land-match/platform-account'
const platformAccount = () => import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/platform-account/list')
const platformAccountDetail = () => import(/* webpackChunkName: "ecms" */ '../../pages/new-land-match/platform-account/detail/platform-account-detail')

export default [{
  path: 'new-land-match/platform-account',
  component: platformAccount,
  meta: {
    tag,
    title: '账单管理'
  }
}, {
  path: 'new-land-match/platform-account-detail/:id',
  component: platformAccountDetail,
  meta: {
    tag,
    title: '账单详情',
    pageType: 'detail'
  }
}]
