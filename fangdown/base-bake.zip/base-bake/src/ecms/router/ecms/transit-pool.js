const tag = '/ecms/transit-pool/list'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/transit-pool/list')
const detail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/transit-pool/detail')
const edit = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/transit-pool/edit')
export default [{
  path: 'transit-pool/list',
  component: list,
  meta: {
    tag,
    title: '运力池'
  }
},
{
  path: 'transit-pool/detail/:id',
  component: detail,
  meta: {
    tag,
    title: '运力详情',
    pageType: 'detail'
  }
},
{
  path: 'transit-pool/edit/:id',
  component: edit,
  meta: {
    tag,
    title: '运力编辑',
  }
}
]
