const tag = '/ecms/land-match/store-code'
const storeCode = () => import(/* webpackChunkName: "ecms" */ '../../pages/land-match/store-code/list')
export default [{
  path: 'land-match/store-code',
  component: storeCode,
  meta: {
    tag,
    title: '门店配置'
  }
}]
