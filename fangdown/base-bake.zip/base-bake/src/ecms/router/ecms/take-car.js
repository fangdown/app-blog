const tag = '/ecms/take-car/list'
const list = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/take-car/list')
const newTask = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/take-car/components/new-task')
const mainDetail = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/take-car/components/main-detail')
const mainEdit = () =>
  import(/* webpackChunkName: "ecms" */ '../../pages/car-manage/take-car/components/main-edit')
export default [{
  path: 'take-car/list',
  component: list,
  meta: {
    tag,
    title: '要车管理'
  }
},
{
  path: 'take-car/new',
  component: newTask,
  meta: {
    tag,
    title: '新增'
  }
},
{
  path: 'take-car/main-detail/:id',
  component: mainDetail,
  meta: {
    tag: tag,
    title: '详情',
    pageType: 'detail'
  }
},
{
  path: 'take-car/main-edit/:id',
  component: mainEdit,
  meta: {
    tag: tag,
    title: '详情'
  }
}
]
