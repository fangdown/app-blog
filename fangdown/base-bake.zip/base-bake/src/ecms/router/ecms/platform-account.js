const tag = '/ecms/land-match/platform-account'
const platformAccount = () => import(/* webpackChunkName: "ecms" */ '../../pages/land-match/platform-account/list')
const platformAccountDetail = () => import(/* webpackChunkName: "ecms" */ '../../pages/land-match/platform-account/detail/platform-account-detail')

export default [{
  path: 'land-match/platform-account',
  component: platformAccount,
  meta: {
    tag,
    title: '账单管理'
  }
}, {
  path: 'land-match/platform-account-detail/:id',
  component: platformAccountDetail,
  meta: {
    tag,
    title: '账单详情',
    pageType: 'detail'
  }
}]
