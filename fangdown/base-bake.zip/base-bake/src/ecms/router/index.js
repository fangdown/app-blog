import ecms from './ecms'
import partner from './partner'

const layout = () => import(/* webpackChunkName: "ecms" */ '../pages/layout')

export default {
  layout,
  name: 'ecmsLayout',
  chunks: { ecms, tms: partner }
}
