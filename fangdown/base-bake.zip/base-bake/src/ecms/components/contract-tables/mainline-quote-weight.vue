
<template>
  <kye-table :data="tableData"
             border
             stripe
             class="ky-table"
             :header-cell-style="{background:'#F1F1F5'}"
             style="width: kye-%"
             @selection-change="handleDataInfoSelectionChange">
    <kye-table-column v-if="showSelection"
                      type="selection"
                      width="40"
                      fixed="left"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="relateContractName"
                      label="合同名称"
                      width="kye-"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="startPoint"
                      label="始发地"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="endPoint"
                      label="目的地"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="range"
                      label="重量区间（kg）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="bottomPrice"
                      label="保底价（元）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="bottomWeight"
                      label="保底重量（kg）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="totalKm"
                      label="总公里数（km）"
                      width="120"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="continueWeightPrice"
                      label="续票价格（元/kg）"
                      width="120"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="returnCargoDiscount"
                      label="回货折扣（%）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createPerson"
                      label="录入人"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createTime"
                      label="录入时间"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="status"
                      label="状态"
                      align="center"
                      width="80"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="remark"
                      label="备注"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
  </kye-table>
</template>

<script>
  export default {
    props: {
      showSelection: {
        type: Boolean,
        default: false
      },
      tableData: {
        type: Array,
        default () {
          return []
        }
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      }
    }
  }
</script>
