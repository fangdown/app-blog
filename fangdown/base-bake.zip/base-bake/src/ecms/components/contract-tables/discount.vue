
<template>
  <kye-table :data="tableData"
             border
             stripe
             class="ky-table"
             :header-cell-style="{background:'#F1F1F5'}"
             style="width: 100%"
             @selection-change="handleDataInfoSelectionChange">
    <kye-table-column v-if="showSelection"
                      type="selection"
                      width="40"
                      fixed="left"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column type="index"
                      width="50"></kye-table-column>
    <kye-table-column prop="range"
                      label="总运费区间"
                      width="180"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="discount"
                      label="折扣（%）"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createPerson"
                      label="录入人"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createTime"
                      label="录入时间"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
  </kye-table>
</template>

<script>
  export default {
    props: {
      showSelection: {
        type: Boolean,
        default: false
      },
      tableData: {
        type: Array,
        default () {
          return []
        }
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      }
    }
  }
</script>
