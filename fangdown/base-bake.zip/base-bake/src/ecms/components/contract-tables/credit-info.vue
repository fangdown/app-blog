<template>
  <div>
    <kye-table :data="tableData"
               max-height="500"
               border
               stripe
               class="ky-table"
               :header-cell-style="{background:'#F1F1F5'}"
               style="width: 100%"
               @selection-change="handleDataInfoSelectionChange">
      <kye-table-column v-if="showSelection"
                        type="selection"
                        width="40"
                        fixed="left"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakContractType"
                        label="违约类型"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakTime"
                        label="违约时间"
                        width="80"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="breakContent"
                        label="违约内容"
                        width="65"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="transportNo"
                        label="运单号/任务编码"
                        width="150"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="createPerson"
                        label="录入人"
                        width="55"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
      <kye-table-column prop="createTime"
                        label="录入时间"
                        align="center"
                        :show-overflow-tooltip="true">
      </kye-table-column>
    </kye-table>
  </div>
</template>

<script>
  export default {
    props: {
      tableData: {
        type: null,
        default: () => ({})
      },
      showSelection: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      },
    }
  }
</script>

