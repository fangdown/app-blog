
<template>
  <kye-table :data="tableData"
             border
             stripe
             class="ky-table"
             :header-cell-style="{background:'#F1F1F5'}"
             style="width: 100%"
             @selection-change="handleDataInfoSelectionChange">
    <kye-table-column v-if="showSelection"
                      type="selection"
                      width="40"
                      fixed="left"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="relateContractName"
                      label="合同名称"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="productTypeName"
                      label="货物类型"
                      align="center"
                      width="80"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="range"
                      label="重量区间（kg）"
                      align="center"
                      width="100"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="chargeByTicket"
                      label="计费（元/票）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="continuingTicketBase"
                      label="续票基数（票）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="continuingTicketUnit"
                      label="续票单价（元/票）"
                      width="120"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createPerson"
                      label="录入人"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createTime"
                      label="录入时间"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="status"
                      label="状态"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
  </kye-table>
</template>

<script>
  export default {
    props: {
      showSelection: {
        type: Boolean,
        default: false
      },
      tableData: {
        type: Array,
        default () {
          return []
        }
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      }
    }
  }
</script>
