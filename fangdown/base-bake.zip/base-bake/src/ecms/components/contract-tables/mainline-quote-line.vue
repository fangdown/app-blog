
<template>
  <kye-table :data="tableData"
             border
             stripe
             class="ky-table"
             :header-cell-style="{background:'#F1F1F5'}"
             style="width: 100%"
             @selection-change="handleDataInfoSelectionChange">
    <kye-table-column v-if="showSelection"
                      type="selection"
                      width="40"
                      fixed="left"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column type="index"
                      width="50"></kye-table-column>
    <kye-table-column prop="relateContractName"
                      label="合同名称"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="statusName"
                      label="计费状态"
                      width="65"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="carTypeName"
                      label="车型"
                      width="60"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="carLength"
                      label="车长"
                      align="center"
                      width="45"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="startPoint"
                      label="始发地"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="stopLand1"
                      label="经停地1"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="stopLand2"
                      label="经停地2"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="stopLand3"
                      label="经停地3"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="stopLand4"
                      label="经停地4"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="endPoint"
                      label="目的地"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="totalKm"
                      label="单边公里(km)"
                      width="90"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="includeLoadPoints"
                      label="含装卸点"
                      width="65"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="overLoadPoints"
                      label="超装卸点（元/个）"
                      width="115"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="transportAskPrice"
                      label="一口价"
                      width="115"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="returnPrice"
                      label="回程价"
                      width="115"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createPerson"
                      label="录入人"
                      width="60"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createTime"
                      label="录入时间"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="remark"
                      label="备注"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
  </kye-table>
</template>

<script>
  export default {
    props: {
      showSelection: {
        type: Boolean,
        default: false
      },
      tableData: {
        type: Array,
        default () {
          return []
        }
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      }
    }
  }
</script>
