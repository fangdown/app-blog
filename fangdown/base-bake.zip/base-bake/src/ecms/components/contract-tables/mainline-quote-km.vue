
<template>
  <kye-table :data="tableData"
             border
             stripe
             class="ky-table"
             :header-cell-style="{background:'#F1F1F5'}"
             style="width: 100%"
             @selection-change="handleDataInfoSelectionChange">
    <kye-table-column v-if="showSelection"
                      type="selection"
                      width="40"
                      fixed="left"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column type="index"
                      width="50"></kye-table-column>
    <kye-table-column prop="productTypeName"
                      label="货物类型"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="carTypeName"
                      label="车型"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="carLength"
                      label="车长(m)"
                      width="80"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="startKilometer"
                      label="起步公里（km）"
                      width="120"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="startPrice"
                      label="起步价"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="returnPricePercent"
                      label="回程价比（%）"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="range"
                      label="单边公里范围（km）"
                      width="140"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="unitPriceByKilometer"
                      label="公里单价"
                      width="70"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="statusName"
                      label="计费状态"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createName"
                      label="录入人"
                      align="center"
                      width="100"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="createdAt"
                      label="录入时间"
                      width="100"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
    <kye-table-column prop="remark"
                      label="备注"
                      align="center"
                      :show-overflow-tooltip="true">
    </kye-table-column>
  </kye-table>
</template>

<script>
  export default {
    props: {
      showSelection: {
        type: Boolean,
        default: false
      },
      tableData: {
        type: Array,
        default: () => ([])
      }
    },
    methods: {
      // 选中的列数据
      handleDataInfoSelectionChange (val) {
        this.$emit('selected-list', val)
      }
    }
  }
</script>
