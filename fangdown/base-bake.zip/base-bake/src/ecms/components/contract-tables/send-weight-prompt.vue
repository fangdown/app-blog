<template>
  <div class="prompt">
    <div class="prompt-heard">价格区间录入须知：</div>
    <div class="prompt-rules">1、重量区间录入时，设：X为起始重量，Y为结束重量，录入时记为X＜货物重量≤Y；</div>
    <div class="prompt-rules">2、最后一个重量区间录入时，区间的最大值录入为0，0代表∞（无穷大），例如：500＜货物重量≤0，代表货物重量在500kg以上。</div>
  </div>
</template>
<style lang="scss" scoped>
  .prompt {
    font-size: 12px;
    color: #333333;
  }
  .prompt-heard {
    font-weight: bold;
    padding: 6px 0;
  }
  .prompt-rules {
    padding-bottom: 5px;
  }
</style>


