
<template >
  <div>
    <!-- 省市区+详细地址 -->
    <div v-if="type===1">
      <kye-row>
        <kye-form-item label="地址"
                       :required="required">
          <kye-col :span="span1"
                   class="pl0">
            <kye-select placeholder=""
                        v-model="data.province"
                        @change="getCityList"
                        :clearable="false"
                        :required="required"
                        :disabled="disabled">
              <kye-option v-for="(item,index) in provinceList"
                          :key="index"
                          :label="item.province"
                          :value="item.provinceid +'#'+ item.province">
              </kye-option>
            </kye-select>
          </kye-col>
          <kye-col :span="span2">
            <kye-select placeholder=""
                        v-model="data.city"
                        @change="getAreaList"
                        :clearable="false"
                        :required="required"
                        :disabled="disabled">
              <kye-option v-for="item in cityList"
                          :key="item.id"
                          :label="item.city"
                          :value="item.cityid+'#'+ item.city">
              </kye-option>
            </kye-select>
          </kye-col>
          <kye-col :span="span3">
            <kye-select placeholder=""
                        v-model="data.area"
                        @change="selectArea"
                        :clearable="false"
                        :required="required"
                        :disabled="disabled">
              <kye-option v-for="item in areaList"
                          :key="item.id"
                          :label="item.area"
                          :value="item.areaid + '#'+ item.area">
              </kye-option>
            </kye-select>
          </kye-col>
          <kye-col :span="span4">
            <kye-input v-model="data.detail"
                       @change="detailBlur"
                       :required="required"
                       :maxlength="500"
                       :disabled="disabled"></kye-input>
          </kye-col>
        </kye-form-item>
      </kye-row>
    </div>

    <!-- 只有省、市 -->
    <div v-if="type===2">
      <kye-row>
        <kye-col :span="span1"
                 class="pl0">
          <kye-form-item label="所在省"
                         :required="required">
            <kye-select placeholder=""
                        v-model="data.province"
                        @change="getCityList"
                        :clearable="false"
                        :required="required"
                        :disabled="disabled">
              <kye-option v-for="(item,index) in provinceList"
                          :key="index"
                          :label="item.province"
                          :value="item.provinceid +'#'+ item.province">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
        <kye-col :span="span2">
          <kye-form-item label="所在市"
                         :required="required">
            <kye-select placeholder=""
                        v-model="data.city"
                        @change="selectCity"
                        :clearable="false"
                        :required="required"
                        :disabled="disabled">
              <kye-option v-for="item in cityList"
                          :key="item.id"
                          :label="item.city"
                          :value="item.cityid+'#'+ item.city">
              </kye-option>
            </kye-select>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </div>
  </div>
</template>

<script>
  import Api from './addr.api.js'

  export default {
    props: {
      // 类型
      type: {
        type: Number,
        default: function () {
          return 1
        }
      },
      // 回显数据
      data: {
        type: Object,
        default: () => ({
          province: '', // 省
          provinceId: '', // 省ID
          city: '', // 市
          cityId: '', // 市ID
          area: '', // 区
          areaId: '', // 区ID
          detail: '' // 详情
        })
      },
      required: {
        type: Boolean,
        default: false
      },
      disabled: {
        type: Boolean,
        default: false
      },
      gutter: {
        type: Number,
        default: 20
      },
      span1: {
        type: Number,
        default: 5
      },
      span2: {
        type: Number,
        default: 5
      },
      span3: {
        type: Number,
        default: 5
      },
      span4: {
        type: Number,
        default: 9
      }
    },
    data () {
      return {
        provinceList: [],
        cityList: [],
        areaList: [],
      }
    },
    activated () {
      this.getProvinceList()
    },
    mounted () {
      this.getProvinceList()
    },
    methods: {
      // 获取省下拉数据
      async getProvinceList () {
        if (!sessionStorage.getItem('ECMS_PROVINCE_LIST')) {
          const data = await this.$http(Api.getProvinceList, {})
          this.provinceList = data
          sessionStorage.setItem('ECMS_PROVINCE_LIST', JSON.stringify(data))
        } else {
          this.provinceList = JSON.parse(sessionStorage.getItem('ECMS_PROVINCE_LIST'))
        }
      },
      // 获取市下拉数据
      async getCityList (val) {
        if (this.data.provinceId !== Number(val.split('#')[0])) {
          this.data.city = '' // 清空城市数据
          this.data.area = '' // 清空区域数据
        }
        this.data.provinceId = Number(val.split('#')[0])
        this.data.province = String(val.split('#')[1])
        const data = await this.$http(Api.getCityList, { provinceId: Number(val.split('#')[0]) })
        this.cityList = data
        this.areaList = []
      },
      // 获取区数据
      async getAreaList (val) {
        if (this.data.cityId !== Number(val.split('#')[0])) {
          this.data.area = '' // 清空区域数据
        }
        this.data.cityId = Number(val.split('#')[0])
        this.data.city = String(val.split('#')[1])
        const data = await this.$http(Api.getAreaList, { cityId: Number(val.split('#')[0]) })
        this.areaList = data
      },
      // 选择区
      selectArea (val) {
        this.data.areaId = Number(val.split('#')[0])
        this.data.area = String(val.split('#')[1])
        this.$emit('addr', this.data)
      },
      // 选择市
      selectCity (val) {
        this.data.cityId = Number(val.split('#')[0])
        this.data.city = String(val.split('#')[1])
        this.$emit('addr', this.data)
      },
      // 地址详情输入框改变时触发
      detailBlur (e) {
        this.data.detail = String(this.data.detail)
        this.$emit('addr', this.data)
      }
    }
  }
</script>

