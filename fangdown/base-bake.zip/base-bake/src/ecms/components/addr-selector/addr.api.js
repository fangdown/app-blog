const prefix = 'ecs.yc.'

const Api = {
  getProvinceList: `${prefix}signedCompanyManage.GetProvinceList.do`, // 找不到
  getCityList: `${prefix}signedCompanyManage.GetCityList.do`, // 找不到
  getAreaList: `${prefix}signedCompanyManage.getAreaList.do`, // 找不到
}

export default Api
