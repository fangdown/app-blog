<template>
  <section v-loading="isLoading">
    <kye-row class="kye-dialog-body">
      <kye-col>
        <p class="title-type">小件报价</p>
        <kye-table :data="[data.small]"
                   class="column-margin">
          <kye-table-column prop="weight"
                            label="小件重量">
            <template slot-scope="scope">
              <kye-number unit="kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          @change="val=>data.big.weight = val"
                          v-model="scope.row.weight"></kye-number>
              <span v-else>≤{{scope.row.weight}}kg</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum1"
                            label="派件量(0,300]">
            <template slot-scope="scope">
              <kye-number unit="元/票"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum1"></kye-number>
              <span v-else>{{scope.row.dispatchNum1}}元/票</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum2"
                            label="派件量(300,600]">
            <template slot-scope="scope">
              <kye-number unit="元/票"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum2"></kye-number>
              <span v-else>{{scope.row.dispatchNum2}}元/票</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum3"
                            label="派件量(600,900]">
            <template slot-scope="scope">
              <kye-number unit="元/票"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum3"></kye-number>
              <span v-else>{{scope.row.dispatchNum3}}元/票</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum4"
                            label="派件量(900,+∞]">
            <template slot-scope="scope">
              <kye-number unit="元/票"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum4"></kye-number>
              <span v-else>{{scope.row.dispatchNum4}}元/票</span>
            </template>
          </kye-table-column>
        </kye-table>
      </kye-col>
      <kye-col>
        <p class="title-type">大件报价</p>
        <kye-table :data="[data.big]"
                   class="column-margin column-margin-nobottom">
          <kye-table-column prop="weight"
                            label="大件重量">
            <template slot-scope="scope">
              <kye-number unit="kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          @change="val=>data.small.weight = val"
                          v-model="scope.row.weight"></kye-number>
              <span v-else>>{{scope.row.weight}}kg</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="firstWeight"
                            label="5kg首重">
            <template slot-scope="scope">
              <kye-number unit="元"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.firstWeight"></kye-number>
              <span v-else>{{scope.row.firstWeight}}元</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum1"
                            label="重量(5,300]">
            <template slot-scope="scope">
              <kye-number unit="元/kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum1"></kye-number>
              <span v-else>{{scope.row.dispatchNum1}}元/kg</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum2"
                            label="重量(300,500]">
            <template slot-scope="scope">
              <kye-number unit="元/kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum2"></kye-number>
              <span v-else>{{scope.row.dispatchNum2}}元/kg</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum3"
                            label="重量(500,1000]">
            <template slot-scope="scope">
              <kye-number unit="元/kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum3"></kye-number>
              <span v-else>{{scope.row.dispatchNum3}}元/kg</span>
            </template>
          </kye-table-column>
          <kye-table-column prop="dispatchNum4"
                            label="重量(1000,+∞]">
            <template slot-scope="scope">
              <kye-number unit="元/kg"
                          v-if="type"
                          :clearable="false"
                          placeholder=""
                          v-model="scope.row.dispatchNum4"></kye-number>
              <span v-else>{{scope.row.dispatchNum4}}元/kg</span>
            </template>
          </kye-table-column>
        </kye-table>
      </kye-col>
    </kye-row>
    <div class="el-dialog__footer"
         v-show="!isDetail">
      <div v-show="type">
        <kye-button type="primary"
                    hotkey="ctrl+s"
                    @click="submit">保存(S)</kye-button>
        <kye-button @click="close">取消</kye-button>
      </div>
      <div v-show="!type">
        <kye-button type="primary"
                    @click.native="editTable">编辑</kye-button>
      </div>
    </div>
  </section>
</template>
<script>
  export default {
    props: {
      quoteData: Object
    },
    data () {
      return {
        isLoading: false,
        type: 0,
        data: {},
        isDetail: false
      }
    },
    created () {
      this.isDetail = this.$route.name === 'tms-partner-backstage-detail'
      this.setData()
    },
    methods: {
      // 初始化报价数据
      setData () {
        const small = {
          dispatchNum1: this.quoteData.small.dispatchNum1,
          dispatchNum2: this.quoteData.small.dispatchNum2,
          dispatchNum3: this.quoteData.small.dispatchNum3,
          dispatchNum4: this.quoteData.small.dispatchNum4,
          weight: this.quoteData.small.weight
        }
        const big = {
          dispatchNum1: this.quoteData.big.dispatchNum1,
          dispatchNum2: this.quoteData.big.dispatchNum2,
          dispatchNum3: this.quoteData.big.dispatchNum3,
          dispatchNum4: this.quoteData.big.dispatchNum4,
          firstWeight: this.quoteData.big.firstWeight,
          weight: this.quoteData.big.weight
        }
        this.data = { small, big }
      },
      // 编辑报价
      editTable () {
        this.type = 1
      },
      // 判断非法数据
      validate () {
        let validate = true
        const small = Object.values(this.data.small)
        const big = Object.values(this.data.big)
        for (let v of small) {
          if (v + '' === '') {
            return validate = false
          }
        }
        for (let v of big) {
          if (v + '' === '') {
            return validate = false
          }
        }
        return validate
      },
      submit () {
        const saveAble = this.validate()
        if (saveAble) {
          this.$emit('save', this.data)
          return this.close()
        } else {
          return this.$message({
            type: 'error',
            message: '请填写完整报价信息'
          })
        }
      },
      close () {
        this.type = 0
        this.$emit('close')
      }
    }
  }
</script>
<style lang="scss" scoped>
  .title-type {
    color: #333;
    &::before {
      content: "";
      margin-right: 12px;
      display: inline-block;
      height: 8px;
      width: 8px;
      border-radius: 50%;
      background-color: #ff9300;
    }
  }
  .kye-dialog-body {
    margin: 0 !important;
  }
  .column-margin {
    margin: 8px 0 16px;
    &.column-margin-nobottom {
      margin-bottom: 0px;
    }
  }
</style>
