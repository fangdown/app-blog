<template>
  <div>
    <section class="kye-dialog-body">
      <kye-form label-width="auto"
                inline>
        <!-- <kye-row> -->
        <!-- <kye-col :span="4"> -->
        <kye-form-item label="点部名称">
          <kye-input v-model="request.pointName"
                     clearable></kye-input>
        </kye-form-item>
        <!-- </kye-col> -->
        <!-- <kye-col :span="4"> -->
        <kye-form-item label="点部负责人">
          <kye-input v-model="request.pointLeader"
                     clearable></kye-input>
        </kye-form-item>
        <!-- </kye-col> -->
        <!-- <kye-col :span="4"> -->
        <kye-form-item label=" ">
          <kye-button type="primary"
                      icon="iconfont icon-search"
                      auth="partner.point.search"
                      @click="getList">查询</kye-button>
        </kye-form-item>
        <!-- </kye-col> -->
        <!-- </kye-row> -->
      </kye-form>
      <table-list :column="columns"
                  :data="tableList"
                  :options="tableOptions"
                  :dialog="true"
                  style="margin-top:4px"></table-list>
    </section>
    <div class="el-dialog__footer">
      <kye-pagination :page-sizes="$pagination.pageSizes"
                      :layout="$pagination.layout"
                      :total="total"
                      :current-page="page"
                      :page-size="pageSize"
                      @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"></kye-pagination>
    </div>
  </div>
</template>
<script>
  import mixins from 'public/mixins'
  export default {
    mixins: [mixins],
    data () {
      return {
        request: {
          pointLeader: '',
          pointName: ''
        },
        total: 0,
        page: 1,
        pageSize: 20,
        tableList: [],
        columns: [
          {
            label: '点部名称',
            key: 'pointName',
            width: '90px',
            show: true
          }, {
            label: '走货否',
            key: 'transportGoods',
            width: '52px',
            show: true,
            filter: {
              type: 'lookUp',
              args: ['common_yes_no']
            }
          }, {
            label: '点部地址',
            key: 'nodeAddress',
            width: '86px',
            show: true
          }, {
            label: '点部负责人',
            key: 'pointLeader',
            width: '76px',
            show: true
          }, {
            label: '所属级别',
            key: 'pointLevel',
            width: '64px',
            show: true
          }, {
            label: '联系电话',
            key: 'pointLeaderContact',
            width: '90px',
            show: true
          }, {
            label: '所属点部',
            width: '86px',
            key: 'alongTo',
            show: true
          }
        ],
        tableOptions: {
          moduleCode: 'partner',
          detailAuth: 'partner.basic.get',
          rowDblClick: (val) => { return this.goDetail(val) }
        }
      }
    },
    methods: {
      // 获取列表
      async getList () {
        let postData = {
          vo: this.request,
          page: this.page,
          pageSize: this.$pagination.pageSize
        }
        let res = await this.$http('partner.point.search', postData)
        this.tableList = res.rows
        this.total = res.rowTotal
      },
      // 调整至详情
      goDetail (row, e) {
        this.$emit('goDetail', row)
      },
      //  分页大小改变
      handleSizeChange (val) {
        this.pageSize = val
        this.getList()
      },
      //  当前页下标改变
      handleCurrentChange (val) {
        this.page = val
        this.getList()
      }
    },
    // 取消默认加载数据
    // created () {
    //   this.getList()
    // }
  }
</script>

<style lang="scss" scoped>
  .query-branch {
    margin: 10px;
  }
</style>
