<template>
  <section>
    <div class="kye-dialog-body">
      <kye-upload code="partner_basic_license"
                  :id="`${id}_${type}_license`"
                  ref="upload"
                  btn-type="text"
                  :accept="['image']"
                  :attr="uploadAttr"
                  :disabled="fileList.length>=3"
                  @success="uploadSuccess"></kye-upload>
      <kye-table :data="fileList"
                 style="margin-top:4px">
        <kye-table-column prop="name"
                          label="文件名">
          <template slot-scope="scope">
            <kye-button type="text"
                        class="button-text"
                        @click="previewFile(scope.row)">{{scope.row.name}}</kye-button>
          </template>
        </kye-table-column>
        <kye-table-column prop="updatedBy"
                          label="上传人"></kye-table-column>
        <kye-table-column prop="updationDate"
                          label="上传时间"
                          width="120px"
                          :formatter="formatV"></kye-table-column>
        <kye-table-column label="操作"
                          width="46px">
          <template slot-scope="scope">
            <kye-button type="text"
                        @click="deleteFile(scope.$index,scope.row)">删除</kye-button>
          </template>
        </kye-table-column>
      </kye-table>
    </div>
    <div class="el-dialog__footer">
      <kye-button @click="close"
                  type="primary">关闭</kye-button>
    </div>
  </section>
</template>
<script>
  import { minute } from 'public/utils'
  export default {
    props: {
      id: String,
      files: {
        type: Array,
        default: () => {
          return []
        }
      },
      type: String
    },
    data () {
      return {
        fileList: [],
        uploadAttr: {
          'show-file-list': false,
          limit: 3,
          'on-exceed': () => {
            this.$message({ type: 'error', message: '最多上传3张图片' })
          }
        }
      }
    },
    created () {
      this.fileList = [...this.files]
    },
    methods: {
      formatV (r, c, v, i) {
        return minute(v)
      },
      previewFile (file) {
        return this.$refs.upload.handlePreview(file)
      },
      uploadSuccess (data) {
        this.fileList = [...data]
        this.$emit('change', this.fileList, this.type)
      },
      deleteFile (index, row) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示')
          .then(() => {
            const params = { bizCode: row.bizCode, bizId: row.bizId, id: row.id }
            this.$http('file.deleteByBizAndId', params).then(res => {
              if (res) {
                this.fileList.splice(index, 1)
                this.$emit('change', this.fileList, this.type)
                return this.$message.success('删除成功')
              } else {
                return this.$message.error('删除失败')
              }
            }).catch(() => {
              return this.$message.error('删除失败')
            })
          }).catch(() => {
            return false
          })
      },
      close () {
        this.$emit('close')
      }
    }
  }
</script>
<style lang="scss" scoped>
  .button-text {
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
