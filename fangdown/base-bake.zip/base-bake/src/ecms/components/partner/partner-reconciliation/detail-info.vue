<template>
  <div>
    <kye-form :model="queryForm"
              label-width="auto"
              inline>
      <form-item-menu :option="option"
                      :model="queryForm"></form-item-menu>
      <kye-form-item label="运单号">
        <kye-input v-model="queryForm.waybillNumber"
                   clearable
                   style="width:116px;"></kye-input>
      </kye-form-item>
      <kye-button icon="iconfont icon-search"
                  size="small"
                  @click="searchList"
                  auth="partner.partnerWaybill.search"
                  type="primary">查询</kye-button>
    </kye-form>
    <kye-form :model.sync="reconciliationForm"
              module-code="partner"
              :biz-id="id"
              ref="addForm"
              label-width="auto"
              label-position="left"
              class="kye-detail"
              inline>
      <kye-form-item label="公司全称"
                     prop="companyName">
        <kye-field style="width:128px;background-color:#ECECF5">{{reconciliationForm.companyName}}</kye-field>
      </kye-form-item>
      <kye-form-item label="一级点部"
                     prop="pointName">
        <kye-field style="width:128px;background-color:#ECECF5">{{reconciliationForm.pointName}}</kye-field>
      </kye-form-item>
      <kye-form-item label="部门"
                     prop="departmentName">
        <kye-field style="width:128px;background-color:#ECECF5">{{reconciliationForm.departmentName}}</kye-field>
      </kye-form-item>
      <kye-form-item label="审核人"
                     prop="auditBy">
        <kye-field style="width:86px;background-color:#ECECF5">{{reconciliationForm.auditBy}}</kye-field>
      </kye-form-item>
      <kye-form-item label="审核时间"
                     prop="auditTime">
        <kye-field style="width:122px;background-color:#ECECF5">{{+reconciliationForm.auditTime | minute}}</kye-field>
      </kye-form-item>
      <kye-form-item label="月度额外奖"
                     prop="monthExtraPrize">
        <kye-field style="width:90px;background-color:#ECECF5">{{reconciliationForm.monthExtraPrize | money}}</kye-field>
      </kye-form-item>
    </kye-form>
    <!--统计信息-->
    <kye-form :model.sync="summaryData"
              module-code="partner"
              :biz-id="id"
              label-width="auto"
              inline
              class="kye-data-rows backcolor">
      <kye-button type="text"
                  style="margin-right:32px"
                  icon="iconfont icon-ecs-xiugaibaojia"
                  auth="partner.reconciliation.update"
                  @click="modifyMonthExtra">修改月度奖</kye-button>
      <kye-form-item label="应付总款额 :"
                     prop="summaryTotalPayment">
        <strong>{{summaryData.summaryTotalPayment||'0'|money}}</strong>
      </kye-form-item>
      <kye-form-item label="派送总票数 :"
                     prop="deliveryTotalNumber">
        <strong>{{summaryData.deliveryTotalNumber||0|thousands}}</strong>
      </kye-form-item>
      <kye-form-item label="派送总运费 :"
                     prop="deliveryTotalFee">
        <strong>{{summaryData.deliveryTotalFee||'0'|money}}</strong>
      </kye-form-item>
      <kye-form-item label="月扣款总额 :"
                     prop="totalAmountDeduction">
        <strong>{{summaryData.totalAmountDeduction||'0'|money}}</strong>
      </kye-form-item>
      <kye-form-item label="其它总费 :"
                     prop="summaryOtherChargin">
        <strong>{{summaryData.summaryOtherChargin||'0'|money}}</strong>
      </kye-form-item>
      <kye-form-item label="总重量 :"
                     prop="summaryThrowOutWeight">
        <strong>{{summaryData.summaryThrowOutWeight||0|thousands}}</strong>
      </kye-form-item>
      <!-- <kye-form-item label="月度额外奖 :"
                     prop="monthExtraPrize">
        <strong>{{summaryData.monthExtraPrize||'0'|money}}</strong>
      </kye-form-item> -->
      <kye-form-item label="准达率 :"
                     prop="arrivalRate">
        <strong>{{summaryData.arrivalRate||0}}%</strong>
      </kye-form-item>
    </kye-form>
    <kye-dialog v-if="dialogOption.show"
                v-bind="dialogOption"
                :visible.sync="dialogOption.show">
      <component :is="dialogOption.view"
                 :id="id"
                 :data="reconciliationForm"
                 @success="chengeExtra"
                 @close="dialogOption.show = false">
      </component>
    </kye-dialog>
  </div>
</template>

<script>
  import mixins from 'public/mixins'
  import { time } from 'public/utils'
  import modifyExtra from './modify-extra'
  export default {
    mixins: [mixins],
    props: {
      id: String,
      data: Object,
      queryParams: Object
    },
    components: { modifyExtra },
    data () {
      return {
        pickType: 0,
        summaryData: {},
        dialogOption: {
          show: false,
          view: 'modifyExtra',
          title: '修改月度额外奖'
        },
        option: {
          change: val => {
            if (val.key === 'deliveryDate') {
              this.pickType = 0
            } else {
              this.pickType = 1
            }
            return val.model[val.key] = [time(this.reconciliationForm.deliveryMonth), time(this.defaultEndDate)]
          },
          options: [
            {
              propertyName: 'deliveryDate',
              label: '派送时间',
              type: 'datePicker',
              dateType: 'daterange',
              placeholder: '请输入派送时间',
              filter: 'date',
              attr: {
                'editable': false,
                'clearable': false,
                'picker-options': {
                  disabledDate: val => {
                    return val.getMonth() + 1 !== this.selectMonth
                  }
                }
              }
            },
            {
              propertyName: 'signDate',
              label: '签收时间',
              type: 'datePicker',
              dateType: 'daterange',
              filter: 'date',
              attr: {
                'editable': false,
                'clearable': false,
                'picker-options': {
                  disabledDate: val => {
                    return val.getMonth() + 1 !== this.selectMonth
                  }
                }
              }
            }
          ]
        },
        queryForm: {
          signDate: '',
          deliveryDate: '',
          waybillNumber: ''
        },
        reconciliationForm: {},
        selectMonth: 0
      }
    },
    activated () {
      this.reconciliationForm = this.queryParams
      this.selectMonth = new Date(this.reconciliationForm.deliveryMonth).getMonth() + 1
      let start = time(this.reconciliationForm.deliveryMonth)
      let end = time(this.defaultEndDate)
      this.queryForm.deliveryDate = [start, end]
      this.queryForm.waybillNumber = this.reconciliationForm.waybillNumber
      return this.$emit('change', this.queryForm)
    },
    watch: {
      data (val) {
        this.summaryData = val
      },
      queryParams (val) {
        if (this.queryParams.deliveryMonth) {
          this.reconciliationForm = this.queryParams
          this.selectMonth = new Date(this.reconciliationForm.deliveryMonth).getMonth() + 1
          this.queryForm.deliveryDate = [time(this.reconciliationForm.deliveryMonth), time(this.defaultEndDate)]
        }
      }
    },
    computed: {
      // 计算派送时间/签收时间当前月最后一天
      defaultEndDate () {
        let date = new Date(this.reconciliationForm.deliveryMonth)
        let Y = date.getFullYear()
        let curMonth = date.getMonth() + 1
        let curLastDate = new Date(Y, curMonth)
        return new Date(curLastDate.getTime() - 1000)
      }
    },
    methods: {
      // 查询
      searchList () {
        this.queryForm.type = 1
        if (this.pickType) {
          this.queryForm.deliveryDate = null
        } else {
          this.queryForm.signDate = null
        }
        this.$emit('searchList', this.queryForm)
      },
      onFilter (filter, val) {
        let str = this[filter](val)
        if (filter === 'decimal') str += '%'
        return str
      },
      // 修改额外奖成功
      chengeExtra (val) {
        this.reconciliationForm.monthExtraPrize = val
      },
      modifyMonthExtra () {
        this.dialogOption.show = true
      }
    }
  }
</script>
<style lang="scss" scoped>
  .kye-data-rows {
    height: 28px !important;
    margin: 0 0 4px;
    padding: 0 !important;
    background-color: transparent;
    .el-form-item--mini.el-form-item {
      margin: 0px 24px 0 0 !important;
      font-size: 12px;
      strong {
        font-size: 12px;
      }
    }
  }
  .kye-field-content {
    background-color: #f5f5f5;
  }
  .el-form-item--mini.el-form-item {
    margin-bottom: 4px !important;
  }
  .kye-detail {
    .el-col {
      height: 28px;
      margin-bottom: 4px;
    }
  }
</style>
