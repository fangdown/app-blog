<template>
  <section v-loading="isLoading">
    <kye-form class="kye-dialog-body"
              :model.sync="formData"
              :biz-id="id"
              module-code="partner">
      <kye-form-item label="月度额外奖"
                     prop="monthExtraPrize">
        <kye-number symbol="￥"
                    :precision="2"
                    placeholder=""
                    v-model="formData.monthExtraPrize"></kye-number>
      </kye-form-item>
    </kye-form>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  hotkey="ctrl+s"
                  auth="partner.reconciliation.update"
                  @click="submit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </section>
</template>
<script>
  export default {
    props: {
      data: Object,
      id: String
    },
    data () {
      return {
        isLoading: false,
        formData: {}
      }
    },
    created () {
      this.formData = JSON.parse(JSON.stringify(this.data))
    },
    methods: {
      submit () {
        if (this.formData.monthExtraPrize + '' === '') {
          return this.$message.error('请填写月度额外奖!')
        }
        this.isLoading = true
        const vo = {
          id: this.id,
          monthExtraPrize: this.formData.monthExtraPrize
        }
        this.$http('partner.reconciliation.update', { vo }).then(res => {
          this.$message({
            type: 'success',
            message: '保存成功'
          })
          this.isLoading = false
          this.$emit('success', vo.monthExtraPrize)
          return this.close()
        }).catch(() => { this.isLoading = false })
      },
      close () {
        this.$emit('close')
      }
    }
  }
</script>
