## ecms系统版本分支管理

### 流程图-日常开发
![](./pages/assets/images/flow-normal.jpg)

### 流程图-紧急修复
![](./pages/assets/images/flow-prod.jpg)
