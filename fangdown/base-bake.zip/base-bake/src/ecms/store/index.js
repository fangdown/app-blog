export default {
  namespaced: true,
  state: {
    sys_guid: '',
    billDetail: null,
    billList: null,
    driverData: null,
    ecs_wholecar_reparams: null,
    ecs_finace_enterprise: null,
    contractRefresh: false
  },
  getters: {
    FINACE_BillDetail: state => { return state.billDetail },
    FINACE_BillList: state => { return state.billList },
    ecs_finace_enterprise: state => { return state.ecs_finace_enterprise },
    ecs_wholecar_reparams: (state) => {
      return state.ecs_wholecar_reparams
    },
    CONTRACT_DriverData: state => { return state.driverData },
  },
  mutations: {
    SET_SYS_GUID (state, payload) {
      state.sys_guid = payload.id
    },
    FINACE_BillDetail (state, payload) {
      state.billDetail = payload
    },
    FINACE_BillList (state, payload) {
      state.billList = payload
    },
    SET_ECS_FINACE_ENTERPRISE (state, params) {
      state.ecs_finace_enterprise = params
    },
    SET_ECS_WHOLECAR_REPARAMS (state, params) {
      state.ecs_wholecar_reparams = params
    },
    SET_CONTRACT_DRIVER_DATA (state, params) {
      state.driverData = params
    }
  },
  actions: {},
  modules: {}
}
