<script>
  export default {
    name: 'kye-field',
    props: {
      value: [String, Number]
    },
    render (h) {
      let title = this.$slots && this.$slots.default && this.$slots.default[0] && this.$slots.default[0].text
      return (
        <span class="kye-field-content" title={this.value || title || ''}>
          <label>{this.value !== undefined ? this.value : this.$slots.default}</label>
        </span>
      )
    }
  }
</script>
