import Vue from 'vue'

const KyeTable = Vue.component('kye-table', {
  functional: true,
  render (h, self) {
    let { attrs } = self.data
    if (attrs.border === void 0) {
      attrs.border = true
    }
    if (attrs.stripe === void 0) {
      attrs.stripe = true
    }
    if (attrs['highlight-current-row'] === void 0) {
      attrs[['highlight-current-row']] = true
    }
    return h('el-table', self.data, self.children)
  }
})

export default KyeTable
