import { version, MessageBox } from 'element-ui'
import * as filters from '../utils/filter'
import directives from '../directives'
import { CHARTS_THEME, PAGINATION } from '../config'
import { http } from '../utils/http'
import rules from '../utils/rules'
import pattern from '../utils/pattern'
import { filterParams } from '../utils/common'

import '../assets/scss/element-variables.scss'
import '../assets/scss/app.scss'

// QueryTable
import FormItemMenu from './query-table/form-item-menu'
import QueryForm from './query-table/query-form'
import QueryTable from './query-table/index'
import SearchPager from './query-table/search-pager'
import TableList from './query-table/table-list'
import ToolList from './query-table/tool-list'

// 重写 el 组件
import ELPagination from './el-pagination/index'
import ELTable from './el-table/index'
import ELTableColumn from './el-table/src/table-column'
import ELTabs from './el-tabs/index'
import ELTabPane from './el-tabs/src/tab-pane'

// KYE组件库
import KyeAreaRemote from './kye-area-remote'
import KyeAutocomplete from './kye-autocomplete'
import KyeBadge from './kye-badge/index.vue'
import KyeButton from './kye-button'
import kyeCanvasTable from './kye-canvas-table'
import KyeCard from './kye-card'
import KyeCascader from './kye-cascader'
import KyeCheckbox from './kye-checkbox'
import KyeCheckboxButton from './kye-checkbox-button'
import KyeCheckboxGroup from './kye-checkbox-group'
import KyeCol from './kye-col'
import KyeDatePicker from './kye-date-picker'
import KyeDataRange from './kye-date-picker/date-range'
import KyeDecrypt from './kye-decrypt'
import KyeDialog from './kye-dialog'
import KyeDropdown from './kye-dropdown'
import KyeDropdownItem from './kye-dropdown-item'
import KyeDropdownMenu from './kye-dropdown-menu'
import KyeEditTable from './kye-edit-table'
import KyeExpandPage from './kye-expand-page'
import KyeDetailTable from './kye-edit-table/detail'
import KyeField from './kye-field'
import KyeForm from './kye-form'
import KyeFormItem from './kye-form-item'
import KyeImage from './kye-image'
import KyeInput from './kye-input'
import KyeInputNumber from './kye-input-number'
import KyeNumber from './kye-number/index'
import KyeOption from './kye-option'
import KyePopover from './kye-popover'
import KyeRadio from './kye-radio'
import KyeRadioGroup from './kye-radio-group'
import KyeRow from './kye-row'
import KyeSearchTips from './kye-search-tips'
import KyeSelect from './kye-select/index.vue'
import KyeStep from './kye-step'
import KyeSteps from './kye-steps'
import KyePagination from './kye-pagination'
import KyeTable from './kye-table'
import KyeTableColumn from './kye-table-column'
import KyeTabs from './kye-tabs'
import KyeTabPane from './kye-tab-pane'
import KyeTag from './kye-tag'
import KyeTimePicker from './kye-time-picker/index.vue'
import KyeTimeSelect from './kye-time-select'
import KyeUpload from './kye-upload'

const components = [
  FormItemMenu,
  QueryForm,
  QueryTable,
  SearchPager,
  TableList,
  ToolList,
  ELPagination,
  ELTable,
  ELTableColumn,
  ELTabs,
  ELTabPane,
  KyeAreaRemote,
  KyeAutocomplete,
  KyeBadge,
  KyeButton,
  kyeCanvasTable,
  KyeCard,
  KyeCascader,
  KyeCheckbox,
  KyeCheckboxButton,
  KyeCheckboxGroup,
  KyeCol,
  KyeDatePicker,
  KyeDataRange,
  KyeDecrypt,
  KyeDialog,
  KyeDropdown,
  KyeDropdownItem,
  KyeDropdownMenu,
  KyeEditTable,
  KyeExpandPage,
  KyeDetailTable,
  KyeField,
  KyeForm,
  KyeFormItem,
  KyeImage,
  KyeInput,
  KyeInputNumber,
  KyeNumber,
  KyeOption,
  KyePopover,
  KyeRadio,
  KyeRadioGroup,
  KyeRow,
  KyeSearchTips,
  KyeSelect,
  KyeStep,
  KyeSteps,
  KyePagination,
  KyeTable,
  KyeTableColumn,
  KyeTabs,
  KyeTabPane,
  KyeTag,
  KyeTimePicker,
  KyeTimeSelect,
  KyeUpload
]

const setPrototype = (Vue) => {
  Vue.prototype.$bus = new Vue()
  Vue.prototype.$rule = rules
  Vue.prototype.$reg = pattern
  Vue.prototype.$http = http
  Vue.prototype.$chartsTheme = CHARTS_THEME
  Vue.prototype.$pagination = PAGINATION
  Vue.prototype.$diff = filterParams

  Vue.prototype.$refreshMainQueryTable = function (tag) {
    tag = tag || this.$route.meta.tag
    this.$store.commit('queryTable/refresh', tag)
  }

  Vue.prototype.$filter = Object.keys(filters).reduce((s, key) => {
    Vue.filter(key, filters[key])
    s[key] = filters[key]
    return s
  }, {})

  Object.assign(Vue.prototype.$ELEMENT, { version })
}

const setDirective = (Vue) => {
  Object.keys(directives).forEach(v => Vue.directive(v, directives[v]))
}

const install = function (Vue) {
  window.$version = { vue: Vue.version, ele: version }
  components.filter(v => typeof v !== 'function').forEach(v => Vue.component(v.name, v))
  setPrototype(Vue)
  setDirective(Vue)
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

// 自定义 MessageBox 默认配置
MessageBox.setDefaults({
  type: 'warning',
  showClose: true,
  closeOnClickModal: false,
  closeOnPressEscape: false
})

export default install
