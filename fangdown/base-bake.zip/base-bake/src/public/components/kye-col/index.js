import Vue from 'vue'

const KyeCol = Vue.component('kye-col', {
  functional: true,
  render (h, self) {
    return h('el-col', self.data, self.children)
  }
})

export default KyeCol
