import Vue from 'vue'

const KyeRadio = Vue.component('kye-radio', {
  functional: true,
  render (h, self) {
    return h('el-radio', self.data, self.children)
  }
})

export default KyeRadio
