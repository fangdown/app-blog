import Vue from 'vue'

const KyeSteps = Vue.component('kye-steps', {
  functional: true,
  render (h, self) {
    return h('el-steps', self.data, self.children)
  }
})

export default KyeSteps
