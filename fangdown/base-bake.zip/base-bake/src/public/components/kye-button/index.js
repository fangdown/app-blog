import Vue from 'vue'
import store from 'public/store'

const menus = store.getters.permission.menus

const KyeButton = Vue.component('kye-button', {
  functional: true,
  render (h, self) {
    const { attrs } = self.data
    if (attrs && self.props.auth) {
      attrs.auth = self.props.auth
      if (!self.props.auth.startsWith('crm$$')) {
        attrs.disabled = !menus.includes(self.props.auth) || attrs.disabled
      }
    }
    return h('el-button', self.data, self.children)
  },
  props: {
    auth: String
  }
})

export default KyeButton
