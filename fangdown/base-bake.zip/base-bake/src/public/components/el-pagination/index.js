import Pagination from './src/pagination'

export default Pagination
