import Vue from 'vue'

const KyeCheckboxGroup = Vue.component('kye-checkbox-group', {
  functional: true,
  render (h, self) {
    return h('el-checkbox-group', self.data, self.children)
  }
})

export default KyeCheckboxGroup
