import Vue from 'vue'

const KyeCheckboxButton = Vue.component('kye-checkbox-button', {
  functional: true,
  render (h, self) {
    return h('el-checkbox-button', self.data, self.children)
  }
})

export default KyeCheckboxButton
