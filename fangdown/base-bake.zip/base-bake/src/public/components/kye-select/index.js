import Vue from 'vue'

// 输入子项序号自动匹配选择
const filterByIndex = (val, context) => {
  let index = +val - 1
  const { options } = context.props
  if (options && options[index] && !isNaN(index)) {
    let value = context.data.attrs && context.data.attrs.multiple ? [options[index]] : options[index]
    context.data.props.value = value
    context.data.model.value = value
    context.data.model.callback(value)
    context.listeners.change && context.listeners.change(value)
  }
}

const KyeSelect = Vue.component('kye-select', {
  functional: true,
  render (h, self) {
    const { attrs } = self.data
    let clearable = self.props.clearable
    if (attrs && !self.props.hasOwnProperty('filterable')) {
      attrs.clearable = clearable === undefined ? true : clearable
      attrs.filterable = true
      attrs.filterMethod = val => filterByIndex(val, self)
    } else if (!attrs) {
      self.data.attrs = {
        clearable: clearable === undefined ? true : clearable,
        filterable: true,
        filterMethod: val => filterByIndex(val, self)
      }
    }
    if (attrs && attrs.disabled !== undefined) {
      if (attrs.disabled === '' || attrs.disabled === true) {
        attrs.placeholder = attrs.placeholder ? attrs.placeholder : ' '
      }
    }
    self.data.attrs.defaultFirstOption = true
    if (typeof self.props.value === 'number' && self.props.toStr !== false) {
      self.data.attrs.value = String(self.props.value)
      self.data.props.value = String(self.props.value)
      self.data.model.value = String(self.props.value)
    }
    if (!self.props.options) {
      self.props.options = self.children && self.children
        .filter(v => !!v.componentOptions)
        .map(t => t.componentOptions.propsData.value)
    }
    return h('el-select', self.data, self.children)
  }
})

export default KyeSelect
