<script>
export default {
  name: 'kye-time-picker',
  mounted () {
    this.resetEnter()
  },
  render (h) {
    let data = this.$vnode.data
    let on = data.on || {}
    data.on = {...on, ...this.$listeners}

    let attrs = this.$attrs
    let props = data.props || {}
    let value = props.value || attrs.value || ''

    let valueFormat = attrs['value-format'] || attrs.valueFormat || 'HH:mm:ss'

    if (typeof value === 'number') {
      value = new Date(value)
      if (data.model) {
        data.model = {...data.model, value}
      }
    }

    data.props = {...props, value, valueFormat}

    return h('el-time-picker', data, this.$slots.default)
  },
  methods: {
    resetEnter () {
      let c = this.$children[0]
      if (c) {
        c.handleKeydown = (e) => {
          const keyCode = e.keyCode

          // ESC
          if (keyCode === 27) {
            c.pickerVisible = false
            e.stopPropagation()
            return
          }

          // Tab
          if (keyCode === 9) {
            if (!c.ranged) {
              c.handleChange()
              c.pickerVisible = c.picker.visible = false
              c.blur()
              e.stopPropagation()
            } else {
              // user may change focus between two input
              setTimeout(() => {
                if (c.refInput.indexOf(document.activeElement) === -1) {
                  c.pickerVisible = false
                  c.blur()
                  e.stopPropagation()
                }
              }, 0)
            }
            return
          }

          // Enter
          if (keyCode === 13) {
            if (c.userInput === '' || c.isValidValue(c.parseString(c.displayValue))) {
              c.handleChange()
              c.pickerVisible = c.picker.visible = false
              // c.blur()
            }
            e.stopPropagation()
            return
          }

          // if user is typing, do not let picker handle key input
          if (c.userInput) {
            e.stopPropagation()
            return
          }

          // delegate other keys to panel
          if (c.picker && c.picker.handleKeydown) {
            c.picker.handleKeydown(e)
          }
        }
      }
    },
    focus () {
      this.$children[0] && this.$children[0].focus()
    }
  }
}
</script>
