import Vue from 'vue'

const KyeTimePicker = Vue.component('kye-time-picker', {
  functional: true,
  render (h, self) {
    const { attrs } = self.data
    const model = self.data.model.value
    if (typeof model === 'number') {
      self.data.model.value = new Date(model)
    }
    let valueFormat = self.props.valueFormat || 'HH:mm:ss'
    if (attrs && !attrs.valueFormat) {
      attrs.valueFormat = valueFormat
    } else if (!attrs) {
      self.data.attrs = { valueFormat }
    }
    return h('el-time-picker', self.data, self.children)
  }
})

export default KyeTimePicker
