import Vue from 'vue'

const KyeTableColumn = Vue.component('kye-table-column', {
  functional: true,
  render (h, self) {
    if (self.data.attrs) {
      self.data.attrs.align = 'left'
    } else {
      self.data.attrs = { align: 'left' }
    }
    if (self.data.attrs.type === 'index') {
      self.data.attrs.label = '序号'
    }
    return h(
      'el-table-column',
      self.data,
      self.children
    )
  }
})

export default KyeTableColumn
