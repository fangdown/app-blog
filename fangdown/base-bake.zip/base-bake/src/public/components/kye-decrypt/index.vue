<template>
  <span :class="(maskFiled.mask || maskFiled.virtual) && maskFiled.filed && String(maskFiled.filed).includes('****') ? 'kye-label-click' : ''"
        @click="getSensitiveField">
    <slot></slot>
  </span>
</template>

<script>
  import AsyncValidator from 'async-validator'
  import { noop } from 'element-ui/src/utils/util'
  import { decrypt } from 'public/utils/common'

  export default {
    name: 'kye-decrypt',
    data () {
      return {
        pathArr: this.$parent.prop ? this.$parent.prop.split('.') : [],
        pathLen: this.$parent.prop ? this.$parent.prop.split('.').length - 1 : 0
      }
    },
    created () {
      this.rewriteValidate()
    },
    computed: {
      model () {
        return this.$parent.form.model
      },
      module () {
        return this.$parent.$attrs['module-code'] || this.$parent.form.$attrs['module-code']
      },
      dataId () {
        return this.$parent.$attrs['biz-id'] || this.$parent.form.$attrs['biz-id']
      },
      maskFiled () {
        let mask = null
        let virtual = null
        let filed = null
        if (this.model) {
          let tempModel = JSON.parse(JSON.stringify(this.model))
          this.pathArr.forEach((t, i) => {
            if (i === this.pathLen) {
              filed = tempModel[t]
              if (tempModel[t + 'Mask']) {
                mask = tempModel[t + 'Mask']
              }
              if (tempModel[t + 'Virtual']) {
                virtual = tempModel[t + 'Virtual']
              }
              if (tempModel[t + 'MaskSec']) {
                // this.hideItem()
              }
            }
            tempModel = tempModel[t]
          })
        }
        return { mask, virtual, filed }
      }
    },
    methods: {
      rewriteValidate () {
        let parent = this.$parent
        // 重写FormItem中的validate方法
        parent.validate = (trigger, callback = noop) => {
          // 判断字段中包含**，则不做表单校验，并清空校验信息
          let field = parent.fieldValue
          if (field && String(field).includes('****')) {
            parent.clearValidate()
            callback()
            return true
          } else {
            parent.validateDisabled = false
            const rules = parent.getFilteredRule(trigger)
            if ((!rules || rules.length === 0) && parent.required === undefined) {
              callback()
              return true
            }
            parent.validateState = 'validating'
            const descriptor = {}
            if (rules && rules.length > 0) {
              rules.forEach(rule => {
                delete rule.trigger
              })
            }
            descriptor[parent.prop] = rules
            const validator = new AsyncValidator(descriptor)
            const model = {}
            model[parent.prop] = parent.fieldValue
            validator.validate(model, { firstFields: true }, (errors, invalidFields) => {
              parent.validateState = !errors ? 'success' : 'error'
              parent.validateMessage = errors ? errors[0].message : ''
              callback(parent.validateMessage, invalidFields)
              parent.elForm && parent.elForm.$emit('validate', parent.prop, !errors)
            })
          }
        }
      },
      hideItem () {
        // 敏感字段，隐藏该字段
        this.$parent.$el.querySelector('.el-form-item__content > *').style.display = 'none'
      },
      async getSensitiveField () {
        let type = this.maskFiled.mask ? 'mask' : this.maskFiled.virtual ? 'virtual' : ''
        if (!((type === 'mask' || type === 'virtual') && this.maskFiled.filed && String(this.maskFiled.filed).includes('****'))) {
          return
        }
        let data = await decrypt({
          dataId: this.dataId,
          moduleCode: this.module,
          fieldName: this.$parent.$attrs['field-name'] || this.$parent.prop,
          fieldContent: type === 'mask' ? this.maskFiled.mask : type === 'virtual' ? this.maskFiled.virtual : ''
        }, type)
        this.updateModel(data || '')
      },
      // 更新Form组件中model
      updateModel (value) {
        let model = JSON.parse(JSON.stringify(this.model))
        let tempModel = model
        this.pathArr.forEach((t, i) => {
          if (i === this.pathLen) {
            tempModel[t] = value
          }
          tempModel = tempModel[t]
        })
        this.$parent.form.$listeners.update(model)
      }
    }
  }
</script>
