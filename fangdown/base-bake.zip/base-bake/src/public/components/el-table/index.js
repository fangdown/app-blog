import ElTable from './src/table'

export default ElTable
