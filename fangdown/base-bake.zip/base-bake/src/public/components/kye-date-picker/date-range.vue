<template>
  <div class="kye-date-range__wrapper">
    <!--<div class="kye-date-range__icon">
      <i class="el-input__icon el-icon-date"></i>
    </div>-->
    <div class="kye-date-range__box"
         :style="{width: `${dataPickerWidth * 2 + 17}px`}">
      <div class="kye-date-range__start"
           :style="{width: `${dataPickerWidth}px`}">
        <kye-date-picker prefix-icon="kye-date-range__prefix-icon"
                         ref="start"
                         style="width:100%;"
                         :type="currentType"
                         :format="currentFormat"
                         :value-format="valueFormat"
                         v-model="currentDate[0]"
                         :placeholder="startPlaceholder"
                         :disabled="disabled"
                         :picker-options="createPickerOptions('Start')"
                         :clearable="false"
                         popper-class="date-range__popper date-range__popper-start"
                         @input="v => handleChange(v, 0)"
                         @blur="handleBlur"
                         @focus="handleFocus"></kye-date-picker>
      </div>
      <div class="kye-date-range__split">
        <span>-</span>
      </div>
      <div class="kye-date-range__end"
           :style="{width: `${dataPickerWidth}px`}">
        <kye-date-picker prefix-icon="kye-date-range__prefix-icon"
                         ref="end"
                         style="width:100%;"
                         :type="currentType"
                         :format="currentFormat"
                         :value-format="valueFormat"
                         v-model="currentDate[1]"
                         :placeholder="endPlaceholder"
                         :disabled="disabled"
                         :picker-options="createPickerOptions('End')"
                         :clearable="false"
                         popper-class="date-range__popper date-range__popper-end"
                         @input="v => handleChange(v, 1)"
                         @blur="handleBlur"
                         @focus="handleFocus"></kye-date-picker>
      </div>
    </div>
  </div>
</template>

<script>
  import { FORMAT, VALUE_FORMAT } from './index'
  import moment from 'moment'

  export default {
    name: 'kye-date-range',
    props: {
      type: {
        type: String,
        default: 'daterange'
      },
      value: [Array, String, Number, Object],
      format: String,
      clearable: {
        type: Boolean,
        default: true
      },
      valueFormat: {
        type: String,
        default: 'yyyy-MM-dd HH:mm:ss'
      },
      startPlaceholder: String,
      endPlaceholder: String,
      disabled: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        cacheDate: this.genCurrentDate(this.value),
        currentDate: this.genCurrentDate(this.value)
      }
    },
    watch: {
      value: {
        handler (val) {
          if (Array.isArray(val) && val[0] && val[1]) {
            this.currentDate = this.genCurrentDate(val)
            this.cacheDate = JSON.parse(JSON.stringify(this.currentDate))
          } else if (!val) {
            this.currentDate = ['', '']
          }
        }
      }
    },
    computed: {
      currentType () {
        return this.currentFormat === 'yyyy-MM' ? 'month' : this.type.replace('range', '')
      },
      dataPickerWidth () {
        if (this.format && this.format === 'yyyy-MM-dd HH:mm:ss') {
          return 118
        }
        return this.type === 'daterange' ? 68 : this.type === 'datetimerange' ? 102 : 54
      },
      currentFormat () {
        if (this.format) {
          return this.format.replace(':ss', '')
        } else {
          return this.type === 'daterange' ? 'yyyy-MM-dd' : this.type === 'datetimerange' ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM'
        }
      }
    },
    methods: {
      createPickerOptions (v) {
        return {
          disabledDate: this[`create${v}DisabledDate`],
          shortcuts: this.createShortcuts(v)
        }
      },
      createStartDisabledDate (time) {
        if (this.currentDate[1]) {
          return time.getTime() > moment(this.currentDate[1]).endOf('day').unix() * 1000
        }
      },
      createEndDisabledDate (time) {
        if (this.currentDate[0]) {
          return time.getTime() < moment(this.currentDate[0]).startOf('day').unix() * 1000
        }
      },
      createShortcuts (v) {
        let shortcuts = []
        if (this.clearable) {
          shortcuts = [...shortcuts, {
            text: '清除',
            onClick (picker) {
              picker.$emit('pick', null)
            }
          }]
        }
        if (this.currentFormat === 'yyyy-MM') {
          shortcuts = [...shortcuts, {
            text: '本月',
            onClick (picker) {
              picker.$emit('pick', FORMAT(new Date(), 'yyyy-MM'))
            }
          }, {
            text: '上月',
            onClick (picker) {
              picker.$emit('pick', FORMAT(moment().subtract(1, 'month'), 'yyyy-MM'))
            }
          }]
        } else {
          shortcuts = [...shortcuts, {
            text: '今天',
            onClick: this.handleTodayPick
          },
          {
            text: '昨天',
            onClick: this.handleYesterdayPick
          },
          {
            text: '当月',
            onClick: this.handleMonthPick
          },
          {
            text: '近30天',
            onClick: this.handleOneMonthPick
          }]
        }
        return shortcuts
      },
      handleTodayPick (picker) {
        this.onClickPicker(picker, 'today')
      },
      handleYesterdayPick (picker) {
        this.onClickPicker(picker, 'yesterday')
      },
      handleMonthPick (picker) {
        this.onClickPicker(picker, 'month')
      },
      handleOneMonthPick (picker) {
        this.onClickPicker(picker, 'oneMonth')
      },
      onClickPicker (picker, t) {
        let isStart = picker.$el.className.includes('date-range__popper-start')

        let s = new Date()
        let e = new Date()
        switch (t) {
          case 'yesterday':
            s = moment().subtract(1, 'days')
            e = moment().subtract(1, 'days')
            break
          case 'month':
            s = FORMAT(s, 'yyyy-MM')
            break
          case 'oneMonth':
            s = moment().subtract(30, 'day')
            break
        }

        let start = FORMAT(moment(s).startOf('day'), VALUE_FORMAT)
        let end = FORMAT(moment(e).endOf('day'), VALUE_FORMAT)
        this.currentDate = [start, end]
        if (isStart && this.cacheDate[0] === start) {
          this.handleChange(end, 1)
        }
        if (!isStart && this.cacheDate[1] === end) {
          this.handleChange(start, 0)
        }
        picker.$emit('pick', isStart ? start : end)
      },
      genCurrentDate (d) {
        let arr = []
        if (d) {
          if (typeof d === 'string' || typeof d === 'number') {
            arr = [d, ''].map(v => FORMAT(v, this.valueFormat))
          } else if (d.length === 0) {
            arr = ['', '']
          } else {
            arr = d.map(v => FORMAT(v, this.valueFormat))
          }
        } else {
          arr = ['', '']
        }
        return arr
      },
      handleChange (val, index) {
        let d = JSON.parse(JSON.stringify(this.currentDate))
        if (d[0] && d[1]) {
          d = d.map(v => FORMAT(v, 'yyyy-MM-dd HH:mm:ss'))
          if (this.type === 'daterange') {
            d[0] = d[0].slice(0, 11) + '00:00:00'
            d[1] = d[1].slice(0, 11) + '23:59:59'
          } else if (this.type === 'datetimerange' && d[0] === d[1]) {
            d[1] = d[1].slice(0, 11) + '23:59:59'
          }

          if (new Date(d[0]).getTime() > new Date(d[1]).getTime()) {
            d[index] = this.cacheDate[index]
          }

          d = d.map(v => FORMAT(v, this.valueFormat))
        } else {
          d = []
        }

        if (!this.clearable && d.length === 0 && this.cacheDate[0] && this.cacheDate[1]) {
          d = JSON.parse(JSON.stringify(this.cacheDate))
        }

        this.$emit('input', d)
      },
      handleFocus () {
        this.$emit('focus')
      },
      handleBlur () {
        if (!this.clearable && this.cacheDate[0] && this.cacheDate[1]) {
          this.currentDate = JSON.parse(JSON.stringify(this.cacheDate))
        }
        this.$emit('blur')
      },
      focus () {
        this.$refs.start.focus()
      }
    }
  }
</script>

<style lang="scss">
  .kye-date-range {
    &__wrapper {
      height: 28px;
      border: 1px solid #dcdae2;
      background-color: #ffffff;
      border-radius: 4px;
      padding-left: 8px;
      .el-input__inner {
        border: 0;
      }
      &:hover {
        border-color: #9571e9;
      }
      .el-input--mini .el-input__inner {
        height: 24px !important;
        line-height: 24px !important;
      }
      .el-date-editor.el-input--mini {
        top: -1px;
      }
      .el-input--mini,
      .el-input--mini .el-input__icon {
        height: 24px;
        line-height: 24px;
      }
      .el-input--prefix .el-input__inner {
        padding-left: 0 !important;
      }
      .el-input--suffix .el-input__inner {
        padding-right: 0 !important;
      }
      .el-date-editor--datetime.el-input--prefix .el-input__inner {
        padding-left: 0;
      }
      .el-date-editor--datetime.el-input--suffix .el-input__inner {
        padding-right: 0;
      }
      .el-input__suffix {
        right: 0;
      }
    }
    &__icon {
      display: inline-block;
      height: 26px;
      width: 20px;
      color: #c0c4cc;
      margin-right: -2px;
      .el-input__icon {
        line-height: 26px;
      }
    }
    &__box {
      display: inline-block;
      height: 26px;
      line-height: 26px;
    }
    &__start {
      display: inline-block;
      position: relative;
      height: 26px;
      line-height: 26px;
    }
    &__split {
      display: inline-block;
      width: 16px;
      height: 12px;
      margin-left: -8px;
      margin-right: 0;
      padding-left: 6px;
      text-align: center;
    }
    &__end {
      display: inline-block;
      position: relative;
      height: 26px;
      line-height: 26px;
    }
    .kye-date-range__prefix-icon {
      display: none;
    }
  }
  .date-range__popper {
    &.el-date-picker.has-sidebar {
      width: 398px;
    }
    .el-picker-panel__sidebar {
      width: 70px;
    }
    .el-picker-panel__sidebar + .el-picker-panel__body {
      margin-left: 70px;
    }
  }
</style>
