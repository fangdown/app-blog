import Vue from 'vue'
import { time } from '../../utils'

const VALUE_FORMAT = 'yyyy-MM-dd HH:mm:ss'

export const format = (val, fmt) => {
  return time(val, fmt.replace(/y/g, 'Y').replace(/d/g, 'D'))
}

const KyeDatePicker = Vue.component('kye-date-picker', {
  functional: true,
  render (h, self) {
    let valueFormat = self.props.valueFormat || VALUE_FORMAT

    let { attrs } = self.data
    if (attrs && !attrs.valueFormat) {
      attrs.valueFormat = valueFormat
    } else if (!attrs) {
      self.data.attrs = { valueFormat }
    }

    let value = self.props.value

    let type = self.props.type

    let onInput = self.listeners.input

    if (type === 'daterange' || type === 'datetimerange') {
      return h('kye-date-range', self.data, self.children)
    } else {
      if (type === 'datetime') {
        self.data.attrs.format = self.props.format || 'yyyy-MM-dd HH:mm'
      }
      self.data.attrs.unlinkPanels = true

      let newVal = null

      if (value) {
        // if (Array.isArray(value)) {
        //   let needFormat = value.some(v => {
        //     return typeof v !== 'string' || (typeof v === 'string' && v && v.length !== valueFormat.length)
        //   })
        //   if (value.length && needFormat) {
        //     newVal = value.map(v => format(v, valueFormat))
        //   }
        // } else
        if (typeof value !== 'string' || (typeof value === 'string' && value.length !== valueFormat.length)) {
          newVal = format(value, valueFormat)
        }
      }


      if (onInput) {
        let operation = self.data.attrs.operation
        self.data.on.input = (val) => {
          // if (Array.isArray(val) && val.length && valueFormat === VALUE_FORMAT) {
          // if (self.props.type === 'daterange' && val[0] && val[1]) {
          //   // daterange，后端要求格式为：['YYYY-MM-DD 00:00:00', 'YYYY-MM-DD 23:59:59']
          //   val[0] = val[0].slice(0, 11) + '00:00:00'
          //   val[1] = val[1].slice(0, 11) + '23:59:59'
          // } else if (self.props.type === 'datetimerange' && val[0] && val[0] === val[1]) {
          //   // datetimerange，如果起止时间相同，把截止时间改为 23:59:59
          //   val[1] = val[1].slice(0, 11) + '23:59:59'
          // }
          // } else
          if (typeof val !== 'string') {
            val = format(val, valueFormat)
          } else if (val && operation && self.props.type === 'date' && valueFormat === VALUE_FORMAT) {
            // 通用查询 条件关系
            switch (operation) {
              case 'greaterthan': // '>'
              case 'lessthanorequal': // '<='
                val = val.slice(0, 11) + '23:59:59'
                break
              case 'lessthan': // '<'
              case 'greaterthanorequal': // '>='
                val = val.slice(0, 11) + '00:00:00'
                break
            }
          }
          onInput(val)
        }
      }

      if (newVal) {
        self.props.value = newVal
        self.data.on && self.data.on.input && self.data.on.input(newVal)
        if (self.data.props) {
          self.data.props.value = newVal
        } else {
          self.data.props = { ...self.props }
        }
        if (self.data.model) {
          self.data.model.value = newVal
          self.data.model.callback && self.data.model.callback(newVal)
        }
      }

      return h('el-date-picker', self.data, self.children)
    }
  }
})

export default KyeDatePicker
