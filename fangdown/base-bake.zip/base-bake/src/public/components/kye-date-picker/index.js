import { time } from '../../utils'

export const VALUE_FORMAT = 'yyyy-MM-dd HH:mm:ss'

export const FORMAT = (val, fmt) => {
  return time(val, fmt.replace(/y/g, 'Y').replace(/d/g, 'D'))
}

const formatMap = {
  year: 'yyyy',
  month: 'yyyy-MM',
  date: 'yyyy-MM-dd',
  datetime: 'yyyy-MM-dd HH:mm',
  daterange: 'yyyy-MM-dd',
  datetimerange: 'yyyy-MM-dd HH:mm',
}

export default {
  name: 'kye-date-picker',
  mounted () {
    this.resetEnter()
  },
  render (h) {
    let data = this.$vnode.data
    let on = data.on || {}
    data.on = { ...on, ...this.$listeners }

    let attrs = this.$attrs
    let t = attrs.type || 'date'
    let valueFormat = attrs['value-format'] || attrs.valueFormat || VALUE_FORMAT
    let format = attrs.format
    if (format) {
      format = format.replace(':ss', '') // 不要显示秒
    } else {
      format = formatMap[t] || formatMap.date
    }
    if (format === 'yyyy-MM') {
      valueFormat = format
    }

    let props = data.props || {}
    let value = props.value || attrs.value || ''
    data.props = { ...props, format, valueFormat, value }

    if (t === 'daterange' || t === 'datetimerange') {
      return h('kye-date-range', data, this.$slots.default)
    }

    let newVal = null
    if (value && (typeof value !== 'string' || (typeof value === 'string' && value.length !== valueFormat.length))) {
      newVal = FORMAT(value, valueFormat)
    }

    let onInput = data.on.input
    if (onInput) {
      let operation = attrs.operation
      data.on.input = (val) => {
        if (typeof val !== 'string') {
          val = FORMAT(val, valueFormat)
        } else if (val && operation && t === 'date' && valueFormat === VALUE_FORMAT) {
          // 通用查询 条件关系
          switch (operation) {
            case 'greaterthan': // '>'
            case 'lessthanorequal': // '<='
              val = val.slice(0, 11) + '23:59:59'
              break
            case 'lessthan': // '<'
            case 'greaterthanorequal': // '>='
              val = val.slice(0, 11) + '00:00:00'
              break
          }
        }
        onInput(val)
      }
    }

    if (newVal) {
      if (data.model) {
        data.model = { ...data.model, value: newVal }
      }
      data.props = { ...data.props, value: newVal }
      if (data.on.input) {
        data.on.input(newVal)
      }
    }

    return h('el-date-picker', data, this.$slots.default)
  },
  methods: {
    resetEnter () {
      let c = this.$children[0]
      if (c) {
        c.handleKeydown = (e) => {
          const keyCode = e.keyCode

          // ESC
          if (keyCode === 27) {
            c.pickerVisible = false
            e.stopPropagation()
            return
          }

          // Tab
          if (keyCode === 9) {
            if (!c.ranged) {
              c.handleChange()
              c.pickerVisible = c.picker.visible = false
              c.blur()
              e.stopPropagation()
            } else {
              // user may change focus between two input
              setTimeout(() => {
                if (c.refInput.indexOf(document.activeElement) === -1) {
                  c.pickerVisible = false
                  c.blur()
                  e.stopPropagation()
                }
              }, 0)
            }
            return
          }

          // Enter
          if (keyCode === 13) {
            if (c.userInput === '' || c.isValidValue(c.parseString(c.displayValue))) {
              c.handleChange()
              c.pickerVisible = c.picker.visible = false
              // c.blur()
            }
            e.stopPropagation()
            return
          }

          // if user is typing, do not let picker handle key input
          if (c.userInput) {
            e.stopPropagation()
            return
          }

          // delegate other keys to panel
          if (c.picker && c.picker.handleKeydown) {
            c.picker.handleKeydown(e)
          }
        }
      }
    },
    focus () {
      this.$children[0] && this.$children[0].focus()
    }
  }
}
