import Vue from 'vue'

const KyeTabPane = Vue.component('kye-tab-pane', {
  functional: true,
  render (h, self) {
    return h('el-tab-pane', self.data, self.children)
  }
})

export default KyeTabPane
