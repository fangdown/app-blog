import Vue from 'vue'

const KyePagination = Vue.component('kye-pagination', {
  functional: true,
  render (h, self) {
    let background = self.data.attrs.background || true
    self.data.attrs = { ...self.data.attrs, background }
    // 当前菜单模块是否共享分页参数
    if (self.parent.$route.meta.page) {
      const tag = self.parent.$route.meta.tag
      let sizeChange = self.listeners && self.listeners['size-change']
      let json = localStorage.getItem('GLOBAL_PAGINATION')
      try {
        if (json) {
          json = JSON.parse(json)
          if (json[tag]) {
            self.data.attrs.pageSize = json[tag]
          }
        }
      } catch (e) {
      }
      if (sizeChange) {
        self.listeners['size-change'] = val => {
          try {
            json = localStorage.getItem('GLOBAL_PAGINATION')
            if (json) {
              json = JSON.parse(json)
              json[tag] = val
              localStorage.setItem('GLOBAL_PAGINATION', JSON.stringify(json))
            } else {
              json = { [tag]: val }
              localStorage.setItem('GLOBAL_PAGINATION', JSON.stringify(json))
            }
          } catch (e) {
          }
          sizeChange(val)
        }
      }
    }
    return h('el-pagination', self.data, self.children)
  }
})

export default KyePagination
