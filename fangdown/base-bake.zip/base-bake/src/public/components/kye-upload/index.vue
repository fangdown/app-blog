<template>
  <el-upload :action="uploadUrl"
             :on-success="handleSuccess"
             :on-change="handleChange"
             :before-remove="beforeRemove"
             :on-preview="handlePreview"
             :on-remove="handleRemove"
             :before-upload="handleBeforeUpload"
             :file-list="value"
             :data="fileData"
             v-bind="attr || $attrs"
             :accept="currentAccept"
             :disabled="disabled"
             ref="upload"
             v-on="$listeners">
    <kye-button v-if="$attrs['list-type'] !== 'picture-card'"
               :disabled="disabled"
               :auth="auth"
               :type="btnType"
               :icon="btnIcon">{{btnText}}</kye-button>
    <div :style="{pointerEvents: disabled ? 'none' : ''}"
         v-else-if="$attrs['list-type'] === 'picture-card'">
      <i class="el-icon-plus"></i>
    </div>
    <template slot="tip">
      <slot name="tip"></slot>
    </template>
  </el-upload>
</template>

<script>
  import { getToken } from 'public/utils'
  export default {
    name: 'kye-upload',
    props: {
      value: Array,
      code: String,
      id: String,
      btnIcon: {
        type: String,
        default: 'iconfont icon-shangchuan'
      },
      btnType: {
        type: String,
        default: 'primary'
      },
      btnText: {
        type: String,
        default: '上传文件'
      },
      disabled: {
        type: Boolean,
        default: false
      },
      accept: Array,
      size: Number,
      replace: Boolean,
      fileId: String,
      attr: Object,
      successMsg: {
        type: String,
        default: '上传成功'
      },
      auth: String
    },
    data () {
      return {
        count: 0,
        num: 0,
        // signature: null,
        accepts: {
          excel: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, application/kset',
          word: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword, application/kswps',
          pdf: 'application/pdf, application/kswps',
          image: 'image/gif, image/jpeg, image/png, image/x-ms-bmp',
          zip: 'application/zip, application/x-zip-compressed',
          ppt: `application/vnd.ms-powerpoint,
            application/vnd.ms-powerpoint,
            application/vnd.ms-powerpoint,
            application/vnd.openxmlformats-officedocument.presentationml.template,
            application/vnd.openxmlformats-officedocument.presentationml.slideshow,
            application/vnd.openxmlformats-officedocument.presentationml.presentation`
        },
        isInAccept: true
      }
    },
    computed: {
      uploadUrl () {
        return `/router/upload`
      },
      fileData () {
        let obj = {
          bizCode: this.code.replace(/\./g, '_'),
          bizId: this.id,
          num: this.num,
          // signature: this.signature,
          token: getToken(),
          'x-uid': this.$store.getters.user.id
        }
        if (this.replace) {
          obj.id = this.fileId
        }
        return obj
      },
      currentAccept () {
        if (this.accept) {
          return this.accept.map(k => this.accepts[k]).join(',')
        }
        return ''
      }
    },
    methods: {
      // getSign () {
      //   if (!this.signature) {
      //     this.count = this.count + 1
      //     let params = { args: { code: this.code }, timeout: 300 }
      //     this.$http('openapi.signature', params).then(data => {
      //       this.signature = data
      //     }).catch(err => {
      //       console.log(err)
      //       if (this.count < 4) {
      //         this.getSign()
      //       } else {
      //         this.$message.error('签名失败')
      //       }
      //     })
      //   }
      // },
      handleChange (file, list) {
        this.num = list.length
      },
      handleSuccess (res, file, list) {
        this.num = 0
        // 上传文件大小为0kb的不往下走
        if (file.size === 0) {
          this.$message.warning(`文件大小不能为0KB!`)
          return
        }
        if (res.code === 0) {
          this.$emit('input', res.data, list)
          this.$emit('success', res.data, list)
          this.successMsg && this.$message.success(this.successMsg)
        } else {
          this.$message.warning(res.msg || res.message || '上传失败')
        }
      },
      beforeRemove (file, list) {
        if (!(this.size && file.size > this.size * 1024 * 1024) && this.isInAccept) {
          return this.$confirm('此操作将永久删除该文件, 是否继续?', '提示')
        }
      },
      handleRemove (file, list) {
        if (file && file.status === 'success') {
          let params = { bizCode: file.bizCode, bizId: file.bizId, id: file.id }
          this.$http('file.deleteByBizAndId', params).then(res => {
            if (res) {
              let arr = JSON.parse(JSON.stringify(this.value))
              let index = arr.findIndex(t => t.id === params.id)
              arr.splice(index, 1)
              this.$emit('input', arr)
              this.$emit('delete-success', arr)
              this.$message.success('删除成功')
            }
          })
        }
      },
      handlePreview (file) {
        if (this.$attrs['on-preview']) {
          this.$attrs['on-preview'](file)
        } else {
          window.erpOpen(file.url)
        }
      },
      handleBeforeUpload (file) {
        if (this.size && file.size > this.size * 1024 * 1024) {
          this.$message.warning(`文件大小不能超过${this.size}MB!`)
          return false
        }
        if (this.accept && this.accept.length) {
          this.isInAccept = true
          let str = ''
          this.accept.forEach(t => {
            str = str + this.accepts[t] + ','
          })
          if (str.indexOf(file.type) === -1) {
            this.isInAccept = false
            this.$message.warning(`文件类型与要求不符`)
            return false
          }
        }
      },
      // 手动调用upload上传组件
      manualUpload () {
        this.$refs.upload.$children[0].handleClick()
      }
    }
  }
</script>
