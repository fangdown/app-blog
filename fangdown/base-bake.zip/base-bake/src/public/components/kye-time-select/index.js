import Vue from 'vue'

const toZero = number => number > 9 ? number + '' : '0' + number

const KyeTimeSelect = Vue.component('kye-time-select', {
  functional: true,
  render (h, self) {
    const model = self.data.model.value
    if (typeof model === 'number') {
      const date = new Date(model)
      self.data.model.value = `${toZero(date.getHours())}:${toZero(date.getMinutes())}`
    }
    return h('el-time-select', self.data, self.children)
  }
})

export default KyeTimeSelect
