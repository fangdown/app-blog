import Vue from 'vue'

const KyeDropdownItem = Vue.component('kye-dropdown-item', {
  functional: true,
  render (h, self) {
    return h('el-dropdown-item', self.data, self.children)
  }
})

export default KyeDropdownItem
