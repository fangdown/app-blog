import Vue from 'vue'

const KyePopover = Vue.component('kye-popover', {
  functional: true,
  render (h, self) {
    return h('el-popover', self.data, self.children)
  }
})

export default KyePopover
