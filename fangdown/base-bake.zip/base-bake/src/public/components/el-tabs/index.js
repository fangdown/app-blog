import ElTabs from './src/tabs'

export default ElTabs
