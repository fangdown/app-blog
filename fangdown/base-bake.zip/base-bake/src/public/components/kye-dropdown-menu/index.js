import Vue from 'vue'

const KyeDropdownMenu = Vue.component('kye-dropdown-menu', {
  functional: true,
  render (h, self) {
    return h('el-dropdown-menu', self.data, self.children)
  }
})

export default KyeDropdownMenu
