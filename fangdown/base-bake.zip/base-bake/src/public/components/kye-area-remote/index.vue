<template>
  <div class="remote-area">
    <div class="area-item flex-1"
         :style="areaItemStyle">
      <span v-if="showLabel"
            class="area-item__label">{{ labels[0] }}</span>
      <kye-select :value="province.id"
                 :placeholder="showPlaceholder ? labels[0] : ''"
                 :disabled="disabled"
                 filterable
                 clearable
                 default-first-option
                 @visible-change="loadProvince"
                 @clear="handleClear(1)"
                 @change="(val) => handleSelect(val, 1)">
        <el-option v-for="(item, index) in provinces"
                   :key="index"
                   :label="item.addressName || ' '"
                   :value="item.id"></el-option>
      </kye-select>
    </div>
    <div v-if="level > 1"
         class="area-item flex-1"
         :style="areaItemStyle">
      <span v-if="showLabel"
            class="area-item__label">{{ labels[1] }}</span>
      <kye-select :value="city.id"
                 :placeholder="showPlaceholder ? labels[1] : ''"
                 :disabled="disabled"
                 filterable
                 clearable
                 default-first-option
                 @clear="handleClear(2)"
                 @change="(val) => handleSelect(val, 2)">
        <el-option v-for="item in citys"
                   :key="item.id"
                   :label="item.addressName || ' '"
                   :value="item.id"></el-option>
      </kye-select>
    </div>
    <div v-if="level > 2"
         class="area-item flex-1"
         :style="areaItemStyle">
      <span v-if="showLabel"
            class="area-item__label">{{ labels[2] }}</span>
      <kye-select :value="county.id"
                 :placeholder="showPlaceholder ? labels[2] : ''"
                 :disabled="disabled"
                 filterable
                 clearable
                 default-first-option
                 @clear="handleClear(3)"
                 @change="(val) => handleSelect(val, 3)">
        <el-option v-for="item in countys"
                   :key="item.id"
                   :label="item.addressName || ' '"
                   :value="item.id"></el-option>
      </kye-select>
    </div>
    <div v-if="level > 3"
         class="area-item flex-2"
         :style="areaItemStyle">
      <span v-if="showLabel"
            class="area-item__label">{{ labels[3] }}</span>
      <kye-select :value="town.id"
                 :placeholder="showPlaceholder ? labels[3] : ''"
                 :disabled="disabled"
                 filterable
                 clearable
                 default-first-option
                 @clear="handleClear(4)"
                 @change="(val) => handleSelect(val, 4)">
        <el-option v-for="item in towns"
                   :key="item.id"
                   :label="item.addressName || ' '"
                   :value="item.id"></el-option>
      </kye-select>
    </div>
    <div v-if="level > 4"
         class="area-item flex-2"
         :style="areaItemStyle">
      <span v-if="showLabel"
            class="area-item__label">{{ labels[4] }}</span>
      <kye-select :value="road.id"
                 :placeholder="showPlaceholder ? labels[4] : ''"
                 :disabled="disabled"
                 filterable
                 clearable
                 default-first-option
                 @clear="handleClear(5)"
                 @change="(val) => handleSelect(val, 5)">
        <el-option v-for="item in roads"
                   :key="item.id"
                   :label="item.addressName || ' '"
                   :value="item.id"></el-option>
      </kye-select>
    </div>
  </div>
</template>

<script>
  import { random } from '../../utils'

  export default {
    name: 'kye-area-remote',
    props: {
      value: {
        type: Array,
        default: () => []
      },
      level: {
        type: Number,
        default: 5
      },
      disabled: {
        type: Boolean,
        default: false
      },
      showLabel: {
        type: [Boolean, String],
        default: false
      },
      showPlaceholder: {
        type: Boolean,
        default: true
      },
      auto: {
        type: Boolean,
        default: true
      },
      labels: {
        type: Array,
        default: () => (['省', '市', '区/县', '街/镇', '路/村'])
      }
    },
    data () {
      return {
        changedByInner: false,
        remote_citys: [],
        remote_countys: [],
        remote_towns: [],
        remote_roads: [],
        regions: ['provinces', 'citys', 'countys', 'towns', 'roads'],
        districtLevels: ['province', 'city', 'zone', 'street', 'village'],
        areaItemStyle: { flexDirection: this.showLabel === 'top' ? 'column' : 'row' },
        levalMap: {
          'province': 'provinces',
          'city': 'citys',
          'zone': 'countys',
          'street': 'towns',
          'village': 'roads',
        }
      }
    },
    created () {
      this.loadProvince(true)
      this.initArea(this.value)
      this.$bus.$on('AREA_REMOTE_REFRESH', this.areaRemoteRefresh)
    },
    beforeDestroy () {
      this.$bus.$off('AREA_REMOTE_REFRESH', this.areaRemoteRefresh)
    },
    watch: {
      value (val) {
        this.initArea(val)
      }
    },
    computed: {
      province () {
        return (this.value && this.value[0]) || {}
      },
      city () {
        return (this.value && this.value[1]) || {}
      },
      county () {
        return (this.value && this.value[2]) || {}
      },
      town () {
        return (this.value && this.value[3]) || {}
      },
      road () {
        return (this.value && this.value[4]) || {}
      },
      provinces () {
        return this.$store.state.gisProvinces
      },
      citys () {
        if (this.remote_citys.length) {
          return this.remote_citys
        } else if (this.value && this.value[1]) {
          return [this.value[1]]
        } else {
          return []
        }
      },
      countys () {
        if (this.remote_countys.length) {
          return this.remote_countys
        } else if (this.value && this.value[2]) {
          return [this.value[2]]
        } else {
          return []
        }
      },
      towns () {
        if (this.remote_towns.length) {
          return this.remote_towns
        } else if (this.value && this.value[3]) {
          return [this.value[3]]
        } else {
          return []
        }
      },
      roads () {
        if (this.remote_roads.length) {
          return this.remote_roads
        } else if (this.value && this.value[4]) {
          return [this.value[4]]
        } else {
          return []
        }
      }
    },
    methods: {
      handleSelect (val, level) {
        if (val) {
          let arr = JSON.parse(JSON.stringify(this.value)) || []
          arr.splice(level - 1, arr.length)
          let key = this.regions[level - 1]
          let area = this[key].find(t => t.id === val)
          if (arr.length === level - 2) {
            arr.push({ addressName: '', id: '' })
          }
          arr.push(area)
          for (let i = level; i < this.level; i++) {
            this['remote_' + this.regions[i]] = []
          }
          this.emitEvent(arr)
          if (level < this.level) {
            this.getNextArea(val, level)
          }
        }
      },
      getNextArea (id, level) {
        let method = 'address.addressBgTerritory.getMultiLevelSubList'
        let params = {
          method,
          jsonrpc: '2.0',
          id: random().toString().substr(4),
          params: { commonDistrID: id, districtLevel: this.districtLevels[level] }
        }
        return this.$http(method, params).then(({ districtLevel, districtList }) => {
          if (districtList && districtList.length) {
            let arr = districtList.map(v => ({ id: v.districtID, addressName: v.districtName }))
            let str = this.levalMap[districtLevel] || this.regions[level]
            this['remote_' + str] = arr
          }
        })
      },
      emitEvent (arr, inner = true) {
        this.changedByInner = true
        let last = arr[arr.length - 1]
        let address = arr.map(v => v.addressName).join('')
        this.$emit('input', arr, last, address)
        // 手动改变下拉框 或者 默认自动触发事件
        if (inner || this.auto) {
          this.$emit('change', arr, last, address)
          if (arr.length === this.level) {
            this.$emit('finish', arr, last, address)
          }
        }
        // 同步事件执行完成后修改状态，否则会触发 watch
        setTimeout(_ => {
          this.changedByInner = false
        }, 0)
      },
      initArea (val) {
        if (!val || !val.length) {
          this.remote_citys = []
          this.remote_countys = []
          this.remote_towns = []
          this.remote_roads = []
          return
        }
        if (!this.changedByInner) {
          let promise = []
          for (let i = 0; i < this.level; i++) {
            let v = val[i]
            if (v && v.id) {
              this['remote_' + this.regions[i + 1]] = []
              promise.push(this.getNextArea(v.id, i + 1))
            }
          }
          // 补全 addressName
          Promise.all(promise).then(_ => {
            val.forEach((v, i) => {
              if (!v.addressName) {
                let item = null
                if (i === 0) {
                  item = this.provinces.find(t => t.id === v.id)
                } else {
                  let key = this.regions[i]
                  item = this[key].find(t => t.id === v.id)
                }
                if (item) {
                  v.addressName = item.addressName
                }
              }
            })
            this.emitEvent(val, false)
          })
        }
      },
      areaRemoteRefresh (id, level) {
        if (!id) {
          this.$store.dispatch('getProvinces', true)
          return
        }
        let preArea = this.value && this.value[level - 1]
        if (preArea && preArea.id === id) {
          this.getNextArea(id, level)
        }
      },
      handleClear (i) {
        let arr = JSON.parse(JSON.stringify(this.value))
        let len = arr.length
        arr.splice(i - 1, len)
        this.regions.filter((item, index) => index > i - 1).forEach(t => {
          this[`remote_${t}`] = []
        })
        this.emitEvent(arr)
      },
      loadProvince (need) {
        if (need && this.provinces.length === 0) {
          this.$store.dispatch('getProvinces')
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .remote-area {
    display: flex;
    .area-item {
      display: inline-flex;
      &__label {
        font-size: 12px;
        color: #333333;
        font-weight: 500;
        padding-right: 4px;
      }
      .el-select {
        flex: 1;
      }
    }
    .flex-1 {
      flex: 1;
    }
    .flex-2 {
      flex: 1.5;
    }
    .area-item + .area-item {
      margin-left: 8px;
    }
  }
</style>
