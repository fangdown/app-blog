import Vue from 'vue'

const KyeInputNumber = Vue.component('kye-input-number', {
  functional: true,
  render (h, self) {
    return h('el-input-number', self.data)
  }
})

export default KyeInputNumber
