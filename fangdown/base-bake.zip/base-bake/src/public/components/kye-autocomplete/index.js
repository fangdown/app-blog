import Vue from 'vue'

const KyeAutocomplete = Vue.component('kye-autocomplete', {
  functional: true,
  render (h, self) {
    return h('el-autocomplete', self.data, self.children)
  }
})

export default KyeAutocomplete
