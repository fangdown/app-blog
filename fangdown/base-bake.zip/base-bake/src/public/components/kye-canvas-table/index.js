import kyeCanvasTable from './canvas-table.vue'

export default kyeCanvasTable
