// 初始化
import { rowHeight, fontSize } from '../config'

export default {
  mounted () {
    this.boxPosition = {
      left: 0,
      top: 0
    }
    this.highlight = this.options.highlightCurrentRow !== false
  },
  methods: {
    // dom获取存储
    getDom () {
      const refs = this.$refs
      this.box = refs.box
      this.canvas = refs.canvas
      this.editCell = refs.editCell
      this.hScrollbar = refs.hScrollbar
      this.horizontal = refs.horizontal
      this.vScrollbar = refs.vScrollbar
      this.vertical = refs.vertical
      this.canvasBox = refs.canvasBox
      this.divideTag = refs.divideTag
      this.divideLine = refs.divideLine
      this.ctx = this.canvas.getContext('2d')
      this.textCtx = refs.textCanvas.getContext('2d')
      this.updatedBoxPosition()
      this.initCanvas()
    },
    // 初始化canvas，获取像素比
    initCanvas () {
      const { textCtx } = this
      this.ratio = 1 // TODO: 因为缩放了，就不需要设置这个了。后面稳定之后会删掉
      this.scaleRatio = window.devicePixelRatio
      this.scaleRatio = this.scaleRatio < 1 ? 1 : this.scaleRatio
      this.rowH = rowHeight * this.ratio
      this.fontSize = fontSize * this.ratio
      this.font = `normal ${this.fontSize}px Microsoft YaHei`
      textCtx.font = this.font
    },
    // 设置canvas
    setCanvas () {
      const { ctx, scaleRatio, canvas, cHeight, box } = this
      let oldWidth = box.offsetWidth
      let oldHeight = cHeight
      ctx.translate(-0.5, -0.5)
      canvas.width = Math.round(oldWidth * scaleRatio)
      canvas.height = Math.round(cHeight * scaleRatio)
      canvas.style.width = oldWidth + 'px'
      canvas.style.height = oldHeight + 'px'
      ctx.scale(scaleRatio, scaleRatio)
      ctx.translate(0.5, 0.5)
    },
    // 更新canvas父级容器在窗口的位置
    updatedBoxPosition () {
      let { top, left } = this.box.getBoundingClientRect()
      this.boxPosition.top = top
      this.boxPosition.left = left
    },
    // 更新divideTag的位置
    updatedDivideTag (x) {
      this.divideTag.style.left = `${x}px`
      this.showDivideTag = true
    }
  }
}
