import Vue from 'vue'

const KyeCard = Vue.component('kye-card', {
  functional: true,
  render (h, self) {
    return h(
      'el-card',
      self.data,
      self.children && self.children.map(t => h((t.componentOptions && t.componentOptions.tag) || t.tag, t.data, t.children))
    )
  }
})

export default KyeCard
