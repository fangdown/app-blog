import Vue from 'vue'

const KyeForm = Vue.component('kye-form', {
  functional: true,
  render (h, self) {
    let labelWidth = self.props.labelWidth || '64px'
    self.data.attrs = { ...self.data.attrs, labelWidth }
    self.data.on = {
      update: (model) => {
        self.listeners['update:model'](model)
      }
    }
    return h('el-form', self.data, self.children)
  }
})

export default KyeForm
