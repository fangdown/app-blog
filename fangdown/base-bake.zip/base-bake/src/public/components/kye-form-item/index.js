import Vue from 'vue'

const KyeFormItem = Vue.component('kye-form-item', {
  functional: true,
  render (h, self) {
    return h(
      'el-form-item',
      self.data,
      [
        // 渲染decrypt组件
        h('kye-decrypt', { slot: 'label' }, self.props.label),
        ...self.children && self.children.map(t => {
          if (t.data && t.data.attrs) {
            t.data.attrs = { ...t.data.attrs, ...(t.componentOptions && t.componentOptions.propsData) }
          }
          if (t.data && t.data.on === undefined) {
            t.data.on = t.data.on || (t.componentOptions && t.componentOptions.listeners)
          }
          return h(
            (t.componentOptions && t.componentOptions.tag) || t.tag,
            t.data,
            t.children || (t.componentOptions && t.componentOptions.children)
          )
        })
      ]
    )
  }
})

export default KyeFormItem
