import Vue from 'vue'

const KyeTabs = Vue.component('kye-tabs', {
  functional: true,
  render (h, self) {
    return h('el-tabs', self.data, self.children)
  }
})

export default KyeTabs
