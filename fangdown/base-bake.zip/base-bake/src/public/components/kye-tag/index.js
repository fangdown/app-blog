import Vue from 'vue'

const KyeTag = Vue.component('kye-tag', {
  functional: true,
  render (h, self) {
    return h('el-tag', self.data, self.children)
  }
})

export default KyeTag
