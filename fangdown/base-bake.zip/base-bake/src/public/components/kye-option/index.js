import Vue from 'vue'

const KyeOption = Vue.component('kye-option', {
  functional: true,
  render (h, self) {
    const { attrs } = self.data
    if (attrs && !attrs.label) {
      attrs.label = ' '
      const show = {
        name: 'show',
        value: false
      }
      if (self.data.directives) {
        self.data.directives.push(show)
      } else {
        self.data.directives = [show]
      }
    }
    return h('el-option', self.data, self.children)
  }
})

export default KyeOption
