import Vue from 'vue'

const KyeRadioGroup = Vue.component('kye-radio-group', {
  functional: true,
  render (h, self) {
    return h('el-radio-group', self.data, self.children)
  }
})

export default KyeRadioGroup
