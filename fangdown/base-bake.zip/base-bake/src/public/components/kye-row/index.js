import Vue from 'vue'

const KyeRow = Vue.component('kye-row', {
  functional: true,
  render (h, self) {
    let gutter = self.props.gutter || 8
    self.data.attrs = { ...self.data.attrs, gutter }
    return h('el-row', self.data, self.children)
  }
})

export default KyeRow
