import Vue from 'vue'
// import {lookup} from '../../utils/filter'
const KyeInput = Vue.component('kye-input', {
  functional: true,
  render (h, self) {
    // 宽度设置
    // if (self.props && self.props.width) {
    //   self.data.style = self.data.style || {}
    //   self.data.style.width = self.props.width + 'px'
    // }
    // 显示数据字典
    // let str = lookup(self.props.value, self.props.dic)
    // self.props.value = str
    // self.data.props.value = str
    // self.data.model.value = str
    // self.data.model.callback(str)
    let input = self.listeners.input
    if (input) {
      self.data.on.input = (value) => {
        if (value) value = value.trim()
        // 处理多个绑定input 为数组情况
        if (Array.isArray(input)) {
          input.forEach(cb => {
            cb(value)
          })
        } else {
          input(value)
        }
      }
    }
    return h('el-input', self.data, self.children)
  }
})

export default KyeInput
