import Vue from 'vue'

const KyeStep = Vue.component('kye-step', {
  functional: true,
  render (h, self) {
    return h(
      'el-step',
      self.data,
      self.children && self.children.map(t => h(
        t.tag,
        t.data,
        t.children)))
  }
})

export default KyeStep
