<template>
  <kye-dialog
    class="kye-query-table-dialog-drag noselect"
    :visible.sync="show"
    append-to-body
    title="个性设置"
    width="420px"
    @open="onOpen"
    @close="onClose">
    <el-tabs v-model="active">
      <el-tab-pane
        v-for="(item,i) in tables"
        :key="i"
        :disabled="tableDisabled(item.url.method)"
        :label="item.option.label || '字段设置'"
        :name="'tab'+i">
        <el-input
          v-if="!tableDisabled(item.url.method)"
          style="margin-top:4px;"
          placeholder="输入列名后可定位到指定项"
          @input="val => filterChange(val, i)">
        </el-input>
        <div class="header-title">
          <el-checkbox
            v-model="checkedMap[i].value"
            :indeterminate="checkedMap[i].indeterminate"
            :disabled="tableDisabled(item.url.method)"
            @change="e => handleCheckAll(e, item.$columns, i)">全选
          </el-checkbox>
          <span>字段名(上下拖动排序)</span>
        </div>
        <ul v-if="tableDisabled(item.url.method)" class="tabs-content">
          <li
            v-for="col in item.$columns"
            :key="col.key"
            class="item_disabled">
            <el-checkbox disabled>{{col.label}}</el-checkbox>
          </li>
        </ul>
        <draggable
          v-else
          ref="draggable"
          class="tabs-content"
          element="ul"
          :list="item.$columns"
          :options="{draggable:'.item', animation: 150}">
          <li
            v-for="col in item.$columns"
            :key="col.key"
            v-if="!col.fixed && col.auth && !col.undraggable"
            :class="scrolledList[i] === col.key ? 'item is-active': 'item'">
            <el-checkbox
              v-model="col.$show"
              @change="handleCheck(item.$columns, i)">{{col.label}}
            </el-checkbox>
          </li>
          <template slot="footer">
            <li
              v-for="col in item.$columns.filter(v => !v.auth && !v.undraggable)"
              :key="col.key"
              class="item_disabled">
              <el-checkbox disabled>{{col.label}}</el-checkbox>
            </li>
          </template>
        </draggable>
      </el-tab-pane>
      <el-tab-pane
        v-if="option.searchCode"
        :disabled="searchDisabled"
        :label="option.label || '快捷查询设置'"
        name="query">
        <div class="header-title">
          <el-checkbox
            v-model="checkedMap.form.value"
            :indeterminate="checkedMap.form.indeterminate"
            :disabled="searchDisabled"
            @change="e => handleCheckAll(e, formFields.$columns, 'form')">全选
          </el-checkbox>
          <span>字段名(上下拖动排序)</span>
        </div>
        <ul v-if="searchDisabled" class="tabs-content">
          <li
            v-for="col in formFields.$columns"
            :key="col.propertyName"
            class="item_disabled">
            <el-checkbox disabled>{{col.label}}</el-checkbox>
          </li>
        </ul>
        <draggable
          v-else
          class="tabs-content"
          element="ul"
          :list="formFields.$columns"
          :options="{draggable:'.item', animation: 150}">
          <li
            v-for="col in formFields.$columns"
            :key="col.propertyName"
            v-if="!col.required"
            class="item">
            <el-checkbox
              v-model="col.$show"
              @change="handleCheck(formFields.$columns, 'form')">{{col.label}}
            </el-checkbox>
          </li>
          <template slot="header" v-if="disabledFields.length > 0">
            <li
              v-for="col in disabledFields"
              :key="col.propertyName"
              class="item_disabled">
              <el-checkbox checked disabled>{{col.label}}</el-checkbox>
            </li>
          </template>
        </draggable>
      </el-tab-pane>
    </el-tabs>
    <div slot="footer">
      <el-button type="primary" hotkey="ctrl+s" :disabled="savedDisabled" @click="onSave">保存(S)</el-button>
      <el-button @click="show = false">取消</el-button>
    </div>
  </kye-dialog>
</template>

<script>
  import Draggable from 'vuedraggable'
  import mixins from '../../mixins'

  export default {
    mixins: [mixins],
    components: { Draggable },
    props: {
      option: Object,
      formFields: Object,
      tables: Array
    },
    data () {
      return {
        show: false,
        isSaved: false,
        savedDisabled: true,
        active: this.option.searchCode ? 'query' : 'tab0',
        scrolledList: [],
        checkedMap: {
          '0': { value: false, indeterminate: false },
          '1': { value: false, indeterminate: false },
          form: { value: false, indeterminate: false }
        }
      }
    },
    created () {
      this.setActive()
    },
    computed: {
      disabledFields () {
        return this.formFields.$columns.filter(v => v.required)
      },
      searchDisabled () {
        return this.option.auth ? !this.permission.menus.includes(this.tables[0].url.method) : false
      }
    },
    methods: {
      setActive () {
        this.tables.forEach((v, i) => {
          this.scrolledList[i] = ''
          this.$set(this.checkedMap, i, { value: false, indeterminate: false })
          let auth = !this.option.auth || this.permission.menus.includes(v.url.method)
          if (this.savedDisabled && auth) {
            this.savedDisabled = false
          }
          if (auth && this.active === 'query') {
            this.active = `tab${i}`
          }
        })
      },
      tableDisabled (auth) {
        return this.option.auth ? !this.permission.menus.includes(auth) : false
      },
      handleCheckAll (val, arr, key) {
        arr.forEach(v => {
          v.$show = !!val
        })
        this.checkedMap[key].value = val
        this.checkedMap[key].indeterminate = false
      },
      handleCheck (arr, key) {
        if (!arr) return
        const flag = arr[0].$show
        this.checkedMap[key].value = arr.every(v => v.$show)
        this.checkedMap[key].indeterminate = arr.some(v => v.$show !== flag)
      },
      onOpen () {
        this.tables.forEach((tab, i) => this.handleCheck(tab.$columns, i))
        this.handleCheck(this.formFields && this.formFields.$columns, 'form')
      },
      onClose () {
        if (!this.isSaved) {
          this.tables.forEach(tab => {
            tab.$columns = tab.columns.map(v => {
              v.$show = v.show
              return v
            })
          })
          if (this.option.searchCode) {
            this.formFields.$columns = this.formFields.columns.map(v => {
              v.$show = v.show
              return v
            })
          }
        }
        this.isSaved = false
        this.$emit('close')
      },
      filterChange (val, i) {
        val = val.trim()
        if (val) {
          let num = -1
          // 先全匹配再模糊匹配
          let obj = this.tables[i].$columns.find(v => {
            if (v.auth && !v.undraggable) {
              num++
            }
            return v.label === val
          })
          if (!obj) {
            num = -1
            obj = this.tables[i].$columns.find(v => {
              if (v.auth && !v.undraggable) {
                num++
              }
              return v.label.indexOf(val) !== -1
            })
          }
          if (obj) {
            this.scrolledList[i] = obj.key
            let col = this.tables[i].$columns[0]
            col.$show = !col.$show
            col.$show = !col.$show
            this.$refs.draggable[i].$el.scrollTo({ top: num * 33, behavior: 'smooth' })
          }
        } else {
          this.scrolledList[i] = ''
          let col = this.tables[i].$columns[0]
          col.$show = !col.$show
          col.$show = !col.$show
        }
      },
      onSave () {
        let enable = true
        let tasks = []
        let method = 'system.genericSearch.field.saveOrUpdate'

        this.tables.forEach(tab => {
          let keys = tab.$columns.filter(v => v.$show && (v.fixed || !v.undraggable)).map(v => v.key)
          if (keys.length === 0) {
            enable = false
            this.$message.warning('请至少保留一列')
            return
          }
          if (!tab.searchCode) {
            return
          }
          tasks.push({
            menuId: this.option.menuId,
            genericId: this.option[tab.searchCode],
            fieldContent: JSON.stringify(keys)
          })
        })
        let keys = this.formFields.$columns.filter(v => v.$show).map(v => v.propertyName)
        if (this.formFields.$columns.length && keys.length === 0) {
          enable = false
          this.$message.warning('请至少保留一个查询条件')
        }
        if (!enable) {
          return
        }
        if (this.option.searchCode) {
          tasks.push({
            menuId: this.option.menuId,
            genericId: this.option[this.option.searchCode],
            fieldContent: JSON.stringify(keys)
          })
        }
        tasks.forEach(v => this.$http(method, v))

        this.tables.forEach(tab => {
          tab.columns = tab.$columns.map(v => {
            v.show = v.$show
            return v
          })
        })
        if (this.option.searchCode) {
          this.formFields.$columns.forEach(v => v.show = v.$show)
          this.formFields.columns.length = 0
          this.formFields.columns.push(...this.formFields.$columns)
        }
        this.isSaved = true
        this.$message.success('保存成功')
        this.show = false
      }
    }
  }
</script>

<style lang="scss">
  @import '../../assets/scss/variable.scss';

  .kye-query-table-dialog-drag {
    .el-dialog__body {
      padding-top: 4px;
    }
    .el-checkbox {
      width: 100%;
    }
    .tabs-content {
      height: 45vh;
      overflow-y: auto;
      .el-checkbox__label {
        padding-left: 50px;
      }
    }
    .item {
      padding: 5px 0 5px 16px;
      border-top: 1px solid $--color-24;
      &:first-child {
        border-top: none;
      }
      &.is-active {
        background-color: aliceblue;
      }
      &_disabled {
        pointer-events: none;
        padding: 5px 0 5px 16px;
        border-top: 1px solid $--color-24;
        &:first-child {
          border-top: none;
        }
      }
    }
    .icon-sort {
      padding-top: 3px;
    }
    .header-title {
      margin: 4px 0;
      padding: 4px 0 4px 16px;
      color: #333;
      font-size: 12px;
      font-weight: 600;
      background-color: $--color-28;
      .el-checkbox {
        width: 62px;
        &__label {
          color: #333;
          font-size: 12px;
          font-weight: 600;
        }
      }
    }
  }
</style>
