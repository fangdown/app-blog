<template>
  <el-form-item
    :prop="option.propertyName"
    :rules="option.attr && option.attr.rules">
    <!-- slot label -->
    <el-dropdown
      slot="label"
      :trigger="option.trigger || 'click'"
      :placement="option.placement || 'bottom-start'"
      @command="handleMenuClick">
      <div class="el-dropdown-link">
        <span class="theme">{{ option.type === 'rangeMenu' ? option.label : item.label }}</span>
        <i class="iconfont icon-caretdown"></i>
      </div>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item
          v-for="(opt, i) in option.options"
          :key="opt.propertyName+i"
          :command="opt">
          {{ opt.label }}
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <!-- slot default -->
    <kye-number
      v-if="item.type === 'number'"
      :style="item.width ? {width: item.width} : null"
      :placeholder="item.placeholder"
      :symbol="option.type === 'rangeMenu' ? item.label : ''"
      v-bind="item.attr"
      :value="bindValue(item.propertyName)"
      @input="bindChange">
    </kye-number>
    <el-input
      v-else-if="item.type === 'text'"
      :style="item.width ? {width: item.width} : null"
      clearable
      :placeholder="item.placeholder"
      v-bind="item.attr"
      :value="bindValue(item.propertyName)"
      @input="bindChange">
      <template v-if="option.type === 'rangeMenu'" slot="prepend">{{ item.label }}</template>
    </el-input>
    <el-select
      v-else-if="item.type === 'select'"
      :style="item.width ? {width: item.width} : null"
      clearable
      :placeholder="item.placeholder"
      v-bind="item.attr"
      :value="bindValue(item.propertyName)"
      @input="bindChange"
      @visible-change="selectVisibleChange">
      <el-option
        v-for="(opt, i) in item.options"
        :key="opt.value+i"
        :label="opt.label || ' '"
        :value="opt.value">
      </el-option>
    </el-select>
    <el-select
      v-else-if="item.type === 'remoteSelect'"
      :style="item.width ? {width: item.width} : null"
      :placeholder="item.placeholder"
      clearable
      filterable
      remote
      default-first-option
      :remote-method="remoteMethod"
      :loading="item.loading"
      v-bind="item.attr"
      :value="bindValue(item.propertyName)"
      ref="remoteSelect"
      @input="bindChange"
      @visible-change="selectVisibleChange">
      <i slot="prefix" class="el-icon-search" style="padding-top:8px;padding-left:4px;"></i>
      <el-option
        v-for="(opt, i) in item.options"
        :key="opt.value+i"
        :label="opt.label"
        :value="opt.value">
      </el-option>
    </el-select>
    <el-autocomplete
      v-else-if="item.type === 'autocomplete'"
      ref="autocomplete"
      popper-class="kye-popper-auto"
      :style="item.width ? {width: item.width} : null"
      :placeholder="item.placeholder"
      :trigger-on-focus="false"
      :fetch-suggestions="fetchSuggestions"
      v-bind="item.attr"
      :value="bindValue(item.propertyName)"
      @input="bindChange"
      @select="bindSelect">
    </el-autocomplete>
    <el-row
      v-else-if="item.type === 'range'"
      :gutter="8"
      :style="item.width ? {width: item.width} : null">
      <el-col
        v-for="(opt, i) in item.options"
        :key="opt.propertyName+i"
        :span="24 / item.options.length">
        <kye-number
          v-if="opt.type === 'number'"
          :symbol="opt.prepend"
          :unit="opt.append"
          v-bind="opt.attr"
          :value="bindValue(opt.propertyName)"
          @input="e => bindChange(e, opt)">
        </kye-number>
        <el-input
          v-else
          clearable
          :placeholder="opt.placeholder"
          v-bind="opt.attr"
          :value="bindValue(opt.propertyName)"
          @input="e => bindChange(e, opt)">
          <template v-if="opt.prepend" slot="prepend">{{ opt.prepend }}</template>
          <template v-if="opt.append" slot="append">{{ opt.append }}</template>
        </el-input>
      </el-col>
    </el-row>
    <!-- 日期组件：v-if 会导致弹框定位失效 -->
    <kye-date-picker
      v-for="opt in option.options.filter(v => v.type === 'datePicker')"
      v-show="item.propertyName === opt.propertyName"
      :style="opt.width ? {width: opt.width} : null"
      :key="opt.propertyName"
      :placeholder="opt.placeholder"
      :type="opt.dateType || 'date'"
      :format="opt.format || 'yyyy-MM-dd'"
      :value-format="opt.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
      :operation="opt.operation"
      v-bind="opt.attr"
      :value="bindValue(opt.propertyName)"
      @input="e => datePickerChange(e, opt)">
    </kye-date-picker>
    <el-time-picker
      v-for="opt in option.options.filter(v => v.type === 'timePicker')"
      v-show="item.propertyName === opt.propertyName"
      :style="opt.width ? {width: opt.width} : null"
      :key="opt.propertyName"
      :clearable="false"
      :is-range="opt.dateType === 'range'"
      value-format="HH:mm:ss"
      v-bind="opt.attr"
      :value="bindValue(opt.propertyName)"
      @input="e => datePickerChange(e, opt)">
    </el-time-picker>
  </el-form-item>
</template>

<script>
  import mixins from '../../mixins'
  import { getModelValue, setModelValue } from '../../utils'
  import { perfectField, getRemoteOptions, remoteSelectMethod, navigateSelectFirstOption } from './utils'

  export default {
    name: 'form-item-menu',
    mixins: [mixins],
    props: {
      option: Object,
      model: Object,
      fields: Array
    },
    data () {
      return {
        item: {}
      }
    },
    created () {
      this.option.$index = 0
      this.initOption()
      let first = this.option.options[0]
      if (first) {
        this.item = first
        let key = this.item.propertyName
        let obj = { key, value: getModelValue(this.model, key), model: this.model }
        this.item.change && this.item.change(obj)
      }
    },
    methods: {
      bindValue (key) {
        return getModelValue(this.model, key)
      },
      bindChange (value, opt = this.item) {
        if (value && typeof value === 'string') {
          value = value.trim()
        }
        let key = opt.propertyName
        setModelValue(value, this.model, key)
        opt.change && opt.change({ key, value, model: this.model, fields: this.fields })
      },
      bindSelect (value) {
        let key = this.item.propertyName
        this.item.select && this.item.select({ key, value, model: this.model, fields: this.fields })
      },
      datePickerChange (val, opt) {
        let keys = opt.valueKey
        if (keys && Array.isArray(keys)) {
          this.mergeModelInArray(val, keys, this.model)
        }
        this.bindChange(val, opt)
      },
      selectVisibleChange (val) {
        // 远程下拉框可见时，同步下拉框
        if (val && typeof this.item.remoteMethod === 'function') {
          if (this.item.type === 'remoteSelect') {
            // 远程搜索有默认的子选项
            this.item.options = this.item.lookupCode ? this.lookUpOptions[this.item.lookupCode] : []
          } else if (this.item.type === 'select') {
            getRemoteOptions(this.item, this.model)
          }
        }
      },
      async remoteMethod (val) {
        let arr = await remoteSelectMethod(val, this.item)
        if (arr.length) {
          // 自动选中第一行
          this.$nextTick(_ => navigateSelectFirstOption(this.$refs.remoteSelect))
        }
      },
      async fetchSuggestions (val, cb) {
        let arr = await remoteSelectMethod(val, this.item)
        cb(arr)
        if (arr.length) {
          // 自动选中第一行
          this.$nextTick(_ => {
            let ref = this.$refs.autocomplete
            ref && ref.highlight && ref.highlight(0)
          })
        }
      },
      handleMenuClick (menu) {
        let key = menu.propertyName
        this.item = menu
        let index = this.option.options.findIndex(v => v.propertyName === key)
        this.option.$index = index === -1 ? 0 : index
        let obj = { key, value: getModelValue(this.model, key), model: this.model }
        this.option.change && this.option.change(obj)
        this.$emit('menu-change', this.option, menu)
      },
      initOption () {
        if (this.option && this.option.options) {
          this.option.options.forEach(v => {
            perfectField(this, v)
          })
        }
      },
      mergeModelInArray (val, keys, model) {
        keys.forEach((v, i) => {
          setModelValue((val && val[i]), model, v)
        })
      }
    }
  }
</script>
