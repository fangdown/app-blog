<template>
  <div>
    <kye-canvas-table
      ref="table"
      :scrollY="scrollY"
      :height="height"
      :data="data"
      :column="column"
      :operation="operation"
      :options="options"
      :buttonOptions="buttonOptions"
      :imageOptions="imageOptions"
      :checkedOptions="checkedOptions"
      :uploadOptions="uploadOptions"
      :selection="options.type === 'selection'"
      :page="page"
      :pageable="pageable"
      :dialog="dialog"
      :fixed-header="fixedHeader"
      :offset-left="offsetLeft"
      @cell-click="cellClick"
      @row-click="rowClick"
      @row-dblclick="rowDblClick"
      @current-change="currentChange"
      @selection-change="selectionChange"
      @row-edit="handleCommand"
      @cell-checkbox="onCheckChange"
      @cell-upload="onClickUpload"
      @sort-change="sortChange"
      @switch-menu="e => $emit('switch-menu', e)"
      @btn-dbclick="btnDbclick"
      @col-resize="saveColWidth">
      <slot slot="tooltip"></slot>
    </kye-canvas-table>
    <kye-upload
      v-if="uploadkey"
      style="display: none"
      ref="upload"
      :code="uploadOptions[uploadkey].code"
      :id="uploadId"
      list-type="text"
      :show-file-list="false"
      :size="uploadOptions[uploadkey].size"
      @success="uploadSuccess"
      v-model="fileList">
    </kye-upload>
  </div>
</template>

<script>
  import mixins from '../../mixins'
  import { decrypt } from '../../utils/common'
  import KyeCanvasTable from '../kye-canvas-table'
  import { headerHeight, rowHeight } from '../kye-canvas-table/config'

  const DEFAULT_HEIGHT = headerHeight + 10 * rowHeight

  export default {
    mixins: [mixins],
    name: 'table-list',
    components: { KyeCanvasTable },
    props: {
      scrollY: Boolean,
      page: Object,
      pageable: Boolean,
      dialog: Boolean,
      fixedHeader: Boolean,
      maxHeight: Number,
      offsetLeft: Number,
      searchCode: String,
      data: Array,
      options: Object,
      column: Array,
      operation: Object,
      buttonOptions: Object,
      imageOptions: Object,
      checkedOptions: Object,
      uploadOptions: Object
    },
    data () {
      return {
        height: DEFAULT_HEIGHT,
        fileList: [],
        uploadRow: null,
        uploadId: ''
      }
    },
    mounted () {
      this.setColWidth()
      if (this.dialog && !this.maxHeight) {
        setTimeout(_ => {
          this.handleDialogHeight()
        }, 100)
      } else {
        this.setCanvasHeight()
      }
    },
    computed: {
      uploadkey () {
        if (this.uploadOptions && Object.keys(this.uploadOptions).length > 0) {
          return Object.keys(this.uploadOptions)[0]
        }
        return ''
      }
    },
    watch: {
      column (val) {
        this.initColWidth(val)
      },
      data () {
        if (this.dialog && !this.maxHeight && this.options.load) {
          setTimeout(_ => {
            this.handleDialogHeight()
          }, 300)
        }
      }
    },
    methods: {
      setCanvasWidth () {
        this.$refs.table.setCanvasWidth()
        this.setCanvasHeight()
      },
      setCanvasHeight () {
        this.$nextTick(_ => {
          if (this.dialog) {
            if (this.maxHeight) {
              this.height = this.maxHeight
            } else {
              this.handleDialogHeight()
            }
          } else {
            let dis = this.$el.getBoundingClientRect().top + 60
            let height = window.innerHeight - dis
            this.height = this.fixedHeader && height < DEFAULT_HEIGHT ? DEFAULT_HEIGHT : height
          }
        })
      },
      handleDialogHeight () {
        // tabs+单行表单+工具栏+统计栏+弹框头部   38+32+30+32+44
        let top = this.$el.offsetTop
        top = (top > 0 && top <= 176) ? top - 44 + 16 : 28
        this.height = Math.floor(window.innerHeight * 0.6) - top
      },
      async cellClick (row, column, val, markrow, mask, virtual) {
        const key = column.key
        if (!column._showButton) {
          return
        }
        // 监控字段
        if (mask || virtual) {
          const res = await decrypt({
            dataId: row.id || '11',
            moduleCode: this.options.moduleCode,
            fieldName: key,
            fieldContent: markrow[`${key}Mask`] || markrow[`${key}Virtual`]
          }, mask ? 'mask' : virtual ? 'virtual' : '')
          // 金额、数据字典等解密后也需要 formatter
          markrow[key] = column.formatter ? column.formatter(row, column, res) : res
          if (mask) {
            delete markrow[`${key}Mask`]
          }
          if (virtual) {
            delete markrow[`${key}Virtual`]
          }
          this.$refs.table.repaint()
        } else {
          this.buttonOptions && this.buttonOptions[key].func && this.buttonOptions[key].func(row, markrow, () => {
            this.$refs.table.repaint()
          })
        }
        this.$emit('cell-click', markrow, column, val, this.$refs.table.showSlotToolTip)
      },
      rowDblClick (val) {
        if (this.options.rowDblClick) {
          let auth = this.options.detailAuth
          auth = auth === false || (auth && this.permission.menus.includes(auth))
          if (!auth) {
            this.$message.warning('无权访问')
            return
          }
          this.options.rowDblClick(val, () => {
            this.$refs.table.reloadData()
          })
        }
      },
      btnDbclick (row, col) {
        col.dbclick(row)
      },
      rowClick (val) {
        if (this.options.rowClick) {
          this.options.rowClick(val)
        }
      },
      currentChange (val) {
        if (this.options.currentChange) {
          this.options.currentChange(val)
        }
      },
      selectionChange (val) {
        if (this.options.type === 'selection' && this.options.selectionChange) {
          this.options.selectionChange(val)
        }
      },
      handleCommand (row, column, value, btn) {
        if (!btn.func || this.buttonDisabled(btn.disabled, row)) {
          return
        }
        if (btn.type === 'link') {
          let route = (typeof btn.func === 'function') ? btn.func(row, btn) : btn.func
          route && this.$router.push(route)
        } else {
          btn.func(row, btn)
        }
      },
      onCheckChange (row, key, opt) {
        this.checkedOptions[key].func && this.checkedOptions[key].func(row, key, opt)
      },
      uploadSuccess (list) {
        const { uploadOptions, uploadkey } = this
        if (typeof uploadOptions[uploadkey].success === 'function') {
          uploadOptions[uploadkey].success(list, this.uploadRow)
        }
      },
      onClickUpload (row, key) {
        const { uploadOptions, uploadkey } = this
        if (typeof uploadOptions[uploadkey].id === 'function') {
          this.uploadId = uploadOptions[uploadkey].id(row)
        } else {
          this.uploadId = uploadOptions[uploadkey].id
        }
        this.uploadRow = row
        this.$refs.upload.manualUpload()
      },
      sortChange (e) {
        this.$emit('sort-change', e)
      },
      buttonDisabled (func, row) {
        return typeof func === 'function' ? func(row) : func
      },
      saveColWidth (key, width) {
        if (!this.searchCode) {
          return
        }
        let res = localStorage.getItem('GLOBAL_COL_WIDTH')
        let tag = `${this.$route.meta.tag}?${this.searchCode}`
        if (res) {
          try {
            res = JSON.parse(res)
            if (res[tag]) {
              res[tag][key] = width
            } else {
              res[tag] = { [key]: width }
            }
            localStorage.setItem('GLOBAL_COL_WIDTH', JSON.stringify(res))
          } catch (e) {
          }
        } else {
          res = { [tag]: { [key]: width } }
          localStorage.setItem('GLOBAL_COL_WIDTH', JSON.stringify(res))
        }
      },
      setColWidth () {
        let res = localStorage.getItem('GLOBAL_COL_WIDTH')
        if (this.searchCode && res) {
          try {
            let tag = `${this.$route.meta.tag}?${this.searchCode}`
            res = JSON.parse(res)
            res = res[tag]
            if (res) {
              this.$refs.table.colWidthMap = res
            }
          } catch (e) {
          }
        }
      },
      initColWidth (arr) {
        if (arr && this.$refs.table && this.$refs.table.textCtx) {
          const ctx = this.$refs.table.textCtx
          arr.forEach(v => {
            // 没有设置列宽或者列宽过小，则根据表头字符个数来设置列宽
            // 字体大小12px, padding: 0 6px, 排序图标8px
            let mixWidth = 12 + (ctx.measureText(v.label).width || v.label.length * 12)
            if (v.sortKeys && v.sortKeys.length) {
              mixWidth += 8
            }
            let width = parseInt(v.width || '')
            if (!width || width < mixWidth) {
              width = mixWidth
            }
            v.width = width
          })
        }
      }
    }
  }
</script>
