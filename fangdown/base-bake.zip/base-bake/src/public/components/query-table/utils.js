import { createModel, getModelValue } from '../../utils'

export const HTTP_ACTION = {
  FORM: 1, // 自定义查询表单
  GENERIC: 2, // 通用查询弹框表单
  PAGER: 3, // 分页组件
  SORT: 4, // 表头排序
  REFRESH: 5, // 调用loadData刷新列表
}

// 通用查询-操作 system_genericsearch_operation
export const OPERATIONS = {
  equal: 'equal',
  not_equal: 'not_equal',
  greaterthan: 'greaterthan',
  greaterthanorequal: 'greaterthanorequal',
  lessthan: 'lessthan',
  lessthanorequal: 'lessthanorequal',
  contain: 'contain',
  not_contain: 'not_contain',
  between: 'between',
  not_between: 'not_between'
}

// 通用查询值类型 system_GenericQuery_ValueType
export const COLUMN_TYPE = {
  number: 'number',
  string: 'string',
  enum: 'enum',
  date: 'date',
  phone: 'phone',
  area: 'area',
  user: 'user',
  department: 'department'
}

export const COMPARES = {
  enum: [
    OPERATIONS.equal,
    OPERATIONS.not_equal,
    OPERATIONS.contain,
    OPERATIONS.not_contain
  ],
  string: [
    OPERATIONS.equal,
    OPERATIONS.not_equal,
    OPERATIONS.contain,
    OPERATIONS.not_contain
  ],
  number: [
    OPERATIONS.equal,
    OPERATIONS.not_equal,
    OPERATIONS.greaterthan,
    OPERATIONS.greaterthanorequal,
    OPERATIONS.lessthan,
    OPERATIONS.lessthanorequal,
    OPERATIONS.between
  ],
  date: [
    OPERATIONS.equal,
    OPERATIONS.greaterthan,
    OPERATIONS.greaterthanorequal,
    OPERATIONS.lessthan,
    OPERATIONS.lessthanorequal,
    OPERATIONS.between
  ],
  phone: [
    OPERATIONS.equal
  ],
  area: [
    OPERATIONS.equal
  ],
  user: [
    OPERATIONS.equal,
    OPERATIONS.not_equal
  ],
  department: [
    OPERATIONS.equal,
    OPERATIONS.not_equal
  ]
}

export const SINGLE_VALUE = [
  COLUMN_TYPE.string,
  COLUMN_TYPE.phone,
  COLUMN_TYPE.user,
  COLUMN_TYPE.department
]

// 组件宽度默认值
const WIDTH_MAP = {
  text: 145, // 文本输入框
  number: 60, // 数字输入框
  select: 157, // 下拉选择框
  remoteSelect: 157, // 远程搜索框
  rangeMenu: 60, // 区间下拉选择
  range: 200, // 区间多选
  year: 60, // 日期格式 yyyy
  month: 80, // 日期格式 yyyy-MM
  date: 98, // 日期格式 yyyy-MM-dd
  datetime: 132, // 日期格式 yyyy-MM-dd HH:mm
  daterange: 168, // 日期区间格式 [yyyy-MM-dd, yyyy-MM-dd]
  datetimerange: 237, // 日期区间格式 [yyyy-MM-dd HH:mm, yyyy-MM-dd HH:mm]
  monthrange: 140, // 日期区间格式 [yyyy-MM, yyyy-MM]
  time: 78, // 时间格式 HH:mm:ss
  timerange: 135, // 时间区间格式 [HH:mm:ss, HH:mm:ss]
  user: 82, // 员工搜索组件
  department: 95 // 部门搜索组件
}

/**
 * 获取远程下拉框
 * @param v
 * @param model
 */
export const getRemoteOptions = (v, model) => {
  v.remoteMethod(model).then(e => {
    if (!e || !e.length) {
      v.options = []
      return
    }
    if (typeof e[0] === 'object') {
      // [{}]，数组每一项是对象
      v.labelKey && v.valueKey && e.forEach(k => {
        k.label = k[v.labelKey]
        k.value = k[v.valueKey]
      })
    } else {
      // ['']，数组每一项是基本类型
      e = e.map(k => ({ label: k, value: k }))
    }
    v.options = e
  })
}

/**
 * 远程搜索下拉框
 * @param val
 * @param v
 * @returns {Promise<Array>}
 */
export const remoteSelectMethod = async (val, v) => {
  val = (val && val.trim()) || ''
  if (val && typeof v.remoteMethod === 'function') {
    v.loading = true
    let arr = await v.remoteMethod(val)
    v.loading = false
    if (!arr || !arr.length) {
      v.options = []
      return Promise.resolve(v.options)
    }
    if (typeof arr[0] === 'object') {
      // [{}]，数组每一项是对象
      v.labelKey && v.valueKey && arr.forEach(k => {
        k.label = k[v.labelKey]
        k.value = k[v.valueKey]
      })
    } else {
      // ['']，数组每一项是基本类型
      arr = arr.map(k => ({ label: k, value: k }))
    }
    v.options = arr
    return Promise.resolve(v.options)
  }
  v.options = []
  return Promise.resolve(v.options)
}

/**
 * 补全 通用查询 的逻辑参数
 * @param vos
 */
export const perfectVos = vos => {
  let len = vos.length - 1
  vos.forEach((v, i) => {
    if (i < len && !v.conditionOperation) {
      v.conditionOperation = 'and'
    } else if (i === len) {
      v.conditionOperation = ''
    }
    if (!v.frontBrackets) {
      v.frontBrackets = '('
    }
    if (!v.postBrackets) {
      v.postBrackets = ')'
    }
  })
}

/**
 * 构造 通用查询 参数
 * @param fields
 * @param model
 * @param generic
 * @returns {{generic: {vos: Array}}}
 */
export const mapGenericSearchParams = (fields, model, generic = {}) => {
  let vos = []
  if (model) {
    fields.forEach(v => {
      if (v.show) {
        if (v.type === 'menu' && v.options) {
          let item = v.options[v.$index || 0]
          if (item && item.columnType && item.operation) {
            if (item.type === 'range') {
              let operation = ''
              let values = []
              item.options && item.options.forEach(m => {
                let val = getModelValue(model, m.propertyName)
                if (val || val === 0) {
                  operation = m.operation
                  values.push(val)
                }
              })
              if (operation) {
                if (values.length > 1) {
                  operation = item.operation
                }
                mapGenericVos(model, vos, item, { operation, values })
              }
            } else {
              mapGenericVos(model, vos, item)
            }
          }
          return
        }
        if (v.type === 'range') {
          let operation = ''
          let values = []
          v.options && v.options.forEach(k => {
            let val = getModelValue(model, k.propertyName)
            if (val || val === 0) {
              operation = k.operation
              values.push(val)
            }
          })
          if (operation) {
            if (values.length > 1) {
              operation = v.operation
            }
            mapGenericVos(model, vos, v, { operation, values })
          }
          return
        }
        if (v.type === 'rangeMenu' && v.options) {
          let item = v.options[v.$index || 0]
          v.operation = item.operation
          mapGenericVos(model, vos, item, { values: [getModelValue(model, item.propertyName)] })
          return
        }
        if (v.type === 'area') {
          let areas = getModelValue(model, v.propertyName)
          areas && v.options && areas.forEach((val, i) => {
            if (val.id) {
              mapGenericVos(model, vos, v.options[i], { values: [val.id] })
            }
          })
          return
        }
        if (v.type === 'user') {
          let areas = getModelValue(model, v.propertyName)
          areas && v.options && areas.forEach((val, i) => {
            mapGenericVos(model, vos, v.options[i], { values: [val.id] })
          })
          return
        }
        mapGenericVos(model, vos, v)
      }
    })
  }
  perfectVos(vos)
  return { generic: { ...generic, vos } }
}

/**
 * 构造 非通用查询 参数
 * @param fields
 * @param model
 * @returns {{}}
 */
export const mapFormModelParams = (fields, model) => {
  let vo = {}
  let arr = []
  if (model) {
    fields.forEach(v => {
      if (v.show) {
        if ((v.type === 'menu' || v.type === 'rangeMenu') && v.options) {
          parseValueKey(arr, v.options[v.$index || 0], model)
          return
        }
        if (v.type === 'area') {
          let flag = v.options && v.options.some(k => (!k.columnType || !k.operation))
          if (flag) {
            let areas = getModelValue(model, v.propertyName)
            areas && areas.forEach((val, i) => {
              if (val.id) {
                arr.push({
                  key: v.options[i].propertyName,
                  default: val.id
                })
              }
            })
          }
          return
        }
        parseValueKey(arr, v, model)
      }
    })
  }
  return arr.length ? createModel(arr, 'key') : vo
}

/**
 * 扁平化 区间列
 * @param rows
 * @param sectionOption
 */
export const mapSectionValueList = (rows, sectionOption) => {
  if (sectionOption && rows) {
    let row_key = sectionOption.row
    let key_key = sectionOption.key
    let value_key = sectionOption.value
    let $row_key = sectionOption.$row
    rows.forEach(v => {
      if (v[row_key] && v[row_key].length) {
        v[$row_key] = v[row_key].reduce((s, k) => {
          s[k[key_key]] = k[value_key]
          return s
        }, {})
      } else {
        v[$row_key] = {}
      }
    })
  }
}

/**
 * 处理后台数据
 * 容错: [null, {}] -> [{}, {}]
 * @param res
 * @returns {*}
 */
export const perfectRows = (res) => {
  if (Array.isArray(res)) {
    res = { rows: res, rowTotal: res.length }
  }
  if (res.rows) {
    res.rows.forEach((v, i) => {
      if (!v) {
        res.rows[i] = {}
      }
    })
  }
  return res
}

/**
 * 补全 自定义查询表单 默认配置
 * @param vm
 * @param v
 */
export const perfectField = (vm, v) => {
  // 员工、部门
  if (v.type === 'remoteSelect') {
    if (v.columnType === 'user') {
      let label = 'chineseName'
      v.width = WIDTH_MAP['user']
      v.columnType = 'string'
      v.labelKey = label
      v.valueKey = 'id'
      let fn = v.formatterOption || (v => `${v[label]}-${v.employeeNumber}`)
      v.remoteMethod = val => vm.$http('data.employee.listByName', { chineseName: val }).then(res => {
        res && res.forEach(c => c[label] = fn(c))
        return res
      })
    } else if (v.columnType === 'department') {
      let label = 'name'
      v.width = WIDTH_MAP['department']
      v.columnType = 'string'
      v.labelKey = label
      v.valueKey = 'id'
      let fn = v.formatterOption || (v => `${v[label]}-${v.departmentCode}`)
      v.remoteMethod = val => vm.$http('hr.department.refactoring.getByFuzzyValue', { fuzzyValue: val }).then(res => {
        res && res.forEach(c => c[label] = fn(c))
        return res
      })
    }
  }
  // 远程搜索下拉框
  if (v.remoteMethod) {
    vm.$set(v, 'loading', false)
    vm.$set(v, 'options', [])
  }
  if (v.type === 'select' && !v.remoteMethod) {
    if (v.lookupCode) {
      let arr = vm.lookUpOptions[v.lookupCode] || []
      // null 查询
      if (!v.unNull) {
        arr = arr.concat({ label: '(空)', value: 'null' })
      }
      v.options = arr
    } else if (!v.options) {
      vm.$set(v, 'options', [])
    }
  }
  // 日期单位为月，自动设置 yyyy-MM
  if (v.type === 'datePicker') {
    let type = v.dateType
    if (type === 'month') {
      v.format = v.valueFormat = 'yyyy-MM'
    } else if (type && type.includes('time')) {
      v.format = 'yyyy-MM-dd HH:mm'
    } else if (v.format === 'yyyy-MM' && type && type.includes('range')) {
      type = 'monthrange'
    }
    v.width = WIDTH_MAP[type || 'time']
  }
  v.placeholder = '' // 单行不用这个功能
  setFieldWidth(v) // 宽度处理
}

/**
 * 构造 通用查询 vos
 * @param model
 * @param vos
 * @param v
 * @param v2
 */
const mapGenericVos = (model, vos, v, v2) => {
  if (!v.columnType || !v.operation) {
    return
  }
  let val = ''
  if (v2) {
    val = v2.values
  } else {
    val = getModelValue(model, v.propertyName)
    if (val && !Array.isArray(val)) {
      val = [val]
    }
  }
  if (val && val.length) {
    let vo = {
      propertyName: v.propertyName,
      columnName: v.columnName,
      frontBrackets: v.frontBrackets,
      postBrackets: v.postBrackets,
      conditionOperation: v.conditionOperation,
      operation: v.operation,
      type: v.columnType,
      values: val,
      ...v2
    }
    // 扩展字段
    if (v.attribute1 && typeof v.attribute1 === 'object') {
      Object.assign(vo, v.attribute1)
    }
    vos.push(vo)
  }
}

/**
 * 详情页通用查询分页器对象
 * @param idKey
 * @param rows
 * @returns {{total, ids, query}}
 */
export const getQueryPager = (idKey, rows) => {
  let pager = { total: rows.length }
  if (typeof idKey === 'object' && typeof idKey.func === 'function') {
    // {idKey: 'xx.xx', func: row => ({xx: 'xx'})}
    let ids = []
    let key = idKey.idKey || 'id'
    pager.query = rows.reduce((s, v) => {
      let id = `${getModelValue(v, key)}`
      ids.push(id)
      s[id] = idKey.func(v)
      return s
    }, {})
    pager.ids = ids
  } else {
    pager.ids = rows.map(v => `${getModelValue(v, idKey)}`)
  }
  return pager
}

const parseValueKey = (arr, v, model) => {
  if (v && (!v.columnType || !v.operation)) {
    let keys = v.valueKey
    let val = getModelValue(model, v.propertyName)
    if (keys && Array.isArray(keys)) {
      val && keys.forEach((k, i) => {
        arr.push({
          key: k,
          default: val[i]
        })
      })
    } else {
      arr.push({
        key: v.propertyName,
        default: val
      })
    }
  }
}

const setFieldWidth = (v) => {
  let width = v.width
  let type = v.type
  if (width && type !== 'menu') {
    v.width = parseInt(width) + 'px'
    return
  }
  if (type === 'timePicker') {
    width = WIDTH_MAP['time' + (v.dateType || '')]
  } else if (type === 'area' && v.options && v.options.length) {
    let len = v.options.length
    width = len <= 3 ? 118 * len : 118 * 3 + 180 * (len - 3)
  } else if (type === 'menu' && v.options && v.options.length) {
    v.options.forEach(c => {
      let cwidth = c.width
      if (!cwidth) {
        let ctype = c.type
        if (ctype === 'datePicker' || ctype === 'timePicker') {
          cwidth = WIDTH_MAP[c.dateType || 'time' + (v.dateType || '')]
        } else {
          cwidth = WIDTH_MAP[ctype]
        }
      }
      c.width = parseInt(cwidth) + 'px'
    })
    width = v.options[0].width
  } else {
    width = WIDTH_MAP[type]
  }
  v.width = parseInt(width) + 'px'
}

/**
 * select 自动选中第一个子项
 * @param vm: select 组件实例
 */
export const navigateSelectFirstOption = vm => {
  if (vm && vm.$refs && vm.$refs.remoteSelect && vm.$refs.remoteSelect.navigateOptions) {
    // kye-select
    vm.$refs.remoteSelect.navigateOptions('next')
  } else if (vm && vm.navigateOptions) {
    // el-select
    vm.navigateOptions('next')
  }
}

/**
 * 根据通用查询模板生成通用查询参数
 * @param arr
 * @param fields
 * @param esFlag
 * @returns {Array}
 */
export const appendGenericVosByTemplate = (arr, fields, esFlag) => {
  const vos = []
  if (!arr || !fields) {
    return vos
  }

  let key = esFlag ? 'propertyName' : 'columnName'
  const componentMap = {
    [COLUMN_TYPE.user]: COLUMN_TYPE.string,
    [COLUMN_TYPE.department]: COLUMN_TYPE.string,
    [COLUMN_TYPE.phone]: COLUMN_TYPE.string
  }

  arr.forEach(v => {
    let field = fields.find(f => f.key === v[key])
    let values = v.queryValue
    if (!field || !values) {
      return false
    }
    let type = field.columnType
    let vo = {
      propertyName: v.propertyName,
      columnName: v.columnName,
      frontBrackets: v.frontBrackettemplates,
      postBrackets: v.postBrackets,
      conditionOperation: v.conditionOperation,
      operation: v.operation,
      type: componentMap[type] || type
    }
    // 将模板字符串形式的值解析为数组
    if (type === COLUMN_TYPE.user || type === COLUMN_TYPE.department) {
      try {
        let arr = JSON.parse(values)
        values = [arr[0].value]
      } catch (e) {
        values = values.split(',')
      }
    } else {
      values = values.split(',')
    }
    // merge 扩展字段的参数
    if (field.attribute1) {
      try {
        Object.assign(vo, JSON.parse(field.attribute1))
      } catch (e) {
      }
    }
    // 组装通用查询参数
    if (type === COLUMN_TYPE.area) {
      let options = field.$attr.options
      let lastIndex = values.length - 1
      values.forEach((id, index) => {
        if (id) {
          let opt = options[index]
          vos.push({
            propertyName: opt.propertyName,
            columnName: opt.columnName,
            frontBrackets: '(',
            postBrackets: ')',
            conditionOperation: index === lastIndex ? v.conditionOperation : 'and',
            operation: v.operation,
            type: opt.columnType,
            values: [v]
          })
        }
      })
    } else {
      vo.values = values
      vos.push(vo)
    }
  })
  return vos
}
