<template>
  <div class="kye-tool-list" :style="wrapStyle">
    <template
      v-for="(btn, i) in tools"
      v-if="typeof btn.show === 'function' ? btn.show() : btn.show">
      <formatter v-if="btn.formatter" :key="i" :option="btn" />
      <el-checkbox
        v-else-if="btn.type === 'checkbox'"
        :key="btn.label+i"
        :class="activeBtn === btn.label ? 'el-button--text is-active' : 'el-button--text'"
        :checked="typeof btn.default === 'function' ? btn.default() : btn.default"
        :disabled="authDisabled(btn)"
        @change="val => otherClick(val, btn)">{{ btn.label }}
      </el-checkbox>
      <kye-upload
        v-else-if="btn.type === 'upload'"
        :key="btn.label+i"
        style="display:inline-block;"
        :class="activeBtn === btn.label ? 'el-button--text is-active' : 'el-button--text'"
        v-model="btn.value"
        btn-type="text"
        :btn-text="btn.label"
        :id="getUUID(btn)"
        :disabled="btnClick(btn)"
        :attr="btn.attr"
        v-bind="btn"
        @success="btn.success"
        @delete-success="btn.deleteSuccess">
      </kye-upload>
      <el-dropdown
        v-else-if="btn.type === 'menu'"
        :key="btn.label+i"
        :class="activeBtn === btn.label ? 'el-button--text is-active' : 'el-button--text'"
        :disabled="btnDisabled(btn.disabled)"
        :trigger="btn.trigger || 'click'"
        placement="bottom-start"
        @command="val => otherClick(val, btn)">
        <span class="el-dropdown-link el-button el-button--text">
          {{btn.label}}<i class="iconfont icon-caretdown"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item
            v-for="(opt, j) in btn.options"
            :key="opt.key+j"
            :command="opt"
            :disabled="authDisabled(opt)">{{opt.label}}
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <kye-button
        v-else
        :key="btn.label+i"
        type="text"
        :class="activeBtn === btn.label ? 'is-active' : ''"
        :icon="iconClass(btn)"
        :auth="btn.auth"
        :hotkey="btn.hotkey"
        :disabled="btnDisabled(btn.disabled)"
        @click="btnClick(btn)">{{btn.label}}
      </kye-button>
    </template>
  </div>
</template>

<script>
  import mixins from '../../mixins'
  import Formatter from './form-item-formatter'

  export default {
    mixins: [mixins],
    name: 'tool-list',
    components: { Formatter },
    props: {
      tools: Array,
      wrapStyle: Object,
      active: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        activeBtn: ''
      }
    },
    created () {
      this.initProps()
    },
    watch: {
      tools () {
        this.initProps()
      }
    },
    methods: {
      initProps () {
        if (this.tools && this.tools.length) {
          this.tools.forEach(v => {
            if (!v.hasOwnProperty('show')) {
              v.show = true
            }
            let label = v.label && v.label.replace(/\([A-Z]\)/, '')
            switch (label) {
              case '新增':
                v.hotkey = 'ctrl+o'
                break
              case '保存':
                v.hotkey = 'ctrl+s'
                break
              case '取消':
                v.hotkey = 'ctrl+q'
                break
              case '刷新':
                v.hotkey = 'ctrl+r'
                break
            }
            let hotkey = v.hotkey
            if (label && hotkey && hotkey.includes('+')) {
              v.label = `${label}(${hotkey.substr(hotkey.indexOf('+') + 1).toUpperCase()})`
            }
          })
        }
      },
      btnDisabled (disabled) {
        return (typeof disabled === 'function') ? disabled() : !!disabled
      },
      authDisabled ({ disabled, auth }) {
        return (auth && !this.permission.menus.includes(auth)) || this.btnDisabled(disabled)
      },
      iconClass (btn) {
        let cls = (typeof btn.class === 'function') ? btn.class() : (btn.class || '')
        return `${cls} ${btn.icon ? 'iconfont icon-' + btn.icon : ''}`
      },
      btnClick (btn) {
        if (btn.type === 'link') {
          let route = (typeof btn.func === 'function') ? btn.func(btn) : btn.func
          this.$router.push(route)
        } else {
          btn.func && btn.func(btn)
        }
        if (this.active) {
          this.activeBtn = btn.label
        }
      },
      otherClick (val, btn) {
        btn.func && btn.func(val, btn)
        if (this.active) {
          this.activeBtn = btn.label
        }
      },
      clearActiveBtn () {
        this.activeBtn = ''
      },
      getUUID (btn) {
        return typeof btn.id === 'function' ? btn.id(btn) : btn.id
      }
    }
  }
</script>
