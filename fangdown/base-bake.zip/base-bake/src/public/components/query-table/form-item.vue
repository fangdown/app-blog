<template>
  <el-form-item
    :class="item.type === 'area' ? 'item-area' : ''"
    :label="item.type === 'area' ? ' ' : item.label"
    :prop="item.propertyName"
    :rules="item.attr && item.attr.rules">
    <!-- slot label -->
    <formatter v-if="item.formatterLabel" slot="label" :formatter="item.formatterLabel" :option="item" />
    <el-radio
      v-else-if="item.labelType === 'radio' && item.labelModel"
      slot="label"
      :label="item.propertyName"
      v-model="model[item.labelModel]"
      @change="e => item.labelChange && item.labelChange(e, model, item)">{{ item.label }}
    </el-radio>
    <!-- slot default -->
    <formatter v-if="item.formatter" :option="item" :model="model" />
    <kye-number
      v-else-if="item.type === 'number'"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @input="bindChange">
    </kye-number>
    <el-input
      v-else-if="item.type === 'text'"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @input="bindChange">
    </el-input>
    <kye-select
      v-else-if="item.type === 'select'"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      default-first-option
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @input="bindChange"
      @visible-change="selectVisibleChange">
      <kye-option
        v-for="(opt, i) in item.options"
        :key="opt.value+i"
        :label="opt.label || ' '"
        :value="opt.value">
      </kye-option>
    </kye-select>
    <kye-select
      v-else-if="item.type === 'remoteSelect'"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      filterable
      remote
      default-first-option
      :remote-method="remoteMethod"
      :loading="item.loading"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      ref="remoteSelect"
      @input="bindChange"
      @visible-change="selectVisibleChange">
      <!-- <i slot="prefix" class="el-icon-search" style="padding-top:8px;padding-left:4px;"></i> -->
      <kye-option
        v-for="(opt, i) in item.options"
        :key="opt.value+i"
        :label="opt.label"
        :value="opt.value">
      </kye-option>
    </kye-select>
    <el-autocomplete
      v-else-if="item.type === 'autocomplete'"
      ref="autocomplete"
      popper-class="kye-popper-auto"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      :trigger-on-focus="false"
      :fetch-suggestions="fetchSuggestions"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @blur="handleBlur"
      @input="bindChange"
      @select="bindSelect">
    </el-autocomplete>
    <kye-date-picker
      v-else-if="item.type === 'datePicker'"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :placeholder="item.placeholder"
      :type="item.dateType || 'date'"
      :format="item.format || 'yyyy-MM-dd'"
      :value-format="item.valueFormat || 'yyyy-MM-dd HH:mm:ss'"
      :operation="item.operation"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @input="datePickerChange">
    </kye-date-picker>
    <kye-time-picker
      v-else-if="item.type === 'timePicker'"
      :style="item.width ? {width: item.width} : null"
      :is-range="item.dateType === 'range'"
      value-format="HH:mm:ss"
      v-bind="bindAttr"
      :value="bindValue(item.propertyName)"
      @input="datePickerChange">
    </kye-time-picker>
    <kye-area-remote
      v-else-if="item.type === 'area'"
      show-label
      :show-placeholder="false"
      :style="item.width ? {width: item.width} : null"
      :disabled="isDisabled(item)"
      :level="item.options.length"
      :labels="item.options.map(v => v.label)"
      :value="bindValue(item.propertyName)"
      @input="e => bindChange(e)">
    </kye-area-remote>
    <el-row
      v-else-if="item.type === 'range'"
      :gutter="8"
      :style="item.width ? {width: item.width} : null">
      <el-col
        v-for="(opt, i) in item.options"
        :key="opt.propertyName+i"
        :span="24 / item.options.length">
        <kye-number
          v-if="opt.type === 'number'"
          :symbol="opt.prepend"
          :unit="opt.append"
          v-bind="opt.attr"
          :value="bindValue(opt.propertyName)"
          @input="e => bindChange(e, opt)">
        </kye-number>
        <el-input
          v-else
          :placeholder="opt.placeholder"
          v-bind="opt.attr"
          :value="bindValue(opt.propertyName)"
          @input="e => bindChange(e, opt)">
          <template v-if="opt.prepend" slot="prepend">{{ opt.prepend }}</template>
          <template v-if="opt.append" slot="append">{{ opt.append }}</template>
        </el-input>
      </el-col>
    </el-row>
  </el-form-item>
</template>

<script>
  import mixins from '../../mixins'
  import { getModelValue, setModelValue } from '../../utils'
  import { getRemoteOptions, remoteSelectMethod, navigateSelectFirstOption } from './utils'
  import Formatter from './form-item-formatter'

  export default {
    name: 'form-item',
    mixins: [mixins],
    components: { Formatter },
    props: {
      item: Object,
      model: Object,
      fields: Array
    },
    computed: {
      bindAttr () {
        if (!this.item.attr) {
          return { clearable: !this.item.required }
        }
        if (!this.item.attr.hasOwnProperty('clearable')) {
          // eslint-disable-next-line
          this.item.attr.clearable = !this.item.required
        }
        return this.item.attr
      }
    },
    methods: {
      bindValue (key) {
        return getModelValue(this.model, key)
      },
      bindChange (value, opt = this.item) {
        if (value && typeof value === 'string') {
          value = value.trim()
        }
        let key = opt.propertyName
        setModelValue(value, this.model, key)
        opt.change && opt.change({ key, value, model: this.model, fields: this.fields })
      },
      bindSelect (value) {
        let key = this.item.propertyName
        this.item.select && this.item.select({ key, value, model: this.model, fields: this.fields })
      },
      datePickerChange (val) {
        let keys = this.item.valueKey
        if (keys && Array.isArray(keys)) {
          this.mergeModelInArray(val, keys, this.model)
        }
        this.bindChange(val)
      },
      selectVisibleChange (val) {
        // 远程下拉框可见时，同步下拉框
        if (val && typeof this.item.remoteMethod === 'function') {
          if (this.item.type === 'remoteSelect') {
            // 远程搜索有默认的子选项
            this.item.options = this.item.lookupCode ? this.lookUpOptions[this.item.lookupCode] : []
          } else if (this.item.type === 'select') {
            getRemoteOptions(this.item, this.model)
          }
        }
      },
      async remoteMethod (val) {
        let arr = await remoteSelectMethod(val, this.item)
        if (arr.length) {
          // 自动选中第一行
          this.$nextTick(_ => navigateSelectFirstOption(this.$refs.remoteSelect))
        }
      },
      async fetchSuggestions (val, cb) {
        let arr = await remoteSelectMethod(val, this.item)
        cb(arr)
        if (arr.length) {
          // 自动选中第一行
          this.$nextTick(_ => {
            let ref = this.$refs.autocomplete
            ref && ref.highlight && ref.highlight(0)
          })
        } else {
          this.$refs.autocomplete.$emit('select', {[this.item.labelKey]: val})
        }
      },
      handleBlur () {
        let isEmpty = true
        for (let [k, v] of Object.entries(this.model)) {
          if (k !== this.item.propertyName) {
            isEmpty = !v
          }
        }
        isEmpty && this.$refs.autocomplete.$emit('input', null)
      },
      mergeModelInArray (val, keys, model) {
        keys.forEach((v, i) => {
          setModelValue((val && val[i]), model, v)
        })
      },
      isDisabled (item) {
        if (typeof item.disabled === 'function') {
          let obj = { key: item.propertyName, model: this.model }
          return item.disabled(obj)
        }
        return !!item.disabled
      }
    }
  }
</script>
