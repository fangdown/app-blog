<template>
  <el-form ref="queryForm"
           class="kye-query-form"
           v-next
           inline
           :model="model">
    <template v-for="item in rowFields">
      <form-item-menu v-if="item.type === 'menu' || item.type === 'rangeMenu'"
                      :key="item.propertyName"
                      :fields="rowFields"
                      :model="model"
                      :option="item"
                      @menu-change="menuChange">
      </form-item-menu>
      <form-item v-else
                 :key="item.propertyName"
                 :fields="rowFields"
                 :model="model"
                 :item="item" />
    </template>
    <el-form-item v-if="generic && generic.searchCode"
                  class="item-generic"
                  title="可以选择“通用查询”里面的模板进行组合查询"
                  label="查询模板">
      <kye-select v-model="templateId" placeholder="" style="width:78px;">
        <kye-option
          v-for="opt in templateList"
          :key="opt.id+opt.name"
          :label="opt.name"
          :value="opt.id">
        </kye-option>
      </kye-select>
    </el-form-item>
    <kye-button type="primary"
                icon="iconfont icon-search"
                :auth="option.auth"
                @click="onSubmit">查询
    </kye-button>
    <!-- tools内联到右边 -->
    <tool-list v-if="option.inlineTools && tools"
               :active="false"
               :tools="tools"
               style="display:inline-block;position:absolute;right:0;">
    </tool-list>
  </el-form>
</template>

<script>
  import { throttle } from 'lodash'
  import Schema from 'async-validator'
  import mixins from '../../mixins'
  import { createModel } from '../../utils'
  import { perfectField, mapFormModelParams, mapGenericSearchParams, appendGenericVosByTemplate } from './utils'
  import FormItem from './form-item.vue'

  export default {
    mixins: [mixins],
    name: 'query-form',
    components: { FormItem },
    props: {
      value: {
        type: Object,
        default: () => ({})
      },
      option: {
        type: Object,
        default: () => ({})
      },
      fields: {
        type: Array,
        default: () => ([])
      },
      tools: Array,
      generic: Object,
      genericModel: Object,
      templateList: Array
    },
    data () {
      return {
        model: {},
        menuWidth: 160,
        rowFields: [],
        templateId: ''
      }
    },
    created () {
      this.initFields()
      this.handleRowFields()
      this.model = this.createModel()
      let params = {
        ...mapFormModelParams(this.fields, this.model),
        ...mapGenericSearchParams(this.fields, this.model)
      }
      this.$emit('created', this.model, params)
    },
    mounted () {
      if (!this.option.dialog) {
        this.resizeEvent = throttle(this.handleResize, 16)
        window.addEventListener('resize', this.resizeEvent)
        this.$bus.$on('SWITCH_MENU', this.handleSwitchMenu)
      }
    },
    beforeDestroy () {
      if (!this.option.dialog) {
        window.removeEventListener('resize', this.resizeEvent)
        this.$bus.$off('SWITCH_MENU', this.handleSwitchMenu)
      }
    },
    computed: {
      rules () {
        return this.rowFields.reduce((s, v) => {
          if (v.attr && v.attr.rules) {
            s[v.propertyName] = v.attr.rules
          }
          return s
        }, {})
      }
    },
    watch: {
      fields (val) {
        this.handleRowFields(val)
      }
    },
    methods: {
      getModel () {
        return this.model
      },
      onSubmit () {
        const validator = new Schema(this.rules)
        validator.validate(this.model, (errors, fields) => {
          if (errors) {
            this.$message.warning(errors[0].message)
          } else {
            let params = {
              ...mapFormModelParams(this.rowFields, this.model),
              ...mapGenericSearchParams(this.rowFields, this.model)
            }
            // 拼接查询模板
            let model = this.genericModel
            if (model && this.templateList && this.templateId) {
              let obj = this.templateList.find(v => v.id === this.templateId)
              if (obj && obj.columnList) {
                let vos = appendGenericVosByTemplate(obj.columnList, model.fields, model.esFlag)
                params.generic.vos.push(...vos)
              }
            }
            this.$emit('submit', this.model, params)
          }
        })
      },
      onReset () {
        this.model = this.createModel()
        this.$refs.queryForm.resetFields()
        this.$emit('reset', this.model)
      },
      createModel () {
        let model = createModel(this.fields, 'propertyName', this.getDefaultValue)
        if (this.fields && this.fields.length) {
          this.fields.forEach(v => {
            if (v.labelType === 'radio' && v.labelModel && v.labelValue) {
              model[v.labelModel] = v.labelValue
            }
          })
        }
        return model
      },
      getDefaultValue (v, key) {
        if (this.value.hasOwnProperty(key)) {
          let func = this.value[key]
          if (typeof func === 'function') {
            return func()
          }
          return this.value[key]
        } else {
          return v.default || ''
        }
      },
      initFields () {
        if (this.fields && this.fields.length) {
          this.fields.forEach(this.mergeFormField)
        }
      },
      mergeFormField (v) {
        this.$set(v, '$show', !!v.show)
        this.$set(v, 'show', !!v.show)
        let span = this.option.span && +v.span // 配置span则启用自定义布局
        v.span = span || (this.option.dialog ? 4 : (v.dateType && v.dateType.includes('range') ? 6 : 3))
        // 必传字段，个性设置里不可编辑
        v.required = !!v.required
        if ((v.type === 'range' || v.type === 'rangeMenu') && v.options && v.options.length) {
          v.options.forEach(this.mergeField)
        } else if (v.type === 'menu' && v.options && v.options.length) {
          v.label = v.options[0].label
          v.options.forEach(k => {
            if (k.type === 'range' && k.options && k.options.length) {
              k.options.forEach(this.mergeField)
            } else {
              this.mergeField(k)
            }
          })
          // menu 类型的子项有日期区间
          let dateRange = !span && v.options.some(k => k.dateType && k.dateType.includes('range'))
          if (dateRange) {
            v.span = this.option.dialog ? 4 : 6
          }
        } else if (v.type === 'area' && v.options && v.options.length) {
          v.span = (span || (this.option.dialog ? 4 : 3)) * v.options.length
          v.label = v.options.map(v => v.label).join('-')
        }
        this.mergeField(v)
      },
      mergeField (v) {
        if (this.option[v.propertyName]) {
          Object.assign(v, this.option[v.propertyName])
        }
        if (!v.hasOwnProperty('default') && (v.type === 'area' || (v.type === 'select' && v.attr && v.attr.multiple))) {
          v.default = []
        }
        perfectField(this, v)
      },
      handleResize () {
        this.handleRowFields()
      },
      handleSwitchMenu (width) {
        this.menuWidth = width
        this.handleRowFields()
      },
      menuChange (item, menu) {
        item.width = menu.width
        this.handleRowFields()
      },
      handleRowFields (fields = this.fields) {
        // 内联表单溢出
        if (this.option.overflow) {
          this.rowFields = fields.filter(v => v.show)
          return
        }
        this.$nextTick(_ => {
          let sum = 0
          let arr = []
          // 查询模板140，查询按钮70 + 左右内边距32 + 滚动条16
          const diff = this.generic && this.generic.searchCode ? 140 + 118 : 118
          const maxWidth = this.option.dialog
            ? this.$parent.$el.getBoundingClientRect().width - diff
            : document.documentElement.clientWidth - this.menuWidth - diff
          fields.forEach(v => {
            if (v.show) {
              let type = v.type
              let w = parseInt(v.width)
              // 地址组件不计算 label
              if (type !== 'area') {
                w += v.label.length * 12 + 12
              }
              // 三角箭头
              if (type && type.includes('menu')) {
                w += 16
              }
              sum += w
              // console.log('query-form-field', v.label, w, sum, maxWidth)
              if (sum < maxWidth) {
                arr.push(v)
              }
            }
          })
          this.rowFields = arr
        })
      }
    }
  }
</script>
