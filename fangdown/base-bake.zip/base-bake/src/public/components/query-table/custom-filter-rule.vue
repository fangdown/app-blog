<template>
  <div class="kye-filter-rule noselect" v-next>
    <el-table :height="height" :data="rules" :stripe="false" :border="false" :highlight-current-row="false">
      <el-table-column width="60" align="center" label="(" label-class-name="td-front">
        <template slot-scope="scope">
          <div class="colindex">{{scope.$index+1}}</div>
          <el-input v-model="scope.row.frontBrackets" style="width:36px;"></el-input>
        </template>
      </el-table-column>
      <el-table-column width="120" align="left" label="查询条件">
        <template slot-scope="scope">
          <kye-select
            v-model="scope.row.key"
            placeholder="选择字段名"
            filterable
            default-first-option
            :disabled="isDisabled(scope.row.key, scope.$index)"
            @change="clearFieldValue(scope.row)">
            <el-option
              v-for="opt in config.fields"
              :key="opt.key"
              v-if="opt.show"
              :label="opt.columnDisplayName || v.label"
              :value="opt.key">
            </el-option>
          </kye-select>
        </template>
      </el-table-column>
      <el-table-column width="90" align="left" label="条件关系">
        <template slot-scope="scope">
          <kye-select
            v-model="scope.row.operation"
            placeholder="请选择"
            default-first-option
            :disabled="isDisabled(scope.row.key, scope.$index)"
            @change="operationChange(scope.row)">
            <el-option
              v-for="opt in config.operations"
              v-if="isValidCompareOption(opt.value, scope.row)"
              :key="opt.value"
              :label="opt.label"
              :value="opt.value">
            </el-option>
          </kye-select>
        </template>
      </el-table-column>
      <el-table-column align="left" label="条件值">
        <template slot-scope="scope">
          <kye-select
            v-if="typeof scope.row.remoteMethod === 'function'"
            ref="remoteSelect"
            class="kye-select--multiple"
            placeholder="请搜索"
            clearable
            filterable
            default-first-option
            :remote-method="e => remoteMethod(e, scope.row)"
            :loading="scope.row.loading"
            v-bind="scope.row.$attr"
            :value="scope.row.$attr.multiple ? scope.row.queryValue2 : scope.row.queryValue"
            @input="e => bindChange(e, scope.row)"
            @visible-change="e => selectVisibleChange(e, scope.row)">
            <kye-option
              v-for="opt in scope.row.options"
              :key="opt.value"
              :label="opt.label"
              :value="opt.value">
            </kye-option>
          </kye-select>
          <div v-else-if="isInputRange(scope.row)" style="display:flex;">
            <kye-number
              v-model="scope.row.queryValue"
              style="flex:1;"
              placeholder="请输入内容">
            </kye-number>
            <kye-number
              v-model="scope.row._queryValue"
              style="flex:1;"
              placeholder="请输入内容">
            </kye-number>
          </div>
          <el-input
            v-else-if="isInputComponent(scope.row)"
            v-model.trim="scope.row.queryValue"
            v-bind="scope.row.$attr"
            placeholder="请输入内容">
          </el-input>
          <template v-else-if="getComponentType(scope.row) === 'enum'">
            <kye-select
              v-show="isEmptyOperation(scope.row)"
              clearable
              filterable
              default-first-option
              placeholder="请选择"
              v-model="scope.row.queryValue"
              v-bind="scope.row.$attr"
              @change="queryValueChange(scope.row)">
              <el-option
                v-for="opt in getFieldOptions(scope.row)"
                :key="opt.value"
                :label="opt.label || ' '"
                :value="opt.value">
              </el-option>
            </kye-select>
            <kye-select
              v-show="!isEmptyOperation(scope.row)"
              class="kye-select--multiple"
              multiple
              collapse-tags
              filterable
              default-first-option
              placeholder="请选择"
              v-model="scope.row.queryValue2"
              v-bind="scope.row.$attr"
              @change="queryValueChange(scope.row)">
              <el-option
                v-for="opt in getFieldOptions(scope.row)"
                :key="opt.value"
                :label="opt.label || ' '"
                :value="opt.value">
              </el-option>
            </kye-select>
          </template>
          <template v-else-if="getComponentType(scope.row) === 'date'">
            <el-radio-group
              v-if="scope.row.operation === 'equal'"
              v-model="scope.row._queryValue"
              @change="e => radioDateChange(scope.row, e)">
              <el-radio label="date" style="width:335px;">
                <kye-date-picker
                  v-model="scope.row.queryValue"
                  style="width:95%;"
                  v-bind="scope.row.$attr"
                  :disabled="scope.row._queryValue === 'null'"
                  :clearable="false"
                  :type="getDatePickerType(scope.row.key)">
                </kye-date-picker>
              </el-radio>
              <el-radio label="null">
                <el-input
                  style="width:38px;"
                  :disabled="scope.row._queryValue !== 'null'"
                  value="(空)"
                  readonly>
                </el-input>
              </el-radio>
            </el-radio-group>
            <el-input v-else-if="scope.row.operation === 'not_equal'" value="(空)" disabled />
            <template v-else>
              <template v-if="getSelectField(scope.row).lookupCode === 'time'">
                <el-time-picker
                  v-show="!isRange(scope.row)"
                  v-model="scope.row.queryValue"
                  v-bind="scope.row.$attr"
                  :operation="scope.row.operation"
                  :clearable="false"
                  value-format="HH:mm:ss"
                  placeholder="请选择时间">
                </el-time-picker>
                <el-time-picker
                  v-model="scope.row.queryValue2"
                  v-show="isRange(scope.row)"
                  v-bind="scope.row.$attr"
                  is-range
                  :clearable="false"
                  value-format="HH:mm:ss"
                  start-placeholder="开始时间"
                  end-placeholder="结束日时间">
                </el-time-picker>
              </template>
              <template v-else>
                <kye-date-picker
                  v-show="!isRange(scope.row)"
                  v-model="scope.row.queryValue"
                  v-bind="scope.row.$attr"
                  :clearable="false"
                  :type="getDatePickerType(scope.row.key)"
                  :operation="scope.row.operation"
                  placeholder="请选择日期">
                </kye-date-picker>
                <kye-date-picker
                  v-model="scope.row.queryValue2"
                  v-show="isRange(scope.row)"
                  v-bind="scope.row.$attr"
                  :clearable="false"
                  :type="getDatePickerType(scope.row.key, true)"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期">
                </kye-date-picker>
              </template>
            </template>
          </template>
          <kye-area-remote
            v-else-if="getComponentType(scope.row) === 'area'"
            v-model="scope.row.queryValue2"
            :level="scope.row.$attr.options.length"
            :labels="scope.row.$attr.labels">
          </kye-area-remote>
          <el-input placeholder="请选择查询条件和条件关系" disabled v-else></el-input>
        </template>
      </el-table-column>
      <el-table-column width="46" align="center" label=")" label-class-name="td-post">
        <template slot-scope="scope">
          <el-input v-model="scope.row.postBrackets" style="width:36px;margin-left:5px;"></el-input>
        </template>
      </el-table-column>
      <el-table-column width="110" align="left" label="">
        <template slot-scope="scope">
          <kye-select v-model="scope.row.conditionOperation" style="width:52px;">
            <el-option
              v-for="opt in config.conditionOperation"
              :key="opt.value"
              :label="opt.label"
              :value="opt.value">
            </el-option>
          </kye-select>
          <i class="iconfont icon-minus"
             v-show="showDeleteIcon(scope.row.key, scope.$index)"
             @click="deleteRule(scope.$index)">
          </i>
          <i class="iconfont icon-plus"
             v-show="showAddIcon(scope.row.key, scope.$index)"
             @click="insertRule(scope.$index + 1)">
          </i>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  import mixins from '../../mixins/index'
  import {
    OPERATIONS,
    COLUMN_TYPE,
    COMPARES,
    SINGLE_VALUE,
    perfectVos,
    remoteSelectMethod,
    navigateSelectFirstOption
  } from './utils'

  export default {
    mixins: [mixins],
    name: 'filter-rule',
    props: {
      inner: Boolean,
      height: [String, Number],
      module: {
        type: Object,
        default: () => ({})
      }
    },
    data () {
      const lookUpOptions = this.$store.getters.lookUpOptions
      return {
        rules: [],
        config: {
          esFlag: true,
          fields: {},
          conditionOperation: lookUpOptions['system_GenericQuery_conditionOperation'],
          operations: lookUpOptions['system_GenericQuery_Operation']
        }
      }
    },
    async created () {
      if (!this.module.option) {
        this.module.option = {}
      }
      if (!this.inner && this.module.searchCode) {
        let menuId = this.$store.getters.menus[this.$route.meta.tag].id
        let rs = await this.$http('system.genericSearch.listByMenuId', { menuId })
        if (rs && rs.length) {
          let obj = rs.find(v => v.searchCode === this.module.searchCode)
          if (obj && obj.columnList && obj.columnList.length) {
            this.config.esFlag = obj.esFlag === '10'
            obj.columnList.forEach(v => {
              v.key = this.config.esFlag ? v.propertyName : v.columnName
            })
            this.setGenericSearchFields(obj.columnList)
          }
        }
      }
    },
    methods: {
      createdModel () {
        return {
          key: '',
          propertyName: '',
          columnName: '',
          frontBrackets: '(',
          postBrackets: ')',
          conditionOperation: 'and',
          operation: '',
          columnType: '',
          queryValue: '',
          queryValue2: null,
          _queryValue: '',
          $attr: {}
        }
      },
      createdDefaultModel () {
        let arr = []
        Object.keys(this.module.option).forEach(v => {
          let conf = this.module.option[v]
          let field = this.config.fields[v]
          if (field && conf.required && conf.operation) {
            let model = this.createdModel()
            model.key = v
            model.propertyName = field.propertyName
            model.columnName = field.columnName
            model.columnType = field.columnType
            model.operation = conf.operation
            model.$attr = field.$attr
            let value = conf.default
            if (model.columnType === COLUMN_TYPE.date) {
              if (this.isRange(model)) {
                model.queryValue2 = Array.isArray(value) && value.length
                  ? value.map(v => this.formatTime(v, field.lookupCode))
                  : null
              } else {
                model.queryValue = this.formatTime(value, field.lookupCode)
              }
            } else {
              model.queryValue2 = value
              if (Array.isArray(value)) {
                model.queryValue = value[0]
                model._queryValue = value[1]
              } else {
                model.queryValue = value
              }
            }
            arr.push(model)
          }
        })
        if (arr.length === 0) {
          arr.push(this.createdModel())
        }
        return arr
      },
      // 对外暴露，merge 查询条件
      setGenericFields (option) {
        Object.keys(option).forEach(v => {
          let opt = this.config.fields[v]
          if (opt) {
            Object.assign(opt, option[v])
          }
        })
      },
      setGenericSearchFields (fields, esFlag) {
        if (esFlag !== void 0) {
          this.config.esFlag = esFlag
        }
        if (!Object.keys(this.config.fields).length) {
          this.perfectModuleOption(fields)
          this.config.fields = fields.reduce((s, v) => {
            this.$set(v, 'show', true)
            if (!v.$attr) {
              // 后台数据库设计方案不支持保存前端组件的某些属性，需要 merge
              v.$attr = this.module.option[v.key] || {}
              // 后台扩展字段支持前端属性
              if (v.attribute2) {
                try {
                  let attr = JSON.parse(v.attribute2)
                  // 前端的配置覆盖模板的配置
                  Object.assign(attr, v.$attr)
                  Object.assign(v.$attr, attr)
                } catch (e) {
                }
              }
            }
            let type = v.columnType === 'component' ? (v.lookupCode || COLUMN_TYPE.string) : v.columnType
            v.columnType = type
            v.remoteMethod = v.$attr.remoteMethod
            if (type === COLUMN_TYPE.area) {
              let labels = v.$attr.options.map(v => v.label)
              v.label = labels.join('-')
              v.$attr.labels = labels
            } else if (type === COLUMN_TYPE.user) {
              v.remoteMethod = this.searchUser
              v.$attr.remote = true
            } else if (type === COLUMN_TYPE.department) {
              v.remoteMethod = this.searchDepartment
              v.$attr.remote = true
            } else if (type === COLUMN_TYPE.date) {
              v.$attr.type = v.$attr.type || 'datetime'
              v.$attr.format = v.$attr.format || 'yyyy-MM-dd HH:mm'
              v.$attr.valueFormat = v.$attr.valueFormat || 'yyyy-MM-dd HH:mm:ss'
            }
            s[v.key] = v
            return s
          }, {})
          this.rules = this.createdDefaultModel()
        }
        this.$emit('created')
      },
      // 完善前端配置（Y/N)
      perfectModuleOption (fields) {
        Object.keys(this.module.option).forEach(k => {
          fields.some(v => {
            if (k === v.propertyName) {
              this.module.option[v.columnName] = this.module.option[k]
              return true
            }
            if (k === v.columnName) {
              this.module.option[v.propertyName] = this.module.option[k]
              return true
            }
            return false
          })
        })
      },
      getValidRules () {
        let arr = []
        this.rules.forEach(v => {
          if (v.operation && v.key && this.isValidQueryValue(v)) {
            v.values = this.getQueryValue(v, true)
            let o = { ...v }
            delete o.options
            delete o.remoteMethod
            delete o.$attr
            arr.push(o)
          }
        })
        if (arr.length > 0) {
          return arr
        }
        return null
      },
      getRules () {
        return this.rules
      },
      setRules (rules) {
        if (rules && typeof rules === 'string') {
          try {
            rules = JSON.parse(rules)
          } catch (e) {
            rules = null
          }
        }
        if (Array.isArray(rules) && rules.length) {
          let key = this.config.esFlag ? 'propertyName' : 'columnName'
          let fields = this.config.fields
          this.rules = rules.filter(v => {
            let field = fields[v[key]]
            if (!field) {
              return false
            }
            let type = field.columnType
            v.key = v[key]
            v.columnType = type
            v.$attr = field.$attr
            if (!v.conditionOperation) {
              v.conditionOperation = 'and'
            }
            let value = v.values || v.queryValue || []
            if (field.remoteMethod) {
              v.remoteMethod = field.remoteMethod
              try {
                let arr = JSON.parse(value)
                v.options = arr
                value = arr.map(item => item.value)
              } catch (e) {
                value = value.split(',')
              }
            } else if (value && typeof value === 'string') {
              value = value.split(',')
            }
            if (type === COLUMN_TYPE.date) {
              if (!field.lookupCode && v.operation === OPERATIONS.equal) {
                v.queryValue = value[0].replace('null', '')
                v._queryValue = value[0]
              } else {
                v.queryValue = this.formatTime(value[0], field.lookupCode)
              }
              v.queryValue2 = value.length === 2 ? value.map(v => this.formatTime(v, field.lookupCode)) : []
            } else if (type === COLUMN_TYPE.area) {
              v.queryValue2 = value.map(v => ({ id: v }))
            } else {
              v.queryValue = value[0]
              v._queryValue = value[1]
              v.queryValue2 = value
            }
            return true
          })
        }
      },
      appendGenericVos () {
        const vos = []
        const componentMap = {
          [COLUMN_TYPE.user]: COLUMN_TYPE.string,
          [COLUMN_TYPE.department]: COLUMN_TYPE.string,
          [COLUMN_TYPE.phone]: COLUMN_TYPE.string
        }
        this.rules.forEach(obj => {
          let values = this.getQueryValue(obj)
          let type = obj.columnType
          let vo = {
            propertyName: obj.propertyName,
            columnName: obj.columnName,
            frontBrackets: obj.frontBrackets,
            postBrackets: obj.postBrackets,
            conditionOperation: obj.conditionOperation,
            operation: obj.operation,
            type: componentMap[type] || type,
            values
          }
          // 扩展字段
          let field = this.config.fields[obj.key] || {}
          if (field.attribute1) {
            try {
              Object.assign(vo, JSON.parse(field.attribute1))
            } catch (e) {
            }
          }
          if (type === COLUMN_TYPE.area) {
            let options = field.$attr.options
            let lastIndex = values.length - 1
            values.forEach((v, index) => {
              if (v) {
                let opt = options[index]
                vos.push({
                  propertyName: opt.propertyName,
                  columnName: opt.columnName,
                  frontBrackets: '(',
                  postBrackets: ')',
                  conditionOperation: index === lastIndex ? obj.conditionOperation : 'and',
                  operation: obj.operation,
                  type: opt.columnType,
                  values: [v]
                })
              }
            })
          } else if (type === COLUMN_TYPE.date && obj.operation === OPERATIONS.equal) {
            if (obj._queryValue === 'null') {
              vo.values = ['null']
            } else {
              let type = field.$attr.type || 'date'
              vo.values = this.calculateDateRange(obj.queryValue, type)
              if (type.includes('date')) {
                vo.operation = OPERATIONS.between
              }
            }
            vos.push(vo)
          } else {
            vos.push(vo)
          }
        })
        return vos
      },
      onSubmit () {
        let frontNum = 0
        let postNum = 0
        for (let i = 0, l = this.rules.length; i < l; i++) {
          let obj = this.rules[i]
          if (!this.isValidQueryValue(obj)) {
            this.$message.warning(`第${i + 1}行的条件值不能为空`)
            return null
          }
          if (!obj.operation) {
            this.$message.warning(`第${i + 1}行的条件关系不能为空`)
            return null
          }
          obj.frontBrackets = obj.frontBrackets ? obj.frontBrackets.replace(/（/g, '(') : ''
          obj.postBrackets = obj.postBrackets ? obj.postBrackets.replace(/）/g, ')') : ''
          frontNum += obj.frontBrackets.length
          postNum += obj.postBrackets.length
        }
        if (frontNum !== postNum) {
          this.$message.warning('前后括号数量不一致！')
          return null
        }
        const vos = this.appendGenericVos()
        perfectVos(vos)
        return vos
      },
      mapColumnList () {
        return this.rules.map((v, i) => {
          return {
            rowIndex: i + 1,
            propertyName: v.propertyName,
            columnName: v.columnName,
            frontBrackettemplates: v.frontBrackets,
            postBrackets: v.postBrackets,
            conditionOperation: v.conditionOperation,
            operation: v.operation,
            queryValue: this.getQueryValue(v, true).join()
          }
        })
      },
      addRule () {
        this.rules.push(this.createdModel())
      },
      insertRule (index) {
        this.rules.splice(index, 0, this.createdModel())
      },
      deleteRule (index) {
        this.rules.splice(index, 1)
      },
      getQueryValue (model, isTemplate) {
        let { columnType, queryValue, queryValue2, operation } = model
        // 员工、部门 等远程搜索组件，保存模板时，需要同时保存 [{label,value}]，这样才能在加载模板时显示 label
        if (isTemplate && model.remoteMethod) {
          if (model.$attr.multiple) {
            let arr = queryValue2.map(val => model.options.find(v => v.value === val))
            return [JSON.stringify(arr)]
          } else {
            return [JSON.stringify([model.options.find(v => v.value === queryValue)])]
          }
        }
        if (columnType === COLUMN_TYPE.number) {
          if (operation === OPERATIONS.between) {
            return [+queryValue, +model._queryValue]
          }
          return isNaN(queryValue) ? [queryValue] : [+queryValue]
        }
        if (SINGLE_VALUE.includes(columnType)) {
          return [queryValue]
        }
        if (columnType === COLUMN_TYPE.enum && this.isEmptyOperation(model)) {
          return [queryValue]
        }
        if (columnType === COLUMN_TYPE.date) {
          let lookupCode = this.getSelectField(model).lookupCode
          if (this.isRange(model)) {
            return queryValue2.map(v => this.splitTime(v, lookupCode))
          } else if (isTemplate && !lookupCode && operation === OPERATIONS.equal && !queryValue) {
            return ['null']
          } else {
            return [this.splitTime(queryValue, lookupCode)]
          }
        }
        if (columnType === COLUMN_TYPE.area) {
          return queryValue2.map(v => v.id)
        }
        return queryValue2
      },
      isEmptyOperation ({ operation }) {
        return operation === OPERATIONS.equal || operation === OPERATIONS.not_equal
      },
      isRange ({ operation }) {
        return operation === OPERATIONS.between || operation === OPERATIONS.not_between
      },
      isValidQueryValue (model) {
        let { columnType, queryValue, queryValue2, operation } = model
        if (SINGLE_VALUE.includes(columnType) && queryValue) {
          return true
        }
        if (columnType === COLUMN_TYPE.number) {
          if (operation === OPERATIONS.between && queryValue !== '' && model._queryValue !== '') {
            return true
          } else if (operation !== OPERATIONS.between && !this.isEmpty(queryValue)) {
            return true
          }
        }
        if (columnType === COLUMN_TYPE.enum) {
          if (this.isEmptyOperation(model) && queryValue) {
            return true
          }
          if (!this.isEmptyOperation(model) && queryValue2 && queryValue2.length) {
            return true
          }
        }
        if (columnType === COLUMN_TYPE.date) {
          if (!this.isRange(model) && (queryValue || model._queryValue === 'null')) {
            return true
          }
          if (this.isRange(model) && queryValue2 && queryValue2.length) {
            return true
          }
        }
        if (columnType === COLUMN_TYPE.area && queryValue2 && queryValue2.length) {
          return true
        }
        return false
      },
      isValidCompareOption (val, { key, columnType, operation }) {
        // 自定义条件关系
        let operations = (this.config.fields[key] && this.config.fields[key].$attr.operations) || COMPARES[columnType]
        if (operations) {
          return operations.includes(val)
        }
        return val === operation
      },
      getFieldOptions (model) {
        let obj = this.getSelectField(model)
        // select 前端配置 options
        let arr = obj.$attr.options || this.lookUpOptions[obj.lookupCode] || []
        if (!obj.$attr.unNull && this.isEmptyOperation(model)) {
          return arr.concat([{ label: '(空)', value: 'null' }])
        }
        return arr
      },
      isDisabled (key, index) {
        if (key && this.config.fields[key].$attr.required) {
          let firstIndex = this.rules.findIndex(v => v.key === key)
          if (index === firstIndex) {
            return true
          }
        }
        return false
      },
      showDeleteIcon (key, index) {
        return index > 0 && (!key || !this.config.fields[key].$attr.required || !this.isDisabled(key, index))
      },
      showAddIcon (key, index) {
        return index === 0 || index < this.rules.length - 1
      },
      getDatePickerType (key, isRange) {
        let type = this.config.fields[key].$attr.type
        if (isRange) {
          return (type === 'date' || type === 'datetime') ? `${type}range` : 'daterange'
        }
        return type
      },
      getComponentType ({ propertyName, columnName, operation, columnType }) {
        return (propertyName || columnName) && operation && columnType
      },
      isInputComponent ({ columnType }) {
        return columnType === COLUMN_TYPE.number || columnType === COLUMN_TYPE.string || columnType === COLUMN_TYPE.phone
      },
      isInputRange ({ columnType, operation }) {
        return columnType === COLUMN_TYPE.number && operation === OPERATIONS.between
      },
      getSelectField (model) {
        return this.config.fields[model.key] || {}
      },
      clearFieldValue (model) {
        // 因为每个字段的类型都不一样 这里清空上次的输入值
        let obj = this.getSelectField(model)
        let type = obj.columnType
        model.propertyName = obj.propertyName
        model.columnName = obj.columnName
        model.columnType = type
        model.operation = ''
        model.queryValue = ''
        model.queryValue2 = null
        model._queryValue = ''
        model.remoteMethod = null
        model.$attr = obj.$attr || {}
        // 员工、部门 等远程搜索select
        if (obj.remoteMethod) {
          this.$set(model, 'loading', false)
          this.$set(model, 'options', [])
          model.remoteMethod = obj.remoteMethod
        }
      },
      operationChange (model) {
        if (model.columnType === COLUMN_TYPE.date) {
          model.queryValue = model.operation === OPERATIONS.not_equal ? 'null' : ''
        } else if (model.columnType === COLUMN_TYPE.enum) {
          model.queryValue = ''
          model.queryValue2 = []
        }
      },
      queryValueChange (model) {
        let conf = this.module.option[model.key]
        if (conf && typeof conf.change === 'function') {
          let val = this.isEmptyOperation(model) ? model.queryValue : model.queryValue2
          conf.change(val, this.config.fields, this.rules)
        }
      },
      selectVisibleChange (val, model) {
        // 远程下拉框可见时，同步下拉框
        if (val && typeof model.remoteMethod === 'function') {
          this.remoteMethod('0', model)
        }
      },
      async remoteMethod (val, model) {
        let arr = await remoteSelectMethod(val, model)
        if (arr.length) {
          // 自动选中第一行
          this.$nextTick(_ => navigateSelectFirstOption(this.$refs.remoteSelect))
        }
      },
      async searchUser (val) {
        let arr = await this.$http('data.employee.listByName', { chineseName: val })
        if (arr && arr.length) {
          return arr.map(v => ({ label: `${v.chineseName}-${v.employeeNumber}`, value: v.id }))
        }
        return []
      },
      async searchDepartment (val) {
        let arr = await this.$http('hr.department.refactoring.getByFuzzyValue', { fuzzyValue: val })
        if (arr && arr.length) {
          return arr.map(v => ({ label: `${v.name}-${v.departmentCode}`, value: v.id }))
        }
        return []
      },
      formatTime (val, type) {
        return type === 'time' && val && val.length <= 8 ? `2000-01-01 ${val}` : val
      },
      splitTime (val, type) {
        return type === 'time' && val && val.length > 8 ? val.split(' ')[0] : val
      },
      radioDateChange (model, val) {
        if (val === 'null') {
          model.queryValue = ''
        }
      },
      /**
       * 计算日期区间
       * date: [2018-12-12 00:00:00, 2018-12-12 23:59:59]
       * datetime: [2018-12-12 12:12:00, 2018-12-12 12:12:59]
       * @param val
       * @param type
       */
      calculateDateRange (val, type) {
        if (type === 'date') {
          return [val, val.replace('00:00:00', '23:59:59')]
        } else if (type === 'datetime') {
          return [val.replace(/:\d{2}$/, ':00'), val.replace(/:\d{2}$/, ':59')]
        } else {
          return [val]
        }
      },
      isEmpty (val) {
        return val === '' || val === null || val === undefined
      },
      bindChange (val, model) {
        if (model.$attr.multiple) {
          model.queryValue2 = val
        } else {
          model.queryValue = val
        }
      }
    }
  }
</script>

<style lang="scss">
  .kye-filter-rule {
    .el-table__body {
      padding: 0;
    }
    .el-table .cell {
      padding: 4px 2px;
    }
    .el-table::before {
      display: none;
    }
    .el-table th {
      background: none;
    }
    .el-table td {
      padding: 6px 0;
      border-bottom: none;
    }
    .el-table__body tr:hover > td,
    .el-table__body tr.current-row > td {
      background: #ffffff !important;
    }
    .icon-minus,
    .icon-plus {
      color: #9571e9;
      border: 1px solid #9571e9;
      border-radius: 9px;
      font-size: 16px;
      cursor: pointer;
    }
    .td-front.cell {
      padding-left: 30px !important;
    }
    .td-post.cell {
      padding-left: 16px !important;
    }
    .colindex {
      display: inline-block;
      width: 16px;
      text-align: right;
    }
  }
</style>
