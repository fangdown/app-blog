<template>
  <div class="kye-search-pager">
    <section class="search-pager-warp">
      <router-link v-if="option.back"
                   :to="option.back"
                   replace
                   style="height:28px;line-height:28px;display:inline-flex;">
        <i class="iconfont icon-yemianfanhui iconback"></i>
        <span class="title">返回</span>
      </router-link>
      <span class="title" v-else>{{this.option.title}}</span>
      <div :style="pagerStyle">
        <div v-if="option.route"
             class="pager-wrap">
          <el-button icon="iconfont icon-first"
                     class="btn-text"
                     type="text"
                     :disabled="firstDisabled()"
                     @click="goFirst">
          </el-button>
          <el-button icon="iconfont icon-previous"
                     class="btn-text"
                     type="text"
                     :disabled="previousDisabled()"
                     @click="goPrevious">
          </el-button>
          <kye-number v-model.number="curPage"
                      style="width:40px;"
                      :clearable="false"
                      :min="1"
                      :max="total()"
                      :disabled="pageDisabled()"
                      @focus="isBlur = false"
                      @blur="pageBlur">
          </kye-number>
          <span>/ {{total()}}</span>
          <el-button icon="iconfont icon-next"
                     class="btn-text"
                     type="text"
                     :disabled="nextDisabled()"
                     @click="goNext(true)">
          </el-button>
          <el-button icon="iconfont icon-last"
                     class="btn-text"
                     type="text"
                     :disabled="lastDisabled()"
                     @click="goLast">
          </el-button>
        </div>
        <el-input v-if="option.formFields && option.formFields.length > 0"
                  v-model.trim="searchInput"
                  class="search-wrap"
                  :placeholder="selectField.placeholder">
          <template v-if="option.formFields.length === 1"
                    slot="prepend">
            {{ selectField.label }}
          </template>
          <el-select v-else
                     slot="prepend"
                     style="width:84px;"
                     :value="selectField.propertyName"
                     @input="searchChange">
            <el-option v-for="item in option.formFields"
                       :key="item.propertyName"
                       :label="item.label"
                       :value="item.propertyName">
            </el-option>
          </el-select>
          <el-button v-if="option.formFields && option.formFields.length > 0"
                     slot="append"
                     icon="iconfont icon-search"
                     :disabled="!searchInput"
                     @click="searchClick">
          </el-button>
        </el-input>
      </div>
      <div class="tools-wrap">
        <slot></slot>
        <div v-if="tools"
             ref="tools"
             style="flex:1;display:flex;">
          <el-dropdown v-if="adjustIndex > 0"
                       @command="handleCommand">
            <span class="el-dropdown-link el-button el-button--text"
                  style="margin-right:2px;">
              更多<i class="iconfont icon-caretdown"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="btn in tools.slice(adjustIndex)"
                                :key="btn.label"
                                :command="btn"
                                :disabled="authDisabled(btn)">
                {{btn.label}}
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
          <tool-list ref="toolList"
                     :active="false"
                     :tools="adjustTools"
                     :wrap-style="{flex: 1, display: 'flex', justifyContent: 'flex-end'}">
          </tool-list>
        </div>
      </div>
    </section>
    <p class="line"></p>
    <custom-filter v-if="option.method && option.searchCode"
                   ref="genericDialog"
                   :module="option"
                   @close="showGenericDialog(false)"
                   @submit="handleGenericSubmit">
    </custom-filter>
  </div>
</template>

<script>
  import mixins from '../../mixins'
  import createStoreModule from '../../store/modules/queryTable/factory'
  import { localPageSize } from '../../utils'
  import CustomFilter from './custom-filter.vue'
  import {
    HTTP_ACTION,
    getQueryPager,
    perfectVos,
    perfectRows,
    mapSectionValueList
  } from './utils'

  export default {
    name: 'search-pager',
    mixins: [mixins],
    components: { CustomFilter },
    props: {
      option: {
        type: Object,
        default: () => ({})
      },
      tools: Array
    },
    data () {
      return {
        id: '',
        curPage: 0,
        isBlur: true,
        esFlag: 'Y',
        searchInput: '',
        selectField: {},
        adjustIndex: 0,
        tag: this.$route.meta.tag,
        pagerStyle: { minWidth: '24px', display: 'flex' }
      }
    },
    created () {
      this.initProps()
    },
    activated () {
      if (this.option.method && !this.option.unpager) {
        let ids = this.pagerConf.ids
        this.searchInput = ''
        this.id = this.$route.params.id
        this.curPage = (ids && ids.indexOf(this.id) + 1) || 0
        let store = this.$store.state.queryTable[this.option.module]
        let data = store && store.query && store.query[0] && store.query[0].data
        this.saveGenericParams(data)
      }
    },
    mounted () {
      this.resetToolsLayout()
      if (this.option.formFields && this.option.formFields.length === 1) {
        let dom = this.$el.querySelector('.search-wrap > .el-input-group__prepend')
        dom.style.padding = '0 8px'
        dom = null
      }
    },
    computed: {
      menuId () {
        return this.$store.getters.menus[this.tag].id
      },
      queryTableAction () {
        return this.$store.state.queryTable.$action
      },
      pagerConf () {
        let obj = this.$store.state.queryTable[this.option.module]
        return obj ? obj.pager : {}
      },
      adjustTools () {
        return this.adjustIndex > 0 ? this.tools.slice(0, this.adjustIndex) : this.tools
      }
    },
    methods: {
      showGenericDialog (val = true) {
        this.$refs.genericDialog.show = val
      },
      async initProps () {
        this.option.title = this.option.title || this.$route.meta.title
        // 详情 通用查询
        if (this.option.method) {
          this.option.back = this.option.back || this.tag
          if (!this.option.unpager) {
            this.option.idKey = this.option.idKey || 'id'
            this.option.module = this.option.module || this.option.method
            let ids = this.pagerConf.ids
            this.id = this.$route.params.id
            this.curPage = (ids && ids.indexOf(this.id) + 1) || 0
            if (!this.option.route) {
              let path = this.$route.matched[1].path.replace(/:\w+/, '')
              this.option.route = id => {
                let oldQuery = this.$route.query
                let query = this.pagerConf.query && this.pagerConf.query[id]
                return {
                  path: `${path}${id}`,
                  query: { ...oldQuery, ...query }
                }
              }
            }
            if (this.option.formFields && this.option.formFields.length) {
              this.pagerStyle.minWidth = '510px'
              this.selectField = this.option.formFields[0]
            } else {
              this.pagerStyle.minWidth = '226px'
            }
          }
          // 获取通用查询、自定义查询配置
          await this.getGenericSearchFields()
          // 详情页刷新浏览器，store 需要动态注册 queryTable
          this.registerStoreModule()
        }
      },
      resetToolsLayout () {
        if (this.option.back && Array.isArray(this.tools) && this.tools.length) {
          let width = 70
          const maxWidth = this.$refs.tools.clientWidth
          let doms = this.$refs.toolList.$el.childNodes
          if (doms) {
            for (let i = 0, l = doms.length; i < l; i++) {
              if (width > maxWidth && this.adjustIndex === 0) {
                this.adjustIndex = i - 1
                break
              }
              width = width + doms[i].offsetWidth + 5
            }
          }
          doms = null
        }
      },
      async replaceRouter (id, page) {
        if (id) {
          let fn = this.option.beforeRouteUpdate
          if (fn && typeof fn === 'function') {
            let val = await fn(id)
            if (!val) {
              return false
            }
          }
          this.id = id
          this.curPage = page
          this.$router.replace(this.option.route(id))
          return true
        }
        return false
      },
      total () {
        let ids = this.pagerConf.ids
        if (ids && ids.includes(this.id)) {
          return this.pagerConf.total
        }
        return 0
      },
      pageDisabled () {
        let ids = this.pagerConf.ids
        return !(ids && ids.length > 0)
      },
      previousDisabled () {
        let ids = this.pagerConf.ids
        return !this.isBlur || !(ids && ids.indexOf(this.id) > 0)
      },
      nextDisabled () {
        let id = this.id
        let ids = this.pagerConf.ids
        return !this.isBlur || !(ids && ids.includes(id) && ids.indexOf(id) < ids.length - 1)
      },
      firstDisabled () {
        let id = this.id
        let ids = this.pagerConf.ids
        return !this.isBlur || !(ids && ids.includes(id) && ids[0] !== id)
      },
      lastDisabled () {
        let ids = this.pagerConf.ids
        if (!ids) {
          return true
        }
        let id = this.id
        let lastId = ids[ids.length - 1]
        return !this.isBlur || !(ids.includes(id) && lastId !== id)
      },
      // 从缓存里删除该条数据
      deleteById (ids, index) {
        this.pagerConf.total -= 1
        ids.splice(index, 1)
        let pager = { total: this.pagerConf.total, ids }
        this.$store.commit(this.queryTableAction.updatePager(this.option.module), pager)
        let module = this.$store.state.queryTable[this.option.module]
        if (module && module.query[0] && module.query[0].res) {
          let res = module.query[0].res
          module.query[0].res.rowTotal -= 1
          module.query[0].res.rows.splice(index, 1)
          this.$store.commit(this.queryTableAction.setQuery(this.option.module), { res, index: 0 })
        }
      },
      goPrevious () {
        let ids = this.pagerConf.ids
        let index = ids.indexOf(this.id)
        let id = ids[index - 1]
        this.replaceRouter(id, index)
      },
      // 详情点击 “删除” 按钮，显示下一条
      goNext (inner = false) {
        let ids = this.pagerConf.ids
        let index = ids.indexOf(this.id)
        let id = ids[index + 1]
        if (inner) {
          this.replaceRouter(id, index + 2)
          return
        }
        let page = index + 1
        // 详情页通用需求：当删除的是最后一条时，如果集合中只有当前这一条，则跳转到列表页，否则跳转到上一条
        if (!id) {
          if (ids.length < 2) {
            this.$router.push(this.tag)
            return
          }
          id = ids[index - 1]
          page = index
        }
        if (this.replaceRouter(id, page)) {
          this.deleteById(ids, index)
        }
      },
      // 财务模块需求：自己控制 next 行为
      goNext2 (isDelete, isLastGoList) {
        let ids = this.pagerConf.ids
        let index = ids.indexOf(this.id)
        let id = ids[index + 1]
        let page = isDelete ? index + 1 : index + 2
        // 当删除的是最后一条时，如果集合中只有当前这一条，则跳转到列表页，否则跳转到上一条
        if (isLastGoList && !id) {
          if (ids.length < 2) {
            this.$router.push(this.tag)
            return
          }
          id = ids[index - 1]
          page = index
        }
        if (this.replaceRouter(id, page)) {
          if (isDelete) {
            this.deleteById(ids, index)
          }
        }
      },
      goFirst () {
        let id = this.pagerConf.ids[0]
        this.replaceRouter(id, 1)
      },
      goLast () {
        let ids = this.pagerConf.ids
        let index = ids.length
        let id = ids[index - 1]
        this.replaceRouter(id, index)
      },
      pageBlur () {
        if (typeof this.curPage === 'number' && this.curPage > 0 && this.curPage <= this.total()) {
          let id = this.pagerConf.ids[this.curPage - 1]
          if (id && id !== this.id) {
            this.replaceRouter(id, this.curPage)
          }
        } else {
          this.$message.warning('请输入合适的数字')
        }
        this.isBlur = true
      },
      searchChange (val) {
        this.selectField = this.option.formFields.find(v => v.propertyName === val)
      },
      searchClick () {
        let vos = this.option.formFields.find(v => v.propertyName === this.selectField.propertyName).vos
        if (vos && vos.length) {
          let vo = vos.find(v => v.propertyName === this.selectField.propertyName)
          if (vo) {
            vo.values = [this.searchInput]
          }
        }
        // 替换搜索按钮的默认的通用查询接口
        if (this.option.onSearch) {
          this.$store.commit('SET_LOADING', true)
          this.option.onSearch(vos).then(res => {
            this.handleSearchData(res)
            this.$store.commit('SET_LOADING', false)
          }).catch(_ => this.$store.commit('SET_LOADING', false))
        } else {
          this.genericSubmit({ generic: { vos } }, HTTP_ACTION.FORM, this.option.axios)
        }
      },
      handleCommand (btn) {
        if (btn.type === 'link') {
          let route = typeof btn.func === 'function' ? btn.func(btn) : btn.func
          this.$router.push(route)
        } else {
          btn.func && btn.func(btn)
        }
      },
      btnDisabled (disabled) {
        return (typeof disabled === 'function') ? disabled() : !!disabled
      },
      authDisabled ({ disabled, auth }) {
        return (auth && !this.permission.menus.includes(auth)) || this.btnDisabled(disabled)
      },
      handleSearchData (res, data = {}, init) {
        // 容错后台数据
        res = perfectRows(res)
        if (res.rows && res.rows.length) {
          // 扁平化 区间列
          mapSectionValueList(res.rows, this.option.sectionOption)
          if (!this.option.unpager) {
            let pager = getQueryPager(this.option.idKey, res.rows)
            this.$store.commit(this.queryTableAction.updatePager(this.option.module), pager)
            this.$store.commit(this.queryTableAction.setQuery(this.option.module), { data, res, index: 0 })
            if (init) {
              let id = this.$route.params.id
              this.id = id
              this.curPage = pager.ids.indexOf(id) + 1
              this.$emit('change', res)
            } else {
              this.$emit('change', res)
              this.replaceRouter(pager.ids[0], 1)
            }
          } else {
            this.$emit('change', res)
          }
        } else if ((!res.rows || !res.rows.length) && !init) {
          this.$message.warning(this.option.noDataMsg || '无数据')
          this.$emit('change', res)
        }
      },
      handleGenericSubmit (data) {
        this.genericSubmit(data, HTTP_ACTION.GENERIC)
      },
      async genericSubmit (data, action, axios, init) {
        if (!data.generic || !data.generic.vos) {
          return
        }
        Object.assign(data, { elasticsearchFlag: this.esFlag, page: 1, pageSize: localPageSize(this) })
        // 后台排序
        let sort = this.option.defaultSort
        if (sort && sort.keys && sort.keys.length) {
          let index = this.esFlag === 'Y' ? 0 : 1
          data.orderByClauses = [
            {
              field: sort.keys[index],
              orderByMode: sort.order === 'ascending' ? 0 : 1
            }
          ]
        }
        let fn = this.option.beforeFormSubmit
        if (fn && typeof fn === 'function' && fn(data, action) === true) {
          return
        }
        perfectVos(data.generic.vos)
        if (this.option.searchCode) {
          data.menuId = this.menuId
          data.genericSearchCode = this.option.searchCode
        }
        if (!init && this.option.method && !this.option.unpager) {
          this.saveGenericParams(data)
        }
        this.$store.commit('SET_LOADING', true)
        try {
          axios = axios ? { axios } : null
          let res = await this.$http(this.option.method, data, axios)
          this.handleSearchData(res, data, init)
        } finally {
          this.$store.commit('SET_LOADING', false)
        }
      },
      async getGenericSearchFields () {
        if (!this.option.searchCode && !this.option.formCode) {
          return
        }
        try {
          let res = await this.$http('system.genericSearch.listByMenuId', { menuId: this.menuId })
          if (res && res.length) {
            // 通用查询配置
            let opt = res.find(v => v.searchCode === this.option.searchCode)
            this.esFlag = opt && opt.esFlag === '10' ? 'Y' : 'N'
            this.$refs.genericDialog.setGenericSearchFields(opt)
            opt = res.find(v => v.searchCode === this.option.formCode)
            if (opt) {
              // 自定义查询配置
              let { fieldContent } = await this.$http('system.genericSearch.get', { id: opt.id })
              fieldContent = JSON.parse(fieldContent)
              if (this.option.formFields && this.option.formFields.length) {
                let errors = []
                this.option.formFields.forEach(v => {
                  if (!v.vos) {
                    let obj = fieldContent.find(k => k.propertyName === v.propertyName)
                    if (obj) {
                      v.label = v.label || obj.label
                      v.placeholder = v.placeholder || obj.placeholder
                      v.vos = [{
                        propertyName: obj.propertyName,
                        columnName: obj.columnName,
                        columnType: obj.columnType,
                        operation: obj.operation
                      }]
                    } else {
                      errors.push(`[${v.propertyName}: ${v.label}]`)
                    }
                  }
                })
                if (errors.length) {
                  errors = errors.join() + '，缺少通用查询配置'
                  this.$message.error(errors)
                  console.error(errors)
                }
              }
            }
          }
        } catch (e) {
        }
      },
      registerStoreModule () {
        if (this.option.unpager) {
          return
        }
        let module = this.option.module
        let store = this.$store.state.queryTable[module]
        if (!store) {
          let tag = this.tag
          this.$store.registerModule(['queryTable', module], createStoreModule())
          this.$store.commit('queryTable/registerModule', { module, tag })
          let params = null
          try {
            params = JSON.parse(sessionStorage.getItem('GLOBAL_SEARCH_PAGER') || null)
            params = params && params[`${tag}?${module}`]
          } catch (e) {
          }
          params = params || {}
          let payload = { index: 0, data: params, res: { rowTotal: 0, rows: [] } }
          this.$store.commit(this.queryTableAction.setQuery(module), payload)
          // 详情页刷新浏览器，根据本地参数进行一次搜索
          if (!this.option.unReload) {
            this.genericSubmit(params, HTTP_ACTION.FORM, null, true)
          }
        } else {
          this.saveGenericParams(store.query && store.query[0] && store.query[0].data)
        }
      },
      // 详情页刷新浏览器，保存通用查询参数
      saveGenericParams (data) {
        if (data) {
          sessionStorage.setItem('GLOBAL_SEARCH_PAGER', JSON.stringify({ [`${this.tag}?${this.option.module}`]: data }))
        }
      }
    }
  }
</script>

<style lang="scss">
  @import '../../assets/scss/variable.scss';

  .kye-search-pager {
    position: sticky;
    top: 0;
    z-index: 10;
    background-color: white;
    margin: 0 -16px;
    padding: 0 16px 4px;

    .el-input__inner {
      padding-left: 8px !important;
      padding-right: 8px !important;
    }
    .el-input--suffix {
      .el-input__inner {
        padding-left: 8px !important;
        padding-right: 25px !important;
      }
    }
    .el-input-group__append > .el-button {
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
    }

    .line {
      margin: 0 -16px;
      background-color: $--color-24;
      height: 2px;
    }

    .search-pager-warp {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 4px 0;

      .pager-wrap {
        display: inline-block;
        padding-left: 24px;
        padding-right: 40px;
        .el-input__inner {
          text-align: center;
        }
      }
      .search-wrap {
        width: 285px;
        font-size: 12px;
        > .el-input__inner {
          border-radius: 0 !important;
        }
      }
      .tools-wrap {
        display: flex;
        flex: 1;
        max-height: 28px;
      }
      .title {
        color: $--color-21;
        font-size: 14px;
        font-weight: bold;
        height: 28px;
        line-height: 28px;
      }
      .iconback {
        margin-right: 6px;
        font-size: 18px;
        color: $theme;
      }
    }
  }
</style>
