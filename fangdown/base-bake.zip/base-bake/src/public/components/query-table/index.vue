<template>
  <div class="query-table-container noselect" v-loading="loading">
    <search-pager
      v-if="formTools && formTools.length && !option.dialog"
      :option="option"
      :tools="formTools">
    </search-pager>
    <div v-if="configError" class="error" @click="getGenericSearchFields">
      获取配置失败，<span class="theme">请点击</span> 重新获取
    </div>
    <slot name="header"></slot>
    <div
      style="display:flex;"
      :class="option.pageFooter ? 'kye-dialog-body' : ''">
      <slot name="prepend"></slot>
      <div :style="bodyStyle">
        <slot name="form-header"></slot>
        <div :class="queryFormWrap">
          <query-form
            ref="queryForm"
            v-if="formFields && formFields.length > 0"
            v-model="formModel"
            :fields="formFields"
            :tools="tools"
            :option="option"
            :generic="null"
            :generic-model="genericModel"
            :template-list="templateList"
            @created="triggerHttp"
            @submit="formSubmit"
            @reset="formReset">
          </query-form>
        </div>
        <tool-list
          ref="tools"
          v-if="tools && tools.length && !option.inlineTools"
          :wrap-style="{marginBottom: '2px'}"
          :tools="tools">
        </tool-list>
        <slot name="desc"></slot>
        <el-tabs
          v-if="tables && tables.length > 1"
          v-model="active"
          @tab-click="tabClick">
          <el-tab-pane
            v-for="(item,i) in tables"
            :key="i"
            :disabled="tabDisabled(item.url.method)"
            :label="getTabLabel(item.option, i)">
            <table-list
              ref="tableList"
              :style="tableListStyle"
              :scrollY="scrollY"
              :page="{currentPage: remotePage[i], pageSize: pageSize(i)}"
              :pageable="item.option.page"
              :data="getTableData(i)"
              :options="item.option"
              :dialog="option.dialog"
              :fixed-header="option.fixedHeader"
              :max-height="option.maxHeight"
              :offset-left="option.offsetLeft"
              :search-code="item.searchCode"
              :column="item.columns"
              :operation="item.operation"
              :buttonOptions="item.buttonOptions"
              :imageOptions="item.imageOptions"
              :checkedOptions="item.checkedOptions"
              :uploadOptions="item.uploadOptions"
              @cell-click="item.option.cellClick"
              @switch-menu="switchMenu"
              @sort-change="e => sortChange(i, e)">
              <slot :name="'tooltip'+i"></slot>
            </table-list>
            <kye-pagination
              v-if="item.option.page"
              class="fixedPagination"
              :style="fixedPaginationStyle"
              background
              :current-page="page(i)"
              :page-size="pageSize(i)"
              :page-sizes="pageSizes"
              :total="total(i)"
              :layout="total(i) > 0 ? $pagination.layout2 : $pagination.layout"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange">
              <el-button class="jumper-button" type="primary" plain>确定</el-button>
            </kye-pagination>
          </el-tab-pane>
        </el-tabs>
        <template v-else-if="tables && tables.length === 1">
          <table-list
            ref="tableList"
            :style="tableListStyle"
            :scrollY="scrollY"
            :page="{currentPage: remotePage[0], pageSize: pageSize(0)}"
            :pageable="tables[0].option.page"
            :data="getTableData(0)"
            :options="tables[0].option"
            :dialog="option.dialog"
            :fixed-header="option.fixedHeader"
            :max-height="option.maxHeight"
            :offset-left="option.offsetLeft"
            :search-code="tables[0].searchCode"
            :column="tables[0].columns"
            :operation="tables[0].operation"
            :buttonOptions="tables[0].buttonOptions"
            :imageOptions="tables[0].imageOptions"
            :checkedOptions="tables[0].checkedOptions"
            :uploadOptions="tables[0].uploadOptions"
            @cell-click="tables[0].option.cellClick"
            @switch-menu="switchMenu"
            @sort-change="e => sortChange(0, e)">
            <slot name="tooltip"></slot>
          </table-list>
          <kye-pagination
            v-if="!option.pageFooter && tables[0].option.page"
            :class="option.dialog ? '' : 'fixedPagination'"
            :style="fixedPaginationStyle"
            background
            :current-page="page(0)"
            :page-size="pageSize(0)"
            :page-sizes="pageSizes"
            :pager-count="option.dialog ? 5 : 7"
            :total="total(0)"
            :layout="total(0) > 0 ? $pagination.layout2 : $pagination.layout"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
            <el-button class="jumper-button" type="primary" plain>确定</el-button>
          </kye-pagination>
        </template>
      </div>
      <slot name="append"></slot>
    </div>
    <kye-pagination
      v-if="option.pageFooter && tables && tables.length === 1 && tables[0].option.page"
      class="el-dialog__footer"
      background
      :current-page="page(0)"
      :page-size="pageSize(0)"
      :page-sizes="pageSizes"
      :pager-count="5"
      :total="total(0)"
      :layout="total(0) > 0 ? $pagination.layout2 : $pagination.layout"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange">
      <el-button class="jumper-button" type="primary" plain>确定</el-button>
    </kye-pagination>
    <custom-filter
      v-if="generic && generic.searchCode"
      ref="genericDialog"
      init-template
      :module="generic"
      @close="showGenericDialog(false)"
      @submit="genericSubmit"
      @loaded="onGenericLoaded"
      @onTemplateListChange="onTemplateListChange">
    </custom-filter>
    <drag-dialog
      v-if="option.draggable && (option.searchCode || tables[0].searchCode)"
      ref="dragDialog"
      :option="option"
      :tables="tables"
      :form-fields="copyFormFields"
      @close="showDragDialog(false)">
    </drag-dialog>
  </div>
</template>

<script>
  import { intersection } from 'lodash'
  import mixins from '../../mixins'
  import { random, localPageSize } from '../../utils'
  import {
    HTTP_ACTION,
    perfectVos,
    perfectRows,
    mapFormModelParams,
    mapGenericSearchParams,
    mapSectionValueList
  } from './utils'
  import createStoreModule from '../../store/modules/queryTable/factory'
  import CustomFilter from './custom-filter.vue'
  import DragDialog from './drag-dialog.vue'
  import TableList from './table-list.vue'

  const EMPTY_ARR = [] // 防止 canvas watch 反复执行，影响性能
  export default {
    name: 'query-table',
    mixins: [mixins],
    components: { CustomFilter, DragDialog, TableList },
    props: {
      generic: Object,
      option: {
        type: Object,
        default: () => ({})
      },
      formTools: {
        type: Array,
        default: () => ([])
      },
      formModel: Object,
      formFields: {
        type: Array,
        default: () => ([])
      },
      tools: {
        type: Array,
        default: () => ([])
      },
      tables: Array
    },
    data () {
      const sty = (this.$slots.prepend || this.$slots.append)
        ? { 'overflow-x': 'hidden' }
        : { 'max-width': '100%' }
      const params = this.tables[0].url.data
      return {
        canLoad: false,
        loading: false,
        configError: false,
        offsetLeft: 176 + (this.option.offsetLeft || 0),
        forceCache: true,
        scrollY: false,
        active: '0',
        formIndex: -1,
        remotePage: [1, 1],
        pageMap: { page: 1, pageSize: localPageSize(this, params && params.pageSize) },
        copyFormFields: { columns: this.formFields, $columns: [...this.formFields] },
        bodyStyle: Object.assign({ flex: 1 }, sty),
        genericModel: null,
        templateList: []
      }
    },
    created () {
      this.initOption()
      this.initTables()
      this.registerStoreModule()
      this.getGenericSearchFields()
      if (!this.option.dialog && this.$route.path === this.$route.meta.tag) {
        this.refreshUnwatch = this.$watch('refreshList', this.onRefreshMainQueryTable)
      }
    },
    activated () {
      document.querySelector('.el-main, .main-panel').scrollTop = 0
      this.onRefreshMainQueryTable()
    },
    mounted () {
      this.$bus.$on('GLOBAL_RESIZE', this.handleResize)
    },
    beforeDestroy () {
      this.$bus.$off('GLOBAL_RESIZE', this.handleResize)
      this.refreshUnwatch && this.refreshUnwatch()
    },
    computed: {
      queryTableAction () {
        return this.$store.state.queryTable.$action
      },
      queryModule () {
        if (this.option.module) {
          const module = this.$store.state.queryTable[this.option.module]
          return module ? module.query : []
        }
        return this.tables.map(v => v.url)
      },
      refreshList () {
        return this.$store.state.queryTable.$refreshList
      },
      fixedPaginationStyle () {
        if (this.option.dialog) {
          return { marginTop: '8px' }
        }
        let obj = { left: `${this.offsetLeft}px` }
        if (this.option.fixedHeader) {
          obj.width = '1280px'
        } else {
          obj.right = '16px'
        }
        return obj
      },
      tableListStyle () {
        // 滚动条2+12 + 分页28+8
        return this.option.dialog ? { marginTop: '4px' } : { marginTop: '4px', marginBottom: '50px' }
      },
      queryFormWrap () {
        if (this.option.overflow) {
          return 'query-form-wrap_overflow'
        }
        if (!this.option.searchCode && this.formFields.length === 0) {
          return 'query-form-wrap_none'
        }
        return 'query-form-wrap'
      },
      pageSizes () {
        return this.tables[0].option.pageSizes || this.$pagination.pageSizes
      }
    },
    methods: {
      // 刷新列表数据，设置页码为1
      loadData (params, index, method, axios, action) {
        if (typeof index !== 'number') {
          index = +this.active
        }
        let data = { ...params, page: this.pageMap.page }
        if (this.option.module) {
          this.setQuery({ index, data })
        } else {
          Object.assign(this.tables[index].url.data, data)
        }
        if (this.canLoad) {
          this.forceCache = true
          this.tables[index].method = method
          this.tables[index].axios = axios ? { axios } : null
          return this.getList(index, method, action || HTTP_ACTION.REFRESH)
        }
        return Promise.resolve(false)
      },
      // 根据缓存的参数，刷新当前页码的列表数据
      loadCurrentData (index = 0, method) {
        if (this.canLoad) {
          this.forceCache = true
          this.getList(index, method, HTTP_ACTION.PAGER)
        }
      },
      loadHeader (params, index = 0) {
        return this.getHeader(this.tables[index], params)
      },
      getFormModel () {
        return this.$refs.queryForm && this.$refs.queryForm.getModel()
      },
      getParams (index = 0) {
        let generic = { generic: { vos: [] } }
        let obj = this.queryModule[index]
        if (obj && obj.data) {
          if (!obj.data.generic) {
            obj.data.generic = generic
          }
          // 删除接口缓存标志
          obj = obj.data
          delete obj.ERPSearchCacheFlag
          delete obj.forceCache
          return obj
        }
        Object.assign(generic, this.pageMap, { elasticsearchFlag: 'Y' })
        return generic
      },
      createGenericParams (index = 0) {
        let generic = this.tables[index].url.originData.generic
        return mapGenericSearchParams(this.formFields, this.getFormModel(), generic)
      },
      getData (index = 0) {
        let obj = this.queryModule[index]
        return (obj && obj.res) || {}
      },
      getTableData (index = 0) {
        let obj = this.queryModule[index]
        return (obj && obj.res && obj.res.rows) || EMPTY_ARR
      },
      getTableSortData (index = 0) {
        if (this.tables.length === 1) {
          return this.$refs.tableList.$refs.table.tableData()
        }
        return this.$refs.tableList[index].$refs.table.tableData()
      },
      setTableColumns (option, index = 0) {
        this.tables[index].columns.forEach(v => {
          let obj = option[v.key]
          if (obj) {
            v.undraggable = !v.show
            Object.assign(v, obj)
            v.$show = v.show
          }
        })
        if (this.tables.length === 1) {
          this.$refs.tableList.$refs.table.setTableColumns()
        } else if (this.tables.length > 1) {
          this.$refs.tableList[index].$refs.table.setTableColumns()
        }
      },
      setGenericFields (option) {
        if (this.generic && this.generic.searchCode) {
          this.$refs.genericDialog.setGenericFields(option)
        }
      },
      showDragDialog (val = true) {
        this.$refs.dragDialog.show = val
      },
      showGenericDialog (val = true) {
        this.$refs.genericDialog.show = val
      },
      page (index) {
        let obj = this.queryModule[index]
        return (obj && obj.data && obj.data.page) || this.pageMap.page
      },
      pageSize (index) {
        let obj = this.queryModule[index]
        return (obj && obj.data && obj.data.pageSize) || this.pageMap.pageSize
      },
      total (index) {
        let obj = this.queryModule[index]
        return (obj && obj.res && obj.res.rowTotal) || 0
      },
      sortChange (index, e) {
        let method = this.tables[index].method || this.tables[index].url.method
        if (!this.option.auth || this.$store.getters.permission.menus.includes(method)) {
          this.tables[index].option.sort = e
          this.loadData({}, index, this.tables[index].method, null, HTTP_ACTION.SORT)
        }
      },
      handleRemoteSort (data, defSort, sortConf) {
        let hasDefSort = defSort && defSort.keys && defSort.keys.length
        if (sortConf) {
          if (sortConf.order) {
            let prop = sortConf.column.sortKeys[data.elasticsearchFlag === 'Y' ? 0 : 1]
            let order = sortConf.order === 'ascending' ? 0 : 1
            data.orderByClauses = [{ field: prop, orderByMode: order }]
          } else {
            delete data.orderByClauses
          }
        } else if (!sortConf && hasDefSort) {
          let prop = defSort.keys[data.elasticsearchFlag === 'Y' ? 0 : 1]
          let order = defSort.order === 'ascending' ? 0 : 1
          data.orderByClauses = [{ field: prop, orderByMode: order }]
        }
      },
      doHttp (method, url, headerUrl, data, option, index, action) {
        method = method || url.method
        // 添加接口缓存标志
        data.ERPSearchCacheFlag = true
        if (this.forceCache) {
          data.forceCache = true
        } else {
          delete data.forceCache
        }
        let axios = this.tables[index].axios
        this.$http(method, data, axios).then(res => {
          this.remotePage[index] = data.page || 1
          // 容错后台数据
          res = perfectRows(res)
          // 扁平化 区间列
          mapSectionValueList(res.rows, headerUrl && headerUrl.sectionOption)
          this.setLoading(false)
          if (this.option.module) {
            this.setQuery({ index, res })
          } else {
            url.res = res
          }
          this.$emit('change', res, index)
          // 缓存：预加载下一页，最多查询2万条数据
          // ERPSearchPreload：用户快速点击分页按钮时，重复的http请求会被取消
          if (res.rowTotal > data.page * data.pageSize && data.page < 20000 / (data.pageSize || this.pageMap.pageSize)) {
            let preData = { ...data, page: data.page + 1, ERPSearchPreload: true }
            delete preData.forceCache
            let conf = axios ? { cancel: true, ...axios } : false
            this.$http(method, preData, conf)
          }
          this.clearHScroll(index, action)
          this.isScrollY()
          return res
        }).catch(e => {
          this.setLoading(false)
          throw e
        })
      },
      getList (index, method, action) {
        const { url, option, headerUrl } = this.tables[index]
        const data = this.queryModule[index].data || {}
        this.handleRemoteSort(data, option.defaultSort, option.sort)
        let fn = option.beforeHttp
        if (fn && typeof fn === 'function' && fn(data, action) === true) {
          return Promise.resolve(false)
        }
        if (data.generic && data.generic.vos) {
          perfectVos(data.generic.vos)
        }
        if (this.generic && this.generic.searchCode) {
          data.menuId = this.option.menuId
          data.genericSearchCode = this.generic.searchCode
        }
        if (!option.timeout) {
          this.setLoading(true)
        }
        // TODO 后台消息队列延迟尚未解决，前端延迟执行
        if (data.elasticsearchFlag === 'Y' && this.forceCache && this.isRefresh) {
          this.isRefresh = false
          return new Promise(resolve => {
            setTimeout(() => {
              resolve(this.doHttp(method, url, headerUrl, data, option, index, action))
            }, 1000)
          })
        }
        return this.doHttp(method, url, headerUrl, data, option, index, action)
      },
      handleSizeChange (val) {
        this.pageMap.pageSize = val
        let index = +this.active
        const data = { page: this.pageMap.page, pageSize: val }
        if (this.option.module) {
          this.setQuery({ index, data })
        } else {
          Object.assign(this.tables[index].url.data, data)
        }
        this.forceCache = true
        this.getList(index, this.tables[index].method, HTTP_ACTION.PAGER)
      },
      handleCurrentChange (val) {
        let index = +this.active
        const data = { page: val }
        if (this.option.module) {
          this.setQuery({ index, data })
        } else {
          Object.assign(this.tables[index].url.data, data)
        }
        this.forceCache = false
        this.getList(index, this.tables[index].method, HTTP_ACTION.PAGER)
      },
      formSubmit (model, params) {
        let index = this.formIndex === -1 ? +this.active : this.formIndex
        this.initQueryParams(model, index, params)
        let fn = this.tables[index].option.beforeFormSubmit
        if (fn && typeof fn === 'function' && fn(this.queryModule[index].data, model) === true) {
          return
        }
        this.forceCache = true
        this.tables[index].method = ''
        this.tables[index].axios = null
        this.getList(index, null, HTTP_ACTION.FORM)
        if (this.$refs.tools) {
          this.$refs.tools.clearActiveBtn()
        }
      },
      formReset (model) {
        let index = this.formIndex === -1 ? +this.active : this.formIndex
        let option = this.tables[index].option
        if (typeof option.beforeFormReset === 'function') {
          option.beforeFormReset(this.queryModule[index].data, model)
        }
      },
      registerStoreModule () {
        let module = this.option.module
        if (!module) {
          return
        }
        let tag = this.$route.meta.tag
        let moduleTag = this.$store.state.queryTable.$module[module]
        if (moduleTag && tag !== moduleTag) {
          let msg = `QueryTable组件子模块“'${module}':'${moduleTag}'”已注册，不能重复注册！`
          this.$alert(msg, '提示', { type: 'error', showClose: false })
          return
        }
        if (!moduleTag) {
          this.$store.registerModule(['queryTable', module], createStoreModule())
          this.$store.commit('queryTable/registerModule', { module, tag })
        }
        this.tables.forEach((v, i) => this.setQuery({ index: i, data: v.url.data }))
      },
      setQuery (payload) {
        if (this.$store.state.queryTable[this.option.module]) {
          this.$store.commit(this.queryTableAction.setQuery(this.option.module), payload)
        }
      },
      initQueryParams (model, index, params) {
        let url = this.tables[index].url
        if (this.option.module) {
          let generic = this.tables[index].url.originData.generic
          if (params && params.generic) {
            Object.assign(params.generic, generic)
          } else if (!params && this.formFields.length) {
            params = {
              ...mapFormModelParams(this.formFields, model),
              ...mapGenericSearchParams(this.formFields, model, generic)
            }
          }
          let data = { ...url.data, page: this.pageMap.page, ...params }
          this.setQuery({ index, data })
        } else {
          let data = { ...url.data, page: this.pageMap.page }
          let isGeneric = this.formFields.some(v => {
            return (v.columnType && v.operation) || (v.options && v.options.some(k => k.columnType && k.operation))
          })
          if (isGeneric) { // 通用查询
            let generic = this.tables[index].url.originData.generic
            if (params && params.generic) {
              Object.assign(params.generic, generic)
            } else if (!params) {
              params = {
                ...mapFormModelParams(this.formFields, model),
                ...mapGenericSearchParams(this.formFields, model, generic)
              }
            }
            Object.assign(data, params)
          } else { // 普通表单查询
            Object.assign(data, model)
          }
          url.data = data
        }
      },
      initOption () {
        // 检测是否在 dialog 中使用
        let isDialog = !this.option.dialog && this.$parent && (
          (this.$parent.modalAppendToBody) ||
          (this.$parent.$parent && this.$parent.$parent.modalAppendToBody)
        )
        if (isDialog) {
          this.option.dialog = true
          this.option.pageFooter = this.option.pageFooter !== false
        }
        const menu = this.$store.getters.menus[this.$route.meta.tag]
        let obj = {
          inline: true,
          auth: true,
          unpager: true, // 是否需要详情页的上下分页器
          draggable: !this.option.dialog,
          module: this.option.dialog ? false : !!(this.generic && this.generic.searchCode),
          menuId: menu && menu.id
        }
        Object.assign(obj, this.option)
        // 有通用查询需求时，如果没有设置 module，则自动设置 module
        if (obj.module && typeof obj.module === 'boolean') {
          obj.module = this.tables[0].url.method
        }
        Object.assign(this.option, obj)
        this.option.auth = this.option.auth ? this.tables[0].url.method : ''
      },
      initTables () {
        this.tables.forEach((v, i) => {
          this.remotePage[i] = 1
          v.option = Object.assign({
            type: 'index', // index, selection
            border: true,
            stripe: true,
            page: true,
            load: true
          }, v.option)
          this.initUrl(v.url, v.headerUrl)
          this.initEvent(v, i)
          this.$set(v, '$columns', [])
          if (!v.columns) {
            this.$set(v, 'columns', [])
          }
          if (v.operation) {
            v.operation.label = v.operation.label || '操作'
            v.operation.width = v.operation.width || 40
            v.operation.fixed = v.operation.fixed || 'left'
          }
        })
      },
      initUrl (url, headerUrl) {
        this.$set(url, 'res', { rows: [], rowTotal: 0 })
        let data = {
          ...this.pageMap,
          elasticsearchFlag: 'Y',
          generic: { vos: [] },
          ...url.data
        }
        data.generic.vos = data.generic.vos || []
        if (url.data) {
          url.originData = JSON.parse(JSON.stringify(url.data))
        } else {
          url.originData = {}
        }
        this.$set(url, 'data', data)
        if (headerUrl && headerUrl.sectionOption) {
          headerUrl.sectionOption.$row = `$${headerUrl.sectionOption.row}`
        }
      },
      initEvent (v, i) {
        const func = v.option.rowDblClick
        if (this.option.module && func) {
          v.option.rowDblClick = (row) => {
            this.setPager(v.option.idKey, i)
            func(row)
          }
        }
        if (!v.option.cellClick) {
          v.option.cellClick = _ => {
          }
        }
      },
      // 双击进入详情前，初始化详情页【翻页功能】需要的数据
      setPager (idKey, index = 0) {
        idKey = idKey || this.tables[index].option.idKey
        this.$store.commit(this.queryTableAction.setPager(this.option.module), { idKey, index })
      },
      triggerHttp (model = {}, params) {
        let load = false
        this.tables.forEach((tab, i) => {
          this.initQueryParams(model, i, params)
          if (tab.option.load) {
            load = true
            this.forceCache = true
            this.getList(i, null, HTTP_ACTION.FORM)
          }
          if (tab.option.timeout) {
            setInterval(_ => this.getList(i, null, HTTP_ACTION.PAGER), tab.option.timeout)
          }
        })
        this.setLoading(load)
        return load
      },
      initLocalFormTable () {
        if (this.formFields.length) {
          this.option.searchCode = ''
        }
        let isLocalTable = this.tables.every(v => v.columns.length > 0)
        if (isLocalTable) {
          for (let i = 0, len = this.tables.length; i < len; i++) {
            let tab = this.tables[i]
            tab.searchCode = ''
            let permissionPrefix = `${tab.url.method}.data.rows.`
            tab.columns.forEach(v => this.mergeColumn(tab, v, permissionPrefix))
            // 获取区间列配置
            if (tab.headerUrl && tab.headerUrl.method) {
              this.getHeader(tab, tab.headerUrl.data)
            }
          }
          if (!this.option.searchCode && this.formFields.length === 0) {
            this.triggerHttp()
          }
          this.canLoad = true
          this.isScrollY()
          this.$emit('created')
        }
        return isLocalTable && !this.option.searchCode
      },
      async getGenericSearchFields () {
        if (this.initLocalFormTable()) {
          return
        }
        try {
          this.setLoading(true)
          // 获取用户自定义配置
          let menuId = this.option.menuId
          // 同一时间重复的请求会被取消，所以带上时间戳
          let userRes = await this.$http('system.genericSearch.listByMenuId', { menuId, time: random() })
          if (userRes && userRes.length) {
            if (this.$refs.genericDialog) {
              let opt = userRes.find(v => v.searchCode === this.generic.searchCode)
              this.$refs.genericDialog.setGenericSearchFields(opt)
            }
            let obj = userRes.find(v => v.searchCode === this.option.searchCode)
            if (obj) {
              this.option[obj.searchCode] = obj.id
              try {
                // 如果用户保存了自定义查询，需要获取自定义查询公共配置
                // 容错处理：没有返回正确的个性模板，则返回公共模板
                let userArr = JSON.parse(obj.fieldContent)
                if (!userArr || !userArr[0] || typeof userArr[0] === 'string') {
                  let { fieldContent } = await this.$http('system.genericSearch.get', { id: obj.id })
                  this.setFormFields(JSON.parse(fieldContent), userArr)
                } else {
                  this.setFormFields(userArr)
                }
              } catch (e) {
              }
            }
            for (let i = 0, len = this.tables.length; i < len; i++) {
              let tab = this.tables[i]
              let obj = userRes.find(v => v.searchCode === tab.searchCode)
              if (obj) {
                this.option[obj.searchCode] = obj.id
                let esFlag = obj.esFlag === '10' ? 'Y' : 'N'
                tab.url.data.elasticsearchFlag = esFlag
                if (this.option.module) {
                  this.setQuery({ index: i, data: { elasticsearchFlag: esFlag } })
                }
                try {
                  // 如果用户保存了自定义列，需要获取自定义列公共配置
                  // 容错处理：没有返回正确的个性模板，则返回公共模板
                  let userArr = JSON.parse(obj.fieldContent)
                  if (!userArr || !userArr[0] || typeof userArr[0] === 'string') {
                    let { fieldContent } = await this.$http('system.genericSearch.get', { id: obj.id })
                    this.setColumns(tab, JSON.parse(fieldContent), userArr)
                  } else {
                    this.setColumns(tab, userArr)
                  }
                } catch (e) {
                }
                // 获取区间列配置
                if (tab.headerUrl && tab.headerUrl.method) {
                  await this.getHeader(tab, tab.headerUrl.data)
                }
              }
            }
          }
          this.configError = false
          if (!this.canLoad) {
            if (this.formFields.length === 0) {
              this.triggerHttp()
            }
            this.canLoad = true
            this.isScrollY()
            this.$emit('created')
          }
        } catch (e) {
          this.configError = true
          this.setLoading(false)
        }
      },
      getHeader (tab, params) {
        return this.$http(tab.headerUrl.method, params, tab.headerUrl.appkey).then(res => {
          if (tab.headerUrl.sectionOption && res && res.length) {
            let $rowKey = tab.headerUrl.sectionOption.$row
            let columnKey = tab.headerUrl.sectionOption.columnKey
            let columnLabel = tab.headerUrl.sectionOption.columnLabel
            let arr = res.map(v => {
              return {
                section: v,
                key: `${$rowKey}.${v[columnKey]}`,
                label: v[columnLabel],
                width: '110px',
                auth: true,
                show: true,
                $show: true,
                undraggable: true
              }
            })
            if (tab.columns.some(v => v.key.indexOf($rowKey) !== -1)) {
              tab.columns = tab.columns.filter(v => v.key.indexOf($rowKey) === -1)
            }
            // 区间列插入到指定位置 sectionIndex
            let sectionIndex = tab.columns.findIndex(v => !!v.sectionIndex)
            sectionIndex = sectionIndex === -1 ? tab.columns.length : sectionIndex
            tab.columns.splice(sectionIndex, 0, ...arr)
            tab.$columns = [...tab.columns]
          }
        })
      },
      setFormFields (originArr, userArr) {
        if (originArr && originArr.length) {
          if (userArr) {
            // 如果没有交集，则取公共模板
            let keys = originArr.map(v => v.propertyName)
            keys = intersection(keys, userArr)
            if (keys && keys.length > 0) {
              let length = userArr.length
              originArr.forEach(v => {
                let index = userArr.indexOf(v.propertyName) + 1
                v.index = index || ++length
                v.show = index > 0
              })
              originArr.sort((a, b) => a.index - b.index)
            }
          }
          this.formFields.push(...originArr)
          this.copyFormFields.$columns.push(...originArr)
        }
      },
      setColumns (tab, originArr, userArr) {
        if (originArr && originArr.length) {
          let flag = !!userArr
          // 如果没有交集，则取公共模板
          if (flag) {
            let keys = originArr.map(v => v.key)
            keys = intersection(keys, userArr)
            flag = keys && keys.length > 0
          }
          let length = flag ? userArr.length : 0
          let permissionPrefix = `${tab.url.method}.data.rows.`
          originArr.forEach(v => {
            // 用户自定义的字段排序在前面
            if (flag) {
              let index = userArr.indexOf(v.key) + 1
              v.index = index || ++length
              v.show = index > 0 || !!v.fixed
            }
            this.mergeColumn(tab, v, permissionPrefix)
          })
          if (flag) {
            originArr.sort((a, b) => a.index - b.index)
          }
          tab.columns = originArr
          tab.$columns = [...originArr]
        }
      },
      mergeColumn (tab, v, permissionPrefix) {
        this.$set(v, '$show', !!v.show)
        this.$set(v, 'show', !!v.show)
        // 列自定义Formatter
        if (tab.formatter && tab.formatter[v.key]) {
          v.formatter = tab.formatter[v.key]
        }
        // 列权限控制
        v.auth = !this.permission.columns.includes(`${permissionPrefix}${v.key}`)
      },
      getTabLabel (option, index) {
        if (!option.tabLabelCount) {
          return option.label
        }
        return `${option.label}(${this.total(index)})`
      },
      tabClick () {
        this.$refs.tableList[+this.active].setCanvasWidth()
        let func = this.tables[+this.active].option.tabClick
        func && func()
      },
      setCanvas () {
        this.$refs.tableList.setCanvasWidth()
        this.$refs.queryForm && this.$refs.queryForm.handleRowFields()
      },
      tabDisabled (auth) {
        return !this.permission.menus.includes(auth)
      },
      getDefaultValue (v, key) {
        if (this.formModel && this.formModel.hasOwnProperty(key)) {
          let func = this.formModel[key]
          return typeof func === 'function' ? func() : func
        } else {
          return v.default || ''
        }
      },
      onRefreshMainQueryTable () {
        let tag = this.$route.meta.tag
        let isMain = this.$route.path === tag && !this.option.dialog
        this.isRefresh = isMain && !this._inactive && this.refreshList.includes(tag)
        if (this.isRefresh) {
          this.$store.commit('queryTable/unrefresh', tag)
          this.tables.forEach((v, i) => this.loadCurrentData(i, v.method))
        }
      },
      genericSubmit (data) {
        this.loadData(data, null, null, null, HTTP_ACTION.GENERIC)
      },
      onGenericLoaded (val) {
        this.genericModel = val
      },
      onTemplateListChange (val) {
        this.templateList = val
      },
      setLoading (val) {
        if (this.option.dialog) {
          this.loading = val
        } else {
          this.$store.commit('SET_LOADING', val)
        }
      },
      switchMenu (width) {
        this.offsetLeft = width + 16 + (this.option.offsetLeft || 0)
      },
      handleResize () {
        if (!this._inactive) {
          let len = this.tables.length
          if (len > 1) {
            for (let i = 0; i < len; i++) {
              this.$refs.tableList[i] && this.$refs.tableList[i].setCanvasHeight()
            }
          } else {
            this.$refs.tableList && this.$refs.tableList.setCanvasHeight()
          }
          this.isScrollY()
        }
      },
      isScrollY () {
        if (this.option.dialog) {
          clearTimeout(this.scrollYTimmer)
          this.scrollYTimmer = setTimeout(_ => {
            let el = this.$el.querySelector('.kye-dialog-body') || this.$parent.$el.querySelector('.el-dialog__body')
            if (el && Math.abs(el.offsetHeight - el.scrollHeight) > 1) {
              this.scrollY = true
            }
          }, 200)
        }
      },
      // 清除 canvas 的定位
      clearHScroll (index, action) {
        if (action && action !== HTTP_ACTION.PAGER && this.$refs.tableList) {
          if (this.tables.length === 1) {
            this.$refs.tableList.$refs.table.clearHScroll()
          } else if (this.tables.length > 1) {
            this.$refs.tableList[index].$refs.table.clearHScroll()
          }
        }
      }
    }
  }
</script>

<style lang="scss">
  .query-table-container {
    .el-tabs__content {
      overflow: inherit
    }
    .jumper-button {
      margin-left: 10px;
      margin-right: 18px;
      padding-left: 6px;
      padding-right: 6px;
      min-width: unset !important;
      span {
        height: 14px;
        line-height: 14px;
      }
    }
    .fixedPagination {
      position: fixed;
      left: 176px;
      bottom: 8px;
      z-index: 10;
      background-color: #ffffff;
      padding-top: 8px;
    }
    .query-form-wrap {
      min-height: 32px;
      height: 32px;
      &_overflow {
        height: auto;
      }
      &_none {
        min-height: 0;
        height: 0;
      }
    }
    .error {
      cursor: pointer;
      text-align: center;
    }
  }
</style>
