import Vue from 'vue'

const KyeExpandPage = Vue.component('kye-expand-page', {
  functional: true,
  render (h, self) {
    let directives = self.data.directives || []
    self.data.directives = [...directives, { name: 'next' }]
    return h('div', {...self.data, attrs: { class: 'kye-expand-page' }}, self.children)
  }
})

export default KyeExpandPage
