import Vue from 'vue'

const KyeCascader = Vue.component('kye-cascader', {
  functional: true,
  render (h, self) {
    return h('el-cascader', self.data, self.children)
  }
})

export default KyeCascader
