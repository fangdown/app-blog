import computed from './computed'

export default {
  computed: computed.computed
}
