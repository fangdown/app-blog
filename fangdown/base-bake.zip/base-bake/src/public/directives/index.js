import drag from './drag'
import scroll from './scroll'
import next from './next'
import notnext from './not-next'
import tablefixed from './table-fixed'

export default {
  drag,
  scroll,
  next,
  notnext,
  tablefixed
}
