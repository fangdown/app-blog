import Vue from 'vue'
import Vuex from 'vuex'
import Pinyin from 'pinyin/lib/web-pinyin'
import queryTable from './modules/queryTable'
import tagsView from './modules/tagsView'
import { HOME_MENUS } from '../config'
import { defineFreezeProperty } from 'public/utils'
import ERPcache from 'public/utils/cache-plugin'

Vue.use(Vuex)

const API = {
  user: 'hr.remoteEmployee.getLoginUser',
  permission: 'auth.permission.getByUserId',
  menu: 'auth.menu.resources.loginUser.list',
  address: 'address.addressBackground.listAddress'
}

const MENUS = Object.values(API).map(v => v.toLowerCase())
MENUS.includes = function includes (val) {
  return val ? [].includes.call(this, val.toLowerCase().replace(/\$/g, '')) : false
}

// 获取属于ERP系统的菜单的子系统编码，菜单管理模块有移动端APP建立的菜单（需要过滤掉）
const SUBSYSTEM_CODES = (arr => {
  if (arr) {
    let item = arr.find(v => v.code === 'auth_menu_resource_sub_system_title')
    if (item && item.value) {
      return item.value.reduce((s, v) => {
        s[v.lookupCode] = v.lookupValue.split('/')[1]
        return s
      }, {})
    }
  }
  return {}
})(window.__ERPLOOKUP__)

export default new Vuex.Store({
  state: {
    loading: false,
    dragMenu: '',
    user: {},
    menus: {},
    gisProvinces: [],
    lookUpOptions: {},
    permission: {
      menus: MENUS,
      columns: [],
      sensitives: []
    }
  },
  getters: {
    user: state => state.user,
    menus: state => state.menus,
    lookUpOptions: state => state.lookUpOptions,
    permission: state => state.permission
  },
  modules: {
    queryTable,
    tagsView
  },
  mutations: {
    SET_LOADING (state, data) {
      state.loading = data
    },
    SET_PROVINCES (state, provinces) {
      state.gisProvinces = provinces
    },
    SET_USER (state, data) {
      if (!data.departmentInfo) {
        data.departmentInfo = { departmentRoute: '' }
      } else if (!data.departmentInfo.departmentRoute) {
        data.departmentInfo.departmentRoute = ''
      }
      // 只要组织路由中包含'销售管理部' 就属于总经办
      data.isGMO = data.departmentInfo.departmentRoute.includes('销售管理部')
      data.isMarket = data.duty === '市场员'
      data.isManager = data.duty === '经理'
      data.isMarketManager = data.duty === '销售主管'
      state.user = data
      defineFreezeProperty(window, '__ERPUSER__', JSON.parse(JSON.stringify(data)))
      ERPcache.removeAllCache()
    },
    SET_PERMISSION (state, data) {
      data.menus = data['authMenuModuleCodes']
      data.columns = data['permissionColumnCodes']
      data.sensitives = data['sensitiveColumnCodes']
      delete data['authMenuModuleCodes']
      delete data['permissionColumnCodes']
      delete data['sensitiveColumnCodes']
      Object.keys(data).reduce((s, v) => {
        let arr = data[v]
        if (arr && arr.length) {
          s[v].push(...arr.map(k => k.toLowerCase()))
          s[v].sort()
        }
        return s
      }, state.permission)
    },
    SET_LOOKUP_OPTIONS (state, data) {
      state.lookUpOptions = data.reduce((o, v) => {
        o[v.code] = (v.value || v.childrenLookupValues || [])
          .sort((a, b) => a.displaySequence - b.displaySequence)
          .map(v1 => ({ label: v1.lookupValue, value: v1.lookupCode }))
        o.lookupMap[v.code] = v.description
        return o
      }, { lookupMap: {} })
    },
    SET_MENUS (state, menus) {
      const codes = Object.keys(SUBSYSTEM_CODES) || []
      const obj = menus ? { rootMenus: {}, menuTree: [] } : {}
      const en = { style: Pinyin.STYLE_FIRST_LETTER, segment: false }
      menus && menus.forEach(v => {
        let subSystem = v.subSystem
        if (!codes.includes(subSystem)) {
          return
        }
        let url = v.menuCode
        let title = v.menuTitle
        let menu = {
          id: v.id,
          menuCode: url,
          icon: v.menuIcon,
          subSystem: subSystem,
          title: title,
          isUpgraded: false,
          $ptitle: SUBSYSTEM_CODES[subSystem],
          $title: title,
          $title_en: Pinyin(title, en).map(v => v[0]).join('') || ''
        }
        obj.rootMenus[v.id] = menu
        if (v.childrenMenuResources && v.childrenMenuResources.length) {
          let menuCodes = []
          v.childrenMenuResources.forEach(v2 => {
            let curl = v2.menuCode
            if (obj[curl]) {
              return
            }
            let ctitle = v2.menuTitle
            let res = {
              id: v2.id,
              parentId: v2.parentId,
              menuCode: curl,
              subSystem: v2.subSystem,
              title: ctitle,
              isUpgraded: false,
              $ptitle: SUBSYSTEM_CODES[v2.subSystem],
              $title: `${title} > ${ctitle}`,
              $title_en: Pinyin(ctitle, en).map(v => v[0]).join('') || ''
            }
            if (!HOME_MENUS.includes(curl)) {
              menuCodes.push(curl)
            }
            obj[curl] = res
          })
          menu.menuCodes = menuCodes
        } else if (!obj[url]) {
          obj[url] = menu
        }
      })
      state.menus = obj
    },
    SET_MENUS_REMIND (state, arr) {
      if (Array.isArray(arr) && arr.length) {
        arr.forEach(v => {
          let menu = state.menus[v.key]
          if (menu) {
            if (menu.hasOwnProperty('$remind')) {
              menu.$remind = v.value
            } else {
              Vue.set(menu, '$remind', v.value)
            }
          }
        })
      }
    }
  }
})
