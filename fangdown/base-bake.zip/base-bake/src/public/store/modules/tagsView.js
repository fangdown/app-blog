const tagsView = {
  state: {
    closedTag: '',
    visitedViews: [],
    cachedViews: []
  },
  mutations: {
    ADD_VISITED_VIEWS (state, route) {
      if (!route.name || !route.meta.tag || state.visitedViews.some(v => v.path === route.fullPath)) {
        return
      }
      let view = state.visitedViews.find(v => v.tag === route.meta.tag)
      if (view) {
        view.path = route.fullPath
        view.closeTag = !!route.meta.closeTag
        view.pageType = route.meta.pageType
        if (!view.names.includes(route.name)) {
          view.names.push(route.name)
          state.cachedViews.push(route.name)
        }
        return
      }
      if (route.meta.layout) {
        route.meta.layout = false
      }
      state.closedTag = ''
      state.visitedViews.push({
        path: route.fullPath,
        names: [route.name],
        tag: route.meta.tag,
        title: route.meta.tagTitle,
        closeTag: !!route.meta.closeTag,
        playout: route.meta.playout,
        pageType: route.meta.pageType
      })
      state.cachedViews.push(route.name)
    },
    DEL_VISITED_VIEWS (state, view) {
      for (const [i, v] of state.visitedViews.entries()) {
        if (v.tag === view.tag) {
          state.visitedViews.splice(i, 1)
          break
        }
      }
      const layout = view.playout
      const hasLayout = state.visitedViews.some(v => layout === v.playout)
      state.cachedViews = state.cachedViews.filter(v => {
        if (hasLayout) {
          return !view.names.includes(v)
        }
        return !view.names.includes(v) && v !== layout
      })
    },
    DEL_OTHERS_VIEWS: (state, view) => {
      state.visitedViews = state.visitedViews.filter(v => v.tag === view.tag || v.tag === '/')
      const layout = view.playout
      state.cachedViews = state.cachedViews.filter(v => v === 'home' || v === layout || view.names.includes(v))
    },
    CLEAR_VISITED_VIEWS (state) {
      state.closedTag = ''
      state.visitedViews = state.visitedViews.filter(v => v.tag === '/')
      state.cachedViews = ['home']
    },
    SET_CLOSED_TAG (state, path) {
      state.closedTag = path
    },
    // coo 需求
    CHANGE_VISITED_VIEWS_TITLE (state, { path, title }) {
      let view = state.visitedViews.find(v => v.tag === path)
      if (view) {
        view.title = title
      }
    }
  },
  actions: {
    addVisitedViews ({ commit, rootState, state }, route) {
      let layout = route.meta.playout
      if (layout && !state.cachedViews.includes(layout)) {
        state.cachedViews.push(layout)
      }
      route.meta.tagTitle = (rootState.menus[route.meta.tag] || {}).title || route.meta.title
      commit('ADD_VISITED_VIEWS', route)
    },
    delVisitedViews ({ commit, state }, view) {
      let tag = view.tag
      commit('queryTable/unregisterModule', [tag])
      commit('DEL_VISITED_VIEWS', view)
      if (view.path === location.hash.replace('#', '')) {
        commit('SET_CLOSED_TAG', tag)
      }
      return Promise.resolve(state.visitedViews)
    },
    delOthersViews ({ commit, state }, view) {
      let tags = []
      state.visitedViews.forEach(v => {
        if (v.tag !== view.tag) {
          tags.push(v.tag)
        }
      })
      commit('queryTable/unregisterModule', tags)
      commit('DEL_OTHERS_VIEWS', view)
    },
    delAllViews ({ commit, state }) {
      let tags = state.visitedViews.map(v => v.tag)
      commit('queryTable/unregisterModule', tags)
      commit('CLEAR_VISITED_VIEWS')
    }
  }
}

export default tagsView
