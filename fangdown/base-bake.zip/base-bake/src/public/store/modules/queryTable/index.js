export default {
  namespaced: true,
  state: {
    $tag: {},
    $module: {},
    $refreshList: [],
    $action: {
      setQuery: (module) => `queryTable/${module}/SET_QUERY`,
      setPager: (module) => `queryTable/${module}/SET_PAGER`,
      updatePager: (module) => `queryTable/${module}/UPDATE_PAGER`
    }
  },
  mutations: {
    registerModule (state, { module, tag }) {
      const tags = state.$tag[tag]
      if (tags && tags.indexOf(module) === -1) {
        tags.push([module])
      } else if (!tags) {
        state.$tag[tag] = [module]
      }
      state.$module[module] = tag
    },
    unregisterModule (state, tags) {
      tags.forEach(v => {
        let modules = state.$tag[v]
        if (modules) {
          state.$tag[v] = []
          modules.forEach(m => {
            state.$module[m] = ''
            delete state[m]
          })
        }
      })
    },
    refresh (state, tag) {
      if (state.$refreshList.indexOf(tag) === -1) {
        state.$refreshList.push(tag)
      }
    },
    unrefresh (state, tag) {
      state.$refreshList.splice(state.$refreshList.indexOf(tag), 1)
    }
  }
}
