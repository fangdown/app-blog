import { getQueryPager } from 'public/components/query-table/utils'

export default function createModule () {
  return {
    namespaced: true,
    state: {
      query: [], // {data: {page: 1}, res: {rowTotal: 0, rows: []}}
      pager: { ids: [], total: 0 }
    },
    mutations: {
      SET_QUERY (state, payload) {
        let obj = state.query[payload.index]
        if (obj) {
          if (payload.data) {
            if (obj.data) {
              Object.assign(obj.data, payload.data)
            } else {
              obj.data = payload.data
            }
            delete payload.data
          }
          Object.assign(obj, payload)
          state.query.splice(payload.index, 1, obj)
        } else {
          state.query.push(payload)
        }
      },
      SET_PAGER (state, payload) {
        let obj = state.query[payload.index]
        if (obj && obj.res && obj.res.rows) {
          let idKey = payload.idKey || 'id'
          state.pager = getQueryPager(idKey, obj.res.rows)
        }
      },
      UPDATE_PAGER (state, payload) {
        state.pager = { ...state.pager, ...payload }
      }
    }
  }
}
