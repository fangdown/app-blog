import hostMap from './host'

const login = 'http://cas.dev.ky-tech.com.cn'
const hostname = `${location.protocol}//${location.hostname}`

export * from './appkey'

export const ENV = hostMap[hostname] && hostMap[hostname].env

export const CASLOGIN = hostMap[hostname] ? hostMap[hostname].login : login

export const REST = '/router/rest'

export const CHARTS_THEME = 'light'

// 首页置顶的常用模块
export const HOME_MENUS = (arr => {
  if (arr) {
    let item = arr.find(v => v.code === 'auth_menu_home')
    if (item && item.value) {
      return item.value
        .sort((a, b) => a.displaySequence - b.displaySequence)
        .map(v => v.lookupCode)
    }
  }
  return []
})(window.__ERPLOOKUP__)

export const PAGINATION = {
  layout: 'sizes, total, prev, pager, next',
  layout2: 'sizes, total, jumper, slot, prev, pager, next',
  pageSizes: [200],
  pageSize: 200
}
