export default { ...window.__ERPHOSTMAP__ }
