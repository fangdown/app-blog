export const APPKEY = { ...window.__ERPAPPKEY__ }
