import axios from 'axios'
import store from '../store'
import { ENV, APPKEY, REST } from '../config'
import { getToken } from '../utils/token'

const enable = ['sit', 'uat', 'prd'].includes(ENV)

const report = (data) => {
  axios({
    method: 'post',
    url: `${REST}?syslog.frontendOperationLog.save`,
    data,
    headers: {
      format: 'JSON',
      method: 'syslog.frontendOperationLog.save',
      appkey: APPKEY['syslog'],
      token: getToken()
    }
  })
}

const install = (Vue) => {
  if (!ENV) return
  const error = Vue.config.errorHandler

  Vue.config.errorHandler = (err, vm, info) => {
    if (enable) {
      let user = store.getters.user
      let tag = vm.$router.history.current.meta.tag
      let menu = store.getters.menus[tag] || {}

      report({
        userId: user.id,
        userName: user.name,
        menuId: menu.id,
        menuName: menu.$title,
        error: err.stack,
        option: JSON.stringify({
          url: location.hash,
          ua: window.navigator.userAgent,
          info: info,
          component: vm.$vnode.componentOptions.tag
        })
      })
    }

    if (typeof error === 'function') {
      error.call(Vue, err, vm, info)
    }
  }
}

export default install
