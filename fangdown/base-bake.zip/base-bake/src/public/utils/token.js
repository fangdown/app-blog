export const getToken = () => {
  return sessionStorage.getItem('ERPTOKEN') || ''
}

export const setToken = token => {
  token = token || ''
  sessionStorage.setItem('ERPTOKEN', token)
}
