<template>
  <el-card class="notice-card">
    <h3 slot="header">新闻通告
      <el-button type="text"
                 class="fr"
                 @click="$router.push('/oa/news-notice/main')">
                 更多
      </el-button>
    </h3>
    <ul class="notice-card__body">
      <li v-for="(msg, i) in list"
          :key="i"
          @click="showPreviewDialog(msg)">
        <span class="topicCell">{{msg.topic}}</span>
        <span class="fr">{{msg.creationDate | time('MM月DD日 HH:mm')}}</span>
      </li>
    </ul>
    <div class="notice-card__footer">

    </div>
    <kye-preview :visible="isInfo"
                 :bizCode="bizCode"
                 :bizId="bizId"></kye-preview>
  </el-card>
</template>
<script>
  import KyePreview from '@/shared/components/kye-preview'
  export default {
    name: 'notice',
    components: {
      KyePreview
    },
    data () {
      return {
        preInfo: '',
        isInfo: false,
        bizCode: null,
        bizId: null,
        list: []
      }
    },
    mounted () {
      this.$bus.$once('APP_LOADED', this.getNoticeList)
    },
    methods: {
      async showPreviewDialog (row) {
        let res = await this.$http('oams.notice.home.filedownload', {
          id: row.id
        })
        if (res && res.length && res[0]) {
          this.bizCode = res[0].bizCode
          this.bizId = res[0].bizId
          this.isInfo = !this.isInfo
        }
      },
      async getNoticeList () {
        let res = await this.$http('oams.notice.home.search', null, false)
        this.list = res.filter((t, i) => i < 6)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .notice-card {
    h3 {
      font-size: 16px;
      font-weight: bolder;
    }
    &__body {
      margin: 0;
      height: 192px;
      li {
        height: 32px;
        display: flex;
        justify-content: space-between;
        line-height: 32px;
        padding: 0 16px;
        cursor: pointer;
        &:hover {
          background-color: #f5f5f7;
        }
        .topicCell {
          display: block;
          max-width: 350px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
    }
    &__footer {
      margin-right: 8px;
      text-align: right;
    }
  }
</style>
