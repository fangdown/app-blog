<template>
  <el-card class="work-flow-card">
    <div slot="header"
         class="work-flow-card__header">
      <kye-tabs v-model="workFlowTab"
                @tab-click="handleClickTab">
        <kye-tab-pane :label="`待我处理(${workFlowTaskTotal})`"
                      name="1"></kye-tab-pane>
        <kye-tab-pane :label="`我的申请(${workFlowInstanceTotal})`"
                      name="2"></kye-tab-pane>
      </kye-tabs>
      <div class="work-flow-card__header__btn">
        <kye-button type="primary" @click="addApply">新建申请</kye-button>
        <kye-button type="text" @click="moreFlow">更多</kye-button>
      </div>
    </div>
    <div class="work-flow-card__body">
      <ul class="work-flow-card__list header_list
                                     row_box">
        <li style="width:20%">申请类型</li>
        <li style="width:16%">申请人</li>
        <li>所在部门</li>
        <li style="float: right;width:103px">申请时间</li>
      </ul>
      <div v-show="workFlowTab === '1'">
        <ul v-for="(w, i) in workFlowTaskList"
            :key="i"
            @click="tapApprove(w)"
            class="work-flow-card__list row_box">
          <li style="width:20%">{{w.typeId | lookup('oams_typeid')}}</li>
          <li style="width:16%">{{w.applyName}}</li>
          <li style="max-width:40%">{{w.applyOrgName}}</li>
          <li style="float: right;width:103px;">{{w.creationDate | time('MM月DD日 HH:mm')}}</li>
        </ul>
      </div>
      <div v-show="workFlowTab === '2'">
        <ul v-for="(w, i) in workFlowInstanceList"
            :key="i"
            @click="()=>tapApply(w.id)"
            class="work-flow-card__list row_box">
          <li style="width:20%">{{w.typeId | lookup('oams_typeid')}}</li>
          <li style="width:16%">{{w.employeeName}}</li>
          <li style="max-width:40%">{{w.createOrgName}}</li>
          <li style="float: right;width:103px;">{{w.creationDate | time('MM月DD日 HH:mm')}}</li>
        </ul>
      </div>
    </div>
  </el-card>
</template>

<script>
  export default {
    name: 'work-flow',
    data () {
      return {
        workFlowTab: '1',
        workFlowTaskList: [],
        workFlowTaskTotal: 0,
        workFlowInstanceList: [],
        workFlowInstanceTotal: 0
      }
    },
    mounted () {
      this.$bus.$once('APP_LOADED', _ => {
        this.getWFTask()
        this.getWFInstance()
      })
    },
    methods: {
      async getWFTask () {
        let params = {
          page: 1,
          pageSize: 11,
          elasticsearchFlag: 'N',
          generic: {
            vos: [
              {
                'propertyName': 'taskStatus',
                'columnName': 'task_status',
                'frontBrackets': '(',
                'postBrackets': ')',
                'conditionOperation': '',
                'operation': 'contain',
                'type': 'enum',
                'values': ['30', '120', '110', '40']
              }
            ]
          },
          orderByClauses: [{ field: 'creation_date', orderByMode: 1 }]
        }
        let res = await this.$http('oams.wfTask.search', params, false)
        this.workFlowTaskList = res.rows
        this.workFlowTaskTotal = res.rowTotal
      },
      async getWFInstance () {
        let params = {
          page: 1,
          pageSize: 11,
          elasticsearchFlag: 'N',
          generic: {
            vos: [
              {
                'propertyName': 'instanceStatus',
                'columnName': 'instance_status',
                'frontBrackets': '(',
                'postBrackets': ')',
                'conditionOperation': '',
                'operation': 'contain',
                'type': 'enum',
                'values': ['30', '80', '20']
              }
            ]
          },
          orderByClauses: [{ field: 'creation_date', orderByMode: 1 }]
        }
        let res = await this.$http('oams.wfInstance.search', params, false)
        this.workFlowInstanceList = res.rows
        this.workFlowInstanceTotal = res.rowTotal
      },
      handleClickTab (tab) {
        this.workFlowTab = tab.name
        if (tab.name === '1') {
          this.getWFTask()
        } else if (tab.name === '2') {
          this.getWFInstance()
        }
      },
      moreFlow () {
        switch (this.workFlowTab) {
          case '1':
            this.$router.push('/oa/workflow/list')
            break
          case '2':
            this.$router.push('/oa/workflow/apply-list')
            break
        }
      },
      // 新建申请
      addApply () {
        this.$router.push('/oa/workflow/apply-pane')
      },
      // 待我处理
      tapApprove (task) {
        switch (task.taskStatus) {
          case '30':
          case '110':
          case '120':
            this.$router.push(`/oa/workflow/approve/${task.id}`)
            break
          case '40': // 抄送给我详情
            this.$router.push(`/oa/workflow/copy-read/${task.id}`)
            break
        }
      },
      // 我的申请
      tapApply (id) {
        this.$router.push(`/oa/workflow/apply-detail/${id}`)
      }
    }
  }
</script>

<style  lang="scss">
  .work-flow-card {
    .title {
      font-size: 16px;
      font-weight: bolder;
    }
    .el-card__header {
      padding: 0;
      border-bottom: #fff;
      .el-tabs__active-bar {
        height: 2px;
        width: 130px;
      }
      .el-tabs__nav-wrap::after {
        background-color: #fff;
      }
    }
    &__header {
      position: relative;
      .el-tabs__header {
        margin-bottom: 0;
      }
      .el-tabs__item {
        font-size: 14px;
        font-weight: 500;
        height: 46px;
        line-height: 46px;
      }
      &__btn {
        position: absolute;
        top: 8px;
        right: 8px;
      }
    }
    .el-card__body {
      padding: 0 0 8px 0;
    }
    &__body {
      margin: 0;
      height: 387px;
      .row_box {
        height: 32px;
        line-height: 32px;
        padding-left: 16px;
        text-align: left;
        width: 100%;
        li {
          float: left;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        cursor: pointer;
        &:hover {
          background-color: #f5f5f7;
        }
      }
      .header_list {
        height: 38px;
        line-height: 38px;
        background: #f5f5f5;
        color: #333333;
        font-weight: bold;
      }
    }
    &__footer {
      margin-right: 8px;
      text-align: right;
    }
  }
</style>
