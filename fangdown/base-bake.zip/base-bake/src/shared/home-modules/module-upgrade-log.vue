<template>
  <el-dialog
    width="720px"
    append-to-body
    :visible.sync="visible"
    :show-close="false"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    custom-class="module-upgrade-log__dialog">
    <div class="module-upgrade-log__dialog__header">
      <h3>升级内容</h3>
    </div>
    <div class="module-upgrade-log__dialog__body">
      <div v-html="log.content"></div>
      <div class="module-upgrade-log__dialog__footer">
        <kye-button type="primary" @click="iKnow">知道了</kye-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
  import moment from 'moment'

  export default {
    name: 'module-upgrade-log',
    data () {
      return {
        visible: false,
        log: {
          content: ''
        }
      }
    },
    mounted () {
      this.$bus.$once('APP_LOADED', this.getUpgradeLogAll)
    },
    watch: {
      $route () {
        if (this.$route.meta.tag) {
          this.checkUpgradeByRoute(this.$route.meta.tag)
        }
      }
    },
    methods: {
      latestUpgradeDate () {
        let last = localStorage.getItem('latestUpgradeDate')
        if (last && !/^\{/.test(last)) {
          localStorage.removeItem('latestUpgradeDate')
        }
        return JSON.parse(localStorage.getItem('latestUpgradeDate') || '{}')
      },
      async getUpgradeLogAll () {
        let r = await this.$http('system.upgradeLog.all', null, false)
        let c = this.latestUpgradeDate()
        if (r.length) {
          r.forEach(t => {
            if (this.$store.state.menus[t.menuCode]) {
              let lastDate = parseInt(c[t.moduleId] || moment().subtract(7, 'days').format('x'))
              this.$store.state.menus[t.menuCode].isUpgraded = lastDate < t.creationDate
            }
          })
          if (this.$route.meta.tag || this.$route.path === '/') {
            this.checkUpgradeByRoute(this.$route.meta.tag || '/')
          }
        }
      },
      checkUpgradeByRoute (path) {
        if (this.$store.getters.menus[path] && this.$store.getters.menus[path].isUpgraded) {
          this.getUpgradeLogByModule(this.$store.getters.menus[path].id)
        }
      },
      async getUpgradeLogByModule (id) {
        let r = await this.$http('system.upgradeLog.search', { page: 1, pageSize: 1, vo: { moduleId: id } }, false)
        if (r.rows[0]) {
          this.log = r.rows[0]
          this.visible = true
        }
      },
      iKnow () {
        this.visible = false
        this.$store.state.menus[this.log.menuCode].isUpgraded = false
        let c = this.latestUpgradeDate()
        c = { ...c, [this.log.moduleId]: this.log.creationDate }
        localStorage.setItem('latestUpgradeDate', JSON.stringify(c))
      }
    }
  }
</script>

<style lang="scss">
  .module-upgrade-log__dialog {
    &.el-dialog {
      background: rgba(0, 0, 0, 0);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0);
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0;
    }
    &__header {
      height: 180px;
      background-image: url('../assets/images/upgrade-log-bg.png');
      position: relative;
      h3 {
        position: absolute;
        top: 70px;
        left: 60px;
        color: #fff;
        font-size: 20px;
        font-weight: bold;
        letter-spacing: 4px;
      }
    }
    &__body {
      padding: 12px 16px;
      background-color: #fff;
      border-radius: 0 0 2px 2px;
      overflow-y: auto;
      max-height: calc(70vh - 225px);
      line-height: 2;
    }
    &__footer {
      text-align: center;
      margin-top: 12px;
    }
  }
</style>
