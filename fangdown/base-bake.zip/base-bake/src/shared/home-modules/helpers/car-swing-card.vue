<template>
  <div style="margin: 10px">
    <kye-expand-page>
      <kye-form :model.sync="formData"
                ref="kform">
        <kye-row>
          <kye-col :span="4">
            <kye-form-item label="司机姓名"
                           prop="driver"
                           :rules="$rule.str('请输入司机姓名', true)">
              <kye-search-tips v-model="formData.driver"
                               url="vms.employeeInfo.list"
                               :keys="['name', 'employeeNumber']"
                               value-key="name"
                               :format-data="nameData"
                               @select="selectDriver">
              </kye-search-tips>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="出车卡号"
                           prop="plateNumber"
                           :rules="$rule.str('请输入出车卡号',true)">
              <kye-input v-model="formData.plateNumber"
                         clearable
                         @blur="enterFn">
              </kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item :label="carLabel"
                           prop="startKm"
                           :rules="$rule.str('请输入公里数', true)">
              <kye-input v-model="formData.startKm"
                         :disabled="kmDisabled"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="使用人"
                           prop="person">
              <kye-input v-model="formData.person"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="出车类型">
              <kye-input v-model="formData.type"
                         disabled></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="4">
            <kye-form-item label="上传人员"
                           prop="uploader"
                           :rules="$rule.str('请输入司机姓名', true)">
              <kye-input v-model="formData.uploader"
                         disabled></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>

      <kye-tabs class="swing-card-tabs" v-model="activeName">
        <kye-tab-pane v-for="(item,i) in tabList"
                      :key="i"
                      :label="item.label"
                      :name="item.name">
          <kye-edit-table status=""
                          v-show="item.name === activeName"
                          :column="item.column"
                          :data="item.data"
                          :showIndex="true"
                          :ref="item.ref">
            <template slot="handle">
              <kye-table-column fixed="left"
                                label="操作"
                                align="center"
                                width="60">
                <template slot-scope="scope">
                  <kye-button v-show="activeName==='driver'"
                              @click="deleteRow(scope.$index, scope.row, item.ref)"
                              type="text"
                              auth="vms.oilseal.distribute.delete"
                              size="small">删除
                  </kye-button>
                </template>
              </kye-table-column>
            </template>
          </kye-edit-table>
        </kye-tab-pane>
        <kye-tab-pane></kye-tab-pane>
      </kye-tabs>
      <div class="el-dialog__footer">
        <kye-button @click="submit" type="primary" size="small">{{text}}</kye-button>
        <kye-button @click="clearAll" type="warn" size="small">清除</kye-button>
      </div>
    </kye-expand-page>
  </div>
</template>

<script>
  import {date} from 'public/utils'

  export default {
    name: 'car-swing-card',
    data() {
      return {
        activeName: 'driver',
        kmDisabled: false,
        text: '出车',
        carLabel: '出车公里数',
        driversList: [],
        formData: {
          type: '',
          plateNumber: '',
          driver: '',
          driverId: '',
          startKm: '',
          uploader: '',
          uploaderId: '',
          person: '',
        },
        tabList: [
          {
            label: '出车人员',
            name: 'driver',
            column: [
              {
                label: '司机姓名',
                key: 'driver',
                type: 'input',
                width: '200px',
              },
              {
                label: '司机点部',
                key: 'point',
                type: 'input',
                width: '200px',
              },
            ],
            data: [],
            showIndex: true,
            ref: 'driver',
          },
          {
            label: '当天出车历史',
            name: 'history',
            column: [
              {
                label: '司机点部',
                key: 'uploaderPoint',
                type: 'input',
                width: '200px',
              },
              {
                label: '出车司机',
                key: 'startDriver',
                type: 'input',
              },
              {
                label: '出车时间',
                key: 'startTime',
                type: 'input',
                width: '200px',
                filter: 'minute',
                defaultSort: {
                  keys: ['startTime', 'start_time'],
                  prop: 'startTime',
                  order: 'descending'
                },
              },
              {
                label: '车牌号',
                key: 'plateNumber',
                type: 'input',
                width: '200px',
              },
              {
                label: '返回时间',
                key: 'returnTime',
                type: 'input',
                width: '200px',
                filter: 'minute'
              },
              {
                label: '计提公里',
                key: 'extractKm',
                moduleCode: 'vms',
                bizIdKey: 'id',
                fieldName: 'extractKm',
                type: 'input',
              }
            ],
            data: [],
            showIndex: true,
            ref: 'history',
          }
        ],
      }
    },
    beforeDestroy() {
      this.formData = null
    },
    watch: {
      activeName(val) {
        this.$refs.kform.clearValidate()
      },
    },
    methods: {
      clearAll() {
        this.formData = {}
        this.driversList = []
        this.tabList.map(v => {
          v.data = []
        })
      },
      nameData(val) {
        return {name: val}
      },
      submit() {
        this.$refs.kform.validate(async (valid) => {
          if (valid) {
            let model = this.$refs.kform.model
            let drivers = []
            let driversId = []
            this.driversList.map(v => {
              drivers.push(v.driver)
              driversId.push(v.driverId)
            })
            let driverParam = drivers.join('-')
            let driverIdParam = driversId.join('-')
            let url = ''
            let params = {}
            if (this.formData.type === '出车') {
              url = 'vms.vehicleDispatch.uploadSaveByApp'
              params = {
                plateNumber: model.plateNumber,
                uploaderId: model.uploaderId,
                uploader: model.uploader,
                recordType: '50',
                startKm: model.startKm,
                startDriverId: driverIdParam,
                startDriver: driverParam,
              }
            } else {
              url = 'vms.vehicledispatch.uploadUpdateByApp'
              params = {
                plateNumber: model.plateNumber,
                returnKm: model.startKm,
                manageCode: model.manageCode,
                returnDriverId: model.uploaderId,
                returnDriver: model.uploader,
              }
            }
            await this.$http(url, params)
            this.$message.success('操作成功')
            this.clearAll()
            this.formData = {
              type: '',
              plateNumber: '',
              driver: '',
              startKm: '',
              uploader: '',
              person: '',
            }
          }
        })
      },
      async enterFn({target}) {
        if (!target.value) return
        // this.formData.plateNumber = target.plateNumber
        let val = target.value

        let today = date(new Date().getTime())
        let params = {
          elasticsearchFlag: 'N',
          generic: {
            vos: [
              {
                propertyName: 'plateNumber',
                columnName: 'plate_number',
                frontBrackets: '(',
                postBrackets: ')',
                conditionOperation: 'and',
                operation: 'contain',
                type: 'string',
                values: [
                  val,
                ],
              },
              {
                propertyName: 'startTime',
                columnName: 'start_time',
                frontBrackets: '(',
                postBrackets: ')',
                conditionOperation: '',
                operation: 'between',
                type: 'date',
                values: [
                  today + ' 00:00:00',
                  today + ' 23:59:59',
                ],
              },
            ],
          },
          menuId: this.$store.state.menus['/vms-instration/car-swipe/main'].id,
          genericSearchCode: 'vms.vehicledispatch.search',
          orderByClauses: [
            {
              field: 'vd.creation_date',
              'orderByMode': 1,
            },
          ],
          ERPSearchCacheFlag: true,
          forceCache: true,
        }
        if (this.formData.driver) {
          let obj = {
            propertyName: 'startDriver',
            columnName: 'start_driver',
            frontBrackets: '(',
            postBrackets: ')',
            conditionOperation: 'and',
            operation: 'contain',
            type: 'string',
            values: [
              this.formData.driver,
            ],
          }
          params.generic.vos.unshift(obj)
        }

        let [data, res] = await Promise.all([this.$http('vms.vehicledispatch.getLast', {outVehicleNumber: val}), this.$http('vms.vehicledispatch.search', params)])
        this.formData.plateNumber = data.plateNumber
        if (data === null || Object.keys(data).length === 0) {
          this.formData.type = '出车'
          this.carLabel = '出车公里数'
          this.text = '出车'
          this.kmDisabled = true
          this.formData.startKm = 0
        } else {
          this.formData.manageCode = data.manageCode
          if (data.returnFlag === '20') {
            this.carLabel = '出车公里数'
            this.kmDisabled = true
            this.text = '出车'
            this.formData.type = '出车'
            this.formData.startKm = data.returnKm
          } else {
            this.formData.type = '返回'
            this.carLabel = '返回公里数'
            this.kmDisabled = false
            this.text = '返回'
            this.formData.startKm = ''
          }
        }
        if (res.rows.length) {
          // this.$message.success('查询成功')
          this.tabList.some(v => {
            v.name === 'history' && (v.data = res.rows)
          })
          return
        }
        this.$message.warning(res.msg)
      },
      selectDriver(val) {
        if (!val) return
        if (!this.formData.uploader) {
          this.formData.uploader = val.name
          this.formData.uploaderId = val.id
        }
        this.formData.driver = val.name
        this.formData.id = val.id
        // if (this.activeName === 'driver') {
        let {data} = this.tabList.find(v => {
          return v.name === 'driver'
        })
        let flag = data && data.length && data.some(v => {
          return v.driverId === val.id
        })
        if (!!data && data.length >= 5) {
          return
        }
        if (flag) {
          this.$message.warning('禁止添加重复人员')
          return
        }
        if ((!!data && data.length >= 5) || flag) {
          return
        }
        data.push({driverId: val.id, driver: val.name, point: val.networkName})
        this.driversList = data
        // }
        // this.$refs[this.activeName][0].addRow({driver: val.name, point: val.department})
      },
      deleteRow(index, row, ref) {
        this.$confirm('确定删除该数据吗', '提示').then(() => {
          if (row.driver) {
            this.$message.success('删除成功')
          }
          this.$refs[ref][0].delRow(index)
          if (this.$refs[ref][0].getData().length === 0) this.formData.uploader = ''
          index === 0 && (this.formData.uploader = this.$refs[ref][0].getData()[0].driver)
          this.tabList.some(v => {
            v.name === 'driver' && v.data.splice(index, 1) && (this.driversList = v.data)
          })
        })
      },
    }
  }
</script>

<style scoped lang="scss">
  .swing-card-tabs {
    /deep/ .el-tabs__nav #tab-2 {
      display: none;
    }
  }
</style>
