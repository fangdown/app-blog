export const carSwipingCard = function () {
  return [
    {
      propertyName: 'startDriver',
      columnName: 'start_driver',
      columnType: 'string',
      operation: 'contain',
      label: '司机姓名',
      type: 'text',
      show: true,
      placeholder: '请填写司机姓名'
    },
    {
      propertyName: 'plateNumber',
      columnName: 'plate_number',
      columnType: 'string',
      operation: 'contain',
      label: '车牌号码',
      type: 'text',
      show: true,
      placeholder: '请填写车牌号码'
    },
    {
      propertyName: 'startGpsKm',
      columnName: 'start_gps_km',
      columnType: 'string',
      operation: 'contain',
      label: '出车里程数',
      type: 'text',
      show: true,
      placeholder: '请填写出车里程数'
    },
    {
      propertyName: 'uploader',
      columnName: 'uploader',
      columnType: 'string',
      operation: 'contain',
      label: '上传人',
      type: 'text',
      show: true,
      placeholder: '请填写上传人'
    }
  ]
}

export const flightSearch = function () {
  return [
    {
      propertyName: 'flightDate',
      columnName: 'flight_date',
      columnType: 'date',
      operation: 'between',
      label: '航班日期',
      type: 'datePicker',
      dateType: 'datetimerange',
      show: true,
      placeholder: '请选择航班日期'
    },
    {
      propertyName: 'flightNumber',
      columnName: 'flight_number',
      columnType: 'string',
      operation: 'contain',
      label: '航班号',
      type: 'text',
      show: true,
      placeholder: '请填写航班号'
    },
    {
      propertyName: 'startingAirport',
      columnName: 'starting_airport',
      columnType: 'string',
      operation: 'contain',
      label: '始发机场',
      type: 'text',
      show: true,
      placeholder: '请填写始发机场'
    },
    {
      propertyName: 'destinationAirport',
      columnName: 'destination_airport',
      columnType: 'string',
      operation: 'contain',
      label: '目的机场',
      type: 'text',
      show: true,
      placeholder: '请填写目的机场'
    }
  ]
}

export const pointSearch = function () {
  return [
    {
      propertyName: 'pointName',
      columnName: 'p.point_name',
      columnType: 'string',
      operation: 'contain',
      label: '所属点部',
      show: true,
      type: 'text',
      placeholder: '请填写所属点部'
    }
  ]
}

export const distributionScan = function () {
  return [
    {
      propertyName: 'copyType',
      columnName: 'copy_type',
      columnType: 'enum',
      operation: 'contain',
      label: '类型',
      show: true,
      type: 'select',
      lookupCode: 'pda_receipt_copy_type',
      placeholder: '请选择类型'
    },
    {
      propertyName: 'waybillNumber',
      columnName: 'waybill_number',
      columnType: 'string',
      operation: 'contain',
      label: '运单号',
      show: true,
      type: 'text',
      placeholder: '请填写运单号'
    },
    {
      propertyName: 'driverName',
      columnName: 'driver_name',
      columnType: 'string',
      operation: 'contain',
      label: '司机',
      show: true,
      type: 'text',
      placeholder: '请填写司机'
    },
    {
      propertyName: 'receiptByName',
      columnName: 'receipt_by_name',
      columnType: 'string',
      operation: 'contain',
      label: '接收人',
      show: true,
      type: 'text',
      placeholder: '请填写接收人'
    }
  ]
}

export const nodeSearch = function () {
  return [
    {
      propertyName: 'nodeAttrib',
      columnName: 'n.node_attrib',
      operation: 'contain',
      columnType: 'string',
      label: '网点属性',
      type: 'select',
      show: true,
      placeholder: '请选择',
      lookupCode: 'base_data_node_attrib'
    },
    {
      propertyName: 'nodeName',
      columnName: 'n.node_name',
      operation: 'contain',
      columnType: 'string',
      label: '点部名称',
      type: 'text',
      show: true,
      placeholder: '请填写点部名称'
    },
    {
      propertyName: 'departmentName',
      columnName: 'n.department_name',
      operation: 'contain',
      columnType: 'string',
      label: '部门',
      type: 'text',
      show: true,
      placeholder: '请填写部门'
    },
    {
      propertyName: 'nodeType',
      columnName: 'n.node_type',
      columnType: 'enum',
      operation: 'contain',
      label: '场地类型',
      show: true,
      type: 'select',
      lookupCode: 'base_data_node_type',
      placeholder: '请选择场地类型'
    }
  ]
}

export const addressSearch = function () {
  return [
    {
      propertyName: 'depot',
      columnName: 'A.Depot',
      columnType: 'string',
      operation: 'contain',
      label: '所属点部',
      type: 'text',
      show: true,
      placeholder: '请填写所属点部'
    },
    {
      propertyName: 'areaCode',
      columnName: 'S.ZoneCode',
      columnType: 'string',
      operation: 'contain',
      label: '区号',
      type: 'text',
      show: true,
      placeholder: '请填写区号'
    },
    {
      propertyName: 'region',
      columnName: 'CTE_D.Col_012',
      columnType: 'enum',
      operation: 'contain',
      label: '所属区域',
      show: true,
      type: 'select',
      placeholder: '请填写所属区域',
      options: [
        {
          value: '华南',
          label: '华南'
        },
        {
          value: '华北',
          label: '华北'
        },
        {
          value: '华东',
          label: '华东'
        },
        {
          value: '京津冀',
          label: '京津冀'
        }
      ]
    }
  ]
}



export const tools = [
  // {
  //   icon: 'shangchuantubiao',
  //   title: '上传图片'
  // },
  // {
  //   icon: 'paisongliansaomiao',
  //   title: '派送联扫描',
  //   helper: 'distributionScan',
  //   url: 'pda.receiptCopy.search'
  // },
  {
    icon: 'gongju-GPS',
    title: 'GPS定位',
    helper: 'GPSLocation',
    url: 'vms.vehicledispatch.search',
    width: 3,
    view: 'GPSLocation'
  },
  // {
  //   icon: 'gongju-tongxunlu',
  //   title: '通讯录',
  //   view: 'AddressBook',
  //   url: 'hr.remoteEmployee.search',
  //   width: '800px',
  // },
  {
    icon: 'gongju-shuaqia',
    title: '车辆出行刷卡',
    helper: 'carSwipingCard',
    url: 'vms.vehicledispatch.search',
    view: 'carSwingCard'
  },
  {
    icon: 'gongju-hangban',
    title: '航班查询',
    helper: 'flightSearch',
    url: 'tms.followfly.thirdflightstatus.search'
  },
  // {
  //   icon: 'dianbuchaxun1',
  //   title: '点部查询',
  //   helper: 'pointSearch',
  //   view: 'Point',
  //   url: 'baseconfig.point.search'
  // },
  {
    icon: 'gongju-wangdian',
    title: '网点查询',
    helper: 'nodeSearch',
    url: 'baseconfig.node.search'
  },
  {
    icon: 'gongju-dizhi',
    title: '地址查询',
    helper: 'addressSearch',
    url: 'address.addressBackground.search'
  },
  {
    icon: 'gongju-rili',
    title: '考勤日历',
    helper: 'attendanceCalendar',
    view: 'Calendar',
    width: 5,
    url: ''
  },
  {
    icon: 'gongju-duanxin',
    title: '即时短信',
    view: 'Sms',
    width: '1032px',
  },
  {
    icon: 'gongju-rizhi',
    title: '升级日志',
    view: 'Log',
    width: '1000px',
  }
]
