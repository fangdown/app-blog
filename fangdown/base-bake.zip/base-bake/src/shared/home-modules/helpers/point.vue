<template>
  <div class="kye-dialog-body">
    <kye-row>
      <kye-form>
        <kye-form-item prop=""
                       label="所属点部">
          <kye-input></kye-input>
        </kye-form-item>
      </kye-form>
    </kye-row>

  </div>
</template>

<script>
  export default {
    name: 'point',
    data () {
      return {

      }
    }
  }
</script>
