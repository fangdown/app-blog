<template>
  <div>
    <div class="kye-dialog-body">
      <kye-row>
        <kye-col :span="12"
                 class="kye-calendar">
          <ele-calendar :data="datedef"
                        ref="calendar"
                        :prop="prop"
                        :disabledDate="disabledDate"
                        @pick="selectDate"></ele-calendar>
        </kye-col>
        <kye-col :span="12">
          <kye-row>
            <h3 class="kye-block-title">报价信息</h3>
          </kye-row>
          <kye-form>
            <!-- <kye-row>
              <kye-col :span="24">
                <kye-form-item label="考勤状态">
                  <kye-field></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row> -->
            <kye-row>
              <kye-col :span="13">
                <kye-form-item :label="`排班时间${isOver ? '1' : ''}`">
                  <kye-field>{{res.scheduleWorkTime | minute}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="11">
                <kye-form-item label="至"
                               label-width="16px">
                  <kye-field>{{res.scheduleAfterWorkTime | minute}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <kye-row>
              <kye-col :span="13">
                <kye-form-item :label="`打卡时间${isOver ? '1' : ''}`">
                  <kye-field>{{res.workTime | minute}}</kye-field>
                </kye-form-item>
              </kye-col>
              <kye-col :span="11">
                <kye-form-item label="至"
                               label-width="16px">
                  <kye-field>{{res.afterWorkTime | minute}}</kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row>
            <div v-if="isOver">
              <kye-row>
                <kye-col :span="13">
                  <kye-form-item label="排班时间2">
                    <kye-field>{{res.overScheduleWorkTime | minute}}</kye-field>
                  </kye-form-item>
                </kye-col>
                <kye-col :span="11">
                  <kye-form-item label="至"
                                 label-width="16px">
                    <kye-field>{{res.overScheduleAfterWorkTime | minute}}</kye-field>
                  </kye-form-item>
                </kye-col>
              </kye-row>
              <kye-row>
                <kye-col :span="13">
                  <kye-form-item label="打卡时间2">
                    <kye-field>{{res.overWorkTime | minute}}</kye-field>
                  </kye-form-item>
                </kye-col>
                <kye-col :span="11">
                  <kye-form-item label="至"
                                 label-width="16px">
                    <kye-field>{{res.overAfterWorkTime | minute}}</kye-field>
                  </kye-form-item>
                </kye-col>
              </kye-row>
            </div>
            <!-- <kye-row>
              <kye-col :span="24">
                <kye-form-item label="审核状态">
                  <kye-field></kye-field>
                </kye-form-item>
              </kye-col>
            </kye-row> -->
          </kye-form>
        </kye-col>
      </kye-row>
    </div>
    <div class="el-dialog__fotter"></div>
  </div>
</template>

<script>
  import moment from 'moment'
  import 'ele-calendar/dist/vue-calendar.css'
  import { time, month } from 'public/utils/filter'

  export default {
    name: 'calendar',
    components: {
      eleCalendar: () => import(/* webpackChunkName: "ele-calendar" */ 'ele-calendar')
    },
    data () {
      return {
        datedef: [],
        prop: 'date',
        res: {}
      }
    },
    computed: {
      isOver () {
        return this.res.overScheduleWorkTime && this.res.overScheduleAfterWorkTime
      }
    },
    mounted () {
      setTimeout(_ => {
        this.$refs.calendar.$el.className = 'el-picker-panel-calendar el-date-picker-calendar'
      }, 300)
    },
    methods: {
      disabledDate (date) {
        return +date > +new Date() || +date < +moment(new Date(month(new Date()) + '-01 00:00:00')).subtract(1, 'month')
      },
      async selectDate (date) {
        let res = await this.$http('hr.attendanceManage.getByCurUserAndTime', { workTime: time(date) })
        this.res = res[0]
      }
    }
  }
</script>

<style lang="scss">
  .kye-calendar {
    .el-date-table-calendar {
      font-size: 16px;
      font-weight: 500;
    }
    .el-date-table-calendar td.current:not(.disabled) {
      background-color: #9571e9;
    }
    .el-date-table-calendar td {
      width: 50px;
      height: 50px;
      line-height: 50px;
      border-top: 1px #dcdce4 solid;
      border-left: 1px #dcdce4 solid;
    }
    .el-date-table-calendar tr:nth-child(2) td {
      border-top: 0;
    }
    .el-date-table-calendar tr td:first-child {
      border-left: 0;
    }
    .el-date-table-calendar td.available {
      color: #4a4a4a;
    }
    .el-date-table-calendar td.available:hover {
      color: #4a4a4a;
      background-color: #f5f4f6;
    }
  }
</style>
