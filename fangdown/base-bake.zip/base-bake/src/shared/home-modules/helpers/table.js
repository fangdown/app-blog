
export const carSwipingCard = function () {
  return [
    {
      key: 'plateNumber',
      label: '车牌号码'
    },
    {
      key: 'startDriver',
      label: '出车司机'
    },
    {
      key: 'uploaderDepartment',
      label: '司机部门'
    },
    {
      key: 'startTime',
      label: '出车时间',
      filter: 'time'
    }
  ]
}

export const flightSearch = function () {
  return [
    {
      key: 'flightNumber',
      label: '航班号'
    },
    {
      key: 'flightDate',
      label: '航班日期',
      filter: 'date'
    },
    {
      key: 'startingAirport',
      label: '始发机场'
    },
    {
      key: 'destinationAirport',
      label: '目的机场'
    },
    {
      key: 'flightStatus',
      label: '航班状态'
    },
    {
      key: 'takeoffTime',
      label: '起飞时间',
      filter: 'time'
    },
    {
      key: 'landingTime',
      label: '落地时间',
      filter: 'time'
    }
  ]
}

export const pointSearch = function () {
  return [
    {
      key: 'landingTime',
      label: '落地时间',
      filter: 'time'
    }
  ]
}

export const distributionScan = function () {
  return [
    {
      key: 'copyType',
      label: '类型',
      filter: { type: 'lookup', args: ['pda_receipt_copy_type'] }
    },
    {
      key: 'waybillNumber',
      label: '运单号'
    },
    {
      key: 'receiptByName',
      label: '接收人'
    },
    {
      key: 'receiptPointName',
      label: '接收点部'
    },
    {
      key: 'driverName',
      label: '司机'
    },
    {
      key: 'driverPointName',
      label: '司机点部'
    },
    {
      key: 'scanTime',
      label: '扫描时间',
      filter: 'time'
    }
  ]
}

export const nodeSearch = function () {
  return [
    {
      key: 'nodeCode',
      label: '网点编码'
    },
    {
      key: 'nodeAttrib',
      label: '网点属性',
      filter: { type: 'lookup', args: ['base_data_node_attrib'] }
    },
    {
      key: 'nodeName',
      label: '点部名称'
    },
    {
      key: 'nodeType',
      label: '场地类型',
      filter: { type: 'lookup', args: ['base_data_node_type'] }
    },
    {
      key: 'cityCode',
      label: '城市区号'
    }
  ]
}

export const addressSearch = function () {
  return [
    {
      key: 'depot',
      label: '所属点部'
    },
    {
      key: 'areaCode',
      label: '区号'
    },
    {
      key: 'region',
      label: '所属区域'
    },
    {
      key: 'province',
      label: '省'
    },
    {
      key: 'city',
      label: '市'
    },
    {
      key: 'county',
      label: '区/县'
    },
    {
      key: 'street',
      label: '镇/街道'
    }
  ]
}
