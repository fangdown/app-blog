export const formFields = [
  {
    propertyName: '$receiver',
    type: 'menu',
    show: true,
    options: [
      {
        propertyName: 'vo.id',
        columnType: 'user',
        label: '姓名',
        show: true,
        width: 82,
        formatterOption: v => `${v.chineseName}-${v.departmentName}-${v.position}`,
        type: 'remoteSelect'
      },
      {
        propertyName: 'vo.departmentId',
        columnType: 'department',
        label: '部门',
        show: true,
        width: 95,
        type: 'remoteSelect'
      },
      {
        propertyName: 'vo.networkId',
        columnType: 'department',
        label: '点部',
        show: true,
        width: 95,
        type: 'remoteSelect'
      },
      {
        propertyName: 'vo.companyMobile',
        columnType: 'phone',
        label: '公司机号',
        width: 100,
        show: true,
        type: 'number'
      },
      {
        propertyName: 'vo.privateMobile',
        columnType: 'phone',
        label: '私人机号',
        width: 100,
        show: true,
        type: 'number'
      }
    ]
  }
]

export const columns = [
  {
    key: 'name',
    label: '姓名',
    width: '80px',
    show: true
  },
  {
    key: 'companyMobile',
    label: '公司手机',
    width: '100px',
    show: true
  },
  {
    key: 'privateMobile',
    label: '私人手机',
    width: '100px',
    show: true
  },
  {
    key: 'department',
    label: '所属部门',
    width: '80px',
    show: true
  },
  {
    key: 'networkName',
    label: '所属点部',
    width: '80px',
    show: true
  },
  {
    key: 'phone',
    label: '座机号',
    width: '80px',
    show: true
  },
  {
    key: 'shortPhone',
    label: '短号',
    width: '80px',
    show: true
  },
  {
    key: 'shortPhoneArea',
    label: '短号区域',
    width: '80px',
    show: true
  },
  {
    key: 'remark',
    label: '上下班时间',
    width: '120px',
    show: true
  },
  {
    key: 'qq',
    label: 'QQ',
    width: '60px',
    show: true
  }
]
