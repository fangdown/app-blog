export const formFields = [
  {
    propertyName: 'e.name',
    columnName: 'e.name',
    operation: 'contain',
    columnType: 'string',
    label: '姓名',
    type: 'text',
    show: true,
    width: 80
  },
  {
    propertyName: 'e.employeeNumber',
    columnName: 'e.employee_number',
    operation: 'contain',
    columnType: 'string',
    label: '工号',
    type: 'text',
    show: true,
    width: 80
  },
  {
    propertyName: 'e.duty',
    columnName: 'e.duty',
    operation: 'contain',
    columnType: 'string',
    label: '职务',
    type: 'text',
    show: true,
    width: 100
  },
  {
    propertyName: 'e.employeeArea',
    columnName: 'e.employee_area',
    operation: 'contain',
    columnType: 'string',
    label: '区域',
    type: 'select',
    show: true,
    lookupCode: 'common_region_bak',
    unNull: true,
    width: 80
  },
  {
    propertyName: 'e.department',
    columnName: 'e.department',
    operation: 'contain',
    columnType: 'string',
    label: '部门/点部',
    type: 'text',
    show: true,
    width: 100
  }
]

export const columns = [
  {
    key: 'name',
    label: '姓名',
    width: 100,
    show: true
  },
  {
    key: 'department',
    label: '部门',
    width: 100,
    show: true
  },
  {
    key: 'duty',
    label: '职务',
    width: 100,
    show: true
  },
  {
    key: 'officeStatus',
    label: '当前状态',
    filter: { type: 'lookup', args: ['hr_employee_office_status'] },
    width: 100,
    show: true
  },
  {
    key: 'privateMobile',
    label: '电话',
    width: 100,
    show: true
  },
  {
    key: 'phone',
    label: '座机',
    width: 100,
    show: true
  },
  {
    key: 'qq',
    label: 'QQ',
    width: 90,
    show: true
  }
]
