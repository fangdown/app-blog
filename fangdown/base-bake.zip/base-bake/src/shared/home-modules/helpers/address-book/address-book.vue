<template>
  <div>
    <query-table ref="queryTable" :form-fields="formFields" :option="option"  :tools="tools" :tables="tables">
    </query-table>
  </div>
</template>

<script>
  import mixins from 'public/mixins'
  import { formFields, columns } from './conf'
  export default {
    name: 'addressBook',
    mixins: [mixins],
    data () {
      return {
        option: {
          dialog: true,
          pageFooter: true,
          maxHeight: Math.floor(window.innerHeight * 0.6 - 24 - 34 - 28)
        },
        formFields: formFields,
        tools: [],
        tables: [
          {
            url: { method: 'hr.remoteEmployee.search', data: { elasticsearchFlag: 'N' } },
            option: {
              load: false,
              label: '通讯录',
              type: 'index',
              moduleCode: 'hr_employee'
            },
            columns: columns
          }
        ]
      }
    }
  }
</script>
