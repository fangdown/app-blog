<template>
  <div>
    <div class="kye-dialog-body">
      <query-form :fields="formFields"
                  ref="helperForm"
                  @submit="formSubmit"
                  @reset="formReset">
      </query-form>
      <kye-table :data="list">
        <kye-table-column type="index"
                          width="50"
                          :index="indexMethod">
        </kye-table-column>
        <kye-table-column v-for="col of tableColumns"
                          :key="col.key"
                          :label="col.label"
                          :width="col.width"
                          show-overflow-tooltip
                          :formatter="(row, column, cellValue, index) => formatter(row, column, cellValue, index, col.filter)"
                          :prop="col.key">
        </kye-table-column>
      </kye-table>
    </div>
    <div class="el-dialog__footer">
      <kye-pagination :layout="$pagination.layout"
                      :current-page.sync="page"
                      :page-size="pageSize"
                      :total="total"
                      :page-sizes="$pagination.pageSizes"
                      @current-change="pageChange"
                      @size-change="sizeChange">
      </kye-pagination>
    </div>
  </div>
</template>

<script>
  import * as formFields from './form'
  import * as tableColumns from './table'

  export default {
    name: 'helper',
    props: {
      helper: String,
      url: String
    },
    data () {
      return {
        formFields: formFields[this.helper](),
        tableColumns: tableColumns[this.helper](),
        list: [],
        page: 1,
        pageSize: 200,
        total: 0,
        params: null
      }
    },
    methods: {
      async getList (page, pageSize) {
        this.params.page = page
        this.params.pageSize = pageSize
        let res = await this.$http(this.url, this.params)
        if (res) {
          this.list = res.rows
          this.page = res.page
          this.total = res.rowTotal
        }
      },
      indexMethod (index) {
        return index + 1 + (this.page - 1) * this.pageSize
      },
      formSubmit (model, params) {
        params.page = 1
        params.pageSize = this.pageSize
        if (this.helper === 'addressSearch') {
          this.params = {
            params,
            jsonrpc: '2.0',
            id: String(Math.random()).slice(2, 11),
            method: 'addressBackground.search'
          }
        } else {
          this.params = params
        }
        this.getList(1, this.pageSize)
      },
      formReset () {
        this.params = null
      },
      pageChange (page) {
        this.page = page
        this.getList(this.page, this.pageSize)
      },
      sizeChange (pageSize) {
        this.pageSize = pageSize
        this.getList(1, pageSize)
      },
      formatter (row, column, cellValue, index, filter) {
        if (filter && typeof filter === 'string') {
          return this.$filter[filter](cellValue)
        } else if (filter && typeof filter === 'object' && filter.type === 'lookup') {
          return this.$filter[filter.type](cellValue, filter.args[0])
        }
        return cellValue
      }
    }
  }
</script>
