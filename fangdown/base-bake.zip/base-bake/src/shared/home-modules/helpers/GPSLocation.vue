<template>
  <div>
    <div class="location_wrap">
      <div class="customer_info">
        <kye-form label-width="60px"
                  ref="form">
          <kye-card shadow="never">
            <div slot="header">
              <span>车辆定位信息</span>
            </div>
            <div>
              <kye-row>
                <kye-col :span="8">
                  <kye-form-item label="车牌号">
                    <kye-input v-model="form.carNo"></kye-input>
                  </kye-form-item>
                </kye-col>
                <kye-col :span="8">
                  <kye-form-item label="获取经度">
                    <kye-input disabled
                               v-model="form.longitude"></kye-input>
                  </kye-form-item>
                </kye-col>
                <kye-col :span="8">
                  <kye-form-item label="获取纬度">
                    <kye-input disabled
                               v-model="form.latitude"></kye-input>
                  </kye-form-item>
                </kye-col>
              </kye-row>
              <kye-row>
                <kye-col :span="8">
                  <kye-form-item label="手机号">
                    <kye-input disabled
                               v-model="form.mobileNumber"></kye-input>
                  </kye-form-item>
                </kye-col>
                <kye-col :span="16">
                  <kye-form-item label="返回地址">
                    <kye-input disabled
                               v-model="form.carAddress"></kye-input>
                  </kye-form-item>
                </kye-col>
              </kye-row>
            </div>
          </kye-card>
          <kye-card shadow="never"
                    style="margin-top: 10px;">
            <div class="tab-wrap">
              <kye-tabs v-model="activeName"
                        @tab-click="tabClick">
                <kye-tab-pane label="客户信息"
                              name="customer">
                  <div class="tab-content">
                    <kye-row>
                      <kye-col :span="8">
                        <kye-form-item label="客户名称">
                          <kye-autocomplete ref="customerSearchTips"
                                            v-model="customerValue"
                                            :fetch-suggestions="searchData"
                                            @select="customerHandleSelect"
                                            @blur="closeLoading"
                                            :trigger-on-focus="false"
                                            :debounce="500"
                                            :value-key="setting.valueKey"
                                            :search-key="setting.searchKey"
                                            :url="setting.url"></kye-autocomplete>
                        </kye-form-item>
                      </kye-col>
                      <kye-col :span="8">
                        <kye-form-item label="客户经度">
                          <kye-input disabled
                                     v-model="customerData.longitude"></kye-input>
                        </kye-form-item>
                      </kye-col>
                      <kye-col :span="8">
                        <kye-form-item label="客户纬度">
                          <kye-input disabled
                                     v-model="customerData.latitude"></kye-input>
                        </kye-form-item>
                      </kye-col>
                    </kye-row>
                    <kye-row>
                      <kye-col :span="24">
                        <el-form-item label="客户地址">
                          <el-input disabled
                                    v-model="customerData.address"></el-input>
                        </el-form-item>
                      </kye-col>
                    </kye-row>
                  </div>
                </kye-tab-pane>
                <kye-tab-pane label="点部信息"
                              name="network">
                  <div class="tab-content">
                    <kye-row>
                      <kye-col :span="8">
                        <kye-form-item label="点部名称">
                          <kye-autocomplete ref="networkSearchTips"
                                            v-model="networkValue"
                                            :fetch-suggestions="searchData"
                                            @select="networkHandleSelect"
                                            @blur="closeLoading"
                                            :trigger-on-focus="false"
                                            :debounce="500"
                                            :value-key="setting.valueKey"
                                            :search-key="setting.searchKey"
                                            :url="setting.url"></kye-autocomplete>
                        </kye-form-item>
                      </kye-col>
                      <kye-col :span="8">
                        <kye-form-item label="点部经度">
                          <kye-input disabled
                                     v-model="networkData.longitude"></kye-input>
                        </kye-form-item>
                      </kye-col>
                      <kye-col :span="8">
                        <kye-form-item label="点部纬度">
                          <kye-input disabled
                                     v-model="networkData.latitude"></kye-input>
                        </kye-form-item>
                      </kye-col>
                    </kye-row>
                    <kye-row>
                      <kye-col :span="24">
                        <el-form-item label="点部地址">
                          <el-input disabled
                                    v-model="networkData.address"></el-input>
                        </el-form-item>
                      </kye-col>
                    </kye-row>
                  </div>
                </kye-tab-pane>
              </kye-tabs>
            </div>
          </kye-card>
        </kye-form>
      </div>
    </div>
    <div class="el-dialog__footer">
      <kye-button type="primary"
                  @click="getCarLocation"
                  :loading="carLoading">
        <i class="iconfont icon-import"></i>获取经纬度
      </kye-button>
      <kye-button type="primary"
                  auth="baseconfig.node.updateNodeLLtude"
                  v-show="activeName === 'network'"
                  @click="replaceLocation"
                  :loading="replaceLoading">
        <i class="iconfont icon-sort"></i>替换点部经纬度
      </kye-button>
      <kye-button type="primary"
                  auth="crm.customer.sync.saveOrUpdate"
                  v-show="activeName === 'customer'"
                  @click="replaceLocation"
                  :loading="replaceLoading">
        <i class="iconfont icon-sort"></i>替换客户经纬度
      </kye-button>
      <kye-button @click="cancel">取 消</kye-button>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'GPSLocation',
    props: {
      placeholder: {
        type: String,
        default: '请输入内容'
      }
    },
    data () {
      return {
        activeName: 'customer',
        customerValue: '',
        networkValue: '',
        replaceLoading: false,
        carLoading: false,
        customerData: {
          // 客户信息
          id: '',
          address: '',
          longitude: '',
          latitude: ''
        },
        networkData: {
          // 网点信息
          id: '',
          address: '',
          longitude: '',
          latitude: ''
        },
        form: {
          // 车辆信息
          carAddress: '',
          mobileNumber: '',
          latitude: '',
          longitude: '',
          carNo: '',
          carId: ''
        }
      }
    },
    computed: {
      setting () {
        let mapping = {
          customer: {
            url: 'crm.customer.sync.get',
            valueKey: 'customerShortName',
            searchKey: 'customerShortName'
          },
          network: {
            url: 'baseconfig.node.list',
            valueKey: 'nodeName',
            searchKey: 'nodeName'
          },
        }
        let key = this.activeName || 'customer'
        mapping[key].key = key
        return mapping[key]
      }
    },
    methods: {
      tabClick () {
      },
      cancel () {
        this.$emit('close')
      },
      replaceLocation () {
        if (!this.form.carId) {
          this.$message.warning('请输入车辆定位信息!')
          return
        }
        this[this.activeName + 'Replace']()
      },
      customerReplace () {
        if (!this.customerData.id) {
          this.$message.warning('请输入客户信息!')
          return
        }
        let data = {
          id: this.customerData.id,
          customerLat: this.form.latitude,
          customerLon: this.form.longitude
        }
        this.replaceLoading = true
        this.$http('crm.customer.sync.saveOrUpdate', data)
          .then(res => {
            this.replaceLoading = false
            this.customerData.latitude = data.customerLat
            this.customerData.longitude = data.customerLon
            this.$message.success('替换经纬度成功!')
          }).catch(this.replaceLoading = false)
      },
      networkReplace () {
        if (!this.networkData.id) {
          this.$message.warning('请输入点部信息!')
          return
        }
        let data = {
          id: this.networkData.id,
          latitude: this.form.latitude,
          longitude: this.form.longitude
        }
        this.replaceLoading = true
        this.$http('baseconfig.node.updateNodeLLtude', data)
          .then(res => {
            this.replaceLoading = false
            this.networkData.latitude = this.form.latitude
            this.networkData.longitude = this.form.longitude
            this.$message.success('替换经纬度成功!')
          }).catch(this.replaceLoading = false)
      },
      customerHandleSelect (node) {
        if (node) {
          this.customerData.address = node.address
          this.customerData.latitude = node.customerLat
          this.customerData.longitude = node.customerLon
          this.customerData.id = node.id
        } else {
          this.resetInfo()
        }
      },
      networkHandleSelect (node) {
        if (node) {
          this.networkData.address = ''
          if (node.provinceId) {
            let address = [
              node.province || '',
              node.city || '',
              node.county || '',
              node.town || '',
              node.road || '',
              node.addressDetail || ''
            ]
            this.networkData.address = address.join('')
          }
          this.networkData.latitude = node.latitude
          this.networkData.longitude = node.longitude
          this.networkData.id = node.id
          this.networkValue = node.nodeName.split('，')[0]
        } else {
          this.resetInfo('network')
        }
      },
      resetInfo (key = 'customer') {
        this[key + 'Data'].address = ''
        this[key + 'Data'].latitude = ''
        this[key + 'Data'].longitude = ''
        this[key + 'Data'].id = ''
      },
      resetCarInfo () {
        this.form.carAddress = ''
        this.form.latitude = ''
        this.form.longitude = ''
        this.form.mobileNumber = ''
        this.form.carId = ''
      },
      getCarLocation () {
        this.resetCarInfo()
        if (this.form.carNo) {
          this.carLoading = true
          this.$http('vms.external.vehicle.getLastplaceByPlateNumbers', {
            carNumbers: this.form.carNo,
          })
            .then(res => {
              this.carLoading = false
              let carData = res && res[0]
              if (carData) {
                this.form.carAddress = carData.address
                this.form.latitude = carData.latitude
                this.form.longitude = carData.longitude
                this.form.mobileNumber = carData.deviceMobile
                this.form.carId = carData.id
              } else {
                this.$message.warning('找不到该车牌的车辆定位信息！')
              }
            }).catch(this.carLoading = false)
        } else {
          this.$message.warning('请输入车牌号码!')
        }
      },
      closeLoading () {
        this.$refs[this.activeName + 'SearchTips'].loading = false
      },
      searchData (val, cb) {
        if (val && val.length >= 2) {
          let params = {}
          let { searchKey, url, key } = this.setting
          params[searchKey] = val
          this.$http(url, params)
            .then(res => {
              let data
              this.closeLoading()
              if (res && res[searchKey]) {
                data = [res]
              } else if (Array.isArray(res) && res.length) {
                data = res
              } else {
                return this[key + 'HandleSelect'](null)
              }
              // network: {
              //   url: 'baseconfig.node.list',
              //     valueKey: 'nodeName',
              //     searchKey: 'nodeName'
              // },
              // 如果为点部，特殊处理数据格式
              if (this.activeName === 'network') {
                data.forEach(item => {
                  item.nodeName = `${item.nodeName}，${item.departmentName}`
                })
              }
              cb(data)
            }).catch(this.closeLoading)
        } else {
          this.closeLoading()
        }
      }
    }
  }
</script>
<style lang="scss" scope>
  .location_wrap {
    margin: 10px;
  }
  .tab-wrap {
    margin-top: -10px;
    .tab-content {
      margin-top: 20px;
    }
  }
</style>
