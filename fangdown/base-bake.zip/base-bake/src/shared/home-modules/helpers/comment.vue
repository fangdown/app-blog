<template>
  <div>
    <div class="kye-dialog-body comment_body" ref="dailog">
      <div>
        <el-breadcrumb separator="/" class="comment_font" v-model="routerPath">
          <el-breadcrumb-item v-for="item in routerPath" :key="item">{{item}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="comment_contain">
        <h3 class="comment_font" style="margin-bottom: 12px;">添加评价</h3>
        <div>
          <kye-row>
            <kye-col :span="7">
              <kye-row style="margin-bottom: 12px;">
                <kye-col :span="9" class="rate_font">功能完整度</kye-col>
                <kye-col :span="15">
                  <span>
                    <el-rate
                      v-model="form.scoreFuntion"
                      class="rate">
                    </el-rate>
                  </span>
                </kye-col>
              </kye-row>
              <kye-row style="margin-bottom: 12px;">
                <kye-col :span="9" class="rate_font">整体美观度</kye-col>
                <kye-col :span="15">
                  <span>
                    <el-rate
                      v-model="form.scoreUi"
                      class="rate">
                    </el-rate>
                  </span>
                </kye-col>
              </kye-row>
              <kye-row style="margin-bottom: 12px;">
                <kye-col :span="9" class="rate_font">易用程度</kye-col>
                <kye-col :span="15">
                  <span>
                    <el-rate
                      v-model="form.scoreUsing"
                      class="rate">
                    </el-rate>
                  </span>
                </kye-col>
              </kye-row>
              <kye-row style="margin-bottom: 12px;">
                <kye-col :span="9" class="rate_font">响应速度</kye-col>
                <kye-col :span="15">
                  <span>
                    <el-rate
                      v-model="form.scoreResp"
                      class="rate">
                    </el-rate>
                  </span>
                </kye-col>
              </kye-row>
            </kye-col>
            <kye-col :span="17" >
              <kye-row>
                <kye-input
                  type="textarea"
                  v-model="form.comment"
                  rows="6"
                  maxlength="1000"
                  placeholder="请输入详细描述，以便更好地帮助我们提升产品使用体验">
                </kye-input>
              </kye-row>
              <kye-row style="margin-top: 10px;">
                <kye-button type="primary" style="float: right;" @click="submit" :loading="loading">提交</kye-button>
              </kye-row>
            </kye-col>
          </kye-row>
        </div>
      </div>
      <div class="comment_history_contain">
        <h4 class="comment_font">历史评价（{{listTotal.totalNum > 0 ? listTotal.totalNum + '人参与了评价' : 0}}）</h4>
        <ul class="comment_total" v-if="listTotal.scoreFuntion > 0 || listTotal.scoreUi > 0 || listTotal.scoreUsing > 0 || listTotal.scoreResp > 0">
          <li>
            <label>功能完整度：</label>
            <strong>{{listTotal.scoreFuntion}}</strong>
          </li>
          <li>
            <label>整体美观度：</label>
            <strong>{{listTotal.scoreUi}}</strong>
          </li>
          <li>
            <label>易用程度：</label>
            <strong>{{listTotal.scoreUsing}}</strong>
          </li>
          <li>
            <label>响应速度：</label>
            <strong>{{listTotal.scoreResp}}</strong>
          </li>
        </ul>
        <ul class="comment_list_contain" v-if="list.length > 0">
          <li v-for="item in list" :key="item.id">
            <div class="comment_person">
              <div class="person_avater">
                <img :src="item.headImg" v-if="item.headImg"/>
                <i class="iconfont icon-user" v-if="!item.headImg"></i>
              </div>
              <div class="person_info">
                <h5>{{item.username}} <span>{{item.department}}</span></h5>
                <p>{{item.createDateFormat}}</p>
              </div>
            </div>
            <div class="comment_font comment_artitle">{{item.comment}}</div>
          </li>
        </ul>
        <div class="no_comment" v-if="list.length === 0">
          <div>
            <p>
              <img src="@/shared/assets/images/no_comment.png" />
             </p>
            <p>暂无评价!</p>
          </div>
        </div>
      </div>
    </div>
    <div class="comment_side_bar">
      <!-- <div class="comment_bar_tools">
         <i class="iconfont icon-help" style="font-size: 28px;"></i>
      </div> -->
      <div class="comment_bar_tools" @click="visible = true">
         <i class="iconfont icon-customerservice" style="font-size: 28px;"></i>
      </div>
    </div>
    <div class="el-dialog__footer" v-if="list.length !== 0">
      <kye-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="listQuery.page"
        :page-size="listQuery.pageSize"
        :page-sizes="$pagination.pageSizes"
        :layout="$pagination.layout"
        :total="total"
        small>
      </kye-pagination>
    </div>
    <kye-dialog title="联系客服" :visible.sync="visible">
      <div class="customer_dailog">
        <p>客服电话 <span>96324</span></p>
        <p>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          跨声
          <span>
            <img src="@/shared/assets/images/kuasheng_qrcode.png" />
           </span>
        </p>
      </div>
    </kye-dialog>
    <div class="back_to_top" v-if="scroll" @click="handleTop">
      <i class="iconfont  icon-shoudongzhihang" style="font-size: 14px;"></i>
    </div>
  </div>
</template>

<script>
  import moment from 'moment'
  export default {
    name: 'comment',
    props: {
    },
    data () {
      let menus = this.$store.state.menus[this.$route.path]
      if (!menus) {
        menus = this.$store.state.menus[this.$route.meta.tag]
      }
      const user = this.$store.state.user
      let routerPath = []
      if (menus.$title === '首页') {
        routerPath = [menus.$title]
      } else {
        routerPath = menus.$title.split('>')
        routerPath.unshift(menus.$ptitle)
      }
      return {
        total: null,
        visible: false,
        loading: false,
        scroll: false,
        routerPath: routerPath,
        canSubmit: false,
        form: {
          userId: user.id,
          username: user.name,
          headImg: user.photoUrl,
          department: user.duty + '/' + user.department + '/' + user.higherDepartment,
          menuId: menus.id,
          scoreFuntion: 3,
          scoreUi: 3,
          scoreUsing: 3,
          scoreResp: 3,
          comment: null,
          moduleName: routerPath.join('/')
        },
        list: [],
        listTotal: {
          scoreFuntion: 0,
          scoreUi: 0,
          scoreUsing: 0,
          scoreResp: 0,
          totalNum: 0
        },
        listQuery: {
          page: 1,
          pageSize: this.$pagination.pageSize,
          menuId: menus.id,
        }
      }
    },
    created () {
      this.init()
    },
    mounted () {
      this.$refs.dailog.addEventListener('scroll', this.handleShowScroll)
    },
    beforeDestroy () {
      this.$refs.dailog.removeEventListener('scroll', this.handleShowScroll)
    },
    methods: {
      handleTop () {
        this.$refs.dailog.scrollTo(0, 0)
      },
      handleShowScroll () {
        let dailog = this.$refs.dailog
        if (dailog.scrollTop >= 200 && !this.scroll) {
          this.scroll = true
        }
        if (dailog.scrollTop < 200 && this.scroll) {
          this.scroll = false
        }
      },
      init () {
        this.getList()
        this.getListTotal()
      },
      async submit () {
        let {
          scoreFuntion,
          scoreUi,
          scoreUsing,
          scoreResp
        } = this.form
        this.loading = true
        let data = await this.$http('fdb.feedback.createComment', {
          ...this.form,
          scoreFuntion,
          scoreUi,
          scoreUsing,
          scoreResp
        }, false)
        this.loading = false
        if (data) {
          this.resetComment()
          this.init()
          this.$message.success('评价成功！')
        }
      },
      resetComment () {
        this.form.scoreFuntion = 3
        this.form.scoreUi = 3
        this.form.scoreUsing = 3
        this.form.scoreResp = 3
        this.form.comment = ''
      },
      async getListTotal () {
        let data = await this.$http('fdb.feedback.getCommentsTotalMsg', this.listQuery, false)
        this.listTotal = {
          ...data
        }
      },
      async getList () {
        let data = await this.$http('fdb.feedback.getComments', this.listQuery, false)
        this.list = data.rows.map(d => {
          d.createDateFormat = moment(d.createTime).format('YYYY-MM-DD')
          return d
        }, false)
        this.total = data.rowTotal
        this.handleTop()
      },
      handleSizeChange (val) {
        this.listQuery.pageSize = val
        this.getList()
      },
      handleCurrentChange (val) {
        this.listQuery.page = val
        this.getList()
      }
    }
  }
</script>
<style lang="scss" scope>
  .comment_side_bar {
    position: absolute;
    margin-left: 720px;
    top: 0;
  }
  .comment_bar_tools {
    width: 55px;
    height: 55px;
    background: #fff;
    border-radius: 100%;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #7352bf;
  }
  .comment_contain {
    margin-top: 12px;
  }
  .el-rate__icon {
    font-size: 12px;
  }
  .rate_font {
    font-size: 12px;
  }
  .comment_history_contain {

  }
  .comment_list_contain {
    display: block;
    margin-bottom: 20px;
    & > li {
      border-bottom: 1px solid #DCDAE2;
      display: block;
      margin-top: 10px;
      padding-bottom: 10px;
    }
  }
  .comment_font {
    font-size: 12px;
  }
  .comment_total {
    display: flex;
    margin-top: 10px;
    background: #F8F8FA;
    padding: 5px 10px;
    font-size: 12px;
    & > li {
      display: block;
      min-width: 40px;
      margin-right: 24px;
      font-size: 12px;
      & > label {
        color: #666;
        margin-right: 5px;
      }
      & > strong {
        color: #ff9300;
        margin-right: 1px;
      }
    }
  }
  .comment_artitle {
    margin-top: 5px;
  }
  .comment_person {
    display: flex;
    width: 100%;
    .person_avater {
      width: 30px;
      height: 30px;
      border-radius: 100%;
      overflow: hidden;
      img {
        width: 100%;
        height: 100%;
      }
      i {
        font-size: 30px;
        line-height: 30px;
      }
    }
  }
  .person_info {
    margin-left: 8px;
    & > p {
      color: #999;
      font-size: 10px;
      margin-top: 3px;
    }
    & > h5 {
      font-size: 12px;
      span {
        margin-left: 5px;
        font-size: 10px;
        color: #999;
        font-weight: normal;
      }
    }
  }
  .no_comment {
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    div {
      p {
        font-size: 12px;
        color: #666;
        text-align: center;
        margin-bottom: 10px;
      }
    }
  }
  .customer_dailog {
    p {
      font-size: 12px;

      margin-bottom: 12px;
      span {
        display: inline-block;
        vertical-align: top;
        margin-left: 12px;
      }
    }
  }
  .back_to_top {
    width: 30px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    position: absolute;
    bottom: 60px;
    right: 16px;
    background: #fff;
    color: #7352bf;
    border-radius: 100%;
    box-shadow: 0px 2px 6px 0px rgba(0,0,0,.08);
    cursor: pointer;
  }
</style>
