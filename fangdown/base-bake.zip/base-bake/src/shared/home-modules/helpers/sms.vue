<template>
  <div>
    <query-table ref="queryTable" :form-fields="formFields" :option="option" :tools="tools" :tables="tables">
      <kye-form slot="append" ref="msgForm" :model="msgForm" style="width:600px;">
        <kye-row>
          <kye-col :span="8">
            <kye-form-item label="外部号码" prop="remoteEmployee.mobile" :rules="$rule.reg('phone', '请输入正确的手机号', false)">
              <kye-input v-model="msgForm.remoteEmployee.mobile" :disabled="selectedRow.length >= 1" placeholder="请输入手机号码" :clearable="true"  maxlength="11" @clear="clearData" @change="changeData"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="发送渠道" prop="vo.gatewayCode" :rules="[
                                {
                                  required: true,
                                  message: '请选择发送渠道',
                                  trigger: 'change'
                                }]">
              <kye-select v-model="msgForm.vo.gatewayCode" :disabled="selectedRow.length < 1 && msgForm.remoteEmployee.mobile === ''">
                <kye-option v-for="(listItem, listIndex) in gatewayCodeList" :key="listIndex" :label="listItem.gatewayName" :value="listItem.gatewayCode">
                </kye-option>
              </kye-select>
            </kye-form-item>
          </kye-col>
          <kye-col :span="8">
            <kye-form-item label="预约时间">
              <kye-date-picker v-model="msgForm.notify.fixTime" type="datetime" placeholder="选择日期时间" :disabled="selectedRow.length < 1 && msgForm.remoteEmployee.mobile === ''" :picker-options="pickOneMonth" @blur="getLocalTime" @change="getLocalTime">
              </kye-date-picker>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="短信内容" prop="notify.content" :rules="[
                                {
                                  required: true,
                                  message: '您没有填写发送信息内容，不可以发送空信息，请检查',
                                  trigger: 'blur'
                                },
                                {
                                  max: 900,
                                  message: '短信内容不能超过900字',
                                  // 当前短信内容过长，检查是否可精简！标准：55字/条，超长拆分
                                  trigger: 'blur'
                                }]">
              <kye-input type="textarea" :rows="4" :disabled="selectedRow.length < 1 && msgForm.remoteEmployee.mobile === ''" v-model="msgForm.notify.content" @blur="errorMassage"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item style="display:inline-block;" label=" ">
              <kye-button type="primary" @click="sendMsg('msgForm')" :disabled="selectedRow.length < 1 && msgForm.remoteEmployee.mobile === ''">发送短信</kye-button>
              <!-- <kye-checkbox v-model="msgForm.selectAllFlag" class="ml10">全选</kye-checkbox> -->
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
    </query-table>
    <kye-data-import code="sms_notify_import" url="notify.notifyAddressBook.receiversImport" :isAsync="extendConfig.isAsync" :visible.sync="extendConfig.show" :model="extendConfig.backData" @success="val => importSearch(val)">
    </kye-data-import>
  </div>
</template>

<script>
  import moment from 'moment'
  import { formFields, columns } from './sms-conf'
  import KyeDataImport from '@/shared/components/kye-data-import'
  export default {
    name: 'addDialog',
    components: {
      KyeDataImport
    },
    prop: {
      helper: String,
      url: String
    },
    data () {
      return {
        option: {
          dialog: true,
          pageFooter: true,
          maxHeight: Math.floor(window.innerHeight * 0.6 - 24 - 34 - 28)
        },
        formFields: formFields,
        tools: [
          {
            auth: 'notify.notifyAddressBook.receiversImport',
            label: '导入',
            icon: 'import',
            func: () => this.extendConfig.show = true
          }
        ],
        tables: [
          {
            url: { method: 'notify.smsNotify.searchHREmployee', data: { elasticsearchFlag: 'N' } },
            option: {
              load: false,
              type: 'selection',
              moduleCode: 'smsNotify',
              selectionChange: (val) => {
                this.selectedRow = val
                if (this.selectedRow.length >= 1) {
                  this.msgForm.remoteEmployee.mobile = ''
                  this.msgForm.vo.gatewayCode = ''
                  this.msgForm.notify.content = ''
                  this.$refs['msgForm'].resetFields()
                } else {
                  this.msgForm.vo.gatewayCode = ''
                  this.msgForm.notify.content = ''
                  this.$refs['msgForm'].resetFields()
                }
              }
            },
            columns: columns
          }
        ],
        selectedRow: [],
        // 发送短信的表单
        msgForm: {
          notify: {
            content: '',
            templateCode: 'SEC_JS_SMS_T',
            fixTime: moment().format('YYYY-MM-DD HH:mm:ss')
          },
          remoteEmployee: {
            ids: [],
            mobile: ''
          },
          vo: {
            gatewayCode: '',
            sendNum: ''
          }
        },
        extendConfig: {
          show: false,
          isAsync: true,
          backData: null
        },
        gatewayCodeList: [],
        pickOneMonth: {
          disabledDate (time) {
            let curDate = (new Date()).getTime()
            let one = 30 * 24 * 3600 * 1000
            let oneMonth = one + curDate
            return time.getTime() < Date.now() || time.getTime() > oneMonth
          }
        }
      }
    },
    created () {
      this.getGatewayCodeList()
    },
    methods: {
      clearData () {
        this.msgForm.vo.gatewayCode = ''
        this.msgForm.notify.content = ''
        this.$refs['msgForm'].resetFields()
      },
      changeData (val) {
        if (!val) {
          this.msgForm.vo.gatewayCode = ''
          this.msgForm.notify.content = ''
          this.$refs['msgForm'].resetFields()
        }
      },
      getLocalTime (val) {
        if (new Date(val).getTime() < (new Date()).getTime()) {
          this.msgForm.notify.fixTime = moment().format('YYYY-MM-DD HH:mm:ss')
        }
      },
      errorMassage () {
        if (this.msgForm.notify.content.length > 55 && this.msgForm.notify.content.length <= 900) {
          this.$message(`当前短信内容${this.msgForm.notify.content.length}字，检查是否可精简！标准：55字/条，超长拆分，确定继续发送，取消返回发送`)
        }
      },
      // 导入成功后，调用的查询接口
      async importSearch (val) {
        if (val) {
          this.msgForm.vo.sendNum = val.id
          this.$refs.queryTable.loadData({ sendNum: val.id })
        }
      },
      // 发送短信
      sendMsg (formName) {
        this.$refs[formName].validate(async valid => {
          if (valid) {
            if (this.selectedRow.length < 1 && this.msgForm.remoteEmployee.mobile === '') {
              this.$message.warning('请选择接收人或者指定一个外部手机号发送短信')
              // this.$message.warning('没有需要发送的数据！')
              return
            }
            // 如果不是通过导入的数据
            if (!this.msgForm.vo.sendNum) {
              this.msgForm.vo.sendNum = ''
            }
            // 过滤没有 公司手机、私人手机 的记录
            let list = this.selectedRow.filter(item => item.companyMobile || item.privateMobile)
            if (list.length < 1 && this.msgForm.remoteEmployee.mobile === '') {
              this.$message.warning('请选择有公司手机、私人手机或手机号的数据或者指定一个外部手机号发送短信')
              // this.$message.warning('请选择有公司手机、私人手机或手机号的数据！')
            } else {
              // 公司手机 优先于 私人手机
              // this.msgForm.employeeIds = list.map(item => item.id)
              this.msgForm.remoteEmployee.ids = list.map(item => item.id)
              await this.$http('notify.smsNotify.send', this.msgForm)
              this.$message.success('发送成功！')
              this.$emit('close', true)
            }
          } else {
            this.$rule.error(this, this.$refs[formName])
          }
        })
      },
      // 重置发送短信表单
      resetMsgForm () {
        this.msgForm = {
          notify: {
            content: '',
            templateCode: 'SEC_JS_SMS_T',
            fixTime: moment().format('YYYY-MM-DD HH:mm:ss')
          },
          remoteEmployee: {
            ids: [],
            mobile: ''
          },
          vo: {
            gatewayCode: '',
            sendNum: ''
          }
        }
      },
      // 添加短信发送渠道列表
      async getGatewayCodeList () {
        let res = await this.$http('notify.notifyTemplate.search', {
          vo: {
            templateCode: 'SEC_JS_SMS_T'
          }
        })
        let list = res.rows[0].notifyGatewayList
        this.gatewayCodeList = list
      }
    }
  }
</script>
