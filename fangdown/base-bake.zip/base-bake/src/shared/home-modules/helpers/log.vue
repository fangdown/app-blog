<template>
  <div class="kye-dialog-body">
    <kye-row>
      <kye-col :span="4">
        <div class="upgrade-log__menu">
          <div style="margin: 0 6px 8px 6px;">
            <el-autocomplete
              ref="searchMenu"
              v-model="searchKey"
              clearable
              placeholder="名称或首字母"
              class="dialog-menu-popper"
              popper-class="kye-popper-auto"
              value-key="$title"
              :trigger-on-focus="false"
              :fetch-suggestions="searchMenu"
              @select="selectMenu">
              <i slot="prefix" class="el-icon-search" style="padding-top:8px;"></i>
            </el-autocomplete>
          </div>
          <el-tree :data="menuTree" node-key="id" @node-click="handleNodeClick"></el-tree>
        </div>
      </kye-col>
      <kye-col :span="20">
        <div class="upgrade-log__list">
          <div class="upgrade-log__list-item" v-for="item of list" :key="item.id">
            <p class="upgrade-log__title">
              {{item.creationDate | date}} {{menus[item.menuCode] && menus[item.menuCode].title}}
            </p>
            <div class="upgrade-log__centent" v-html="item.content"></div>
          </div>
        </div>
      </kye-col>
    </kye-row>
  </div>
</template>

<script>
  import { HOME_MENUS } from 'public/config'

  export default {
    name: 'log',
    props: {
      upgradeLogList: Array
    },
    data () {
      return {
        searchKey: '',
        list: this.upgradeLogList
      }
    },
    computed: {
      menuTree () {
        return this.$store.getters.menus.menuTree
      },
      menus () {
        return this.$store.getters.menus
      },
      searchedMenus () {
        return Object.values(this.menus).filter(v => v.$title && !HOME_MENUS.includes(v.menuCode))
      },
    },
    methods: {
      async handleNodeClick (item) {
        if (!item.children) {
          let res = await this.$http('system.upgradeLog.search', {
            page: 1,
            pageSize: 20,
            vo: { moduleId: item.id }
          }, false)
          this.list = res.rows
        }
      },
      searchMenu (val, cb) {
        const res = []
        if (val) {
          const letter = /^[a-zA-Z]+$/
          const en = letter.test(val)
          this.searchedMenus.forEach(v => {
            if ((en && v.$title_en.includes(val)) || v.$title.includes(val)) {
              res.push(v)
            }
          })
        }
        cb(res)
        // 自动选择第一行
        this.$nextTick(_ => {
          res.length && this.$refs['searchMenu'].highlight && this.$refs['searchMenu'].highlight(0)
        })
      },
      selectMenu (val) {
        this.handleNodeClick(val)
        this.searchKey = ''
      }
    }
  }
</script>

<style lang="scss" scoped>
  .upgrade-log {
    &__menu {
      margin-left: -16px;
      border-right: 1px solid #dcdae2;
      &__first {
        height: 32px;
        line-height: 32px;
        padding-left: 28px;
        font-size: 14px;
        font-weight: bold;
        color: #9571e9;
        cursor: pointer;
        &:hover {
          background-color: #f1f1f5;
        }
      }
      .el-tree {
        overflow-y: auto;
        max-height: calc(60vh - 65px);
      }
    }
    &__list {
      padding-left: 12px;
      overflow-y: auto;
      max-height: calc(60vh - 25px);
    }
    &__list-item {
      line-height: 1.6;
      border-bottom: 1px dotted #333;
      padding-top: 4px;
      padding-bottom: 4px;
    }
    &__title {
      font-size: 14px;
      font-weight: bold;
      color: #9571e9;
    }
    &__centent {
      font-size: 12px;
    }
  }
</style>
