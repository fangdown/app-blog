<template>
  <kye-dialog :visible="visible"
              v-bind="$attrs"
              v-on="$listeners"
              append-to-body
              :title="$attrs.title || '数据导出'"
              :width="$attrs.width || '360px'"
              :showClose="false"
              @open="open"
              :before-close="close">
    <kye-form label-position="top">
      <kye-row>
        <kye-col :span="24">
          <kye-form-item label="导出进度">
            <el-progress :text-inside="true" :stroke-width="18" :percentage="progress" color="rgba(142, 113, 199, 0.7)"></el-progress>
          </kye-form-item>
        </kye-col>
      </kye-row>
    </kye-form>
  </kye-dialog>
</template>

<script>
  export default {
    name: 'kye-data-export',
    props: {
      visible: { // 是否显示弹窗
        type: Boolean
      },
      code: { // searchCode
        type: String
      },
      url: { // 请求api code
        type: String
      },
      params: { // this.$refs.queryTable.getParams()
        type: [Object, Function],
        default: () => ({})
      },
      time: { // 定时请求间隔时间
        type: Number,
        default: 500
      },
      finish: { // 如果传入，则不执行默认下载操作
        type: [Function, Boolean]
      }
    },
    data () {
      return {
        progress: 0,
        uuid: '',
        list: [],
        disabled: true,
        errorFile: ''
      }
    },
    methods: {
      open () {
        this.export()
      },
      close () {
        clearInterval(this.timer)
        this.$emit('update:visible', false)
        this.progress = 0
      },
      async export () {
        try {
          let tableModel = this.params
          if (typeof tableModel === 'function') tableModel = tableModel()
          const res = await this.$http(this.url, {
            ...tableModel,
            menuId: this.$store.state.menus[this.$route.meta.tag].id,
            searchCode: this.code
          })
          if (res.taskId && res.taskId !== '') {
            this.timer = setInterval(() => {
              this.$http('file.file.result', {
                taskId: res.taskId
              }).then(exportRes => {
                if (exportRes.status === 'finish') {
                  this.$emit('success', exportRes)
                  const isUrl = exportRes.url && exportRes.url.includes('http')
                  this.progress = 100
                  this.close()
                  if (this.finish) {
                    return typeof this.finish === 'function' && this.finish(exportRes)
                  }
                  if (isUrl) {
                    // let link = document.createElement('a')
                    // link.style.display = 'none'
                    // link.target = '_blank'
                    // link.href = exportRes.url
                    // document.body.appendChild(link)
                    // link.click()
                    window.erpOpen(exportRes.url)
                  } else {
                    this.$message('文件错误无法下载')
                  }
                } else if (exportRes.status === 'process') {
                  if (exportRes.page / exportRes.pageTotal) {
                    let progress = parseInt((exportRes.page / exportRes.pageTotal) * 100)
                    this.progress = progress
                  } else {
                    this.progress = 0
                  }
                  if (this.progress > 100) this.progress = 100
                } else if (exportRes.status === 'exception') {
                  this.$message('文件错误无法下载')
                  this.close()
                }
              })
            }, this.time)
          } else {
            this.$message('文件错误无法下载')
            this.close()
          }
        } catch (err) {
          this.close()
        }
      }
    }
  }
</script>
