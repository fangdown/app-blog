<template>
  <kye-dialog
    title="新增响铃人员"
    :visible.sync="show"
    :width="2"
    @close="afterClose"
    append-to-body>
    <div class="set-beller-wrap">
      <kye-form
        :rules="bellRules"
        ref="form"
        :model="employeeInfo"
        class="demo-form-inline">
        <kye-row :gutter="8">
          <kye-col :span="12">
            <kye-form-item label="员工姓名" prop="employeeId">
              <kye-search-tips v-model="employeeInfo.employeeName"
                url="data.employee.listByName"
                :keys="keys"
                :clearable="true"
                :format-data="formatData"
                @clear="searchClear"
                @select="selectEmployee">
              </kye-search-tips>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="员工职务">
              <kye-input v-model="employeeInfo.employeeDuty" :disabled="true"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="所属部门">
              <kye-input v-model="employeeInfo.departmentName" :disabled="true"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="上班时间">
              <kye-input v-model="employeeInfo.workingBeginDate" :disabled="true"></kye-input>
            </kye-form-item>
          </kye-col>
          <kye-col :span="12">
            <kye-form-item label="下班时间">
              <kye-input v-model="employeeInfo.workingEndDate" :disabled="true"></kye-input>
            </kye-form-item>
          </kye-col>
        </kye-row>
        <kye-row>
          <kye-col :span="24">
            <kye-form-item label="响铃类型" prop="bellTypes">
              <kye-checkbox-group class="bell-type-wrap" v-model="employeeInfo.bellTypes">
                  <div class="bell-type-list"
                    :key="item.value"
                    v-for="item in lookUpOptions['oms_order_bell_type']">
                    <kye-checkbox
                      class="bell-checkbox"
                      :label="item.value"
                      >{{item.label}}
                    </kye-checkbox>
                  </div>
              </kye-checkbox-group>
            </kye-form-item>
          </kye-col>
        </kye-row>
      </kye-form>
    </div>
    <div slot="footer">
      <kye-button type="primary" hotkey="ctrl+s" @click="onSubmit">保存(S)</kye-button>
      <kye-button @click="close">取消</kye-button>
    </div>
  </kye-dialog>
</template>

<script>
  import moment from 'moment'
  import mixins from 'public/mixins'
  import { time } from 'public/utils'
  const toZero = n => n > 9 ? n : '0' + n
  let addParams = () => ({
    employeeId: null,
    employeeName: '',
    employeeDuty: '',
    departmentName: '',
    workingEndDate: '',
    workingBeginDate: '',
    bellTypes: []
  })
  export default {
    mixins: [mixins],
    props: {
      bellcode: String
    },
    data () {
      let validateBellTypes = (rule, value, callback) => {
        if (value.length > 0) {
          callback()
        } else {
          return callback(new Error('响铃类型不能为空'))
        }
      }
      return {
        show: false,
        employeeInfo: addParams(),
        keys: ['chineseName', 'departmentName'],
        bellRules: {
          employeeId: this.$rule.str('员工姓名不能为空', true),
          bellTypes: { required: true, validator: validateBellTypes, trigger: 'change' }
        }
      }
    },
    methods: {
      formatData (val) {
        return { chineseName: val }
      },
      async selectEmployee (res) {
        if (res && res.id) {
          this.employeeInfo.employeeId = res.id
          const info = await this.$http('data.employee.get', { id: res.id })
          this.employeeInfo.employeeName = res.chineseName
          this.employeeInfo.departmentName = info.departmentName
          this.employeeInfo.employeeDuty = info.position
          try {
            const hrInfo = await this.$http('hr.remoteAttendanceSchedule.list', {
              sysKey: 'oms',
              employeeIds: [res.id],
              startDate: time(Date.now(), 'YYYY-MM-DD 00:00:00'),
              endDate: time(Date.now(), 'YYYY-MM-DD 23:59:59')
            })
            if (hrInfo && hrInfo.length > 0) {
              const st = hrInfo[0].scheduleWorkTime
              const swt = hrInfo[0].scheduleAfterWorkTime
              this.employeeInfo.workingBeginDate = hrInfo[0].scheduleWorkTime ? `${toZero(moment(st).hour())}:${toZero(moment(st).minute())}` : ''
              this.employeeInfo.workingEndDate = hrInfo[0].scheduleAfterWorkTime ? `${toZero(moment(swt).hour())}:${toZero(moment(swt).minute())}` : ''
            }
          } catch (e) {
            this.employeeInfo.workingBeginDate = ''
            this.employeeInfo.workingEndDate = ''
          }
        } else {
          this.searchClear()
        }
      },
      searchClear () {
        this.employeeInfo.employeeName = ''
        this.employeeInfo.departmentName = ''
        this.employeeInfo.workingBeginDate = ''
        this.employeeInfo.workingEndDate = ''
        this.employeeInfo.employeeDuty = ''
        this.employeeInfo.employeeId = null
      },
      onSubmit () {
        this.$refs.form.validate(async (valid) => {
          if (valid) {
            if (!this.employeeInfo.employeeId) {
              this.$message.warning('员工不存在，无法新增响铃人员')
              return
            }
            let bellType = this.employeeInfo.bellTypes.join(',')
            await this.$http('system.bellSetting.save', { employeeId: this.employeeInfo.employeeId, bellType, bellCode: this.bellcode })
            this.$message.success('新增语音响铃人员成功')
            this.$emit('addSuccess')
            this.close()
          } else {
            this.$rule.error(this, this.$refs.form)
          }
        })
      },
      close () {
        this.show = false
      },
      afterClose () {
        this.employeeInfo = addParams()
        this.$refs.form.clearValidate()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .bell-checkbox {
    display: block;
    vertical-align: top;
    line-height: 28px;
  }
  .set-beller-wrap {
    margin-bottom: -12px;
  }
  .bell-type-wrap {
    overflow: hidden;
    .bell-type-list {
      float: left;
      margin-right: 16px;
    }
  }
</style>
