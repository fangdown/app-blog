<template>
  <div class="kye-dialog-body" v-scroll>
    <div class="btn-info">
      <kye-button
        type="text"
        icon="iconfont icon-plus"
        auth="system.bellSetting.save"
        @click="showDialog">新增</kye-button>
      <el-button
        :class="(currentRow && currentRow.id) ? 'red' : ''"
        type="text"
        auth="system.bellSetting.deleteById"
        @click="onDel" :disabled="!currentRow || !currentRow.id">
        <i class="iconfont icon-delete"></i>删除
      </el-button>
    </div>
    <div ref="bellTable">
      <el-table
        stripe
        border
        :data="tableData"
        :default-sort="{prop: 'operateTime', order: 'descending'}"
        style="width: 100%"
        :max-height="maxHeight"
        @current-change="currentChange">
        <el-table-column
          type="index"
          width="50">
        </el-table-column>
        <el-table-column
          align="center"
          v-for="(item,index) in headData"
          :key="index"
          :prop="item.prop"
          :width="item.width ? item.width : null"
          :show-overflow-tooltip="true"
          :sortable="item.sort"
          :label="item.label">
          <template slot-scope="scope">
            <span v-if="item.formatter">{{item.formatter(scope.row[item.prop])}}</span>
            <span v-else>{{scope.row[item.prop]}}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <add-bell ref="bellPerson" @addSuccess="handleAdd" :bellcode="params.bellCode"></add-bell>
  </div>
</template>

<script>
  import moment from 'moment'
  import mixins from 'public/mixins'
  import { time, minute, lookup } from 'public/utils'
  import AddBell from './add.vue'
  const toZero = n => n > 9 ? n : '0' + n
  export default {
    mixins: [mixins],
    name: 'kye-set-beller',
    props: {
      params: {
        type: Object,
        default: () => ({})
      }
    },
    components: {
      AddBell
    },
    data () {
      return {
        headData: [
          {
            label: '员工姓名',
            prop: 'employeeName',
            width: '80px'
          },
          {
            label: '员工职务',
            prop: 'employeeDuty',
            width: '86px'
          },
          {
            label: '所属部门',
            prop: 'departmentName',
            width: '80px'
          },
          {
            label: '上班时间',
            prop: 'workingBeginDate',
            width: '80px'
          },
          {
            label: '下班时间',
            prop: 'workingEndDate',
            width: '80px'
          },
          {
            label: '录入人',
            prop: 'operateName',
            width: '64px'
          },
          {
            label: '录入时间',
            prop: 'operateTime',
            sort: true,
            formatter: minute,
            width: '118px'
          },
          {
            label: '响铃类型',
            prop: 'bellType',
            formatter: this.formatBellType
          }
        ],
        tableData: [],
        currentRow: null,
        maxHeight: Math.floor(window.innerHeight * 0.6 - 32 - 24)
      }
    },
    created () {
      this.dataList()
    },
    // mounted () {
    //   this.$bus.$on(`scroll${this.$route.meta.tag}`, this.handleDialogScroll)
    // },
    // destroyed () {
    //   this.$bus.$off(`scroll${this.$route.meta.tag}`, this.handleDialogScroll)
    // },
    methods: {
      handleDialogScroll (e) {
        const OFFSETTOP = 44 + 14
        const offsetTop = this.$refs.bellTable.offsetTop
        if (e.scrollTop >= offsetTop - OFFSETTOP) {
          this.maxHeight = e.offsetHeight - 32 - 24
        }
      },
      async dataList () {
        let res = await this.$http('system.bellSetting.list', this.params)
        if (res && res.length > 0) {
          let ids = res.map(item => item.employeeId)
          try {
            const hrInfo = await this.$http('hr.remoteAttendanceSchedule.list', {
              sysKey: 'oms',
              employeeIds: ids,
              startDate: time(Date.now(), 'YYYY-MM-DD 00:00:00'),
              endDate: time(Date.now(), 'YYYY-MM-DD 23:59:59')
            })
            if (hrInfo && hrInfo.length > 0) {
              hrInfo.forEach(item => {
                for (let resObj of res) {
                  if (item.employeeId === resObj.employeeId) {
                    resObj.workingBeginDate = item.scheduleWorkTime ? `${toZero(moment(item.scheduleWorkTime).hour())}:${toZero(moment(item.scheduleWorkTime).minute())}` : ''
                    resObj.workingEndDate = item.scheduleAfterWorkTime ? `${toZero(moment(item.scheduleAfterWorkTime).hour())}:${toZero(moment(item.scheduleAfterWorkTime).minute())}` : ''
                  }
                }
              })
            }
          } catch (e) {
          }
          this.tableData = res
        } else {
          this.tableData = []
        }
      },
      handleAdd () {
        this.dataList()
      },
      onDel () {
        this.$confirm('您确定要删除当前数据吗 ？', '提示').then(() => {
          this.handleDelete()
        })
      },
      async handleDelete () {
        await this.$http('system.bellSetting.deleteById', { id: this.currentRow.id })
        this.dataList()
        this.$message.success('删除成功')
      },
      showDialog () {
        this.$refs.bellPerson.show = true
      },
      formatBellType (val) {
        let res = val.split(',')
        let str = ''
        res.forEach(item => {
          str += `| ${lookup(item, 'oms_order_bell_type')}`
        })
        return str.substr(1)
      },
      currentChange (row) {
        this.currentRow = row
      }
    }
  }
</script>

<style lang="scss" scoped>
  .btn-info {
    margin-bottom: 2px;
  }
</style>
