<template>
  <div class="report-tables">
    <div v-scroll="dialog"
         :class="{'kye-dialog-body': dialog === true}">
      <slot name="form"></slot>
      <kye-table v-if="!canvas"
                 :data="tableData"
                 v-loading="loading"
                 element-loading-text="加载中"
                 border
                 highlight-current-row
                 v-tablefixed="'tableMaxHeight'"
                 :max-height="tableMaxHeight"
                 :height="tableHeight"
                 @sort-change="sortChange"
                 @selection-change="handleSelectionChange"
                 @select="select"
                 @row-dblclick="rowDblclick"
                 @current-change="tableHandleCurrentChange">
        <kye-table-column v-if="index"
                          :index="indexMethod"
                          :resizable="false"
                          width="55"
                          type="index">
        </kye-table-column>
        <kye-table-column v-if="selection"
                          type="selection"
                          width="55">
        </kye-table-column>
        <kye-table-column v-for="(item, index) in columnItems"
                          :sortable="item.sortable"
                          show-overflow-tooltip
                          :fixed="index === 0 && selection"
                          v-if="item.show === false ? false : true"
                          :key="item.key"
                          :prop="item.key"
                          :width="item.width"
                          :min-width="item.width || '100px'"
                          :label="item.label">
          <template slot-scope="scope">
            <template v-if="item.filter && (typeof item.filter === 'function')"> {{item.filter(getModelValue(scope.row, item.key), scope.row)}}</template>
            <template v-else-if="item.renders && (typeof item.renders === 'function')">
              <table-render :index="scope.$index"
                            :value="scope.row[item.key]"
                            :column="scope.row"
                            :renders="item.renders">
              </table-render>
            </template>
            <template v-else-if="item && item.lookupCode">
              <span>{{scope.row[item.key] | lookup(item.lookupCode)}}</span>
            </template>
            <template v-else>
              {{getModelValue(scope.row, item.key)}}
            </template>
          </template>
        </kye-table-column>
      </kye-table>
      <kye-canvas-table v-else
                        ref="reportTable"
                        :data="tableData"
                        :isScroll="true"
                        :scrollY="true"
                        :selection="selection"
                        :dialog="!!dialog"
                        :height="tableHeight"
                        :column="canvasColumn"
                        @row-dblclick="rowDblclick"
                        @current-change="tableHandleCurrentChange"
                        @selection-change="handleSelectionChange"
                        @sort-change="sortChange"
                        v-loading="loading"
                        @col-resize="saveColWidth">
      </kye-canvas-table>
    </div>
    <div v-if="propTools !== -1"
         :style="pagerStyle"
         :class="pageClass">
      <kye-pagination @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"
                      @prev-click="prevClick"
                      @next-click="nextClick"
                      :page-sizes="pageData.pageSizes"
                      :page-size="pageData.pageSize"
                      :layout="$pagination.layout"
                      :total="propTools">
      </kye-pagination>
    </div>
  </div>
</template>

<script>
  import tableRender from './table-render.js'
  import { getModelValue } from 'public/utils'
  export default {
    name: 'report-tables',
    components: {
      tableRender
    },
    props: {
      canvas: {
        type: Boolean,
        default: () => {
          return false
        }
      },
      index: {
        type: Boolean,
        default: () => {
          return false
        }
      },
      selection: {
        type: Boolean,
        default: () => {
          return false
        }
      },
      loading: {
        type: Boolean,
        default: () => {
          return false
        }
      },
      tableData: {
        type: Array,
        default: () => {
          return []
        }
      },
      columnItems: {
        type: Array,
        default: () => {
          return []
        }
      },
      propTools: {
        type: Number,
        default: () => {
          return -1
        }
      },
      dialog: {
        type: [Boolean, String],
        default: () => {
          return false
        }
      },
      sortChange: {
        type: Function,
        default: () => {
          return function () {
          }
        }
      },
      height: {
        type: [String, Number]
      },
      searchCode: {
        type: String
      }
    },
    data () {
      return {
        menuWidth: 176,
        tableMaxHeight: null,
        offsetTop: 0,
        pageData: {
          page: 0,
          pageSize: this.$pagination.pageSize,
          pageSizes: this.$pagination.pageSizes,
          tools: 0
        }
      }
    },
    computed: {
      pageClass () {
        let pagerClass = this.dialog ? 'el-dialog__footer' : 'pager-wrap'
        if (this.dialog === 'inline') pagerClass = 'el-dialog__footer_inline'
        return pagerClass
      },
      pagerStyle () {
        return { left: this.menuWidth + 'px' }
      },
      tableHeight () {
        return this.height ? this.height : null
      },
      canvasColumn () {
        let column = [...this.columnItems]
        column.forEach(item => {
          item.width = item.width || 100
          if (item.lookupCode && !item.filter) {
            item.filter = {
              type: 'lookup',
              args: [item.lookupCode]
            }
          }
        })
        return column
      }
    },
    mounted () {
      this.$bus.$on('SWITCH_MENU', this.handleSwitchMenu)
      if (this.canvas && this.searchCode) {
        this.setColWidth()
      }
    },
    beforeDestroy () {
      this.$bus.$off('SWITCH_MENU', this.handleSwitchMenu)
    },
    methods: {
      getModelValue,
      sortTest (a, b) {
        console.log(a, b)
      },
      handleSwitchMenu (width) {
        this.menuWidth = width
      },
      handleSelectionChange (val) {
        this.$emit('handleSelectionChange', val)
      },
      handleSizeChange (val) {
        this.pageData.pageSize = val
        this.$emit('handleSizeChange', val)
      },
      handleCurrentChange (val) {
        this.pageData.page = val
        this.$emit('handleCurrentChange', val)
      },
      tableHandleCurrentChange (val) {
        this.$emit('tableHandleCurrentChange', val)
      },
      rowDblclick (val) {
        this.$emit('rowDblclick', val)
      },
      select (val, row) {
        this.$emit('select', val, row)
      },
      prevClick (val) {
        this.$emit('prevClick', val)
      },
      nextClick (val) {
        this.$emit('nextClick', val)
      },
      resetData () {
        this.pageData = {
          page: 0,
          pageSize: this.$pagination.pageSize,
          pageSizes: this.$pagination.pageSizes,
          tools: 0
        }
      },
      saveColWidth (key, width) {
        if (!this.searchCode) {
          return
        }
        let res = localStorage.getItem('GLOBAL_COL_WIDTH')
        let tag = `${this.$route.meta.tag}?${this.searchCode}`
        if (res) {
          try {
            res = JSON.parse(res)
            if (res[tag]) {
              res[tag][key] = width
            } else {
              res[tag] = { [key]: width }
            }
            localStorage.setItem('GLOBAL_COL_WIDTH', JSON.stringify(res))
          } catch (e) {
          }
        } else {
          res = { [tag]: { [key]: width } }
          localStorage.setItem('GLOBAL_COL_WIDTH', JSON.stringify(res))
        }
      },
      setColWidth () {
        let res = localStorage.getItem('GLOBAL_COL_WIDTH')
        if (this.searchCode && res) {
          try {
            let tag = `${this.$route.meta.tag}?${this.searchCode}`
            res = JSON.parse(res)
            res = res[tag]
            if (res) {
              this.$refs.reportTable.colWidthMap = res
            }
          } catch (e) {
          }
        }
      },
      indexMethod (index) {
        return index + 1 + (this.pageData.page) * this.pageData.pageSize
      }
    }
  }
</script>

<style lang='scss' scoped>
  .report-tables {
    /* Scrollbar styles */
    /deep/ .el-table__body-wrapper {
      // 注意mac chrome的滚动条默认宽度为 15px 而 windows chrome滚动条宽度为 17px
      // https://codepen.io/sambible/post/browser-scrollbar-widths
      &::-webkit-scrollbar {
        width: 15px;
        height: 15px;
      }

      &::-webkit-scrollbar-thumb {
        cursor: pointer;
        border-radius: 8px;
        background-color: #aa90e8;
        border: 2px solid white;
        border-bottom-width: 3px;
      }

      &::-webkit-scrollbar-track {
        border: 0px solid transparent;
        background-color: #fff;
      }

      &::-webkit-scrollbar-corner {
        background: transparent;
      }
      &::-webkit-scrollbar-button {
        width: 0;
        height: 0;
        display: none;
      }
      // for windows
      &::-webkit-scrollbar {
        width: 17px;
        height: 17px;
      }
    }

    .pager-wrap {
      position: fixed;
      bottom: 0;
      left: 176px;
      right: 16px;
      padding: 12px;
    }
  }
  .el-dialog__footer_inline {
    padding: 12px 0 0;
  }
</style>
