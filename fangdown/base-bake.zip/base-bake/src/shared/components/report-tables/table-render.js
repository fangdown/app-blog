import Vue from 'vue'

const tableRender = Vue.component('table-render', {
  functional: true,
  props: {
    index: {
      type: Number,
      default: () => { }
    },
    value: {
      type: [Object, Number, String, Boolean, Array],
      default: () => { return {} }
    },
    column: {
      type: Object,
      default: () => { return {} }
    },
    renders: {
      type: Function,
      default: () => function () { }
    }
  },
  render (createEl, self) {
    return self.props.renders(createEl, { index: self.props.index, value: self.props.value, column: self.props.column })
  }
})

export default tableRender
