import { setObjectNull, arrayIsLength, setCountNumber } from './utils'
export default {
  methods: {
    handleSizeChange (val) {
      this.formData.pageSize = val
      this.getData()
    },
    handleCurrentChange (val) {
      this.formData.page = val
      this.getData()
    },
    resetForm () {
      this.date = []
      this.formData = {
        page: 1,
        pageSize: this.$pagination.pageSize,
        params: setObjectNull(this.formData.params, '')
      }
      if (this && this.setDate) {
        this.setDate()
      }
      this.$refs.dataReportForm.resetFields()
      this.$refs.reportTables.resetData()
      // this.getData()
    },
    async getList () {
      if (!this.listAjaxCode) {
        return
      }
      this.loading = true
      try {
        const data = await this.$http(
          this.listAjaxCode,
          this.formData
        )
        this.tableData = data.rows
        this.propTools = data.rowTotal
        this.loading = false
      } catch (err) {
        this.tableData = []
        this.total = 0
        this.loading = false
      }
    },
    async getCount () {
      if (!this.countAjaxCode) {
        return
      }
      try {
        const data = await this.$http(
          this.countAjaxCode,
          { params: this.formData.params }
        )
        setCountNumber(this.countDatas, data[0])
      } catch (err) {
      }
    },
    async exportAll () {
      if (!arrayIsLength(this.tableData) && !this.listAjaxCode) {
        this.$message('表格没有可导出的数据')
        return
      }
      await this.$confirm('是否要导出当前页数据?', '导出Excel', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      const url = await this.$http(
        this.listAjaxCode,
        { ...this.formData, ...{ export: true } }
      )
      const isUrl = url && url.includes('http')
      if (isUrl) {
        window.erpOpen(url)
      }
    }
  }
}
