import moment from 'moment'
import { Message } from 'element-ui'
export const addNumber = (data, key) => {
  // 计算费用
  let tool = 0
  if (!arrayIsLength(data)) {
    return '0'
  }
  tool = data.map(v => {
    return +v[key] || 0
  }).reduce((s, v) => { return s += v })
  return tool
}

export const resetDatas = (params) => {
  'use strict'
  // 不支持数组
  let data = {}
  const com = (datas, copy) => {
    // console.log(datas)
    Object.keys(datas).forEach(v => {
      let isObj = isObject(datas[v])
      let val = isObj ? {} : ''
      copy[v] = val
      if (isObj) {
        return com(datas[v], copy[v])
      }
    })
  }
  com(params, data)
  return data
}

export const recursionObj = (objs) => {
  'use strict'
  // 拍平对象
  let obj = {}
  function recursion (objs, name) {
    // 保存当前层次的key
    let presentName = name
    Object.keys(objs).forEach((v) => {
      if (!isObject(objs[v])) {
        let presentNameKey = presentName ? `${presentName}.${v}` : v
        obj[presentNameKey] = objs[v]
        return
      }
      // 是对象的话叠加key
      let key = name ? `${name}.${v}` : v
      let len = Object.keys(objs[v]).length
      if (!len) {
        // 如果对象是空 直接赋值空对象
        obj[`${presentName}.${v}`] = objs[v]
        return
      }
      return recursion(objs[v], key)
    })
  }
  recursion(objs, '')
  return obj
}

export const setCountNumber = (comData, data) => {
  // 设置费用
  if (!data || (data && !isObject(data))) {
    console.error('传的参数不是一个对象')
    return data
  }
  Object.keys(comData).forEach(i => {
    if (comData[i]) {
      comData[i].value = data[i] || 0
    }
  })
}

export const setObjectNull = (data, val) => {
  // 设置obj的所有值
  if (!isObject(data)) {
    console.error('传的参数不是一个对象')
    return data
  }
  let ajaxData = { ...data }
  Object.keys(ajaxData).forEach(v => {
    ajaxData[v] = val
  })
  return ajaxData
}

export const comIsArray = (data) => {
  // 日期选择
  if (isArray(data) && data.length) {
    return data
  }
  return ['', '']
}

// export const setDates = (data, key, format) => {
//   // 设置时间默认值
//   const dates = new Date()
//   const start = moment(dates).format(format || 'YYYY-MM-DD')
//   data.date = [start, start]
//   Object.keys(data.data).forEach(v => {
//     data.data[v] = start
//   })
// }

export const arrayIsLength = (val) => {
  if (isArray(val) && val.length) {
    return true
  }
  return false
}

export const setInput = (className) => {
  let inp = document.querySelectorAll(className)
  let i = 0
  let domArr = []
  inp.forEach((v, index) => {
    if (!v.disabled) {
      v.setAttribute('inputIndex', i)
      domArr.push(v)
      i++
    }
  })
  return domArr
}

export const dateFunc = {
  setDatas (val) {
    const len = val.length
    const data = this.sliceStr(len, val)
    const dateFunc = {
      '2': this.setDateTwo,
      '4': this.setDateFour,
      '6': this.setDateSix
    }
    if (!dateFunc[len]) {
      const originalDate = moment(val).format('YYYY-MM-DD')
      if (originalDate === 'Invalid date') {
        return ''
      }
      if (val === originalDate) {
        return val
      }
      return ''
    }
    const date = dateFunc[len](data)
    if (moment(date).format() === 'Invalid date') {
      Message('时间格式不正确')
      return ''
    }
    return date
  },
  setTimess (val) {
    const len = val.length
    const data = this.sliceStr(len, val)
    const dateFunc = {
      '2': this.setTimeTwo,
      '4': this.setTimeFour,
      '6': this.setTimeSix,
      '8': this.setTimeEight,
      '10': this.setTimeTen
    }
    if (!dateFunc[len]) {
      const originalDate = moment(val).format('YYYY-MM-DD HH:mm')
      const originalDate2 = moment(val).format('YYYY-MM-DD HH')
      // 如果输入的内容无法转换成正确数据 返回空
      if (originalDate === 'Invalid date') {
        return ''
      }
      // 转换后不相等，为错误时间格式
      if (val === originalDate) {
        return val
      } else if (originalDate2 === val) {
        return originalDate
      }
      return ''
    }
    const date = dateFunc[len](data)
    if (moment(date).format() === 'Invalid date') {
      Message('时间格式不正确')
      return ''
    }
    return date
  },
  sliceStr (len, str) {
    // 按两位切割数字成数组，最后拼接成时间
    let data = []
    let j = 0
    for (let i = 0; i < len + 1; i++) {
      if (i !== 0 && i % 2 === 0) {
        data.push(str.slice(j, i))
        j = i
      }
    }
    return data
  },
  setDateTwo (data) {
    const year = moment().format('YYYY-MM')
    return `${year}-${data[0]}`
  },
  setDateFour (data) {
    const year = moment().format('YYYY')
    return `${year}-${data[0]}-${data[1]}`
  },
  setDateSix (data) {
    const year = moment().format('YYYY').slice(0, 2)
    return `${year}${data[0]}-${data[1]}-${data[2]}`
  },
  setTimeTwo (data) {
    // 2位时间
    const year = moment().format('YYYY-MM-DD HH')
    return `${year}:${data[0]}`
  },
  setTimeFour (data) {
    // 4位时间
    const year = moment().format('YYYY-MM-DD')
    return `${year} ${data[0]}:${data[1]}`
  },
  setTimeSix (data) {
    // 5位时间
    const year = moment().format('YYYY-MM')
    return `${year}-${data[0]} ${data[1]}:${data[2]}`
  },
  setTimeEight (data) {
    // 8位时间
    const year = moment().format('YYYY')
    return `${year}-${data[0]}-${data[1]} ${data[2]}:${data[3]}`
  },
  setTimeTen (data) {
    // 10位时间
    const year = moment().format('YYYY').slice(0, 2)
    return `${year}${data[0]}-${data[1]}-${data[2]} ${data[3]}:${data[4]}`
  }
}

export const shortcutDate = (val, type) => {
  const func = {
    setTimess: dateFunc.setTimess,
    setDatas: dateFunc.setDatas
  }
  if (!func[type]) {
    console.log('', '只有2方法 setTimess setDatas')
    return
  }
  return func[type].call(dateFunc, val)
}

export const isObject = (val) => {
  return toString.call(val) === '[object Object]'
}

export const isArray = (val) => {
  return toString.call(val) === '[object Array]'
}

export const isDate = (val) => {
  return toString.call(val) === '[object Date]'
}

export const isBoolean = (val) => {
  return toString.call(val) === '[object Boolean]'
}

export const isFunction = (val) => {
  return toString.call(val) === '[object Function]'
}

export const isNumber = (val) => {
  return toString.call(val) === '[object Number]'
}

export const isUndefined = (val) => {
  return toString.call(val) === '[object Undefined]'
}

export const isString = (val) => {
  return toString.call(val) === '[object String]'
}

export const promise = () => { }
