<template>
  <div class="agency-count">
    <dl class="agency-count_dl"
        v-for="item in countDatas"
        :key="item.key">
      <dt>{{item.label}}</dt>
      <dd>
        {{item.filter ? filter(item.value, item.filter) : toFixeds(item.value)}}
        <span v-if="item.suffix">{{item.suffix}}</span>
      </dd>
    </dl>
  </div>
</template>

<script>
  import { isNumber, isString } from './utils.js'
  import { money } from '@/public/utils'
  export default {
    name: 'count-item',
    props: {
      countDatas: {
        type: Object,
        default: () => {
          return {}
        }
      }
    },
    data () {
      return {
        filterData: {
          'money': money
        }
      }
    },
    methods: {
      toFixeds (val) {
        if (!val || (!isNumber(val) && !isString(val))) {
          return '0'
        }
        const len = String(val).split('.').length
        if (len <= 1) {
          return String(val)
        }
        return Number(val).toFixed(2, 10)
      },
      filter (val, type) {
        return this.filterData[type](val)
      }
    }
  }
</script>

<style lang='scss' scoped>
  .agency-count {
    display: flex;
    padding-left: 15px;
    flex-wrap: wrap;
    margin-bottom: 2px;
    background-color: #f8f8fa;
    .agency-count_dl {
      display: flex;
      line-height: 28px;
      height: 28px;
      font-size: 12px;
      margin-right: 24px;
      dt {
        flex-shrink: 0;
        color: #666;
      }
      dd {
        padding-left: 0px;
        color: #ff9300;
        font-weight: bold;
      }
    }
  }
</style>
