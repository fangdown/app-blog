<template>
  <el-autocomplete ref="searchTips"
                   popper-class="kye-popper-auto"
                   v-bind="$attrs"
                   :value="value"
                   :value-key="valueKey"
                   :placeholder="placeholder"
                   :trigger-on-focus="false"
                   :fetch-suggestions="searchCity"
                   @keyup.enter.native="validateCity"
                   @select="handleSelect"
                   @blur.native="validateCity"
                   @blur.exact="closeLoading">
  </el-autocomplete>
</template>

<script>
  export default {
    name: 'kye-city',
    props: {
      value: String,
      valueKey: {
        type: String,
        default: 'addressName'
      },
      multiSelect: {
        type: Boolean,
        default: false
      },
      placeholder: {
        type: String,
        default: '请输入内容'
      }
    },
    data () {
      return {
        reg: /\d+/
      }
    },
    methods: {
      searchCity (val, cb) {
        this.$emit('input', val)
        if (val && !this.reg.test(val)) {
          this.$http('baseconfig.regionCity.getCityCodeByCodeOrName', { cityName: val })
            .then(res => {
              this.closeLoading()
              if (res && res.length) {
                cb(res)
              } else {
                this.handleSelect(null)
              }
            }).catch(this.closeLoading)
        } else {
          this.closeLoading()
        }
      },
      validateCity (e) {
        let val = e.target.value
        if (this.reg.test(val)) {
          this.closeLoading()
          this.$http('baseconfig.regionCity.getCityCodeByCodeOrName', { cityCode: val })
            .then(res => {
              if (res) {
                if (this.multiSelect && res.length) {
                  let codeObj = {}
                  res.forEach(item => {
                    if (!codeObj[item.cityCode]) {
                      codeObj[item.cityCode] = true
                      this.handleSelect(item)
                    }
                  })
                  return
                }
                this.handleSelect(res[0])
              } else {
                this.handleSelect(null)
              }
            })
        }
      },
      handleSelect (val) {
        if (val && val[this.valueKey]) {
          this.$emit('input', val[this.valueKey])
        }
        this.$emit('select', val)
      },
      closeLoading () {
        this.$refs.searchTips.loading = false
      }
    }
  }
</script>
