<template>
  <div :style="{width: width, height: height || '360px'}"></div>
</template>

<script>
  /* eslint-disable no-undef */
  import jsonp from 'jsonp'
  import AK, { requireSDK } from './utils'
  import carImg from '../../assets/images/car.png'

  export default {
    name: 'kye-map',
    props: {
      width: String,
      height: String,
      options: Object,
      points: Array,
      driving: Array
    },
    data () {
      return {
        carIcon: '',
        loaded: false
      }
    },
    watch: {
      points () {
        this.initMap()
      },
      driving () {
        this.initMap()
      }
    },
    mounted () {
      this.$nextTick().then(_ => {
        if (!this.loaded) {
          this.getMap()
        }
      })
    },
    methods: {
      getMap () {
        if (this.map) {
          return Promise.resolve(this.map)
        }
        if (!this.loaded) {
          this.loaded = true
          return requireSDK().then(_ => {
            this.setMap()
            return this.map
          })
        }
      },
      setMap () {
        if (window.BMap) {
          // 实例化小车icon
          this.carIcon = new BMap.Icon(
            carImg,
            new BMap.Size(32, 48),
            {
              imageOffset: new BMap.Size(0, -15) // 图片的偏移量。为了是图片底部中心对准坐标点。
            }
          )
          this.map = new BMap.Map(this.$el, this.options)
          this.map.centerAndZoom(new BMap.Point(116.404, 39.915), 12)
          this.map.addControl(new BMap.NavigationControl())
          this.map.enableScrollWheelZoom()
          this.initMap()
        }
      },
      // 写入线路与驾车路线
      initMap () {
        // 画路线
        if (this.points && this.points.length) {
          this.points.map(({ start, end }, index) => {
            start = start || end
            end = end || start
            if (!end || !Array.isArray(end) || !end[1]) return
            this.drivingLine(start, end, index)
          })
        }
        // 小车动画
        if (this.driving && this.driving.length) {
          this.driving.map(({ start, end }, index) => {
            start = start || end
            end = end || start
            if (!end || !Array.isArray(end) || !end[1]) return
            this.drivingRoute(start, end, index)
          })
        }
      },
      // 创建路线
      initDriving (start, end, option = {}) {
        // 起始点与目前到达点
        let p1 = new BMap.Point(start[0], start[1])
        let p2 = new BMap.Point(end[0], end[1])
        let driving = new BMap.DrivingRoute(this.map, option) // 驾车实例
        driving.search(p1, p2)
        return {
          driving, p1, p2
        }
      },
      // 驾车小车动画
      drivingRoute (start, end, index) {
        if (!this.map || !BMap) return
        let { driving } = this.initDriving(start, end)
        // 路线回调
        driving.setSearchCompleteCallback(() => {
          let pts = driving.getResults().getPlan(0).getRoute(0).getPath() // 通过驾车实例，获得一系列点的数组
          let paths = pts.length // 获得有几个点
          let carMk = new BMap.Marker(pts[0], { icon: this.carIcon })
          this.$emit('afterCarMarketInit', { car: carMk, start, end, index })
          // 添加market点
          this.map.addOverlay(carMk)

          // 滑动函数
          function resetMkPoint (i) {
            carMk.setPosition(pts[i])
            if (i < paths) {
              setTimeout(() => {
                i++
                resetMkPoint(i)
              }, 80)
            }
          }

          setTimeout(function () {
            resetMkPoint(5)
          }, 100)
        })
      },
      // 驾车线路
      drivingLine (start, end, index) {
        if (!this.map || !BMap) return
        let { driving, p2 } = this.initDriving(start, end, {
          renderOptions: { map: this.map, autoViewport: true },
          onMarkersSet: (res) => {
            // 标签设置后回调
            this.$emit('markersSet', res, index)
          },
          onSearchComplete: (res) => {
            if (driving.getStatus() !== BMAP_STATUS_SUCCESS) return
            let plan = res.getPlan(0)
            this.$emit('searchComplete', res, plan)
            // plan.getDuration(true) // 时间
            // plan.getDistance(true) // 路程
          }
        })
        driving.setPolylinesSetCallback(res => {
          // 路线添加后回调
          this.$emit('setPolylines', res, index)
        })
        this.initMapPosition(p2)
      },
      // 定位可视窗口到指定经纬度(如果不传point，则定位到深圳总部)
      initMapPosition (point = { lng: '113.786939', lat: '22.687931' }, zoom = 12) {
        point = new BMap.Point(point.lng, point.lat)
        this.map.centerAndZoom(point, zoom)
      },
      // bd09ll -> GCJ02
      convertPoint (point, callback) {
        jsonp(
          `https://api.map.baidu.com/geoconv/v1/?coords=${point.lng},${point.lat}&from=5&to=3&ak=${AK}`,
          null,
          (e, data) => {
            if (data && data.result && data.result[0]) {
              let res = { lng: +data.result[0].x.toFixed(6), lat: +data.result[0].y.toFixed(6) }
              callback(res, point)
            } else {
              callback()
            }
          }
        )
      },
      // 地址解析
      getPoint (address, city, callback, gcj) {
        let geoc = new BMap.Geocoder()
        geoc.getPoint(
          address,
          point => {
            if (point) {
              if (gcj) {
                this.convertPoint(point, callback)
              } else {
                callback(point)
              }
            } else {
              callback(point)
            }
          },
          city
        )
      },
      // 逆地址解析
      getLocation () {
        let geoc = new BMap.Geocoder()
        this.map.addEventListener('click', (e) => {
          let pt = e.point
          geoc.getLocation(pt, (rs) => {
          })
        })
      },
      // 浏览器定位
      geoLocation (callback) {
        const geolocation = new BMap.Geolocation()
        geolocation.getCurrentPosition((r) => {
          let status = geolocation.getStatus()
          if (status === 0) {
            this.addMarker(r.point)
            callback && callback(r.point)
          }
        }, { enableHighAccuracy: true })
      },
      // ip 定位
      localCity () {
        let city = new BMap.LocalCity()
        city.get(result => {
          let cityName = result.name
          this.map.setCenter(cityName)
        })
      },
      /**
       * 添加标记点
       * @param point Object
       *  {lng: xxx, lat: xxx}
       * @returns {BMap.Marker}
       */
      addMarker (point = {}, options = {}) {
        if (!point || !point.lng || !point.lat) return false
        let bdPoint = new BMap.Point(point.lng, point.lat)
        let mk = new BMap.Marker(bdPoint, options)
        this.map.addOverlay(mk)
        // this.map.panTo(point)
        return mk
      },
      /**
       * 删除标记点
       * @param mk Array / Object
       */
      removeMarker (mk = []) {
        if (!Array.isArray(mk)) mk = [mk]
        mk.map(item => {
          this.map.removeOverlay(item)
        })
      }
    }
  }
</script>
