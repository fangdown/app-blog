const AK = 'XfYdeSuIAV53HYfFr9dGfvRtLvdNckbd'

export const requireSDK = () => {
  return new Promise(function (resolve, reject) {
    let head = document.head
    let dom = head.querySelector('[src*="api.map.baidu.com"]')
    if (dom) {
      resolve(1)
      return
    }
    window.HOST_TYPE = '2'
    dom = document.createElement('script')
    dom.type = 'text/javascript'
    dom.src = '//api.map.baidu.com/getscript?v=2.0&s=1&ak=' + AK
    dom.onerror = reject
    dom.onload = resolve
    head.appendChild(dom)
  })
}

export default AK
