<template>
  <kye-dialog :visible="show"
              :title="'文档生成提示'"
              :width="'360px'"
              :showClose="false">
    <kye-row style="text-align:center">
      <kye-col :span="24">
        <span style="margin:20px 0;">{{info}}</span>
      </kye-col>
    </kye-row>
  </kye-dialog>
</template>

<script>
  export default {
    name: 'kye-preview',
    props: {
      visible: Boolean,
      bizCode: String,
      bizId: String
    },
    data () {
      return {
        info: '正在生成预览文件，请稍后。',
        show: false
      }
    },
    watch: {
      visible (val, old) {
        if (val !== old) {
          this.init()
        }
      }
    },
    methods: {
      init () {
        if (!this.$props.bizCode) {
          this.$message.warning('缺少bizCode')
          return
        }
        if (!this.$props.bizCode) {
          this.$message.warning('缺少bizId')
          return
        }
        this.show = true
        this.previewDocument(this.$props.bizCode, this.$props.bizId)
      },
      previewDocument (bizCode, bizId) {
        this.show = true
        this.$http('filetool.filetool.preview', {
          vo: {
            bizCode: bizCode,
            bizId: bizId,
            id: ''
          }
        }).then(async data => {
          if (data) {
            if (data.id) {
              if (data.bizCode && data.bizId) {
                const res = await this.$http('system.file.sign', {
                  bizCode: data.bizCode,
                  bizId: data.bizId,
                  createdBy: 0
                })
                this.show = false
                if (res) {
                  const isUrl = data.visit.includes('http')
                  let url = data.visit + '/' + res
                  if (isUrl) {
                    let newWindow = window.open()
                    newWindow.location = url + '?inline=true'
                  } else {
                    this.$message('文件错误无法预览')
                  }
                } else {
                  this.$message('文件授权失败')
                }
              }
            } else {
              this.info = data.remark
              this.show = true
              let that = this
              let timer = setTimeout(() => {
                that.previewDocument(that.$props.bizCode, that.$props.bizId)
                clearTimeout(timer)
              }, 3000)
            }
          } else {
            this.$message('文件不存在')
            this.show = false
          }
        }).catch(() => {
          this.show = false
        })
      }
    }
  }
</script>
