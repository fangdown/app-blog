<template>
  <div class="kye-textarea">
    <kye-input type="textarea"
               class="kye-textarea-txt"
               v-bind="$attrs"
               @input="onInput"></kye-input>
    <div class="kye-textarea-tips" :class="{err: count < 0}">
      <div v-show="count >= 0">还可输入 <span class="count">{{count}}</span> 字</div>
      <div v-show="count < 0">已超出 <span class="count">{{-count}}</span> 字</div>
    </div>
  </div>
</template>

<script>
  const defaultSize = 300
  export default {
    name: 'kye-textarea',
    props: {
      maxLength: {
        type: Number,
        default: defaultSize
      },
      value: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        count: defaultSize
      }
    },
    watch: {
      maxLength (val, oldVal) {
        if (val !== oldVal) {
          this.count = this.count + val - oldVal
        }
      },
      value (val, oldVal) {
        if (val !== oldVal) {
          this.onInput(val)
        }
      }
    },
    mounted () {
      this.onInput(this.value)
    },
    methods: {
      onInput (val) {
        this.count = this.maxLength - val.length
        this.$emit('input', val)
      }
    }
  }
</script>
