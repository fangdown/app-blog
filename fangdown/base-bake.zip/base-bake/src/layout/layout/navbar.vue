<template>
  <div class="kye-navbar noselect" :style="{left: `${paddingLeft}px`}">
    <div class="scroll-container" ref="scrollContainer" @wheel.prevent="handleScroll">
      <div class="scroll-wrapper" ref="scrollWrapper" :style="{left: `${left}px`}">
        <a v-for="tag in visitedViews"
           :key="tag.path"
           :class="tagClass(tag.path)"
           :path="tag.path"
           ref="tags"
           @click="pushRoute(tag.path, true)"
           @contextmenu.prevent="openMenu(tag, $event)">
          <span>{{tag.title}}</span>
          <i v-if="tag.tag !== '/'" class="el-icon-close" @click.prevent.stop="closeSelectedTag(tag)"></i>
        </a>
      </div>
    </div>
    <div style="position:relative;">
      <ul class='contextmenu' v-show="visible" :style="{left: menuLeft}">
        <li @click="closeSelectedTag(selectedTag)">关闭</li>
        <li @click="closeOthersTags">关闭其它</li>
        <li @click="closeAllTags">关闭全部</li>
      </ul>
    </div>
  </div>
</template>

<script>
  const PADDING = 0
  export default {
    name: 'navbar',
    props: {
      paddingLeft: Number
    },
    data () {
      return {
        left: 0,
        menuLeft: '0px',
        visible: false,
        selectedTag: {}
      }
    },
    mounted () {
      this.clientWidth = document.documentElement.clientWidth
    },
    computed: {
      visitedViews () {
        return this.$store.state.tagsView.visitedViews
      }
    },
    watch: {
      visible (value) {
        if (value) {
          document.body.addEventListener('click', this.closeMenu)
        } else {
          document.body.removeEventListener('click', this.closeMenu)
        }
      }
    },
    methods: {
      tagClass (path) {
        return path === this.$route.fullPath ? 'tag is-active' : 'tag'
      },
      pushRoute (path, isClick) {
        const ref = this.$router.resolve(path)
        const route = ref.route
        // 从框架布局进入，添加入口标记
        route.meta.layout = true
        // 标记是否用户主动点击，识别当前打开的子菜单
        route.meta.layoutClick = isClick
        this.$store.dispatch('addVisitedViews', route)
        this.$router.push(path)
        this.$bus.$emit('TAB_CLICK', path)
      },
      closeSelectedTagEvent (tag) {
        this.$store.dispatch('delVisitedViews', tag).then(views => {
          if (tag.path === this.$route.fullPath) {
            let path = views.length ? views[views.length - 1].path : '/'
            this.pushRoute(path)
          }
          this.moveToCurrentTag()
        })
      },
      closeSelectedTag (tag) {
        if (tag.closeTag) {
          // 用户需要监听关闭事件
          this.$bus.$emit('GLOBAL_CLOSE_TAG', tag, this.closeSelectedTagEvent)
        } else if (tag.path !== tag.tag && tag.pageType !== 'detail') {
          // 模块的新增、编辑页，提示保存数据
          this.$confirm('您确定要取消保存当前数据？', '提示').then(_ => {
            this.closeSelectedTagEvent(tag)
          }).catch(console.log)
        } else {
          this.closeSelectedTagEvent(tag)
        }
      },
      async closeOthersTags () {
        try {
          await this.$confirm('您确定要关闭其它模块？', '提示')
          this.pushRoute(this.selectedTag.path)
          this.$store.dispatch('delOthersViews', this.selectedTag).then(() => {
            this.moveToCurrentTag()
          })
        } catch (e) {
        }
      },
      async closeAllTags () {
        try {
          await this.$confirm('您确定要关闭全部模块？', '提示')
          this.$store.dispatch('delAllViews')
          this.pushRoute('/')
        } catch (e) {
        }
      },
      openMenu (tag, e) {
        if (tag.tag === '/') {
          return
        }
        this.visible = true
        this.selectedTag = tag
        let x = e.clientX
        if (x > this.clientWidth - 84) {
          x -= 84
        }
        this.menuLeft = `${x - this.paddingLeft - 20}px`
      },
      closeMenu () {
        this.visible = false
      },
      moveToCurrentTag () {
        const tags = this.$refs.tags
        if (!tags) {
          return
        }
        const maxWidth = this.$refs.scrollContainer.offsetWidth
        this.$nextTick(() => {
          let sum = 0
          for (let i = 0, l = tags.length; i < l; i++) {
            let width = tags[i].offsetWidth
            if (tags[i].attributes.path.value === this.$route.path) {
              if (sum < -this.left) {
                this.left = -sum + (i > 0 ? tags[i - 1].offsetWidth / 2 : 0)
              } else if (sum + width > maxWidth) {
                this.left = maxWidth - sum - width - (i + 1 < l ? tags[i + 1].offsetWidth / 2 : 0)
              } else {
                this.left = 0
              }
              break
            }
            sum += width
          }
        })
      },
      handleScroll (e) {
        const eventDelta = e.wheelDelta || -e.deltaY * 3
        const $container = this.$refs.scrollContainer
        const $wrapper = this.$refs.scrollWrapper
        const containerWidth = $container.offsetWidth
        const wrapperWidth = $wrapper.offsetWidth
        if (eventDelta > 0) {
          this.left = Math.min(0, this.left + eventDelta)
        } else {
          if (containerWidth - PADDING < wrapperWidth) {
            if (this.left >= -(wrapperWidth - containerWidth + PADDING)) {
              this.left = Math.max(this.left + eventDelta, containerWidth - wrapperWidth - PADDING)
            }
          } else {
            this.left = 0
          }
        }
      }
    }
  }
</script>

<style lang="scss">
  .kye-navbar {
    position: absolute;
    top: 50px;
    right: 0;
    padding: 0;
    background-color: #e8e6ee;

    .scroll-container {
      position: relative;
      white-space: nowrap;
      overflow: hidden;
      width: 100%;
      height: 28px;
      background-color: #e8e6ee;
      margin-left: -1px;

      .scroll-wrapper {
        position: absolute;
        display: flex;
        height: 100%;
      }

      .tag {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 12px;
        color: #666666;
        padding-left: 12px;
        padding-right: 4px;
        border-left: 1px solid #d5d3db;
        line-height: 28px;
        cursor: pointer;
        &:last-child {
          border-right: 1px solid #d5d3db;
        }
        &:hover {
          background-color: #f1f1f5;
        }
        span {
          padding-right: 8px;
        }
        .el-icon-close {
          height: 12px;
          cursor: pointer;
          &:hover {
            background-color: #b3b5ce;
            color: #ffffff;
            border-radius: 50%;
          }
        }
      }
      .is-active {
        background-color: #ffffff;
      }
    }

    .contextmenu {
      position: absolute;
      top: -10px;
      margin: 0;
      z-index: 100;
      padding: 5px 0;
      color: #333;
      font-size: 12px;
      font-weight: 400;
      background: #fff;
      border-radius: 4px;
      list-style-type: none;
      box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
      li {
        margin: 0;
        padding: 7px 16px;
        cursor: pointer;
        &:hover {
          background: #eee;
        }
      }
    }
  }
</style>
