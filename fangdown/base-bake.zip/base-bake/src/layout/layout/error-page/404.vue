<template functional>
  <div class="page-error">
    <img :src="require('./404.png')" />
    <!-- <p class="code">404</p> -->
    <p class="error">您访问的地址可能有误, 找不到对应页面</p>
  </div>
</template>

<style lang='scss'>
  @import "index.scss";
</style>
