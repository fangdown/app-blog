<template functional>
  <div class="page-error">
    <img :src="require('./403.png')" />
    <!-- <p class="code">403</p> -->
    <p class="error">需要配置权限才能访问该页面</p>
  </div>
</template>

<style lang='scss'>
  @import "index.scss";
</style>
