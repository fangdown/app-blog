<template>
  <div class="page-error">
    <img :src="require('./error.png')" />
    <p class="error">{{ tips }}</p>
    <div style="margin-top: 28px;">
      <el-button v-if="showReload" type="primary" @click="reload">重试</el-button>
      <el-button @click="goLogin">重新登录</el-button>
    </div>
  </div>
</template>

<script>
  const ERROR_TYPES = {
    1: '登录异常',
    2: '系统初始化失败(2)', // 菜单
    3: '系统初始化失败(3)', // 权限
    4: '系统初始化失败(4)', // 字典
    5: '登录已过期，请重新登录'
  }
  export default {
    name: 'error',
    computed: {
      tips () {
        return ERROR_TYPES[this.$route.query.type || '1']
      },
      showReload () {
        return this.$route.query.type === '2' || this.$route.query.type === '3'
      }
    },
    methods: {
      reload () {
        this.$router.replace('/')
      },
      goLogin () {
        this.$store.dispatch('logout')
      }
    }
  }
</script>

<style lang='scss'>
  @import "index.scss";
</style>
