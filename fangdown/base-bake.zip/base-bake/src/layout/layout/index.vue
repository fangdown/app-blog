<template>
  <el-container
    v-loading.fullscreen="loading"
    element-loading-text="加载中"
    style="background-color:#ffffff;">
    <el-header height="50px">
      <header-top></header-top>
    </el-header>
    <el-container :style="{height: asideHeight, maxHeight: asideHeight}">
      <el-aside :width="`${menuWidth}px`" style="background-color:#F1F1F5;">
        <sidebar :width="menuWidth" @switch-menu="switchMenu"></sidebar>
      </el-aside>
      <navbar ref="navbar" :paddingLeft="menuWidth"></navbar>
      <el-main class="main-panel" ref="main">
        <keep-alive :include="cachedViews">
          <router-view></router-view>
        </keep-alive>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
  import { throttle } from 'lodash'
  import HeaderTop from './header.vue'
  import Sidebar from './sidebar.vue'
  import Navbar from './navbar.vue'

  export default {
    name: 'App',
    components: { HeaderTop, Sidebar, Navbar },
    data () {
      return {
        menuWidth: 160,
        asideHeight: '0'
      }
    },
    created () {
      this.addViewTags(this.$route)
    },
    mounted () {
      this.showViewportScaleTips()
      this.asideHeight = (document.documentElement.clientHeight - this.headerHeightDiff) + 'px'
      this.resizeEvent = throttle(this.handleResize, 16)
      window.addEventListener('resize', this.resizeEvent)
      window.addEventListener('keydown', this.keydownEvent)
      this.scrollEvent = throttle(this.handleScroll, 16)
      this.$refs.main.$el.addEventListener('scroll', this.scrollEvent)
    },
    beforeDestroy () {
      window.removeEventListener('keydown', this.keydownEvent)
      window.removeEventListener('resize', this.resizeEvent)
      this.$refs.main.$el.removeEventListener('scroll', this.scrollEvent)
    },
    computed: {
      cachedViews () {
        return this.$store.state.tagsView.cachedViews
      },
      loading () {
        return this.$store.state.loading
      },
      headerHeightDiff () {
        return 51
      }
    },
    watch: {
      $route (val) {
        this.addViewTags(val)
        this.$refs.navbar.moveToCurrentTag()
        this.hideElPopper()
      }
    },
    methods: {
      switchMenu (width) {
        this.menuWidth = width
      },
      handleResize () {
        this.asideHeight = (document.documentElement.clientHeight - this.headerHeightDiff) + 'px'
        this.$bus.$emit('GLOBAL_RESIZE')
      },
      handleScroll (e) {
        this.$bus.$emit('GLOBAL_SCROLL', e.target)
      },
      addViewTags (route) {
        if (route.name) {
          // 设置当前路由渲染的组件的名字和当前路由的名字相同
          // 保证 keep-alive 的 include 能够正确识别是否缓存组件
          let cpt = this.$router.getMatchedComponents()[1]
          cpt && (cpt._Ctor[0].options.name = route.name)
        }
        this.$store.dispatch('addVisitedViews', route)
      },
      hideElPopper () {
        let elArr = document.querySelectorAll('.el-picker-panel:not([style*="display: none"])')
        elArr && elArr.forEach(v => v.style.display = 'none')
        elArr = null
        elArr = document.querySelectorAll('.el-cascader-menus:not([style*="display: none"])')
        elArr && elArr.forEach(v => v.style.display = 'none')
        elArr = null
      },
      keydownEvent (e) {
        let tag = this.$route.meta.tag
        if (e.keyCode === 27 && tag && tag !== this.$route.path) {
          // 按下 ESC 键，返回到模块列表页
          // 混入了 route-hook 的新增、编辑页面，如果当前已弹出确认提示框，则需要屏蔽“ESC键切换路由”
          if (!document.querySelector('.el-message-box__wrapper:not([style*="display: none"])')) {
            this.$router.replace(tag)
          }
        } else if (e.keyCode === 48 && (e.ctrlKey || e.metaKey) && this.scaleNotify) {
          // 按下 Ctrl+0 键，关闭缩提示
          this.scaleNotify.close()
        }
      },
      isViewportScale () {
        return window.getComputedStyle(document.body).fontSize !== '12px' || window.outerWidth !== window.innerWidth
      },
      showViewportScaleTips () {
        if (this.isViewportScale()) {
          const key = navigator.platform.includes('Mac') ? '⌘+0' : 'Ctrl+0'
          this.scaleNotify = this.$notify.warning({
            title: '温馨提示',
            duration: 0,
            dangerouslyUseHTMLString: true,
            message: `您的浏览器目前处于缩放状态，页面可能会出现错位现象，建议100%大小显示。<br/>按下 ${key} 可恢复正常`
          })
        }
      }
    }
  }
</script>
