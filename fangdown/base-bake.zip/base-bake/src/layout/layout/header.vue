<template>
  <div class="kye-header noselect">
    <module-upgrade-log></module-upgrade-log>
    <div class="panel">
      <i class="iconfont icon-logo"
         style="fontSize:28px;width:28px;height:28px;"></i>
      <h2 style="paddingLeft:12px">{{ appTitle }}</h2>
    </div>
    <div class="panel">
      <!--<el-input
        style="width: 200px"
        placeholder="查询"
        prefix-icon="el-icon-search"
        v-model="search">
      </el-input>-->
      <div v-if="isShowVehicle">
        <span>在线：{{ vehicleMap.onLineTotal }} 辆</span>
        <span>离线：<router-link :to="vehicleMap.offJumpUrl || '/'">{{ vehicleMap.offLineTotal }}</router-link> 辆</span>
      </div>
      <div v-if="isShowComment"
           class="flex-tool"
           @click="showComment">
        <i class="iconfont icon-comment"></i>
        <span>使用评价</span>
      </div>
      <el-popover placement="bottom"
                  trigger="hover"
                  :open-delay="400"
                  popper-class="header-tool-popover"
                  width="382">
        <ul class="header-tool-wrap">
          <li v-for="opt in tools"
              :key="opt.title"
              class="item"
              @click="showHelper(opt)">
            <i :class="`iconfont icon-${opt.icon}`"></i>
            <p>{{opt.title}}</p>
          </li>
        </ul>
        <div slot="reference" class="flex-tool">
          <i class="iconfont icon-tools"></i>
          <span>工具</span>
        </div>
      </el-popover>
      <div class="flex-tool" id="GDPluginMessagesTriggerElement">
        <i class="iconfont icon-bill"></i>
        <span>工单</span>
      </div>
      <div class="flex-tool" @click="toggleScreenFull">
        <i :class="screenFullIcon"></i>
        <span>{{screenFullText}}</span>
      </div>
      <el-dropdown trigger="click" @command="handleCommand">
        <div class="info-wrap">
          <div class="user-avatar"><i class="iconfont icon-user"></i></div>
          <div class="info">
            <p>{{user.name}}</p>
            <label>{{user.department || user.duty}}</label>
          </div>
          <i class="el-icon-caret-bottom"></i>
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="logout">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <kye-dialog :title="dialogOptions.title"
                :width="dialogOptions.width"
                :visible.sync="dialogOptions.visible"
                :view.sync="dialogOptions.view"
                :before-close="closeHelper">
      <component :is="dialogOptions.view"
                 @close="closeHelper"
                 :helper="dialogOptions.helper"
                 :url="dialogOptions.url"
                 :upgradeLogList="upgradeLogList">
      </component>
    </kye-dialog>
  </div>
</template>

<script>
  import ScreenFull from 'screenfull'
  import { defineFreezeProperty, getToken } from 'public/utils'
  import { tools } from '@/shared/home-modules/helpers/form'
  import ModuleUpgradeLog from '@/shared/home-modules/module-upgrade-log'

  export default {
    name: 'header-top',
    components: {
      Helper: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/index'),
      Point: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/point'),
      Calendar: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/calendar'),
      Comment: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/comment'),
      CarSwingCard: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/car-swing-card'),
      AddressBook: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/address-book/address-book'),
      GPSLocation: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/GPSLocation'),
      Log: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/log'),
      Sms: () => import(/* webpackChunkName: "healpers" */ '@/shared/home-modules/helpers/sms'),
      ModuleUpgradeLog
    },
    data () {
      return {
        search: '',
        screenFullIcon: 'iconfont icon-screenfull1',
        tools: tools,
        dialogOptions: this.genDialogOptions(),
        upgradeLogList: []
      }
    },
    created () {
      if (ScreenFull.enabled) {
        ScreenFull.onchange(e => {
          this.screenFullIcon = ScreenFull.isFullscreen ? 'iconfont icon-screenfull' : 'iconfont icon-screenfull1'
        })
      }
    },
    watch: {
      '$store.state.menus' (val) {
        if (val.rootMenus && !this.loaded) {
          this.loaded = true
          this.$bus.$emit('APP_LOADED')
          this.requireGDPlugin()
          this.createWebsocket()
          if (this.$route.path === '/' && val['/']) {
            defineFreezeProperty(window, '__ERPMODULE__', JSON.parse(JSON.stringify(val['/'])))
          }
        }
      }
    },
    computed: {
      appTitle () {
        return document.title.replace(/\s[\d|\-|:]+/g, '')
      },
      user () {
        return this.$store.state.user
      },
      screenFullText () {
        return this.screenFullIcon.endsWith('screenfull') ? '退出全屏' : '全屏'
      },
      isShowComment () {
        return !!this.$store.state.menus[this.$route.path || this.$route.meta.tag]
      },
      isShowVehicle () {
        let val = this.$store.state.vms && this.$store.state.vms.vehicleCount
        return !!(val && (val.onLineTotal || val.offLineTotal))
      },
      vehicleMap () {
        let val = this.$store.state.vms && this.$store.state.vms.vehicleCount
        return val || {}
      },
      remindMenus () {
        let arr = this.$store.state.lookUpOptions['auth_menu_remind'] || []
        let obj = arr.reduce((s, v) => {
          s[v.value] = v.label
          return s
        }, {})
        obj._keys = Object.keys(obj)
        return obj
      }
    },
    methods: {
      logout () {
        this.$store.dispatch('logout')
      },
      toggleScreenFull () {
        if (ScreenFull.enabled) {
          ScreenFull.toggle()
        }
      },
      handleCommand (val) {
        if (val === 'logout') {
          this.logout()
        }
      },
      genDialogOptions () {
        return { title: '', visible: false, view: '', width: null, helper: '', url: '' }
      },
      showHelper (opt) {
        this.dialogOptions.title = opt.title
        this.dialogOptions.width = opt.width || 6
        this.dialogOptions.helper = opt.helper
        this.dialogOptions.url = opt.url
        this.dialogOptions.view = opt.view || 'Helper'
        this.dialogOptions.visible = true
      },
      closeHelper () {
        this.dialogOptions = this.genDialogOptions()
      },
      showComment () {
        this.showHelper({
          title: '使用评价',
          width: 3,
          helper: null,
          url: null,
          view: 'Comment',
        })
      },
      requireGDPlugin () {
        let src = '//erp-wos-1257092428.cos.ap-guangzhou.myqcloud.com/erpwosplugin.js'
        let head = document.head
        let dom = head.querySelector('[src="' + src + '"]')
        if (!dom) {
          setTimeout(_ => {
            dom = document.createElement('script')
            dom.type = 'text/javascript'
            dom.async = true
            dom.src = src
            head.appendChild(dom)
          }, 5000)
        }
      },
      createWebsocket () {
        let url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/websocket/${getToken()}`
        const socket = new WebSocket(url)
        socket.onopen = this.pushMenuMsg
        socket.onmessage = e => {
          this.$bus.$emit('GLOBAL_WEBSOCKET', e.data)
          if (window.onGDPluginWebSocketMessage) {
            window.onGDPluginWebSocketMessage(e.data)
          }
        }
      },
      pushMenuMsg () {
        this.$http('tic.daily.remind', {}, false)
        this.$bus.$on('GLOBAL_WEBSOCKET', this.handleMenuMsg)
      },
      handleMenuMsg (e) {
        if (e) {
          try {
            let data = JSON.parse(e)
            if (data && data.serviceCode === 'tic' && data.messageType && this.remindMenus._keys.includes(data.moduleName)) {
              let value = +(JSON.parse(data.messageType)[data.moduleName]) || 0
              this.$store.commit('SET_MENUS_REMIND', [{ key: this.remindMenus[data.moduleName], value }])
            }
          } catch (e) {
          }
        }
      }
    }
  }
</script>

<style lang="scss">
  .kye-header {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #7352bf;
    color: #ffffff;
    padding: 0 20px;

    .el-input {
      .el-input__inner {
        border-radius: 20px;
        background-color: transparent;
        border-color: #aaa;
        color: #ffffff;
      }
    }

    .panel {
      display: flex;
      align-items: center;
    }
    h1 {
      margin: 0;
      font-size: 20px;
      line-height: 50px;
    }
    .flex-tool {
      display: flex;
      align-items: center;
      cursor: pointer;
      margin-left: 40px;
      &:hover {
        color: #ee802c;
        .iconfont {
          color: #ee802c;
        }
      }
      .iconfont {
        font-size: 24px;
        width: 24px;
        height: 24px;
      }
    }
    .theme-picker {
      padding-right: 20px;
    }
    .info-wrap {
      display: flex;
      align-items: center;
      cursor: pointer;
      .user-avatar {
        margin-left: 20px;
        margin-right: 8px;
        height: 28px;
        line-height: 28px;
        text-align: center;
        width: 28px;
        border-radius: 50%;
        background-color: #FFFFFF;
        i {
          font-size: 24px;
          color: #9571E9;
        }
      }
      .el-icon-caret-bottom {
        padding-left: 8px;
        color: #ffffff;
      }
      .info {
        color: #ffffff;
        p {
          font-weight: bold;
          font-size: 14px;
          line-height: 14px;
        }
      }
    }
    .iconfont {
      color: #ffffff;
    }
  }
</style>
