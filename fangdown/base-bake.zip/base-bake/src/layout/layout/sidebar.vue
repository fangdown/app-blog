<template>
  <nav class="kye-sidebar noselect"
       :style="widthStyle">
    <el-autocomplete ref="searchMenu"
                     v-model="searchKey"
                     clearable
                     placeholder="名称或首字母"
                     class="menu-popper"
                     :style="menuPopperStyle"
                     popper-class="kye-popper-auto"
                     value-key="$title"
                     :trigger-on-focus="false"
                     :fetch-suggestions="searchMenu"
                     @select="selectMenu">
      <i slot="prefix"
         class="el-icon-search"
         style="padding-top:8px;padding-left:4px;"></i>
    </el-autocomplete>
    <el-scrollbar>
      <el-menu unique-opened
               :collapse="isCollapse"
               :default-active="$route.meta.tag"
               :default-openeds="defaultOpeneds"
               background-color="#F1F1F5"
               text-color="#000000"
               active-text-color="#ff9300">
        <template v-for="item in rootMenus">
          <el-submenu v-if="item.menus && item.menus.length"
                      :show-timeout="100"
                      :hide-timeout="100"
                      :index="item.title"
                      :key="item.title">
            <template slot="title">
              <i :class="'iconfont icon-'+item.icon"></i>
              <span :title="item.title_cn">{{item.title}}</span>
              <span v-show="remindRootMenu(item.menus)" class="remind"></span>
            </template>
            <template v-for="child in item.menus">
              <el-submenu v-if="child.menuCodes"
                          :show-timeout="100"
                          :hide-timeout="100"
                          :index="child.id"
                          :key="child.id">
                <template slot="title">
                  <span>{{child.title}}</span>
                  <span v-show="remindChildMenu(child)" class="remind"></span>
                </template>
                <el-menu-item v-for="menuCode in child.menuCodes"
                              :key="menuCode"
                              draggable="true"
                              :index="menuCode"
                              :style="menuItemStyle"
                              @dragstart.native="dragMenu(menuCode)"
                              @click="pushRoute(menuCode)">
                  <span>{{menus[menuCode].title}}</span>
                  <span v-show="remindMenu(menuCode)" class="remind"></span>
                </el-menu-item>
              </el-submenu>
              <el-menu-item v-else
                            :key="child.menuCode"
                            draggable="true"
                            :index="child.menuCode"
                            :style="menuItemStyle"
                            @dragstart.native="dragMenu(child.menuCode)"
                            @click="pushRoute(child.menuCode)">
                <span>{{menus[child.menuCode].title}}</span>
                <span v-show="remindMenu(child.menuCode)" class="remind"></span>
              </el-menu-item>
            </template>
          </el-submenu>
          <el-menu-item v-else
                        :key="item.title"
                        :index="item.menuCode || ''"
                        @click="pushRoute(item.menuCode)">
            <i :class="'iconfont icon-'+item.icon"></i>
            <span slot="title">{{item.title}}</span>
            <span v-show="remindMenu(item.menuCode)" class="remind"></span>
          </el-menu-item>
        </template>
      </el-menu>
    </el-scrollbar>
    <div class="btn-collapse"
         :style="widthStyle"
         @click="switchMenu">
      <i :class="collapseClass"></i>
      <span v-if="!isCollapse">收起侧边栏</span>
    </div>
    <!-- 外链菜单 -->
    <a ref="href" hidden target="_blank" rel="nofollow noopener noreferrer"></a>
  </nav>
</template>

<script>
  import { HOME_MENUS } from 'public/config'
  import { getToken } from 'public/utils'

  const MENU_WIDTH = { full: 160, small: 44 }

  export default {
    name: 'sidebar',
    props: {
      width: {
        type: Number,
        default: MENU_WIDTH.full
      }
    },
    data () {
      return {
        isCollapse: false,
        searchKey: ''
      }
    },
    watch: {
      rootMenus (arr) {
        this.$nextTick().then(_ => {
          arr.forEach(v => {
            if (v.menus) {
              let title = v.title
              v.menus.forEach(c => {
                c.$ptitle = title
                if (c.menuCodes) {
                  c.menuCodes.forEach(url => {
                    let menu = this.menus[url]
                    if (menu) {
                      menu.$ptitle = title
                    }
                  })
                }
              })
            }
          })
        })
      }
    },
    computed: {
      menus () {
        return this.$store.getters.menus
      },
      visitedViews () {
        return this.$store.state.tagsView.visitedViews
      },
      collapseClass () {
        return this.isCollapse ? 'iconfont icon-jiantou_xiangyouliangci' : 'iconfont icon-jiantou_xiangzuoliangci'
      },
      menuPopperStyle () {
        return { padding: this.isCollapse ? '8px 6px' : '8px 16px' }
      },
      widthStyle () {
        return { width: `${this.width}px` }
      },
      menuItemStyle () {
        return { color: '#000000' }
      },
      rootMenus () {
        let menus = []
        let indexMenu = this.menus['/'] || {}
        let lookup = this.$store.getters.lookUpOptions['auth_menu_resource_sub_system_title'] || []
        lookup.forEach(v => {
          let arr = v.label.split('/')
          let obj = menus.find(k => k.title === arr[1])
          if (obj) {
            obj.subSystem = `${obj.subSystem},${v.value}`
          } else {
            menus.push({ icon: arr[0], title: arr[1], title_cn: arr[2], menus: [], subSystem: v.value })
          }
        })
        Object.values(this.menus.rootMenus || {}).forEach(v => {
          let obj = menus.find(k => k.subSystem.indexOf(v.subSystem) > -1)
          if (obj && v.id !== indexMenu.id && !HOME_MENUS.includes(v.menuCode)) {
            obj.menus.push(v)
          } else if (v.id === indexMenu.id) {
            let homeLookup = menus.find(v => v.subSystem === 'HOME') || {}
            indexMenu = { ...v, icon: homeLookup.icon || 'wodeshouye' }
          }
        })
        if (indexMenu.id) {
          menus.splice(0, 0, indexMenu)
        }
        menus = menus.filter(v => {
          return (v.menus && v.menus.length > 0) || !!v.id
        })
        return menus
      },
      searchedMenus () {
        return Object.values(this.menus).filter(v => v.$title && !HOME_MENUS.includes(v.menuCode))
      },
      defaultOpeneds () {
        let tag = this.$store.state.tagsView.closedTag || this.$route.meta.tag
        let menu = this.menus[tag]
        if (!menu) {
          return []
        }
        let pid = menu.parentId
        let id = pid || menu.id
        menu = this.rootMenus.find(v => v.menus && v.menus.some(k => k.id === id))
        if (!menu) {
          return []
        }
        if (this.$route.meta.layoutClick) {
          this.$store.commit('SET_CLOSED_TAG')
        }
        return pid ? [menu.title, pid] : [menu.title]
      }
    },
    methods: {
      switchMenu () {
        this.isCollapse = !this.isCollapse
        let w = this.isCollapse ? MENU_WIDTH.small : MENU_WIDTH.full
        this.$emit('switch-menu', w)
        this.$bus.$emit('SWITCH_MENU', w)
        document.documentElement.style.setProperty('--menu-width', w + 'px')
      },
      pushRoute (path) {
        if (!path) {
          return
        }
        if (path.startsWith('http')) {
          this.openLink(path)
          return
        }
        let view = this.visitedViews.find(v => v.tag === path)
        if (view && view.path !== path) {
          path = view.path
        }
        const ref = this.$router.resolve(path)
        const route = ref.route
        // 从框架布局进入，添加入口标记
        route.meta.layout = true
        this.$store.dispatch('addVisitedViews', route)
        this.$router.push(path)
        this.$bus.$emit('TAB_CLICK', path)
      },
      searchMenu (val, cb) {
        const res = []
        if (val) {
          const letter = /^[a-zA-Z]+$/
          const en = letter.test(val)
          this.searchedMenus.forEach(v => {
            if ((en && v.$title_en.includes(val)) || v.$title.includes(val)) {
              res.push(v)
            }
          })
        }
        cb(res)
        // 自动选择第一行
        this.$nextTick(_ => {
          res.length && this.$refs['searchMenu'].highlight && this.$refs['searchMenu'].highlight(0)
        })
      },
      selectMenu (val) {
        this.pushRoute(val.menuCode)
        this.searchKey = ''
      },
      dragMenu (path) {
        this.$store.state.dragMenu = path
      },
      openLink (path) {
        const token = getToken()
        path = `${path}${path.includes('?') ? '&' : '?'}token=${token}`
        const dom = this.$refs.href
        dom.setAttribute('href', path)
        // dom.setAttribute('target', (new URL(path)).hostname)
        dom.dispatchEvent(new MouseEvent('click'))
      },
      remindRootMenu (menus) {
        return menus && menus.some(this.remindChildMenu)
      },
      remindChildMenu ({ menuCode, menuCodes }) {
        if (menuCode !== '/' && this.remindMenu(menuCode)) {
          return true
        }
        return menuCodes && menuCodes.some(v => this.remindMenu(v))
      },
      remindMenu (url) {
        let menu = this.menus[url]
        return menu ? menu.$remind || menu.isUpgraded : false
      }
    }
  }
</script>
