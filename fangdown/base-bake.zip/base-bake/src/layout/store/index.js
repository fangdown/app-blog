import { CASLOGIN } from 'public/config'
import service, { http } from 'public/utils/http'
import { random, getToken, setToken, defineFreezeProperty } from 'public/utils'
import store from 'public/store'

const API = {
  user: 'hr.remoteEmployee.getLoginUser',
  permission: 'auth.permission.getByUserId',
  menu: 'auth.menu.resources.loginUser.list',
  address: 'address.addressBgTerritory.getMultiLevelSubList'
}

const CASAPI = {
  login: `${CASLOGIN}?service=`,
  validate: `${CASLOGIN}/cas_server/partner/v1/service/validate`
}

const ERROR_TYPES = {
  [API.menu]: 2,
  [API.permission]: 3,
  lookup: 4,
  '2': 'menu',
  '3': 'permission'
}

const hot = {
  actions: {
    async caslogin ({ commit, dispatch, state }, params) {
      try {
        let { access_token, business_id } = await service.get(CASAPI.validate, { params })
        setToken(access_token)
        state.user.id = business_id
        location.hash = '#/'
      } catch (e) {
        state.user.id = ''
        location.hash = `#/error?type=1`
      }
    },
    logout () {
      let token = getToken()
      if (token) {
        setToken()
        http('cas.authorize.deleteToken', { access_token: token }, false)
      }
      window.__intercept__ = 0
      location.reload()
    },
    async getGlobalData ({ commit, dispatch }) {
      try {
        commit('SET_LOADING', true)
        const getPermission = http(API.permission)
        const getMenus = http(API.menu)

        let permission = await getPermission
        let menus = await getMenus

        commit('SET_LOOKUP_OPTIONS', window.__ERPLOOKUP__ || [])
        commit('SET_PERMISSION', permission)
        commit('SET_MENUS', menus)
        commit('SET_LOADING', false)

        dispatch('getUser')
        dispatch('getProvinces')

        if (!window.__ERPLOOKUP__) {
          let e = { type: ERROR_TYPES.lookup, key: 'lookup' }
          throw e
        }
      } catch (e) {
        commit('SET_LOADING', false)
        if (e && Object.values(API).includes(e.method)) {
          let type = ERROR_TYPES[e.method]
          e.type = type
          e.key = ERROR_TYPES[type]
        }
        throw e
      }
    },
    async getUser ({ commit }) {
      defineFreezeProperty(window, '__ERPUSER__', {})
      let getUser = http(API.user, {}, false)
      let user = await getUser
      commit('SET_USER', user)
    },
    async getProvinces ({ commit }) {
      let method = API.address
      let params = {
        method,
        jsonrpc: '2.0',
        id: random().toString().substr(4),
        params: { districtLevel: 'province' }
      }
      let { districtList } = await http(method, params, false)
      if (districtList && districtList.length) {
        commit('SET_PROVINCES', districtList.map(v => ({ id: v.districtID, addressName: v.districtName })))
      }
    }
  }
}

store.hotUpdate(hot)
