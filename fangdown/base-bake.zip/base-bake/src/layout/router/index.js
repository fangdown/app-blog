import Vue from 'vue'
import Router from 'vue-router'
import store from 'public/store'
import routes from './routes'
import { getToken, defineFreezeProperty } from 'public/utils'

Vue.use(Router)

const checkAuth = (menus, tag) => {
  return !tag || !!menus[tag]
}

const reduceCloseDialog = (vms, obj) => {
  vms.forEach(v => {
    reduceCloseDialog(v.$children, obj)
    if (v.visible && v.$listeners['update:visible'] && v.$el.className.indexOf('el-dialog__wrapper') > -1) {
      v.$emit('update:view', '')
      v.$emit('update:visible', false)
      obj.flag = true
    }
  })
}

const router = new Router({
  routes,
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
})

const originPush = router.push
const originReplace = router.replace

function errorTips (e) {
  if (e && e.hasOwnProperty('name')) {
    console.warn('此项目禁止使用 name 跳转')
    return true
  }
  return false
}

function newPush (e) {
  if (!errorTips(e)) {
    originPush.apply(router, arguments)
  }
}

function newReplace (e) {
  if (!errorTips(e)) {
    originReplace.apply(router, arguments)
  }
}

if (process.env.NODE_ENV !== 'production') {
  router.push = newPush
  router.replace = newReplace
}

router.beforeEach((to, from, next) => {
  let menu = store.getters.menus[to.meta.tag]
  defineFreezeProperty(window, '__ERPMODULE__', menu ? JSON.parse(JSON.stringify(menu)) : {})

  // 路由离开前如果有未关闭的模态框，则关闭模态框并终止导航
  let $children = from.matched[1] && from.matched[1].instances.default && from.matched[1].instances.default.$children
  if ($children && $children.length) {
    let needClose = { flag: false }
    reduceCloseDialog($children, needClose)
    if (needClose.flag) {
      next(false)
      return
    }
  }

  if (to.path === '/error') {
    next()
    return
  }

  const token = getToken()
  if (token && to.path === '/login') {
    next(false)
    return
  }

  from.meta.layout = false

  if (token) {
    if (store.getters.menus.rootMenus) {
      if (checkAuth(store.getters.menus, to.meta.tag)) {
        next()
      } else {
        next({ path: '/403', replace: true })
      }
    } else {
      // 首页不等待菜单接口加载完成
      if (to.path === '/') {
        next()
      }
      store.dispatch('getGlobalData').then(() => {
        if (checkAuth(store.getters.menus, to.meta.tag)) {
          next({ ...to })
        } else {
          next({ path: '/403', replace: true })
        }
      }).catch(e => {
        let query = { type: e && e.type, key: e && e.key }
        next({ path: '/error', query, replace: true })
      })
    }
  } else {
    if (to.path === '/login') {
      next()
    } else {
      next('/login')
    }
  }
})

export default router
