/**
 * meta: {
    tag: '/oms/order/index' 归属于同一菜单模块的路由的标签，其值未当前菜单模块的主入口路由的路径   必填
    title: '下单管理'         路由组件左上方标题   必填
    page: true              归属于同一菜单模块的路由是否共享分页器的参数，默认 false
  }
 **/

import Error from '../../layout/layout/error-page/error.vue'
import Error403 from '../../layout/layout/error-page/403.vue'
import Error404 from '../../layout/layout/error-page/404.vue'
import Home from '../pages/index'
import Login from '../pages/login'

const createRouteName = (path) => {
  // 'oms/receipt-waybill/edit/:id/test/:name' => 'oms-receipt-waybill-edit-test'
  return path.replace(/\/:\w+/g, '').replace(/\//g, '-')
}

const getModuleRoutes = (context) => {
  const children = []
  context.keys().forEach(key => {
    let route = context(key).default
    if (route && route.layout && route.chunks) {
      children.push(route)
    }
  })
  return children
}

const chunkRouters = []
const moduleRouters = getModuleRoutes(require.context('../../', true, /router\/index\.js$/))
moduleRouters.forEach(module => {
  Object.keys(module.chunks).forEach(v => {
    chunkRouters.push({
      path: `/${v}`,
      name: v,
      meta: { playout: module.name || module.layout.name },
      component: module.layout,
      children: module.chunks[v]
    })
  })
})
const routes = [
  {
    path: '/login',
    name: 'login',
    component: Login,
  },
  {
    path: '/',
    name: 'home',
    component: Home,
    meta: { tag: '/', title: '首页' }
  },
  ...chunkRouters,
  {
    path: '/error',
    name: 'error',
    component: Error
  },
  {
    path: '/403',
    component: Error403
  },
  {
    path: '*',
    component: Error404
  }
]

routes.forEach(v => {
  if (v.children) {
    v.children.forEach(c => {
      c.name = createRouteName(`${v.name}/${c.path}`)
      c.meta.playout = v.meta.playout
    })
  }
})

export default routes
