import Vue from 'vue'
import App from '../layout/layout/index.vue'
import store from '../public/store'
import router from './router'
import ElementUi from 'element-ui'
import KyeUi from '../public/components'
import { ENV } from '../public/config'
import { getToken } from '../public/utils'
import errorHandle from '../public/utils/error-handler'
import './store'
import '../public/utils/open'

Vue.use(ElementUi, { size: 'mini' })
Vue.use(KyeUi)
Vue.use(errorHandle)

Vue.config.productionTip = false

if (ENV) {
  if (ENV !== 'prd') {
    document.title = `${ENV.toUpperCase()}-${document.title}`
  }
  if (ENV !== 'dev') {
    window.addEventListener('unhandledrejection', e => e.preventDefault())
  }
}

if (navigator.platform.includes('Win')) {
  document.body.className += ' ky-erp-win'
}

// 检测 localStorage 是否超出容量
try {
  localStorage.setItem('checklocalstorage', 1)
  localStorage.removeItem('checklocalstorage')
} catch (e) {
  localStorage.clear()
}

window.onbeforeunload = function (e) {
  if (window.__intercept__ === 0) {
    return null
  }
  return false
}

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  components: { App },
  render: (h) => h('App')
})

function getAccessToken ({ data }) {
  if (data && data.ticket && data.type === 'inline') {
    let ticket = data.ticket
    let service = encodeURIComponent(location.origin + '/#/')
    store.dispatch('caslogin', { ticket, service })
  } else if (!getToken()) {
    location.hash = '#/login'
  }
}

window.addEventListener('message', getAccessToken)
