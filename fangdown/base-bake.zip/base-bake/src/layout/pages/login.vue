<template>
  <div class="page-login">
    <iframe :src="loginUrl" style="width:100%;height:100%;"></iframe>
  </div>
</template>

<script>
  import { CASLOGIN } from 'public/config'

  export default {
    name: 'login',
    data () {
      return {
        loginUrl: `${CASLOGIN}?logintype=inline&service=${location.origin}/#/`
      }
    }
  }
</script>

<style lang="scss" scoped>
  .page-login {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    background-color: #ffffff;
  }
</style>
