<template>
  <kye-dialog
    title="常用模块管理"
    width="420px"
    class="kye-dialog-dynamic"
    :visible.sync="show"
    @open="onOpen">
    <div class="kye-dialog-body" v-scroll>
      <el-form inline>
        <el-form-item label=" ">
          <el-autocomplete
            ref="searchMenu"
            v-model="searchKey"
            placeholder="搜索菜单"
            popper-class="kye-popper-auto"
            value-key="$title"
            clearable
            :trigger-on-focus="false"
            :fetch-suggestions="searchMenu"
            @select="selectMenu">
          </el-autocomplete>
        </el-form-item>
      </el-form>
      <el-table
        :data="tableData"
        stripe
        v-tablefixed="'tableMaxHeight'"
        :height="tableMaxHeight">
        <!--<el-table-column label="系统名" width="200">
          <template slot-scope="scope">
            <span v-if="scope.row.url">{{ getSys(scope.row.url) }}</span>
            <el-select v-else filterable v-model="model.sys" @change="sysChange">
              <el-option
                v-for="opt in sysList"
                :key="opt.title"
                :label="opt.title"
                :value="opt.sys">
              </el-option>
            </el-select>
          </template>
        </el-table-column>-->
        <el-table-column label="模块" width="150">
          <template slot-scope="scope">
            <span v-if="scope.row.url" style="padding-left:8px;">{{ getMenu(scope.row.url) }}</span>
            <el-select v-else filterable v-model="model.menu" @change="menuChange">
              <el-option
                v-for="opt in menuList"
                :key="opt.id"
                :label="opt.title"
                :value="opt.id">
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="子模块" width="150">
          <template slot-scope="scope">
            <span v-if="scope.row.url" style="padding-left:8px;">{{ scope.row.title }}</span>
            <el-select v-else filterable v-model="model.children">
              <el-option
                v-for="(opt, i) in childrenList"
                :key="opt+i"
                :label="menus[opt].title"
                :value="opt">
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              v-if="scope.row.url"
              type="text"
              icon="iconfont icon-delete"
              @click="onDelete(scope.$index)">
            </el-button>
            <el-button
              v-else
              type="text"
              icon="iconfont icon-plus"
              :disabled="addDisabled"
              @click="onAdd(model)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="el-dialog__footer">
      <el-button type="primary" hotkey="ctrl+s" :disabled="!isSave" @click="onSave">保存(S)</el-button>
      <el-button @click="show = false">取消</el-button>
    </div>
  </kye-dialog>
</template>

<script>
  import mixins from 'public/mixins'

  export default {
    name: 'link-dialog',
    mixins: [mixins],
    props: {
      list: Array
    },
    data () {
      return {
        show: false,
        isSave: false,
        searchKey: '',
        tableMaxHeight: null,
        model: { sys: '', menu: '', children: '' },
        tableData: []
      }
    },
    computed: {
      menus () {
        return this.$store.getters.menus
      },
      sysList () {
        let sys = []
        let indexMenu = this.menus['/'] || {}
        let lookup = this.$store.getters.lookUpOptions['auth_menu_resource_sub_system_title'] || []
        lookup.forEach(v => {
          let arr = v.label.split('/')
          let obj = sys.find(k => k.title === arr[1])
          if (obj) {
            obj.sys = `${obj.sys},${v.value}`
          } else {
            sys.push({ icon: arr[0], title: arr[1], menus: [], sys: v.value })
          }
        })
        Object.values(this.menus.rootMenus || {}).forEach(v => {
          let obj = sys.find(k => k.sys.indexOf(v.subSystem) > -1)
          if (obj && v.id !== indexMenu.id) {
            obj.menus.push(v)
          } else if (v.id === indexMenu.id) {
            indexMenu = v
          }
        })
        return sys
      },
      menuList () {
        return this.sysList.reduce((s, v) => {
          s.push(...v.menus)
          return s
        }, [])
      },
      childrenList () {
        return this.model.menu ? this.menus.rootMenus[this.model.menu].menuCodes : []
      },
      addDisabled () {
        return !this.model.children
      }
    },
    methods: {
      getSys (url) {
        if (this.menus[url]) {
          let sys = this.sysList.find(v => v.sys.indexOf(this.menus[url].subSystem) > -1)
          return sys ? sys.title : ''
        }
        return ''
      },
      getMenu (url) {
        if (this.menus[url]) {
          return this.menus[url].$title.split(' > ')[0] || ''
        }
        return ''
      },
      sysChange (val) {
        this.model.menu = ''
        this.model.children = ''
      },
      menuChange (val) {
        this.model.children = ''
      },
      searchMenu (val, cb) {
        const res = []
        if (val) {
          Object.keys(this.menus).forEach(v => {
            let title = this.menus[v].$title
            if (title && title.indexOf(val) > -1) {
              res.push(this.menus[v])
            }
          })
        }
        cb(res)
        // 自动选择第一行
        this.$nextTick(_ => {
          res.length && this.$refs['searchMenu'].highlight && this.$refs['searchMenu'].highlight(0)
        })
      },
      selectMenu (val) {
        if (this.onAdd({ sys: val.subSystem, children: val.menuCode })) {
          this.searchKey = ''
        }
      },
      onAdd (model) {
        if (this.tableData.some(v => v.url === model.children)) {
          this.$message.warning('此模块已存在')
          return false
        }
        this.isSave = true
        let icon = model.sys ? this.sysList.find(v => v.sys.indexOf(model.sys) > -1).icon : ''
        let obj = { icon, title: this.menus[model.children].title, url: model.children }
        this.tableData.splice(1, 0, obj)
        model.children = ''
        return true
      },
      onDelete (index) {
        this.isSave = true
        this.tableData.splice(index, 1)
      },
      onSave () {
        Object.assign(this.model, { sys: '', menu: '', children: '' })
        if (this.isSave) {
          this.isSave = false
          let arr = this.tableData.filter((v, i) => {
            v.displaySequence = i
            return i > 0
          })
          this.$http('system.homeIndex.save', { moduleType: '10', itemList: arr })
          this.$emit('close', arr)
          this.show = false
        }
      },
      onOpen () {
        this.tableData = [this.model].concat(this.list)
      }
    }
  }
</script>
