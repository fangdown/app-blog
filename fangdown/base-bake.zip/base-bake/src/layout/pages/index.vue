<template>
  <div class="page-home">
    <kye-row :gutter="8">
      <kye-col :span="14">
        <el-card :body-style="{height: '655px'}"
                 class="link-card">
          <div slot="header">
            <span class="title">常用模块</span>
            <el-button class="fr"
                       icon="iconfont icon-pen"
                       type="text"
                       @click="showLinkDialog">自定义
            </el-button>
          </div>
          <el-scrollbar
            @dragover.native="e => e.preventDefault()"
            @drop.native="handleDragMenu">
            <ul class='contextmenu' v-show="linkMenu.show" :style="{top: linkMenu.top, left: linkMenu.left}">
              <li @click="removeLink">删除</li>
            </ul>
            <ul class="link-wrap noselect">
              <router-link v-for="(opt, i) in mergedLinks"
                           :key="opt.url+i"
                           :to="opt.url"
                           @contextmenu.native.prevent="openLinkMenu($event, i)">
                <li>
                  <i :class="`iconfont icon-${getLinkIcon(opt.url, opt.icon)}`"></i>
                  <p>{{opt.title}}</p>
                </li>
              </router-link>
            </ul>
          </el-scrollbar>
        </el-card>
      </kye-col>
      <kye-col :span="10">
        <kye-row style="height:354px;">
          <notice></notice>
        </kye-row>
        <kye-row style="height:350px;">
          <work-flow></work-flow>
        </kye-row>
      </kye-col>
    </kye-row>
    <link-dialog ref="linkDialog"
                 :list="links"
                 @close="e => links = e">
    </link-dialog>
  </div>
</template>

<script>
  import mixins from 'public/mixins'
  import { HOME_MENUS } from 'public/config'
  import LinkDialog from './link-dialog'
  import Notice from '@/shared/home-modules/notice'
  import WorkFlow from '@/shared/home-modules/work-flow'

  export default {
    name: 'home',
    mixins: [mixins],
    components: { LinkDialog, Notice, WorkFlow },
    data () {
      return {
        links: [],
        linkMenu: { index: -1, show: false, top: 0, left: 0 }
      }
    },
    mounted () {
      this.$bus.$once('APP_LOADED', this.getLinks)
      this.$store.dispatch('addVisitedViews', this.$route)
    },
    watch: {
      'linkMenu.show' (val) {
        if (val) {
          document.body.addEventListener('click', this.closeLinkMenu)
        } else {
          document.body.removeEventListener('click', this.closeLinkMenu)
        }
      }
    },
    computed: {
      menus () {
        return this.$store.getters.menus
      },
      systemIcons () {
        let arr = this.lookUpOptions['auth_menu_resource_sub_system_title'] || []
        return arr.reduce((s, v) => {
          s[v.value] = v.label.split('/')[0]
          return s
        }, {})
      },
      mergedLinks () {
        let arr = []
        HOME_MENUS.forEach(v => {
          let menu = this.menus[v]
          if (menu) {
            arr.push({ url: menu.menuCode, title: menu.title })
          }
        })
        return arr.concat(this.links)
      }
    },
    methods: {
      showLinkDialog () {
        this.$refs.linkDialog.show = true
      },
      async getLinks () {
        this.links = await this.$http('system.homeIndex.list', { moduleType: '10' }, false)
      },
      getLinkIcon (url, icon) {
        let menu = this.menus[url]
        if (!menu) {
          return icon
        }
        return this.systemIcons[menu.subSystem] || icon
      },
      saveLink () {
        this.$http('system.homeIndex.save', { moduleType: '10', itemList: this.links }, false)
      },
      openLinkMenu (e, index) {
        if (HOME_MENUS.includes(this.mergedLinks[index].url)) {
          this.linkMenu.show = false
        } else {
          this.linkMenu.index = index + this.links.length - this.mergedLinks.length
          this.linkMenu.top = e.y + 'px'
          this.linkMenu.left = e.x + 'px'
          this.linkMenu.show = true
        }
      },
      closeLinkMenu () {
        this.linkMenu.show = false
      },
      removeLink () {
        this.links.splice(this.linkMenu.index, 1)
        this.saveLink()
        this.linkMenu.show = false
        this.linkMenu.index = -1
      },
      handleDragMenu () {
        let path = this.$store.state.dragMenu
        if (path) {
          let menu = this.menus[path]
          if (this.links.some(v => v.url === path)) {
            this.$message.warning('此模块已存在')
            return
          }
          this.links.push({
            url: path,
            title: menu.title,
            displaySequence: this.links.length + 1
          })
          this.saveLink()
        }
      }
    }
  }
</script>

<style lang="scss">
  .page-home {
    padding-top: 16px;
    .el-card.is-always-shadow {
      box-shadow: none;
    }
    .el-card__body {
      padding: 8px 0;
    }
    .link-card {
      .title {
        font-size: 16px;
        font-weight: bolder;
      }
      .el-scrollbar {
        height: 100%;
      }
      .el-scrollbar__wrap {
        height: 100%;
        overflow: auto;
      }
      .el-scrollbar__bar.is-horizontal {
        display: none;
      }
      .contextmenu {
        position: fixed;
        margin: 0;
        z-index: 100;
        padding: 5px 0;
        color: #333;
        font-size: 12px;
        font-weight: 400;
        background: #fff;
        border-radius: 4px;
        list-style-type: none;
        box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
        li {
          margin: 0;
          padding: 7px 16px;
          cursor: pointer;
          &:hover {
            background: #eee;
          }
        }
      }
    }
    .link-wrap {
      display: flex;
      flex-wrap: wrap;
      margin-bottom: -8px;
      margin-left: 8px;
      margin-right: 8px;
      li {
        width: 98px;
        margin: 8px;
        padding: 14px 0;
        text-align: center;
        background-color: #f5f5f7;
        border-radius: 4px;
        cursor: pointer;
        &:hover {
          background-color: #aa90e8;
          i,
          p {
            color: #ffffff;
          }
        }
        i {
          font-size: 26px;
          color: #7352bf;
        }
        p {
          margin-top: 7px;
        }
      }
    }

    .tool-card {
      margin-top: 8px;
      .el-scrollbar {
        width: 100%;
      }
      .el-scrollbar__wrap {
        width: 100%;
        overflow: auto;
      }
      .el-scrollbar__bar.is-vertical {
        display: none;
      }
    }
    .tool-wrap {
      display: flex;
      margin-bottom: 10px;
      li {
        display: inline-block;
        min-width: 80px;
        padding: 13px 0;
        text-align: center;
        // cursor: not-allowed;
        &:hover {
          background-color: #f5f5f7;
          border-radius: 4px;
        }
        i {
          font-size: 16px;
          color: #7352bf;
        }
        p {
          margin-top: 8px;
        }
      }
      .item + .item {
        margin-left: 8px;
      }
    }
  }
</style>
